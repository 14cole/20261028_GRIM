"""S-5 counterexample: accepted unprobed points exceed NEAR_ANGULAR_RTOL.

Set GHOST_SOURCE to tools/GHOST of a checkout with built native libraries.
Only calls the public kernel helper; no numerical functions are replaced.
"""
import os,sys,json
from pathlib import Path
import numpy as np
from scipy.integrate import quad_vec
root=Path(__file__).resolve().parent
sys.path.insert(0,os.environ.get('GHOST_SOURCE',str(root/'repo/tools/GHOST')))
from ghost_backend.bor import kernels as K,streaming

bad=(1.1390625,0.,1.1390625,0.11898510425967053)
good=(1.0140625,0.,1.0140625,0.1017733529476957)
coordinates=[np.full(32,x) for x in bad]
for a,x in zip(coordinates,good):a[::4]=x
k,m=80.,92
rp,zp,rq,zq=bad
def integrand(phi):
    r=np.sqrt((rp-rq)**2+(zp-zq)**2+4*rp*rq*np.sin(phi/2)**2)
    return np.exp(-1j*k*r)/(4*np.pi*r)*np.cos(np.arange(m+2)*phi)
reference=2*quad_vec(integrand,0,np.pi,epsabs=1e-12,epsrel=1e-12)[0]
native=streaming._NATIVE
results={'source':K.__file__,'tolerance':K.NEAR_ANGULAR_RTOL,'k':k,'m_max':m,'good_point':good,'bad_point':bad}
for backend in ['native','fallback']:
    streaming._NATIVE=native if backend=='native' else None
    for mode in ['coarse','fine']:
        os.environ['GHOST_BOR_NEAR_PUBLISH']=mode
        os.environ['GHOST_BOR_NEAR_CHECK_STRIDE']='4'
        result=K.modal_kernels_near(*coordinates,k,m)
        results[backend+'_'+mode+'_reference_error']=float(np.max(abs(result[1]-reference))/np.max(abs(reference)))
print(json.dumps(results,indent=2))
