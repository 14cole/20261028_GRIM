"""Independent quadrature and estimator checks; no production-source edits."""
import os,sys,json,math,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/tools/GHOST'))
sys.path.insert(0,str(ROOT/'repo/audits/claude-2026-11-10/calibration'))
import numpy as np
from ghost_backend.twod import operators as O
from w_far_rule import element
if hasattr(os,'sched_setaffinity'):os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])

def w_grid():
    rng=np.random.default_rng(20261110)
    rows=[]
    worst=[]
    for kl in [1e-8,1e-4,.15,.5,1.,1.5,3.]:
      for separation in [3.,4.999,5.,9.999,10.,30.]:
        maximum=0.; record=None
        for trial in range(36):
          ratio=[1.,.1,.001,1e-6][trial%4]
          arg=[0.,-20.,-70.,-89.9][(trial//4)%4]
          aa,bb=(0.,0.) if trial<4 else rng.uniform(0,2*np.pi,2)
          av=.5*np.array([np.cos(aa),np.sin(aa)])
          bv=.5*ratio*np.array([np.cos(bb),np.sin(bb)])
          p=element(-av,av,0,(0,1));q=element(np.array([separation,0])-bv,np.array([separation,0])+bv,1,(2,3))
          k=kl*np.exp(1j*np.deg2rad(arg))
          floor=O._graded_w_far_floor(k,np.array([p.length,q.length]),3.,1)
          order=O._graded_w_far_order(floor,kl,separation,1)
          def block(n):
            s=O._integrate_linear_pair_box_sk_vectorized(p,q,k,True,(0,1),(0,1),n,n)[0]
            return O._hypersingular_block_from_s_block(s,k,p.normal,q.normal,p.length,q.length)
          a,b=block(order),block(64)
          err=float(np.max(abs(a-b))/np.max(abs(b)))
          if err>maximum:maximum=err;record=dict(ratio=ratio,arg=arg,angles=[aa,bb],order=order)
        rows.append(dict(kl=kl,separation=separation,error=maximum,worst_fixture=record))
    return {'pairs':len(rows)*36,'worst_relative_error':max(r['error'] for r in rows),'rows':rows}

def near_kernels():
    from ghost_backend.bor import kernels as K,streaming as T
    native=T._NATIVE
    rows=[]
    for wave in [3.,30.,100.,300.,30-30j]:
      for gap in [.1,1e-3,1e-7]:
        n=32;r=np.linspace(.99,1.01,n);z=np.zeros(n);rq=r.copy();zq=np.full(n,gap)
        m=min(200,int(abs(wave))+12)
        a=np.linspace(0,np.pi,n);b=a+.23
        args_g=(r,z,rq,zq,wave,m)
        args_b=(r,z,np.cos(a),np.sin(a),rq,zq,np.cos(b),np.sin(b),wave,m)
        for kind,fn,args in [('g',K.modal_kernels_near,args_g),('mfie',K.mfie_kernels_near,args_b),('ibc',K.ibc_kernels_near,args_b)]:
          values={}
          for mode in ['coarse','fine','complete','fallback']:
            os.environ['GHOST_BOR_NEAR_PUBLISH']='fine' if mode=='fine' else 'coarse'
            os.environ['GHOST_BOR_NEAR_CHECK_STRIDE']='0' if mode=='complete' else '4'
            T._NATIVE=None if mode=='fallback' else native
            try:
              v=fn(*args)
              values[mode]=np.concatenate([x.ravel() for x in v]) if isinstance(v,tuple) else v.ravel()
            except Exception as e:values[mode]=repr(e)
          ref=values['complete'];row=dict(wave=str(wave),gap=gap,kind=kind,m=m)
          for mode,v in values.items():
            row[mode]=v if isinstance(v,str) else float(np.max(abs(v-ref))/max(np.max(abs(ref)),1e-280)) if not isinstance(ref,str) else 'reference failed'
          rows.append(row)
    T._NATIVE=native
    os.environ.pop('GHOST_BOR_NEAR_PUBLISH',None);os.environ.pop('GHOST_BOR_NEAR_CHECK_STRIDE',None)
    return rows

def estimator():
    from ghost_backend.linalg.onenorm import onenormest,SEED
    from scipy.sparse.linalg import aslinearoperator,onenormest as scipy_est
    rng=np.random.default_rng(347)
    rows=[]
    for n in [1,2,3,4,5,8,9,17,50,91]:
      for t in [1,2,3]:
        for kind in ['real','complex','sparse','zero','diagonal','inverse']:
          a=rng.standard_normal((n,n))
          if kind in ['complex','inverse']:a=a+1j*rng.standard_normal((n,n))
          if kind=='sparse':a*=rng.uniform(size=(n,n))<.1
          if kind=='zero':a*=0
          if kind=='diagonal':a=np.diag(np.geomspace(1e-9,1e9,n))
          if kind=='inverse':a=np.linalg.inv(a)
          np.random.seed(123);before=np.random.get_state()
          value=onenormest(aslinearoperator(a),t=t)
          after=np.random.get_state()
          exact=float(np.linalg.norm(a,1))
          np.random.seed(SEED);reference=float(scipy_est(aslinearoperator(a),t=t))
          rows.append(dict(n=n,t=t,kind=kind,estimate=value,exact=exact,seeded_scipy=reference,
            rng_unchanged=all(np.array_equal(x,y) for x,y in zip(before,after))))
    return dict(cases=len(rows),all_finite=all(np.isfinite(x['estimate']) for x in rows),
      all_lower_bound=all(x['estimate']<=x['exact']*(1+1e-14) for x in rows),
      all_rng_unchanged=all(x['rng_unchanged'] for x in rows),
      scipy_differences=[x for x in rows if x['estimate']!=x['seeded_scipy']],rows=rows)

if __name__=='__main__':
    name=sys.argv[1];start=time.perf_counter()
    try:r=globals()[name]()
    except Exception as e:r={'error':repr(e),'traceback':traceback.format_exc()}
    (ROOT/'results'/(name+'.json')).write_text(json.dumps(r,indent=2,default=str))
    print(name,'seconds',time.perf_counter()-start, 'summary',str(r)[:600],flush=True)
