"""Inspect EVERY point in actual accepted coarse chunks, beyond Claude's ka<=30 grid."""
import os,sys,json,time,traceback
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/tools/GHOST'))
from ghost_backend.bor import kernels as K
os.environ['GHOST_BOR_NEAR_PUBLISH']='coarse'
os.environ['GHOST_BOR_NEAR_CHECK_STRIDE']='4'
original=K._refine_near_chunk
stats={'chunks':0,'points':0,'worst_raw':0.,'worst_published':0.,'violations':[]}
candidate=None
context={}
def inspect(kind,arrays,ids,stable,base_orders,evaluate,next_orders,out,offset=0):
    global candidate
    original(kind,arrays,ids,stable,base_orders,evaluate,next_orders,out,offset)
    if kind!='g':return
    coarse=evaluate(ids,base_orders,stable)
    fine=evaluate(ids,next_orders(np.asarray(base_orders)),stable)
    err,scale=K._near_check(kind,fine,coarse)
    rel=err/np.maximum(scale,1e-280)
    f=2*(fine[:,0,offset:]+1j*fine[:,1,offset:])
    published=np.max(abs(out[ids]-f),axis=1)/np.maximum(scale,1e-280)
    stats['chunks']+=1;stats['points']+=len(ids)
    stats['worst_raw']=max(stats['worst_raw'],float(max(rel)))
    stats['worst_published']=max(stats['worst_published'],float(max(published)))
    if max(rel)>K.NEAR_ANGULAR_RTOL and min(rel)<K.NEAR_ANGULAR_RTOL/10:
        if candidate is None or max(rel)>candidate['raw_error']:
            hi,lo=int(np.argmax(rel)),int(np.argmin(rel))
            candidate=dict(context,raw_error=float(rel[hi]),probe_error=float(rel[lo]),
                bad=[float(v[ids[hi]]) for v in arrays],good=[float(v[ids[lo]]) for v in arrays],orders=np.asarray(base_orders).tolist())
    bad=np.flatnonzero(published>K.NEAR_ANGULAR_RTOL*1.001)
    if len(bad):
        stats['violations'].append(dict(context,ids=ids.tolist(),orders=np.asarray(base_orders).tolist(),
          bad_indices=bad.tolist(),raw_relative=rel.tolist(),published_relative=published.tolist(),
          coordinates=[np.asarray(a).tolist() for a in arrays]))
K._refine_near_chunk=inspect
start=time.perf_counter()
for k in [60.,80.,100.,120.,160.,200.,300.]:
  for gap in [1e-4,3e-4,1e-3,3e-3,1e-2,.1]:
    n=257;r=np.linspace(.8,1.2,n);z=np.zeros(n);rq=r.copy();zq=gap*np.exp(np.linspace(-.25,.25,n))
    context.update(k=k,gap=gap,m=min(220,int(k)+12))
    try:K.modal_kernels_near(r,z,rq,zq,k,context['m'])
    except Exception as e:stats.setdefault('exceptions',[]).append(dict(context,error=repr(e)))
K._refine_near_chunk=original
if candidate:
    from scipy.integrate import quad_vec
    from ghost_backend.bor import streaming
    arrays=[np.full(32,v) for v in candidate['bad']]
    for a,v in zip(arrays,candidate['good']):a[::4]=v
    k=candidate['k'];m=candidate['m']
    coarse=K.modal_kernels_near(*arrays,k,m)
    os.environ['GHOST_BOR_NEAR_CHECK_STRIDE']='0'
    full=K.modal_kernels_near(*arrays,k,m)
    rp,zp,rq,zq=candidate['bad']
    def integrand(phi):
        distance=np.sqrt((rp-rq)**2+(zp-zq)**2+4*rp*rq*np.sin(phi/2)**2)
        return np.exp(-1j*k*distance)/(4*np.pi*distance)*np.cos(np.arange(m+2)*phi)
    ref=2*quad_vec(integrand,0,np.pi,epsabs=1e-12,epsrel=1e-12,points=[.001,.01,.1])[0]
    candidate.update(coarse_reference_error=float(np.max(abs(coarse[1]-ref))/np.max(abs(ref))),
        full_reference_error=float(np.max(abs(full[1]-ref))/np.max(abs(ref))),
        coarse_full_error=float(np.max(abs(coarse[1]-full[1]))/np.max(abs(full[1]))))
    os.environ['GHOST_BOR_NEAR_CHECK_STRIDE']='4'
    streaming._NATIVE=None
    fallback=K.modal_kernels_near(*arrays,k,m)
    candidate['fallback_reference_error']=float(np.max(abs(fallback[1]-ref))/np.max(abs(ref)))
stats['constructed_same_layout_case']=candidate
stats['seconds']=time.perf_counter()-start
(ROOT/'results/near_probe_search.json').write_text(json.dumps(stats,indent=2))
print(json.dumps({k:v for k,v in stats.items() if k!='violations'}), 'violations',len(stats['violations']),flush=True)
