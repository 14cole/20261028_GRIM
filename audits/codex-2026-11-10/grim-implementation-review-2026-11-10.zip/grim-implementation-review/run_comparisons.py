"""Sequential fresh-process comparisons; keep original measurements separate."""
import os,sys,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',AUDIT_ROOT=str(ROOT))
runner=str(ROOT/'helpers/run_case.py')
cases=[]
for rep in range(3):
    for revision in ['base','latest']:
        cases.append((f'ibc_{revision}_{rep}',revision,{'kind':'ibc','n':1600,'ka':80,'angle_count':61},{}))
    for mode in ['fine','coarse']:
        cases.append((f'bor_{mode}_{rep}','latest',{'bor':True,'n':120,'ka':10,'angle_count':19},{'GHOST_BOR_NEAR_PUBLISH':mode}))
for bor in [False,True]:
    for fb in [False,True]:
        cases.append((f'fallback_{bor}_{fb}','latest',{'bor':bor,'n':60 if bor else 360,'ka':3,'fallback':fb,'angle_count':9},{}))
for name,revision,config,extra in cases:
    p=ROOT/'results'/(name+'.json')
    source=str(ROOT/'base_source') if revision=='base' else str(ROOT/'repo/tools/GHOST')
    if p.exists():continue
    print(name,flush=True)
    subprocess.run([sys.executable,runner,json.dumps(config),str(p)],env=dict(env,GHOST_SOURCE=source,**extra),timeout=240,check=True)
subprocess.run([sys.executable,str(ROOT/'memory_case.py'),'dielectric','3072','1.35'],env=env,timeout=300,check=True)
