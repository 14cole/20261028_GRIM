Independent implementation review — 2026-11-10

Start with IMPLEMENTATION_REVIEW.txt and coverage.csv. There are four requested
changes. results/ contains the captured evidence. No solver fixes were applied.

repo/tools/GHOST contains the reviewed numerical source at commit
1a6addedc89c8e6f9cd52b7e5aaa098a8962dcdb. SOURCE_TREE.json records its Git blob
hashes. repo/audits/claude-2026-11-10 contains Claude's audit and supplied tests.
base_source is the numerical snapshot retained from the previous main audit
(f207c61529c706b9f98990ffa23c0b878f3590e0), with normalized line endings on some
files. The implementation snapshot was restored to exact upstream file bytes.

Prerequisites: Python, NumPy, SciPy, psutil, threadpoolctl, and a C compiler.
Measurements used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 on Linux.
The thread and SIGKILL reproductions were tested on Linux.
Native binaries are omitted; build them for your machine:

  python repo/tools/GHOST/ghost_backend/twod/assembly/native/build.py
  python repo/tools/GHOST/ghost_backend/bor/native/build_kernel.py

Set thread limits before importing NumPy:

  export OPENBLAS_NUM_THREADS=1
  export OMP_NUM_THREADS=1

Run the four finding reproductions from the extracted bundle directory:

  python edge_checks.py lock_inversion
  python edge_checks.py submit_death
  python repro_coarse_near.py
  python edge_checks.py calibration_orders

lock_inversion uses a barrier to expose a real acquisition ordering, captures
the blocked stacks, then aborts the waiting solve so both test threads exit.
submit_death kills only a child worker belonging to its own test executor.
repro_coarse_near performs independent explicit Green-function integration.
It makes no numerical monkeypatches; the environment switch selects the
production coarse/fine path and native/fallback controls.
Finding reproductions print evidence; success of the Python process does not
mean the numerical implementation passed. Consult the reported values.

Other verification:

  python repo/audits/claude-2026-11-10/regression/run_all.py
  python numerical_checks.py w_grid
  python numerical_checks.py near_kernels
  python numerical_checks.py estimator
  python near_probe_search.py
  python original_cone.py

To repeat the before/after benchmark, also build both native families under
base_source/ using the same build.py and build_kernel.py paths, then run:

  python run_comparisons.py

The comparison script skips existing case JSONs. Use a separate bundle copy
with those result files moved aside for fresh timings. It also runs the
6,144-DOF dielectric reservation check. The PEC reservation check is:

  python memory_case.py pec 6144 1.35

run_comparisons.py and memory_case.py were adapted only to use bundle-relative
paths after execution; original_harness/ retains the original versions.
helpers/ contains the previous audit's case generator and runner. Original
logs and stacks retain their execution-machine absolute paths.

Do not run performance comparisons concurrently. Near-kernel reference and
memory tests may run independently, but reported speed comparisons used
sequential fresh processes. Memory peaks are parent ru_maxrss (GiB); no claim
is made that they bound unsampled transient allocations or Windows commit.

bundle_sha256.json hashes included files. Inspect the report's scope and
limitations before treating a passing sample as universal qualification.
