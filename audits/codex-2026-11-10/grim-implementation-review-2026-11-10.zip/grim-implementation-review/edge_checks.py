"""Independent edge-case checks against the pinned implementation snapshot."""
import os, sys, json, time, signal, threading, traceback
from pathlib import Path
ROOT = Path(__file__).resolve().parent
SOURCE = Path(os.environ.get('GHOST_SOURCE', ROOT/'repo/tools/GHOST'))
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(ROOT/'repo/audits/claude-2026-11-10/regression'))
if hasattr(os, 'sched_setaffinity'):
    os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:4])
from common import scene, circle
from ghost_backend.twod import solver as S
from ghost_backend.execution import memory_budget as M, options as O

def geometry():
    return scene([('body', 2, '2 1 0 0 0', circle(.1, 68))])

def solve(**kw):
    return S.solve_monostatic_rcs_2d(geometry(), [1.], [0.,90.],
        geometry_units='meters', solver_method='direct', **kw)

def lock_inversion():
    # Pause request A just after it reserves memory. Request B enters the
    # supported execution_scope, taking the BLAS lock before its public solve.
    reserved, blas_held, release = threading.Event(), threading.Event(), threading.Event()
    abort = threading.Event()
    original = M.MemoryBudget.stable
    results = {'source':S.__file__}
    paused = [False]
    def gated(self):
        result = original(self)
        if threading.current_thread().name == 'audit-request-A' and not paused[0]:
            paused[0] = True
            results['reservation_at_pause'] = {'ceiling':self.ceiling,'capacity':self.cohort['capacity'],'active_state_matches':M.current() is self,'requests':len(M._REQUESTS)}
            reserved.set()
            if not blas_held.wait(5): raise RuntimeError('B did not acquire BLAS lock')
        return result
    M.MemoryBudget.stable = gated
    def a():
        try:
            with O.execution_scope({}, limit_blas=False):
                results['A'] = {'samples':len(solve()['samples'])}
        except BaseException as e: results['A'] = repr(e)
    def b():
        try:
            if not reserved.wait(5): raise RuntimeError('A did not reserve memory')
            with O.execution_scope({}, limit_blas=True):
                results['B_before_solve'] = {'requests':len(M._REQUESTS),'exhausted':getattr(M,'_reservation_exhausted',lambda:None)(),'state':str(M.current())}
                blas_held.set()
                results['B'] = {'samples':len(solve(abort_event=abort)['samples'])}
        except BaseException as e: results['B'] = repr(e)
    ta=threading.Thread(target=a,name='audit-request-A',daemon=True)
    tb=threading.Thread(target=b,name='audit-request-B',daemon=True)
    ta.start();tb.start()
    assert blas_held.wait(8)
    ta.join(1);tb.join(.2)
    frames = sys._current_frames()
    results['both_blocked'] = ta.is_alive() and tb.is_alive()
    results['stacks_before_abort'] = {t.name:traceback.format_stack(frames[t.ident]) for t in [ta,tb] if t.is_alive()}
    abort.set()
    ta.join(10);tb.join(10)
    results['alive_after_abort'] = [t.name for t in [ta,tb] if t.is_alive()]
    M.MemoryBudget.stable = original
    return results

def submit_death():
    from ghost_backend.execution import frequency_sweep as F
    from concurrent.futures import ProcessPoolExecutor
    killed=[]
    class KillBeforeSecondSubmit(ProcessPoolExecutor):
        calls=0
        def submit(self,*a,**kw):
            self.calls+=1
            if self.calls==2:
                # Kill only a worker owned by this test's executor. Wait for
                # its management thread to detect death before submitting.
                p=next(iter(self._processes.values()))
                os.kill(p.pid,signal.SIGKILL);killed.append(p.pid)
                deadline=time.monotonic()+5
                while not self._broken and time.monotonic()<deadline:
                    threading.Event().wait(.01)
            return super().submit(*a,**kw)
    old=F.ProcessPoolExecutor;F.ProcessPoolExecutor=KillBeforeSecondSubmit
    try:
        value=F.compute_parallel(S.solve_monostatic_rcs_2d,
            dict(geometry_snapshot=geometry(),frequencies_ghz=[1.,1.1,1.2,1.3],elevations_deg=[0.,90.],geometry_units='meters',solver_method='direct'),
            None,None,{},'double',False,2,8.)
        return {'killed':killed,'result':value}
    except Exception as e:
        return {'killed':killed,'exception':repr(e),'traceback':traceback.format_exc()}
    finally:F.ProcessPoolExecutor=old

def calibration_orders():
    sys.path.insert(0,str(ROOT/'repo/audits/claude-2026-11-10/calibration'))
    import w_far_rule as W
    import numpy as np
    from ghost_backend.twod import operators as P
    mesh=W.pair_mesh([-.5,0],[.5,0],[2.5,0],[3.5,0])
    orig=P._get_quadrature;record=[]
    def capture(n,*a,**kw):
        record.append(int(n));return orig(n,*a,**kw)
    P._get_quadrature=capture
    rows=[]
    try:
        values=[]
        for q in [5,6,7,8,48]:
            record.clear();v=W.w_block(mesh,1.,q);values.append(v)
            rows.append({'requested_q':q,'actual_rule_calls':list(record)})
        return {'rows':rows,'q5_q6_bitwise_equal':np.array_equal(values[0],values[1]),'q6_q7_bitwise_equal':np.array_equal(values[1],values[2])}
    finally:P._get_quadrature=orig

if __name__=='__main__':
    name=sys.argv[1]
    try: result=globals()[name]()
    except BaseException as e: result={'harness_error':repr(e),'traceback':traceback.format_exc()}
    (ROOT/'results'/(name+os.environ.get('AUDIT_RESULT_SUFFIX','')+'.json')).write_text(json.dumps(result,indent=2,default=str))
    print(json.dumps(result,default=str),flush=True)
