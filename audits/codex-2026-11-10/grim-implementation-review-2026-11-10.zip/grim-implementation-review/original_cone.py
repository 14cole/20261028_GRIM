"""Re-run the independently found November 9 cone, not Claude's fixture."""
import os,sys,json,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'repo/tools/GHOST'))
from ghost_backend.geometry.io import build_geometry_snapshot,parse_geometry
from ghost_backend.bor.dispatch import solve_monostatic_rcs_bor
text='Title: cone\nSegment: body 2\nproperties: 2 37 0 0 0\n0 .2 .1 .1\n.1 .1 .1 -.1\n.1 -.1 0 -.1\nIBCS_Resistances:\n\nDielectrics:\n'
g=build_geometry_snapshot(*parse_geometry(text))
rows=[]
for cap in [None,31]:
    r=solve_monostatic_rcs_bor(g,[3.],[0.,45.,90.,135.,180.],geometry_units='meters',workers=1,mode_tol=1e-13,n_modes=cap)
    rows.append(dict(cap=cap,modes=r['metadata']['per_frequency'][0]['modes_used'],samples=r['samples']))
a,b=[np.array([s['rcs_linear'] for s in r['samples']]) for r in rows]
out={'relative_rcs_difference':float(np.max(abs(a-b))/np.max(abs(b))),'cases':rows}
(ROOT/'results/original_cone.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'relative_rcs_difference':out['relative_rcs_difference'],'modes':[r['modes'] for r in rows]}))
