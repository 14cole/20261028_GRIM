import os,sys,json,time,resource,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['GHOST_SOURCE']=str(ROOT/'repo/tools/GHOST')
os.environ['AUDIT_ROOT']='/workspace/audit'
sys.path.insert(0,'/workspace/audit/portable')
from run_case import geometry,encode,np
from ghost_backend.twod import solver as S
from ghost_backend.execution.selection import select_backend
from ghost_backend.execution.options import validate_options,execution_scope

kind=sys.argv[1]; n=int(sys.argv[2]); multiplier=float(sys.argv[3])
g=geometry(n,kind=kind)
args=dict(geometry_snapshot=g,frequencies_ghz=[(n/20)*299792458/(2*np.pi*.1)/1e9],elevations_deg=[0.,60.,120.],geometry_units='meters',solver_method='direct',strict_quality_gate=False)
options=validate_options({'factorization':'dense','mesh_strategy':'global','assembly_threads':1,'blas_threads':1})
plan=select_backend(args,options,False)
forecast=plan['candidates']['dense']['peak_gb']
cap=forecast*multiplier if multiplier else None
result={'kind':kind,'n':n,'forecast_gib':forecast,'reservation_gib':cap,'plan':plan}
print(json.dumps({k:v for k,v in result.items() if k!='plan'}),flush=True)
start=time.perf_counter()
try:
    with execution_scope(options,memory_budget_gib=cap):out=S.solve_monostatic_rcs_2d(**args)
    result['result']=out
except Exception as e:result.update(error=repr(e),traceback=traceback.format_exc())
result.update(wall=time.perf_counter()-start,rss_peak_gib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024/1024**3)
(ROOT/'results'/('memory_%s_%s_%s.json'%(kind,n,multiplier))).write_text(json.dumps(result,default=encode))
print(json.dumps({k:v for k,v in result.items() if k not in ('plan','result')},default=encode),flush=True)
