"""GHOST ui services."""
