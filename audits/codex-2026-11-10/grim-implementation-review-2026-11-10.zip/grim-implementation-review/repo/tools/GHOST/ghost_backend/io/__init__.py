"""GHOST io services."""
