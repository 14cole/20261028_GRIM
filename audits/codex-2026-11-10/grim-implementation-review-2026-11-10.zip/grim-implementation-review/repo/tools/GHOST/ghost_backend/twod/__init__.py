"""GHOST twod services."""
