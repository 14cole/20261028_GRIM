"""GHOST bor services."""
