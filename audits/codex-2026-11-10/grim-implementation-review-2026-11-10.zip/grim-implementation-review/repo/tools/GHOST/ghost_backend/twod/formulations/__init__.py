"""GHOST formulations services."""
