"""GHOST geometry services."""
