"""Explicit compressed CPU path: bounded geometry assembly and strict rejection."""
from ghost_backend.execution.options import temporary_directory
from ghost_backend.execution.options import environment_value
from ghost_backend.execution.memory_budget import payload_bytes
import os,tempfile,time
import numpy as np
from ghost_backend.execution.metrics import timed_stage


def enabled():
    return environment_value('GHOST_CPU_FACTORIZATION','dense').strip().lower()=='compressed'


# Fallback only when no phase workspace forecast is available.
AUTOMATIC_STORAGE_FRACTION=.6
# Match the minimum explicit cap; a 2-GiB floor could exceed a small job's
# entire RAM allocation before assembly workspaces were counted.
AUTOMATIC_STORAGE_FLOOR=16*1024**2


def automatic_storage():
    return environment_value('GHOST_COMPRESSED_STORAGE_MIB','2048').strip()=='0'


def automatic_storage_bytes():
    """Bytes the automatic setting grants, independent of any environment variable.

    BOR carries its own execution options rather than the 2-D profile, so it
    needs the sizing rule without the GHOST_COMPRESSED_STORAGE_MIB lookup.
    """
    from ghost_backend.twod.solver import _solve_memory_limit_gb
    from ghost_backend.execution.memory_budget import current
    ledger = current()
    limit = ledger.stable() if ledger is not None else _solve_memory_limit_gb()
    if ledger is not None and ledger.plan is not None:
        return planned_storage_bytes(ledger.plan, int(limit*1024**3))
    # A small reservation must never be raised by the payload floor.
    return min(int(limit*1024**3),max(AUTOMATIC_STORAGE_FLOOR,
        int(AUTOMATIC_STORAGE_FRACTION*limit*1024**3)))


def planned_storage_bytes(plan, reservation):
    """Payload remainder after the largest non-overlapping phase workspace."""
    phases = plan.get('nonstorage_phase_bytes', {})
    if set(phases) == {'assembly', 'factorization', 'solve'}:
        return max(0, reservation-max(phases.values()))
    return min(reservation, max(AUTOMATIC_STORAGE_FLOOR,
        int(AUTOMATIC_STORAGE_FRACTION*reservation)))


def release_obsolete_tile_workers(resources, dofs):
    """Release an idle tile team when the admitted mesh uses hierarchical assembly.

    Hierarchical assembly uses threads in this process, so retaining the old
    spawned tile team only consumes RAM/commit. A later tile fallback or mesh
    recreates its team through the existing admission and worker lifecycle.
    Call only for an actual mesh admission, never speculative planning.
    """
    from ghost_backend.compressed import hmatrix
    if not resources.get('hmatrix_storage') or not hmatrix.selected(dofs) or hmatrix.configuration_unsupported():
        return 0
    from ghost_backend.compressed.worker_pool import release_idle
    released = release_idle()
    if released:
        from ghost_backend.execution.cpu import current_state
        state = current_state()
        if state is not None:
            state.memory_estimates.append(dict(method='released_idle_tile_workers',
                released_allowance_bytes=released, system_dofs=int(dofs),
                reason='admitted hierarchical mesh no longer uses the tile process team'))
    return released


def planned_forecast(n, d, count, batch, threads, resources, safety=1., floor_gb=0.,
                     submission_planning=False, live_residency_bytes=None):
    """Price a new mesh without inheriting a previous mesh's payload allowance."""
    from ghost_backend.compressed.memory import forecast, GIB
    from ghost_backend.compressed import hmatrix
    from ghost_backend.execution.memory_budget import current
    from ghost_backend.twod.solver import _solve_memory_limit_gb
    if (resources.get('hmatrix_pressure_candidate') is not None
            and resources.get('compressed_storage', {}).get('hmatrix')):
        # The identity-checked TM partner already exists. Reprice its actual
        # representation even if a fresh tile forecast would now fit.
        resources = dict(resources, hmatrix_storage=resources['hmatrix_pressure_candidate'],
            memory_pressure_hmatrix=True)
    def price(storage):
        plan = forecast(n, d, count, batch, threads, storage, resources, safety, floor_gb)
        if live_residency_bytes is not None:
            # Include unexplained live allocations before choosing an automatic
            # payload cap. Adding them afterward can reject a smaller fitting
            # storage plan, or omit them from later incremental reload checks.
            extra = max(0, int(live_residency_bytes)-plan['process_geometry_bytes'])
            plan['live_residency_adjustment_bytes'] = extra
            plan['process_geometry_bytes'] += extra
            plan['peak_bytes'] += extra
            for field in ('phase_bytes', 'nonstorage_phase_bytes'):
                plan[field] = {key: value+extra for key,value in plan[field].items()}
        return plan
    setting = environment_value('GHOST_COMPRESSED_STORAGE_MIB','2048').strip()
    hierarchical_plan = resources.get('hmatrix_storage') is not None and (
        hmatrix.selected(d) or resources.get('memory_pressure_hmatrix'))
    auto = setting == '0' or hierarchical_plan and setting == '2048'
    if submission_planning:
        # The submitting host does not own the eventual node allocation. Keep
        # the historical 2-GiB payload forecast for automatic storage; the
        # compute process reprices it against its actual allocation at admission.
        initial = 2048*1024**2 if auto else storage_budget()
        plan = price(initial)
        plan['storage_policy'] = 'submission_payload_forecast' if auto else 'explicit_payload_cap'
        return plan
    if auto:
        ledger = current()
        reservation = int((ledger.stable() if ledger is not None else _solve_memory_limit_gb())*GIB)
    initial = planned_storage_bytes({}, reservation) if auto else storage_budget()
    plan = price(initial)
    if auto:
        allowance = planned_storage_bytes(plan, reservation)
        plan = price(allowance)
        plan['storage_policy'] = 'reservation_minus_phase_workspace'
    else:
        plan['storage_policy'] = 'explicit_payload_cap'
    if resources.get('memory_pressure_hmatrix'):
        plan['memory_pressure_hmatrix'] = True
    candidate = resources.get('hmatrix_pressure_candidate')
    if (candidate is not None and not hierarchical_plan and not submission_planning
            and not environment_value('GHOST_HMATRIX_MIN_UNKNOWNS', '').strip()):
        ledger = current()
        capacity = int((ledger.stable() if ledger is not None else _solve_memory_limit_gb())*GIB)
        if plan['peak_bytes'] > capacity:
            alternative = dict(resources, hmatrix_storage=candidate, memory_pressure_hmatrix=True)
            alternative.pop('hmatrix_pressure_candidate', None)
            other = planned_forecast(n, d, count, batch, threads, alternative, safety, floor_gb,
                live_residency_bytes=live_residency_bytes)
            if other.get('storage_fits', True) and other['peak_bytes'] < plan['peak_bytes']:
                other['representation_reason'] = 'Tile forecast exceeds reservation at the requested angle batch.'
                other['tile_alternative_peak_bytes'] = plan['peak_bytes']
                other['memory_pressure_hmatrix'] = True
                return other
    return plan


def storage_budget():
    text=environment_value('GHOST_COMPRESSED_STORAGE_MIB','2048').strip()
    try:value=int(text)
    except ValueError:raise ValueError('GHOST_COMPRESSED_STORAGE_MIB must be a positive integer, or 0 for automatic.')
    if value==0:
        return automatic_storage_bytes()
    if value<16:raise ValueError('GHOST_COMPRESSED_STORAGE_MIB must be at least 16 MiB.')
    return value*1024**2


def hmatrix_storage_budget():
    """Retained-storage cap of hierarchical operators and their inverse.

    The 2048-MiB default was sized for one spooled tile operator; at that
    default (and at 0) hierarchical storage is sized automatically from the
    solve RAM limit, where admission prices both polarizations' operators.
    Any other configured value caps it.
    """
    text=environment_value('GHOST_COMPRESSED_STORAGE_MIB','2048').strip()
    if text in ('0','2048'):return automatic_storage_bytes()
    return storage_budget()


def checkpoint():
    from ghost_backend.execution.cpu import current_state
    from ghost_backend.twod.assembly.session import current_session
    owner=current_state() or current_session()
    if owner is not None:owner.checkpoint()


def coordinates(mesh,n):
    xy=np.zeros((len(mesh.nodes),2))
    for e in mesh.elements:xy[list(e.node_ids)]=[mesh.nodes[i].xy for i in e.node_ids]
    return np.tile(xy,(n//len(mesh.nodes),1))


def hierarchical_selected(n):
    """Normal threshold, or a same-system compressed plan under memory pressure."""
    from ghost_backend.compressed import hmatrix
    if hmatrix.selected(n):
        return True
    if environment_value('GHOST_HMATRIX_MIN_UNKNOWNS', '').strip():
        return False
    from ghost_backend.execution.memory_budget import current
    ledger = current()
    plan = ledger.plan if ledger is not None else None
    return bool(plan and plan.get('model') == 'compressed_hmatrix_v2'
        and plan.get('system_dofs') == n and plan.get('memory_pressure_hmatrix'))


def hierarchical(oracle,xy):
    """(operator, None) above the hierarchical threshold, else (None, fallback reason or None).

    The tile operator of the original path remains for smaller systems, for
    oracles the hierarchical operator cannot sample safely, and whenever its
    assembly is rejected (measured error, rank or storage).
    """
    from ghost_backend.compressed import hmatrix
    if not hierarchical_selected(oracle.n):return None,None
    reason=hmatrix.unsupported(oracle)
    if reason is not None:return None,reason
    sources=getattr(oracle,'oracles',None)
    mesh=sources[0].mesh if sources else oracle.mesh
    if sources:
        from ghost_backend.execution.memory_budget import current
        ledger = current()
        plan = ledger.plan if ledger is not None else None
        if (plan and plan.get('model') == 'compressed_hmatrix_v2'
                and plan.get('system_dofs') == oracle.n
                and plan.get('paired_assembly') is False):
            # Returning without marking rejection preserves the caller's
            # single-polarization H-matrix path and its normal admission.
            return None, 'Memory plan selects separate hierarchical polarizations.'
    try:
        if sources:
            # Both polarizations from one kernel traversal; (TE, TM) operators.
            return hmatrix.build_pair(oracle,xy,hmatrix.support_radius(mesh,xy),
                budget=hmatrix_storage_budget(),checkpoint=checkpoint),None
        return hmatrix.HMatrixOperator(oracle,xy,hmatrix.support_radius(mesh,xy),
            budget=hmatrix_storage_budget(),checkpoint=checkpoint),None
    except (hmatrix.HMatrixRejected,MemoryError) as exc:
        reason='{}: {}'.format(type(exc).__name__,exc)
        # A pair over its storage cap is retried one polarization at a time;
        # otherwise the tile operator assembles this system (and its partner).
        if not (sources and isinstance(exc,MemoryError)):
            for source in sources or [oracle]:source.hmatrix_rejected=reason
        return None,reason


def pairable(oracle):
    """Shared TE/TM tile traversal only where the tile operator will be built."""
    from ghost_backend.compressed import hmatrix
    return not hierarchical_selected(oracle.n) or hmatrix.unsupported(oracle) is not None


def admit_tile_fallback(oracle, xy, reason):
    """Reprice a rejected hierarchical assembly before any tile workers start.

    Sampling is bounded and covers each polarization independently. The tile
    phase model includes its own metadata, process team and correction buffers;
    a retained payload cap alone is not a full-process memory admission.
    """
    if not reason:
        return None
    from ghost_backend.compressed import memory
    from ghost_backend.compressed.worker_pool import release_idle, retained_bytes
    from ghost_backend.execution.cpu import current_state, configured_batch_size
    from ghost_backend.twod.assembly.session import current_session
    from ghost_backend.twod import solver
    from ghost_backend.twod.operators import get_assembly_threads
    checkpoint()
    state, session = current_state(), current_session()
    sources = list(getattr(oracle, 'oracles', [oracle]))
    count = max(1, getattr(session, 'n_rhs', getattr(state, 'n_rhs', 256)))
    batch = min(configured_batch_size(), count)
    released = 0
    plans = []
    for source in sources:
        checkpoint()
        resident = solver._process_rss_bytes() + retained_bytes()
        limit = solver._solve_memory_limit_gb(resident/memory.GIB)*memory.GIB
        if resident + 64*memory.MIB > limit:
            released += release_idle()
            resident = solver._process_rss_bytes() + retained_bytes()
            limit = solver._solve_memory_limit_gb(resident/memory.GIB)*memory.GIB
            if resident + 64*memory.MIB > limit:
                raise MemoryError('Tile fallback sampling does not fit the remaining solve RAM budget.')
        resources = dict(getattr(state, 'current_resources', {}))
        resources.pop('hmatrix_storage', None)
        resources.setdefault('basis_width', 4)
        if getattr(source, 'kind', '') == 'thin':
            resources['formulation'] = 'thin_dielectric_layer'
        tile = min(512, getattr(source, 'maximum_tile', 512))
        resources['compressed_storage'] = memory.sample_operator(source, xy, tile, checkpoint)
        def price():
            live = solver._process_rss_bytes() + retained_bytes()
            plan = planned_forecast(len(source.mesh.nodes), source.n, count, batch,
                get_assembly_threads(), resources, live_residency_bytes=live)
            return plan, solver._solve_memory_limit_gb(live/memory.GIB)*memory.GIB
        plan, limit = price()
        if plan['peak_bytes'] > limit:
            released += release_idle()
            plan, limit = price()
        if plan['peak_bytes'] > limit:
            raise MemoryError('Hierarchical-to-tile fallback needs {:.3f} GiB; {:.3f} GiB allowed. '
                'Fallback workers and workspaces were not started.'.format(plan['peak_bytes']/memory.GIB, limit/memory.GIB))
        plans.append(plan)
    if plans:
        from ghost_backend.execution.memory_budget import record_plan
        envelope = dict(plans[0])
        for field in ('phase_bytes', 'nonstorage_phase_bytes'):
            envelope[field] = {phase: max(p[field][phase] for p in plans)
                for phase in ('assembly', 'factorization', 'solve')}
        envelope['peak_bytes'] = max(p['peak_bytes'] for p in plans)
        envelope['process_geometry_bytes'] = max(p['process_geometry_bytes'] for p in plans)
        record_plan(envelope)
    event = dict(method='tile_fallback_admission', reason=reason, angle_batch_size=batch,
        released_worker_allowance_bytes=released, forecasts=plans)
    if state is not None:
        state.memory_estimates.append(event)
    return event


def record_paired_admission(pair, admission):
    """Keep the same admission visible in each polarization's operator report."""
    if admission is not None:
        for operator, polarization in zip(pair, ('TE', 'TM')):
            operator.evidence['fallback_admission'] = dict(admission, polarization=polarization)
            operator.evidence['hmatrix_fallback'] = admission['reason']


@timed_stage('compressed_assembly')
def build(oracle,xy):
    from ghost_backend.compressed.operator import StreamedOperator
    operator,reason=hierarchical(oracle,xy)
    if operator is not None:return operator
    admission=admit_tile_fallback(oracle,xy,reason)
    operator=StreamedOperator(oracle,xy,tile=min(512,getattr(oracle,'maximum_tile',512)),
        budget=storage_budget(),checkpoint=checkpoint)
    if reason is not None:operator.evidence['hmatrix_fallback']=reason
    if admission is not None:operator.evidence['fallback_admission']=admission
    if hasattr(oracle,'cached'):oracle.cached=oracle.cached_columns=None
    return operator


def native(mesh,infos,pol,k0,kind,obs_order=8,src_order=8,layer=None):
    from ghost_backend.compressed.coefficients import NativeOracle, PairedNativeOracle
    from ghost_backend.compressed.polarization_cache import build_pair
    from ghost_backend.twod.assembly.session import current_session, system_key
    oracle=NativeOracle(mesh,infos,pol,k0,kind,obs_order,src_order,layer)
    from ghost_backend.compressed.pilots import attach
    attach(oracle,mesh,infos,pol,kind,k0,layer,obs_order,src_order)
    session=current_session()
    key=(system_key(mesh,infos or [],'compressed_'+kind,obs_order,src_order),layer)
    previous=session.take(key,pol) if session is not None else None
    if previous is not None:
        previous.load()
        return previous,oracle
    partner=getattr(session,'compressed_partner',None)
    if pol=='TE' and partner is not None and (partner[0] is mesh or kind=='thin') and not pairable(oracle):
        other=NativeOracle(mesh,None if kind=='thin' else partner[1],'TM',k0,kind,obs_order,src_order,layer)
        if other.n==oracle.n:
            pair,reason=hierarchical(PairedNativeOracle(oracle,other),coordinates(mesh,oracle.n))
            if pair is not None:
                pair[0].reserved_partner_bytes=payload_bytes(pair[1])
                key=(system_key(mesh,partner[1] if kind!='thin' else [],'compressed_'+kind,obs_order,src_order),layer)
                session.save(key,'TE',pair[1]);session.compressed_partner=None
                return pair[0],oracle
    if pol=='TE' and partner is not None and (partner[0] is mesh or kind=='thin') and pairable(oracle):
        other=NativeOracle(mesh,None if kind=='thin' else partner[1],'TM',k0,kind,obs_order,src_order,layer)
        attach(other,mesh,None if kind=='thin' else partner[1],'TM',kind,k0,layer,obs_order,src_order)
        if other.n==oracle.n:
            admission=admit_tile_fallback(PairedNativeOracle(oracle,other),coordinates(mesh,oracle.n),
                               getattr(oracle,'hmatrix_rejected',None))
            pair=build_pair(PairedNativeOracle(oracle,other),coordinates(mesh,oracle.n),
                tile=min(512,getattr(oracle,'maximum_tile',512)),budget=storage_budget(),
                checkpoint=checkpoint,spool_directory=temporary_directory())
            record_paired_admission(pair,admission)
            pair[0].reserved_partner_bytes=payload_bytes(pair[1])
            key=(system_key(mesh,partner[1] if kind!='thin' else [],'compressed_'+kind,obs_order,src_order),layer)
            session.save(key,'TE',pair[1]);session.compressed_partner=None
            oracle.cached=oracle.cached_columns=other.cached=other.cached_columns=None
            return pair[0],oracle
    operator=build(oracle,coordinates(mesh,oracle.n))
    return operator,oracle


@timed_stage('compressed_assembly')
def regional(mesh,infos,pol,obs_order=8,src_order=8):
    shared=_projected_regional(mesh,infos,pol,obs_order,src_order)
    return shared if shared is not None else _regional(mesh,infos,pol,obs_order,src_order)


def _projected_regional(mesh,infos,pol,obs_order,src_order):
    from ghost_backend.twod.assembly import polynomial_pair as pair
    owner=pair.current_pair()
    if owner is None or owner.building:return None
    previous=pair.take(mesh,infos,pol,'compressed',obs_order,src_order)
    if previous is not None:
        from ghost_backend.compressed.retained_storage import RetainedOperatorSpool
        operator,layout=previous
        if isinstance(operator,RetainedOperatorSpool):
            try:return operator.restore(),layout
            except InterruptedError:
                pair.discard_backend('compressed')
                raise
            except OSError as exc:
                pair.discard_backend('compressed')
                owner.evidence.append(dict(backend='compressed',polarization=pol,
                    action='independent_assembly',fallback='joint_storage_rejection',
                    reason='retained cubic storage unavailable: '+str(exc)))
                return None
        return previous
    from ghost_backend.twod.assembly.session import current_session,system_key
    session=current_session()
    partner=getattr(session,'compressed_partner',None)
    # A paired traversal is already the baseline. Keep it intact: project both
    # polarizations or leave the ordinary assembly path entirely unchanged.
    if pol!='TE' or partner is None or partner[0] is not mesh:return None
    plans=[pair.prepare(mesh,values,label,obs_order,src_order)
           for values,label in ((infos,'TE'),(partner[1],'TM'))]
    if any(plan is None for plan in plans):return None
    from ghost_backend.compressed import hmatrix
    if hierarchical_selected(len(plans[0]['fine_mesh'].nodes)):
        # Projection consumes tile operators; assemble the coarse system directly.
        owner.evidence.append(dict(backend='compressed',action='independent_assembly',
            reason='hierarchical operator selected for the fine polynomial system'))
        return None
    import ghost_backend.twod.solver as solver
    from ghost_backend.compressed.memory import inverse_storage
    from ghost_backend.twod.formulations.regions import dof_coordinates
    fine=plans[0]['fine_mesh'];records=[]
    for candidate in (mesh,fine):
        phase=[]
        for values,label in ((infos,'TE'),(partner[1],'TM')):
            resources=solver._dense_formulation_resources(candidate,values,label)
            peak=solver._estimate_memory_gb(resources['nodes'],False,
                system_dofs=resources['system_dofs'],n_regions=resources['n_regions'],
                operator_matrices=resources['operator_matrices'],n_rhs=owner.n_rhs,
                solver_method=owner.solver_method,formulation='multi_region',dense_resources=resources)
            phase.append((peak*1024**3,resources['memory_estimate']['operator_allowance_bytes']))
        records.append(phase)
    coarse_allowance=sum(row[1] for row in records[0]);fine_allowance=sum(row[1] for row in records[1])
    inverse=max(inverse_storage(plan['coarse_layout']['n_dof'])[0] for plan in plans)
    from ghost_backend.compressed.projection import projection_workspace_bytes
    projection_workspace=projection_workspace_bytes()
    required=max(max(row[0] for row in records[0])+fine_allowance,
                 max(row[0] for row in records[1])+fine_allowance+coarse_allowance+projection_workspace)
    limit=solver._solve_memory_limit_gb()*1024**3;storage=storage_budget()
    if required>limit or fine_allowance+coarse_allowance+inverse>storage:
        owner.evidence.append(dict(backend='compressed',action='independent_assembly',
            reason='joint polynomial storage exceeds reservation',required_gib=required/1024**3,
            budget_gib=limit/1024**3,retained_storage_required=fine_allowance+coarse_allowance+inverse,
            retained_storage_budget=storage))
        return None
    from ghost_backend.compressed.projection import project_operator
    from ghost_backend.compressed.retained_storage import RetainedOperatorSpool
    built=[];owner.building=True;started=time.perf_counter()
    try:
        session.compressed_partner=(fine,partner[1])
        fine_te,layout_te=_regional(fine,infos,'TE',obs_order,src_order)
        built.append(fine_te)
        fine_tm,layout_tm=session.take(system_key(fine,partner[1],'compressed_region',obs_order,src_order),'TM')
        built.append(fine_tm)
        fine_te.reserved_partner_bytes=0
        retained=sum(operator.bytes for operator in built)
        if storage-retained-inverse<=0:
            raise MemoryError('Retained cubic operators leave no admitted quadratic projection storage.')
        coarse_te=project_operator(fine_te,plans[0]['prolongation'],
            dof_coordinates(mesh,plans[0]['coarse_layout']),storage-retained-inverse,checkpoint)
        built.append(coarse_te)
        retained_te=RetainedOperatorSpool(fine_te,temporary_directory());built.append(retained_te)
        if storage-retained-coarse_te.bytes-inverse<=0:
            raise MemoryError('Retained polynomial operators leave no admitted partner projection storage.')
        # Keep the existing fine TM spool on disk while projecting TE. Only
        # one fine polarization needs resident tiles at a time.
        fine_tm.load()
        coarse_tm=project_operator(fine_tm,plans[1]['prolongation'],
            dof_coordinates(mesh,plans[1]['coarse_layout']),storage-retained-coarse_te.bytes-inverse,
            checkpoint,spool_directory=temporary_directory())
        built.append(coarse_tm)
        retained_tm=RetainedOperatorSpool(fine_tm,temporary_directory());built.append(retained_tm)
        coarse_te.reserved_partner_bytes=coarse_tm.bytes
        pair.remember(fine,infos,'TE',retained_te,layout_te,'compressed',obs_order,src_order)
        pair.remember(fine,partner[1],'TM',retained_tm,layout_tm,'compressed',obs_order,src_order)
        session.save(system_key(mesh,partner[1],'compressed_region',obs_order,src_order),'TE',
                     (coarse_tm,plans[1]['coarse_layout']))
        session.compressed_partner=None
        owner.evidence.append(dict(backend='compressed',action='project_quadratic',
            fine_dofs=len(fine_te),coarse_dofs=len(coarse_te),retained_fine_bytes=0,
            retained_fine_disk_bytes=retained_te.disk_bytes+retained_tm.disk_bytes,
            projection_workspace_bytes=projection_workspace,
            required_gib=required/1024**3,budget_gib=limit/1024**3,
            propagated_fine_errors=True))
        return coarse_te,plans[0]['coarse_layout']
    except InterruptedError:
        # Cancellation is an OSError subclass, but must never start a rebuild.
        session.pending=None;session.compressed_partner=partner
        for operator in built:
            if hasattr(operator,'close'):operator.close()
        pair.discard_backend('compressed')
        raise
    except (MemoryError,OSError) as exc:
        session.pending=None;session.compressed_partner=partner
        for operator in built:
            if hasattr(operator,'close'):operator.close()
        pair.discard_backend('compressed')
        owner.evidence.append(dict(backend='compressed',action='independent_assembly',
            reason=str(exc),fallback='joint_storage_rejection',spent_seconds=time.perf_counter()-started))
        # Return before ordinary assembly so the rejected build and traceback
        # no longer retain its operators while the original path starts.
        return None
    except BaseException:
        session.pending=None;session.compressed_partner=partner
        for operator in built:
            if hasattr(operator,'close'):operator.close()
        raise
    finally:
        owner.building=False


def _regional(mesh,infos,pol,obs_order=8,src_order=8):
    import ghost_backend.twod.formulations.regions as mr
    from ghost_backend.compressed.regional_coefficients import PreparedOracle, PairedOracle
    from ghost_backend.compressed.operator import StreamedOperator
    from ghost_backend.compressed.polarization_cache import build_pair, SpooledOperator
    from ghost_backend.twod.assembly.session import current_session, system_key
    from ghost_backend.compressed.pilots import attach
    session=current_session();key=system_key(mesh,infos,'compressed_region',obs_order,src_order)
    previous=session.take(key,pol) if session is not None else None
    if previous is not None:
        operator,layout=previous
        operator.load()
        return operator,layout
    partner=getattr(session,'compressed_partner',None)
    oracle=None
    if pol=='TE' and partner is not None and partner[0] is mesh:
        oracle=PairedOracle(mesh,infos,partner[1],cut=32,obs_order=obs_order,src_order=src_order)
        if not pairable(oracle.oracles[0]):
            xy=mr.dof_coordinates(mesh,oracle.oracles[0].layout)
            pair,reason=hierarchical(oracle,xy)
            if pair is not None:
                pair[0].reserved_partner_bytes=payload_bytes(pair[1])
                key=system_key(mesh,partner[1],'compressed_region',obs_order,src_order)
                session.save(key,'TE',(pair[1],oracle.oracles[1].layout))
                session.compressed_partner=None
                return pair[0],oracle.oracles[0].layout
            # A combined storage rejection can still fit one hierarchical
            # polarization. Rank/error rejections mark both sources for tiles;
            # preserve that pair so its admitted traversal and evidence stay shared.
            if not pairable(oracle.oracles[0]):
                oracle=oracle.oracles[0]
    if isinstance(oracle,PairedOracle):
        for source,values,label in zip(oracle.oracles,(infos,partner[1]),('TE','TM')):
            attach(source,mesh,values,label,'multi_region',obs_order=obs_order,src_order=src_order)
        xy=mr.dof_coordinates(mesh,oracle.oracles[0].layout)
        admission=admit_tile_fallback(oracle,xy,next((getattr(o,'hmatrix_rejected',None) for o in oracle.oracles
                                          if getattr(o,'hmatrix_rejected',None)),None))
        pair=build_pair(oracle,xy,tile=512,budget=storage_budget(),checkpoint=checkpoint,spool_directory=temporary_directory())
        record_paired_admission(pair,admission)
        pair[0].reserved_partner_bytes=payload_bytes(pair[1])
        key=system_key(mesh,partner[1],'compressed_region',obs_order,src_order)
        session.save(key,'TE',(pair[1],oracle.oracles[1].layout))
        session.compressed_partner=None
        return pair[0],oracle.oracles[0].layout
    if oracle is None:
        oracle=PreparedOracle(mesh,infos,pol,cut=32,obs_order=obs_order,src_order=src_order)
    xy=mr.dof_coordinates(mesh,oracle.layout)
    operator,reason=hierarchical(oracle,xy)
    if operator is not None:return operator,oracle.layout
    admission=admit_tile_fallback(oracle,xy,reason)
    attach(oracle,mesh,infos,pol,'multi_region',obs_order=obs_order,src_order=src_order)
    operator=StreamedOperator(oracle,xy,tile=512,budget=storage_budget(),checkpoint=checkpoint)
    if reason is not None:operator.evidence['hmatrix_fallback']=reason
    if admission is not None:operator.evidence['fallback_admission']=admission
    return operator,oracle.layout


def thin(mesh,k0,pol,eps,mu,d,order=8):
    from ghost_backend.twod.assembly.kernels import incident_loads
    operator,oracle=native(mesh,None,pol,k0,'thin',order,order,(eps,mu,d))
    coefficient,B=oracle.coefficient,oracle.B
    if B==0:
        def rhs(batch):
            bu,_=incident_loads(mesh,k0,batch,want_dn=False)
            return -coefficient*bu
    else:
        C,mass_lu,endpoints,n=oracle.C,oracle.mass_lu,oracle.endpoints,oracle.nn
        def rhs(batch):
            bu,bq=incident_loads(mesh,k0,batch)
            result=np.empty((2*n,len(batch)),complex)
            result[:n]=-C@mass_lu.solve(bu);result[n:]=-B*bq;result[n+endpoints]=0
            return result
    return operator,rhs
