"""GHOST validation services."""
