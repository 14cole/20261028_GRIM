"""GHOST runs services."""
