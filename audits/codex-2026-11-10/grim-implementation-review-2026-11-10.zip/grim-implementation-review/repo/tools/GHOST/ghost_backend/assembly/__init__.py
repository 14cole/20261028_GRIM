"""GHOST assembly services."""
