"""GHOST linalg services."""
