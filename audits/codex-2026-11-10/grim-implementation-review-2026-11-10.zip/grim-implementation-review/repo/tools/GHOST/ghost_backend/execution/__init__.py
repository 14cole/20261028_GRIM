"""GHOST execution services."""
