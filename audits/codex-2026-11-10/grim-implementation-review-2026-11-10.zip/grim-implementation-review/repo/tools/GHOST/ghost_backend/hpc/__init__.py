"""GHOST hpc services."""
