"""GHOST compressed services."""
