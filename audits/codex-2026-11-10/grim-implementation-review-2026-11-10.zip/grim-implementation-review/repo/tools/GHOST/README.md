# GHOST solver and feature workflows

For wheel installation, clean source archives and release checks, see
[distribution and installation](DISTRIBUTION.md).

Open `Launch_GHOST_GUI.bat` to start GHOST. The top level contains the launcher,
Markdown guides, and one `ghost_backend` folder.

BOR controls include a bounded coefficient cache for compressed solves. See
[BOR controls and angle conventions](BOR_PERFORMANCE.md) and the shared
[driver workflow](#local-and-hpc-drivers) for local/HPC transfer.

| Folder | Contents |
| --- | --- |
| `ghost_backend/twod/`, `bor/` | 2-D and body-of-revolution solvers. |
| `ghost_backend/linalg/`, `compressed/` | Factorization, sweep reuse, matrix compression, and RAM forecasts. |
| `ghost_backend/assembly/` | Feature placement, field combination, and assembly validation. |
| `ghost_backend/io/` | Dataset loading, export, and filename operations. |
| `ghost_backend/runs/`, `execution/`, `hpc/` | Run configuration, CPU resources, provenance, and batch scheduling. |
| `ghost_backend/ui/` | Desktop geometry and solver controls. |
| `ghost_backend/data_tools/` | Dataset subtraction, joining, renaming, conversion, and their GUI/CLI. |
| `ghost_backend/geometry/` | Geometry loading, materials, mesh checks, rotation, sample geometries, and placement CSV templates. |
| `ghost_backend/validation/` | Analytical references and runtime feature-comparison services. |

Only `run_gui.py` and the four local/HPC run scripts are directly inside
`ghost_backend`. Native source, libraries, and build tools are under
`ghost_backend/bor/native/` and `ghost_backend/twod/assembly/native/`; runtime support is under `ghost_backend/execution/`.

Batch drivers save new runs under `ghost_backend/results/rcs_runs` or
`ghost_backend/results/rcs_runs_bor` by default. Explicit output paths and saved
configurations keep their selected destinations.

Use the [backend folder map](#ghost-solver-and-feature-workflows) to find solvers, data I/O,
geometry operations, feature assembly, and run management.

2D monostatic runs default to compressed factorization, adaptive meshing, corner
grading, and mesh certification. Threads and memory admission remain automatic,
and completed frequencies are checkpointed for resume. The collapsed
**Advanced / Tools** section contains mesh certification, the accuracy target,
numerical overrides, the selected policy, the accuracy/performance report, and
the boundary-density plot. Geometry and material checks run automatically when
**Run Solver** is pressed.

For a single-mesh 2D monostatic solve, open **Advanced / Tools**, click
**Use one-shot preset (no mesh certification)**, then **Run Solver**. The preset
uses accelerated CPU execution, compressed factorization, and one P1 reference
mesh per frequency for both VV and HH. It skips mesh refinement comparisons;
residual and condition checks remain, and the result is marked uncertified.
The fastest factorization depends on the geometry; Dense remains a manual
override. Recheck **Certify mesh convergence** to return to a certified solve.
The accuracy target is disabled while certification is off.

Mouse-wheel scrolling over GHOST dropdowns and numeric fields does not change
settings, even when focused. Use clicks, typing, or keyboard arrows to edit;
opened dropdown lists retain normal scrolling.

Both monostatic scripts expose the same choices in their CONFIG blocks:

| Setting | Recommended default | Alternatives and behavior |
| --- | --- | --- |
| `FACTORIZATION` | `"compressed"` | Dense is a manual override. Legacy `"adaptive"` uses compressed; `"auto"` maps to dense. Dense may use hierarchical factorization internally, with LU fallback. |
| `MESH_STRATEGY` | `"adaptive"` | Adaptive certification selects polynomial meshes. `"local"` and `"global"` use the manual order. |
| `BASIS_ORDER` | `1` | Choose 1, 2, or 3 for local/global meshes. Ignored for adaptive meshes; the GUI displays **Automatic**. |
| `MESH_GRADING` | `True` | Grades corners, open ends, and material junctions. |
| `MESH_CERTIFICATION` | `True` | Checks mesh convergence before certifying a result. `False` is **Survey — mesh convergence not checked**; adaptive survey uses a single P1 reference mesh. Other quality checks still apply. |

Local and HPC run summaries print these choices, and saved execution profiles
carry them into workers and resumed runs. These controls apply to 2D monostatic
solves; bistatic and BoR keep their own settings. See [running 2D solves](RUN_PROFILES.md).

For 2D batch sweeps, edit the CONFIG block of `run_local_monostatic.py` or
`run_hpc_monostatic.py`. BoR drivers also accept
`--config path/to/settings.config.json` (with `"driver": "bor"`) and
automatically load an adjacent file with the same stem and the `.config.json`
suffix. Each BoR driver declares its accepted setting names in `_CONFIG_KEYS`;
omitted settings keep its defaults. Portable HPC bundles package BoR requests.

The recommended desktop workflow is the top-level GRIM application. Its
**GHOST** tab embeds the same `ghost_backend/run_gui.py` workspace and the same
2-D/BoR numerical implementation found here; no solver is duplicated.

The 2-D diagnostic API defaults to `auto`; `direct` and `experimental_cpu`
remain available to Python callers for tests and diagnostics. NumPy and SciPy are required for
numerical methods and condition-number checks.
BoR supports its separate optional native streaming kernel.
BoR also has [bounded aspect batches, incident-basis reuse, and experimental
compressed modal assembly](BOR_PERFORMANCE.md), with separate controls in
the BoR solver options and local/HPC driver configurations.

In the desktop **Solve Options**, select **BoR** and enter radar **Azimuths**
and **Elevations**, each as a **Discrete List** or **Start / Stop / Step** sweep.
Elevations range from -90 to +90 degrees; azimuths range from 0 to 360 degrees
without including both 0 and 360. The body axis is horizontal with its nose
toward azimuth 0. Elevation defaults to 0 for a single horizontal cut.
The setup check reports the output grid size. The solve computes all unique
body aspects needed by that grid, then exports one monostatic `.grim` with
the requested azimuth/elevation axes and radar-frame VV, HH, and VH channels.
The embedded body model and geometry remain available for feature placement.
Assembly consumes this completed grid; it does not solve additional elevations.

The [phase and quadrature guidance](NUMERICAL_METHODS.md) describes corrected
2-D complex phase, bounded BoR near storage, and quadrature convergence
checks. Read the phase-compatibility notes before combining legacy complex
exports with newly generated results.

2-D assembly supports three optional native libraries in
`ghost_backend/twod/assembly/native/`: the kernel-table evaluator, the
far-field block quadrature and scatter, and the near-pair arithmetic of the
close-pair box recursion and the thin-gap moments. The first two match the
NumPy path bit for bit wherever the kernel table covers the distance; the
near-pair library takes its Hankel, Bessel, logarithm and arctangent values
from NumPy/SciPy and matches the NumPy path bit for bit everywhere. All are
skipped when they cannot load. Portable distributions include their C sources and build script;
development checkouts may also contain binaries built for their host. A release
maintainer can use `scripts/build_distribution.py --native --output <folder>`
to bundle checked kernels in a Windows or Linux wheel. Its recipients need no
compiler; see [native releases](DISTRIBUTION.md#optional-native-releases).
After editing `table.c`, `far.c` or `near.c`, run
`py ghost_backend/twod/assembly/native/build.py`. Both native builders discover
MSYS2 UCRT64 in its standard Windows location and accept `--compiler` and
`--output-dir`. They compile to a temporary file, check it in a fresh process,
and replace the previous library only after validation succeeds.

Build the native BoR sampler on the worker machine with:

```powershell
py ghost_backend/bor/native/build_kernel.py
```

On Windows, install MSYS2 in its default `C:\msys64` location, open the
**MSYS2 UCRT64** terminal, and install the compiler with:

```bash
pacman -Syu
pacman -S --needed mingw-w64-ucrt-x86_64-gcc
```

If the first update asks you to close the terminal, reopen **MSYS2 UCRT64**
and run both commands again. The build script discovers the default UCRT64
compiler automatically; no global PATH change is required. Verify from this
folder with `py ghost_backend/bor/native/build_kernel.py` and restart Python workers.

The build enables OpenMP outer-loop parallelism when the compiler supports it
and automatically retries a portable serial build otherwise. Use
`--no-openmp` to request the serial build explicitly. Result metadata reports
`stream_sampling_backend=native_c` or `numpy`, so production runs do not hide
which path was active.

Bounded far-block streaming is available for PEC/IBC, homogeneous dielectric
PMCHWT, simple coated-PEC bodies, and partial, layered, or banded junction
systems. The budget is enforced across every simultaneously retained self and
rectangular cross-surface block. Peak planning separately includes cached
junction projections and direct near/junction operators, which remain resident
when the far field is streamed. Result metadata records the sampling backend
for each medium side/mapping (a lossy material side uses the complex-wavenumber
NumPy sampler).

## CPU performance and memory

The Windows and Linux CPU paths use the existing NumPy/SciPy stack; these
optimizations require no additional Python package or higher minimum version.
The mesh, precision selection, integration tolerances, retained modes, and
physical acceptance checks keep their existing meanings.

* 2-D bistatic batches share bounded observation weights. Compressed dielectric
  coefficient queries fuse common kernel work and reuse the existing angular
  compression hint across compatible frequencies. Near coefficient storage is
  capped at 16 MiB in RAM, with larger stores using automatically removed
  temporary files; polynomial integration works in bounded batches. Integer
  near-pair plans still grow with the number of interactions.
* BoR near coefficients combine duplicate nodal destinations while preserving
  source impedance weights and independent reciprocal-pair diagnostics.
  Compressed far blocks retain a shared basis when that reduces storage.
  Angular projection selects complex products, packed real products, or
  DCT/DST evaluation of the same folded quadrature, including their scratch
  memory in the chunk allowance.
* Large material BoR systems can use the existing checked hierarchical
  factorization with dense fallback. Rectangular cross-surface storage can
  compress well-separated tiles only after checking every original tile's
  coefficients; nearby tiles remain dense. Mode ranges and temporary disk
  spilling remain available. Closely spaced layers may offer little compression.
* Hierarchical factorization uses bounded matrix panels and shared solve
  destinations. GMRES retains both orthogonalization passes while avoiding
  repeated copies of the growing conjugated basis.
* Batch planning reads CPU allocation once per plan and reuses each candidate's
  thread reservation across its proposed schedules. A new plan reads current
  allocation again; exhaustive searches avoid repeated OS and optional-import
  work without changing their scheduling choices.
* GUI and local/HPC BoR results use shared float64 sample arrays through
  certification and export. Public Python calls still return ordinary lists
  unless wrapped in `ghost_backend.twod.samples.compact_samples()`. GRIM
  formats, channel ordering, amplitudes, phase, and diagnostics are preserved.

Runtime reports retain the original main-process RAM measurement and add
parent-plus-worker samples. Shared pages can be counted more than once in
those sums. Windows private committed memory, when available, is reported
separately from resident RAM. These samples include other concurrent work and
are not an exclusive allocation peak.

Small Windows stage benchmarks found about 22% less dielectric assembly time
and 40% less bistatic projection time. A 100,000-sample BoR storage probe used
about 8.8 MB retained with compact rows versus 92 MB with dictionary rows.
These are component measurements, not whole-solve speedup or peak-RAM
guarantees. Linux timing and native-build qualification require a Linux host.

## Thin-layer and reactive-sheet qualification

The 2-D thin-dielectric model is a first-order thickness approximation. Along
with thickness and curvature checks, it compares local reflection/transmission
and guided-wave dispersion against an independent finite-thickness slab. Cases
outside these local comparison limits require explicit bulk geometry. Matched
guided waves inside the thin-layer expansion's domain enter the mesh-size
estimate and the achieved-resolution check. Higher spatial-frequency modes
outside that domain remain unchecked and are identified in the report.
The solve report shows these comparisons separately from mesh convergence:
passing local slab checks does not establish the full geometry's error against
a bulk model, especially near resonances or open ends.

BoR transmitting impedance sheets use both local surface-wave branches when
planning the meridional mesh. Unresolved surface waves cannot receive a mesh
certificate. Oblique-incidence modal convergence also accounts for the
surface-wave azimuthal bandwidth; exact axial incidence retains its single
azimuthal order. These prerequisites preserve panel, mode and memory limits,
so a strongly reactive sheet may need explicit refinement or exceed available
resources instead of receiving a certificate from an unresolved mesh plateau.

## GPU scope

Configured 2-D solves, including GUI, driver, survey, and certified entry points,
currently select the CPU backend. Setting `GHOST_DENSE_BACKEND=gpu` does not
change that execution profile. GPU support exists only in the low-level dense
linear-algebra diagnostic functions, using optional CuPy and a cuSOLVER health
check; it is not a production solver acceleration option. Release condition
estimates and the configured CPU assembly/factorization path use SciPy.

## Standalone GHOST

Run commands from this folder:

```powershell
py ghost_backend/run_gui.py
```

On Windows, `Launch_GHOST_GUI.bat` first changes to this folder and then opens
the same workspace.

## Local and HPC drivers

Edit the configuration block in the relevant driver, then run:

```powershell
python ghost_backend/run_local_monostatic.py
python ghost_backend/run_local_bor.py
python ghost_backend/run_hpc_monostatic.py
python ghost_backend/run_hpc_bor_monostatic.py
```

Use `python`, not `py`: the scripts' `#!/usr/bin/env python3` line makes the
Windows `py` launcher pick the Microsoft Store `python3` alias, which exits
without running anything.

These four scripts hold only user parameters. Their workflow, scheduling and
worker code lives in `ghost_backend/hpc/bor_driver.py`, `hpc/twod_driver.py`,
`runs/local_bor_driver.py` and `runs/local_twod_driver.py`. Like an HPC run,
a local run freezes a copy of the backend and of its parameter script in
`<run_dir>/runtime` and `<run_dir>/driver_configured.py`, so editing the
checkout while a sweep runs does not affect it.

The 2-D production path co-solves VV/TE and HH/TM and writes them into one
GRIM artifact per geometry/frequency. The BoR path produces a combined
body artifact after its per-frequency restart units complete.

New `.grim` archives use GRIM format version 2: the solver's raw complex
far-field amplitude is stored once as `rcs_complex` (with the
`grim_format_version`, `storage_kind` and `storage_domain` framing GRIM itself
writes), and GRIM and GHOST derive power and phase from it under
`units.rcs_linear_quantity`. The archives are about a third smaller than the
version-1 layout and GRIM loads them faster in less memory. Set
`GHOST_GRIM_FORMAT_VERSION=1` (or pass `format_version=1` to
`export_result_to_grim`) to restore the version-1 layout with `rcs_power`,
`rcs_phase`, `rcs_amp_real` and `rcs_amp_imag` for older GRIM installations.
Every GHOST reader loads both versions.

Each newly prepared HPC run contains its own `runtime/ghost_backend` source
and native-kernel snapshot. The saved worker and generated Slurm scripts use
that snapshot, so editing the original CONFIG block or updating the checkout
cannot alter an already prepared run. Keep the `runtime` folder with the run.
The snapshot is still integrity checked; changing it invalidates that run.
Python, NumPy, SciPy and their numerical build configuration must remain
compatible between submission and workers. Kernel-release and processor
labels are recorded as host information rather than compatibility requirements.

BoR workers refresh resource estimates inside their compute allocation and
bind each solve to its selected backend, CPU count and memory reservation.
Submit-host estimates are planning hints, not worker memory reservations.

BoR TYPE 1 sheets and connected sheet/PEC profiles export their complete
solved profile and radar response. Sheet-containing artifacts identify their
profile as a sheet and cannot be used automatically as an opaque body surface
for feature placement or shadowing. Geometry/export compatibility is checked
before solving; ordinary conductor and dielectric body exports retain their
feature-surface workflow.

See:

- [driver configuration](#local-and-hpc-drivers) for local/cluster operation and resource controls.
- [GEOMETRY_INPUT_CHEATSHEET.md](GEOMETRY_INPUT_CHEATSHEET.md) for `.geo`
  boundaries, regions, materials, winding, and units.
- [BoR conventions](BOR_PERFORMANCE.md#geometry-and-angle-conventions) for BoR geometry, polarization,
  phasor, loss, and RCS conventions.

## Feature assembly service

The GRIM Assembly form and automation wrapper both call
`ghost_backend/assembly/workflow.py`. `ghost_backend/assembly/place_features.py` remains a thin
settings-based wrapper for unattended work. Source certificates, solver-version
tags, and feature/surface manifests are normally advisory. Explicit phase,
amplitude, time-sign, and polarization conventions must be compatible; missing
supported declarations are recorded as assumptions. Numerical units, fields,
axes, and placement geometry are checked. Strict library metadata and certified-body profiles
are optional. Only an explicitly selected strict profile or a large workload
review requires a warning acknowledgment. The GUI uses the same placement,
phase, expansion, and shadowing implementation.

The integrated tab supports editable placements, point rows/circles/polyline
patterns, line paths, explicit surface projection and normal derivation,
body-only baselines, exact stored-grid subsets, and body/feature/total response
comparison. Newly selected BoR bodies can generate their own bounded-error
shadow mesh. The integrated [Assembly workflow guide](../../GRIM_Backend/docs/ASSEMBLY_WORKFLOW.md) describes the user workflow.
The 2-D `amplitude_version` is advisory during subtraction and line loading.
Operations record convention assumptions without inferring a field conversion.
Feature responses need no "delta" tag or declaration: any response with the
physical 2-D (line) or cavity-frame 3-D (point) convention, compatible units,
and grids is accepted. A different phase origin or normalization is still
rejected. Older files tagged `power_domain="delta_amp_sq"` /
`rcs_domain="delta"` are converted to standard samples when they are read;
`declared_coherent_delta` arguments are deprecated and ignored, and
`tag_as_delta` is a deprecated no-op.

FREDDY nominal IBC and dielectric CSVs store frequencies in Hz and are readable
with or without headers. GHOST converts Hz to its internal GHz scale and
preserves signed complex material values. Analysis/uncertainty CSVs are separate
from nominal material tables.

Create and check a reviewed feature-response sidecar with:

```powershell
py ghost_backend/assembly/create_feature_manifest.py create --help
py ghost_backend/assembly/create_feature_manifest.py check --help
py ghost_backend/assembly/create_feature_manifest.py create-surface-binding --help
py ghost_backend/assembly/create_feature_manifest.py check-surface-binding --help
```

For `validated` libraries this is now an evidence-binding and integrity tool:
it consumes the full-wave validator report, re-hashes all four case artifacts,
and proves that the assembled prediction used the exact response. Team review
is still required because software cannot establish external-solver
independence or mesh convergence. The supplied ghost_backend/validation/reconstruction.py compares independent full-wave evidence; use its --help for the supported input format.

Use `python ghost_backend/data_tools/run_cli.py subtract OPN FRD Deltas` for
OPN-FRD 2-D feature responses (written with standard tags). General joins and dataset conversion use the same
CLI. See [the CLI command definitions](ghost_backend/data_tools/run_cli.py).

## Material and IBC files

Use headered, comma-separated `.csv` files with frequency in Hz, following the
[shared GHOST/FREDDY file format](MATERIAL_CSV_FORMAT.md). FREDDY material
and nominal IBC exports can be used directly. The geometry editor validates
CSV selections before adding them. Space/tab-separated tables, headerless
CSVs, and implicit `mat.<flag>` references are not accepted.
