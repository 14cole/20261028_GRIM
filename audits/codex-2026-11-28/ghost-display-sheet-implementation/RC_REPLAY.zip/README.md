# GHOST release-candidate replay

The four subdirectories contain per-test instructions. Run each checkout in its own Python process and pass absolute checkout paths. Use main at 95f8719 and the code candidate at 6621db2. The upstream directory contains the unmodified comparison scripts and relevant raw reference data from Claude at ced2243. Supply upstream/results/rc to the thin and sheet comparisons, upstream/display for the variant driver, and upstream (the directory containing display and results) for variant/compare_hosts.py.

The boundary test uses the actual shipped display allowance, and its synthetic fields and expected values are generated independently. For the physical-matrix evidence, start with thin/comparison.json and thin/candidate/trace.json. The replay directory contains the separate worker export and fixed-budget planning rechecks. Research scripts keep temporary captures inside the running job.

Every member other than SHA256.json is listed by relative path and content digest in that manifest.

To verify the recorded runs after extracting, execute these commands from the archive root.

```sh
python sheet/compare.py sheet/replay upstream/results/rc /tmp/sheet-recheck.json
python thin/compare.py thin/main thin/candidate upstream/results/rc /tmp/thin-recheck.json
python variant/compare_hosts.py upstream variant/output /tmp/display-recheck.json
```
