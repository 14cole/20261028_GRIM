"""Cross-check a pair of traces and Claude's archived full-field arrays."""
from pathlib import Path
import argparse
import json
import numpy as np

def compare(base, candidate, claude):
    data = json.loads((base/'trace.json').read_text())
    assert data == json.loads((candidate/'trace.json').read_text())
    counts = {'one_section': (42,21,42,21),'four_sections':(48,24,42,21),
              'four_sections_two_reversed':(48,24,42,21),'three_bent_sections':(46,23,42,21),
              'codex_nine_panels':(24,12,20,10)}
    worst = dict(claude_vs_fresh_dense_peak_relative=0., dense_vs_compressed_peak_relative=0.)
    matched = 0
    for fixture,(fte,ftm,ate,atm) in counts.items():
        rec = data[fixture]
        assert rec['desktop']==rec['hpc']=={'TE':fte,'TM':ftm}
        for arm,tree in [('main95',base),('rc',candidate)]:
            with np.load(tree/f'{fixture}_dense.npz') as dense, np.load(tree/f'{fixture}_compressed.npz') as compressed:
                for pol,dim in [('TE',ate),('TM',atm)]:
                    assert rec['dense']['channels'][pol]['operator_shape']==[dim,dim]
                    assert rec['compressed']['channels'][pol]['operator_shape']==[dim,dim]
                    assert rec['dense']['outer_execution']['prices']==[fte,ftm]
                    assert rec['compressed']['outer_execution']['prices']==[fte,ftm]
                    for mode, arrays in [('dense',dense),('compressed',compressed)]:
                        with np.load(base/f'{fixture}_{mode}.npz') as first:
                            assert np.array_equal(first[pol],arrays[pol])
                    scale=float(np.max(np.abs(dense[pol])))
                    delta=float(np.max(np.abs(dense[pol]-compressed[pol])))/scale
                    worst['dense_vs_compressed_peak_relative']=max(worst['dense_vs_compressed_peak_relative'],delta)
                    if fixture != 'codex_nine_panels':
                        with np.load(claude/f'{arm}_thin_{fixture}.npz') as reference:
                            assert np.array_equal(reference['angles_deg'], dense['angles_deg'])
                            matched+=len(reference[pol])
                            error=float(np.max(np.abs(reference[pol]-dense[pol]))/np.max(np.abs(reference[pol])))
                            worst['claude_vs_fresh_dense_peak_relative']=max(worst['claude_vs_fresh_dense_peak_relative'],error)
                            assert error<1e-8,(fixture,pol,error)
    return dict(comparison='passed',trees=['95f8719','6621db2'],paired_public_solves=20,polarization_systems=40,
                same_backend_fields_exact_across_trees=True,claude_reference_complex_samples_checked=matched,**worst)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('base',type=Path); p.add_argument('candidate',type=Path)
    p.add_argument('claude_results',type=Path); p.add_argument('output',type=Path)
    a=p.parse_args()
    result=compare(a.base,a.candidate,a.claude_results)
    print(result)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
