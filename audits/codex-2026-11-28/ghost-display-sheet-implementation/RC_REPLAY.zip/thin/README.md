# Thin dielectric layer dimensions at factorization and solve

The thin-layer forecast discrepancy reproduces on both main `95f8719` and the release candidate `6621db2`. The paired public solver was driven with each checkout in its own process. Each of five P1 geometries was solved separately with Dense and Compressed, with one BLAS and assembly thread and all requested incidence angles. Claude's four cases use the geometry, frequency, material, grading, and angles from its `thin_layer.py` at `ced2243`. The fifth is the earlier ungraded nine-panel fixture at 1 GHz. No production files were edited.

| Geometry | Final panels | Desktop / HPC / outer execution estimate, TE and TM | Physical joined nodes | Dense LU and Compressed operator dimensions, TE and TM |
|---|---:|---:|---:|---:|
| Claude straight, one section | 20 | 42 / 21 | 21 | 42 / 21 |
| Claude straight, four sections | 20 | 48 / 24 | 21 | 42 / 21 |
| Claude straight, two of four sections reversed | 20 | 48 / 24 | 21 | 42 / 21 |
| Claude bent, three sections | 20 | 46 / 23 | 21 | 42 / 21 |
| Codex straight, three sections | 9 | 24 / 12 | 10 | 20 / 10 |

The default graded mesh explains the 20 execution panels on Claude's four geometries. Along an open chain, the continuous mesh has one node beyond the physical panel count, independent of how those panels were distributed among named sections. With the tested electric contrast and unit relative permeability, TE needs two field traces per joined node and TM needs one. Segment headers contributed one extra unjoined node at each internal junction in the outer estimate.

For example, in Claude's four-section case the 24-node interface mesh enters the thin-layer routine. Its midsurface preparation joins it to 21 nodes. The formulation passes a 42-by-42 TE matrix to the common field solver. Dense factors that matrix and solves a 42-by-36 RHS, producing a 42-by-36 solution. TM factors a 21-by-21 matrix with a 21-by-36 RHS. Compressed receives identically sized operators and solves identically sized RHS arrays. We checked the complex fields returned by those specific calls against all 36 public samples per polarization. The inner memory estimate and thin-layer evidence use the actual dimensions. The initial desktop, HPC and execution admission estimates use the larger pre-join dimensions.

The material qualification during each tagged call solves two independent stacks of 185 planar systems of size 2 by 2. The probe clears the qualification diagnostic's in-process memoization so its real arrays are observable every time. This distinguishes the material check from the 42 and 21 solved unknowns. Equal physical geometry explains why those dimensions also appear for the unsplit control.

All 20 public solves completed. All same-backend full complex fields were exactly equal across revisions. For the four Claude fixtures, the largest fresh Dense versus Claude archived field discrepancy across 576 complex sample comparisons (both revisions) was 4.25e-16 of a channel's peak. Across all five fixtures the largest Dense/Compressed discrepancy was 9.04e-16 of peak. These are numerical before/after and cross-host controls on this discretization. The observed deficiency is overpricing the thin-layer workload. These checks do not establish process RSS, absolute physical accuracy, or a threshold timing improvement.

The thin-layer issue predates the ordinary impedance-sheet fix. Keep it separate from that release. For a fix, prepare and validate the physical midsurface consistently before pricing, and reuse it for outer admission and the solve. The projected mesh and corresponding physical element information must stay aligned for every consumer. Check initial and later memory gates, explicit unsupported basis orders, branching, the analytic zero-contrast case, both trace counts and certified refinement before changing routing.

## Reproduction

Use a Python environment with the repository's Linux GHOST dependencies. The last argument to `compare.py` before the output JSON is Claude's `audits/claude-2026-11-28/fresh-run-review/results/rc` directory at `ced2243`.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python check.py /path/to/main replay/main
python check.py /path/to/candidate replay/candidate
python compare.py replay/main replay/candidate /path/to/claude/results/rc replay/comparison.json
```

Each tree's `trace.json` records both resource estimates, mesh dimensions, qualification array shapes, physical operator and factor class, all RHS and solution dimensions, and the input angle array. Each NPZ stores all angles and complex TE/TM fields. The factorization labels and shapes were observed at the actual call boundaries. The production routines received and returned their original arrays.
