"""Trace published thin-layer fixture operators to the produced complex samples.

Run each checkout in a fresh interpreter. All wrappers call the corresponding
original functions and forward their real inputs and returned objects.
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

import numpy as np

def fixtures():
    def layer(points, n, reverse=(), previous=False):
        lines = ['Title: thin layer']
        for i,(p,q) in enumerate(zip(points, points[1:])):
            a,b = (q,p) if i in reverse else (p,q)
            lines.extend([f'Segment: section_{i} 1', f'properties: 1 {n} 10 0 0',
                          ' '.join(f'{v:.17g}' for v in (*a,*b))])
        if previous:
            lines.extend(['IBCs:', '10 thin_dielectric 0.00001 2','Dielectrics:', '2 3.0 -0.02 1 0'])
        else:
            lines.extend(['IBCS_Resistances:', '10 thin_dielectric 0.0005 50', '', 'Dielectrics:', '50 3.2 -0.02 1 0'])
        return '\n'.join(lines)+'\n'

    straight = np.column_stack((np.linspace(-.06,.06,5), np.zeros(5)))
    bent=[(-.06,0.),(-.02,0.),(.02,.01),(.06,.03)]
    angles=list(np.arange(0.,360.,10.))
    yield 'one_section', layer([straight[0],straight[-1]],12),3.,angles
    yield 'four_sections',layer(straight,3),3.,angles
    yield 'four_sections_two_reversed',layer(straight,3,(1,3)),3.,angles
    yield 'three_bent_sections',layer(bent,4),3.,angles
    yield 'codex_nine_panels',layer([(i*.003,0.) for i in range(4)],3,previous=True),1.,[-60.,0.,60.]

def run(checkout,out):
    sys.path.insert(0,str(checkout/'tools/GHOST'))
    from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
    from ghost_backend.twod import solver
    from ghost_backend.twod.formulations import thin_layer as tl, thin_layer_qualification as qual
    from ghost_backend.execution.options import validate_options,execution_scope,cpu_allocation_scope
    from ghost_backend.execution.selection import select_backend
    from ghost_backend.hpc.scheduler import predict_2d_resources_many
    from ghost_backend.twod.preparation import preparation_scope
    from ghost_backend.linalg import sweep
    import scipy.linalg

    out.mkdir(parents=True,exist_ok=True)
    output = {}
    for case,geo,frequency,angles in fixtures():
        snap=build_geometry_snapshot(*parse_geometry(geo))
        args=dict(geometry_snapshot=snap,geometry_units='meters',frequencies_ghz=[frequency],elevations_deg=list(angles))
        opts=validate_options(dict(mesh_strategy='global',basis_order=1,assembly_threads=1,blas_threads=1,
                              rhs_compression='off', **({'mesh_grading':False} if case=='codex_nine_panels' else {})))
        with preparation_scope():
            desktop=select_backend(args,opts,False)
        with TemporaryDirectory() as td, execution_scope(opts):
            text=Path(td)/'input.geo'
            text.write_text(geo)
            hpc=predict_2d_resources_many(str(text),[frequency],['VV','HH'],'meters',1000,n_angles=len(angles))
        output[case]=dict(panels=desktop['meshes'][0]['panels'],
                          desktop={v['polarization']:v['unknowns'] for v in desktop['meshes']},
                          hpc={p:hpc[frequency,label]['base_system_dofs'] for label,p in [('VV','TE'),('HH','TM')]})
        for backend in ('dense','compressed'):
            active={}
            reports={}
            original_layer=solver.solve_thin_layer_fields
            original_join=tl._continuous_oriented_mesh
            original_qual=qual.local_bulk_reference
            original_fields=solver._solve_fields
            original_sweep=sweep.solve
            original_lu=scipy.linalg.lu_factor
            original_estimate=solver._estimate_memory_gb
            outer={}

            def layer(mesh,k0,inc,pol,*a,**kw):
                row=reports[pol]=dict(incoming_nodes=len(mesh.nodes), elements=len(mesh.elements),
                    angles=list(map(float,inc)), planar_matrix_shapes=[], operator_lu_shapes=[], rhs=[], factor_solves=[])
                active.update(row=row,pol=pol)
                try:
                    answer=original_layer(mesh,k0,inc,pol,*a,**kw)
                    row['evidence_unknowns']=answer[3]['unknowns']
                    row['qualification_reported']=answer[3]['local_bulk_reference']['passed']
                    row['field_returned']=np.asarray(answer[1]).copy()
                    return answer
                finally:
                    active.clear()
            def join(mesh):
                oriented=original_join(mesh)
                active['row']['joined_nodes']=len(oriented.nodes)
                return oriented
            def qual_ref(*a,**kw):
                if not active:
                    return original_qual(*a,**kw)
                # The reference result is normally cached. Clear its in-process
                # memoization to observe the real work at every selected frequency.
                qual._local_reference.cache_clear()
                real_solve=np.linalg.solve
                def np_solve(matrix,rhs,**kwargs):
                    active['row']['planar_matrix_shapes'].append(list(matrix.shape))
                    return real_solve(matrix,rhs,**kwargs)
                with patch.object(np.linalg,'solve',np_solve):
                    return original_qual(*a,**kw)
            def estimate(*a,**kw):
                resources=kw.get('dense_resources') or {}
                if resources.get('formulation')=='thin_dielectric_layer' and kw.get('activate_memory_plan'):
                    if active:
                        active['row']['inner_memory_price']=kw['system_dofs']
                    else:
                        outer.setdefault('prices',[]).append(kw['system_dofs'])
                return original_estimate(*a,**kw)
            def fields(mesh,matrix,k0,inc,make_rhs,diagnostics,label,**kwargs):
                row=active['row']
                assert label=='thin dielectric layer'
                row.update(operator_shape=list(matrix.shape), operator_type=type(matrix).__name__)
                def rhs(batch):
                    v=make_rhs(batch)
                    row['rhs'].append(list(v.shape))
                    return v
                def solve_sweep(f,b,*a,**kw):
                    x=original_sweep(f,b,*a,**kw)
                    row['factor_solves'].append(dict(factor=type(f).__name__,rhs=list(b.shape),solution=list(x.shape)))
                    return x
                def dense_lu(m,*a,**kw):
                    row['operator_lu_shapes'].append(list(m.shape))
                    return original_lu(m,*a,**kw)
                with patch.object(sweep,'solve',solve_sweep),patch.object(scipy.linalg,'lu_factor',dense_lu):
                    return original_fields(mesh,matrix,k0,inc,rhs,diagnostics,label,**kwargs)
            with ExitStack() as hooks:
                for mod,name,fn in [(solver,'solve_thin_layer_fields',layer),(tl,'_continuous_oriented_mesh',join),
                        (qual,'local_bulk_reference',qual_ref),(solver,'_estimate_memory_gb',estimate),
                        (solver,'_solve_fields',fields)]:
                    hooks.enter_context(patch.object(mod,name,fn))
                with cpu_allocation_scope(1):
                    res=solver.solve_monostatic_rcs_2d(**args,execution_options=dict(opts,factorization=backend))
            output[case][backend]={'channels':reports,'outer_execution':outer}
            fields_out={}
            for label,pol in [('VV','TE'),('HH','TM')]:
                row=reports[pol]
                values=res['co_solved_samples'][label]
                samples=np.array([complex(v['rcs_amp_real'],v['rcs_amp_imag']) for v in values])
                theta=np.array([v['theta_inc_deg'] for v in values])
                assert np.array_equal(angles,theta)
                assert np.array_equal(row.pop('field_returned'), samples)
                dim=row['joined_nodes']*(2 if pol=='TE' else 1)
                assert dim==row['inner_memory_price']==row['evidence_unknowns']
                assert row['operator_shape']==[dim,dim]
                assert sum(x[1] for x in row['rhs'])==len(angles)
                assert all(x[0]==dim for x in row['rhs'])
                assert [r['rhs'] for r in row['factor_solves']]==row['rhs']
                assert all(r['rhs']==r['solution'] for r in row['factor_solves'])
                assert row['planar_matrix_shapes'] and all(s[-2:]==[2,2] for s in row['planar_matrix_shapes'])
                if backend=='dense':
                    assert [dim,dim] in row['operator_lu_shapes']
                fields_out[pol]=samples
            np.savez_compressed(out/f'{case}_{backend}.npz',angles_deg=angles,**fields_out)
            print(case,backend,output[case]['desktop'],[(p,r['operator_shape']) for p,r in reports.items()],flush=True)
    (out/'trace.json').write_text(json.dumps(output,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('checkout',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    run(a.checkout.resolve(),a.output.resolve())
