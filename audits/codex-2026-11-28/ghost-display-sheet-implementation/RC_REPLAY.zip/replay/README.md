# Additional execution checks

The two scripts are from the original candidate evidence archive. Run against an absolute checkout path with the standard GHOST environment. For the desktop script use QT_QPA_PLATFORM=offscreen. Use one OpenBLAS and OpenMP thread. Supply a new JSON file path as the second argument to each script.

The worker result matched the original baseline export JSON byte-for-byte. The thin layer script reproduced the 4,998-panel routing example using a fixed 24 GiB admission estimate. It constructs the hypothetical corrected forecast in its own process and performs no full solve at that size.
