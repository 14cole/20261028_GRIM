"""Verify all rows, all angle orders and fields, authored counts and new branch rejection."""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import numpy as np

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('replay', type=Path)
p.add_argument('claude', type=Path, help='results/rc directory at ced2243')
p.add_argument('out', type=Path)
args = p.parse_args()
def read(root, name):
    return json.loads((root/name).read_text())
summary = {'fixtures': {}, 'max_cross_host_peak_relative': 0., 'max_cross_host_absolute': 0.}
for label in ['main', 'rc']:
    name = 'sheet_rc_' + label + '.json'
    assert read(args.replay, name) == read(args.claude, name)
claude_sheetfix = read(args.claude, 'sheet_rc_sheetfix.json')
assert [dict(row, tree='rc') for row in claude_sheetfix] == read(args.replay, 'sheet_rc_rc.json')
for row in read(args.replay, 'sheet_rc_rc.json'):
    fixture, degree = row['fixture'], row['degree']
    unit = f'{fixture}_p{degree}'
    expected = (83*degree+1, 83*degree+11) if fixture=='hook_sheet' else (544*degree,544*degree)
    polar = dict(zip(('TE','TM'), expected))
    assert [row['planner_TE'],row['planner_TM']] == list(expected)
    assert [row['execution_TE'],row['execution_TM']] == list(expected)
    assert sorted(set(expected)) == row['factored_sizes']
    assert row['hpc_TE_then_TM'] == row['hpc_TM_then_TE'] == polar
    assert [row['hpc_TE_alone'],row['hpc_TM_alone']] == list(expected)
    record = {'factorized':row['factored_sizes'],'same_host_bit_identical':True,'cross_host':{}}
    with ExitStack() as stack:
        archives = {name:stack.enter_context(np.load(folder / f'{label}_{unit}.npz',allow_pickle=False))
                    for name,folder,label in (('original',args.claude,'main'),('intermediate',args.claude,'sheetfix'),
                    ('candidate',args.claude,'rc'),('fresh_base',args.replay,'main'),('fresh_candidate',args.replay,'rc'))}
        ref = archives['original']
        for field in ['angles_deg','TE','TM']:
            a = ref[field]
            assert a.shape == (72,) and np.all(np.isfinite(a))
            assert all(ref[field].tobytes()==archives[k][field].tobytes() for k in ('intermediate','candidate'))
            b = archives['fresh_base'][field]
            assert a.shape == b.shape and a.dtype == b.dtype and np.all(np.isfinite(b))
            assert b.tobytes() == archives['fresh_candidate'][field].tobytes()
            if field=='angles_deg':
                np.testing.assert_array_equal(a,b)
            else:
                delta=float(np.max(np.abs(b-a)))
                rel=delta/float(np.max(np.abs(a)))
                record['cross_host'][field]={'max_abs':delta, 'max_abs_relative_to_ref_peak':rel}
                summary['max_cross_host_peak_relative'] = max(summary['max_cross_host_peak_relative'],rel)
                summary['max_cross_host_absolute'] = max(summary['max_cross_host_absolute'],delta)
                assert rel < 1e-9, (unit, field, rel)
    summary['fixtures'][unit]=record
assert read(args.replay, 'sheet_unknowns_rc.json') == read(args.claude, 'sheet_unknowns_rc.json')
before,after = (read(args.replay,f'fork_{label}.json') for label in ('main','rc'))
for k,v in after.items():
    if k=='force_dense_solve' or k.endswith('HH') and 'VV' not in k or k=='desktop_TM':
        assert before[k] == v, k
    if k=='force_dense_solve' or k=='desktop_both' or 'VV' in k:
        assert 'TE sheet branching' in v['message'], k
        if k!='force_dense_solve':
            assert 'value' in before[k]
summary['seven_fixture_rows']=len(read(args.replay,'sheet_unknowns_rc.json'))
summary['complex_fields_per_tree']=len(summary['fixtures'])*2*72
summary['execution_check']='fresh baseline vs candidate plus all three archived revisions and the new branch test passed'
args.out.write_text(json.dumps(summary, indent=2)+'\n')
