# Impedance-sheet release verification

Claude's bent eleven-piece, two-impedance sheet and coated-cylinder control reproduced. We ran the unmodified `sheet_rc.py` in fresh Python processes on baseline `95f8719` and release candidate `6621db2`, with one BLAS and assembly thread. The middle commit's arrays were verified from Claude’s archive. On the candidate, the desktop and the four single-frequency HPC channel requests predicted TE / TM of **84 / 94, 167 / 177 and 250 / 260** on the bent sheet, matching the factorized sizes at P1, P2 and P3. Main's TE forecasts were respectively 94, 177 and 260. Coated-cylinder dimensions stayed 544, 1,088 and 1,632 in both channels.

Each revision solved 72 directions for two channels at three orders on two geometries, yielding 864 complex field samples per revision. Every complex sample and angle was bit-identical before and after on this host and on Claude's three archived revisions. The largest difference between our fresh arrays and Claude's arrays was 3.29e−13 of the peak of that fixture/order/polarization, or 3.07e−12 maximum absolute. The 21 records from Claude's seven secondary fixtures also reproduced exactly on the release candidate. These same-mesh comparisons test the compatibility of the planning change. They do not measure continuum discretization error.

An additional unsymmetric three-way, three-impedance junction tested the public planner. On main, forecast paths accepted the paired request before forced-Dense execution rejected the TE branch. On the candidate, desktop and both HPC planning paths rejected either paired ordering with the same execution diagnostic. TM-only remained admissible with the same dimensions on both revisions (15 with an explicit ungraded mesh, 31 with the HPC default). The HPC functions ran locally; cluster submission was outside this test.

## Replay

Use the solver's Python environment with NumPy and SciPy. The three original scripts from Claude's commit `ced2243a39a62bb5b220160f7110a7a58cc87f0c` are included byte-for-byte. Their Git blob IDs, as well as IDs for the original comparison arrays and reports, are in `upstream-blobs.json`. Place the three checkout paths in the variables below, with BASE and RC pointing at source trees and CLAUDE at the review branch. Execute the commands from this directory.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p new
GRIM_ROOT="$BASE" python sheet_rc.py main new
GRIM_ROOT="$RC" python sheet_rc.py rc new
GRIM_ROOT="$RC" python sheet_unknowns.py new/sheet_unknowns_rc.json
python check_branch.py "$BASE" new/fork_main.json
python check_branch.py "$RC" new/fork_rc.json
python compare.py new "$CLAUDE/audits/claude-2026-11-28/fresh-run-review/results/rc" new-summary.json
```

The supplied `replay/` directory holds all fresh fields, forecast records, branch diagnostics and dimensions. `summary.json` records per-case cross-host errors. No source edits, native rebuilds or scheduler submission were used.
