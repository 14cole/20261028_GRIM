"""Exercise the desktop and both public HPC paths with a branched impedance sheet."""
import argparse
from contextlib import nullcontext
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('checkout', type=Path)
parser.add_argument('out', type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.checkout.resolve() / 'tools' / 'GHOST'))
from ghost_backend.execution.options import execution_scope, validate_options
from ghost_backend.execution.selection import select_backend
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.hpc.scheduler import predict_2d_resources_many
from ghost_backend.twod.solver import solve_monostatic_rcs_2d_survey

geo = """Title: three-way three-material test
Segment: north 1
properties: 1 3 12 0 0
0.016 0.020 0.012 0.009
Segment: left 1
properties: 1 5 10 0 0
0.012 0.009 -0.013 -0.007
Segment: right 1
properties: 1 4 11 0 0
0.035 0.004 0.012 0.009
IBCS_Resistances:
10 constant 20 7 0 0
11 constant 50 -4 0 0
12 constant 75 -1 0 0
Dielectrics:
"""

def observe(func):
    try:
        return dict(value=func())
    except ValueError as exc:
        return dict(type=type(exc).__name__, message=str(exc))

opt = validate_options(dict(basis_order=1, mesh_strategy='global', factorization='automatic',
                            mesh_grading=False, blas_threads=1, assembly_threads=1))
query = dict(geometry_snapshot=build_geometry_snapshot(*parse_geometry(geo)),
             geometry_units='meters', frequencies_ghz=[1.0], elevations_deg=[-30., 0., 75.], solver_method='auto')
out = {}
for channel in (None, 'TM'):
    call = query if channel is None else dict(query, polarization=channel)
    def desktop():
        r = select_backend(call, opt, False)
        return {p['polarization']:p['unknowns'] for p in r['meshes']}
    out[f'desktop_{channel or "both"}'] = observe(desktop)
with TemporaryDirectory() as temp:
    path = Path(temp)/'junction.geo'
    path.write_text(geo)
    for scoped in (False, True):
        for channels in (['VV','HH'], ['HH','VV'], ['HH']):
            def hpc():
                with execution_scope(opt) if scoped else nullcontext():
                    results = predict_2d_resources_many(str(path), [1.], channels, 'meters', 1000)
                return {pol: r['system_dofs'] for (_,pol),r in results.items()}
            key = 'hpc_' + ('scoped' if scoped else 'default') + '_' + '_'.join(channels)
            out[key] = observe(hpc)
def execute():
    r = solve_monostatic_rcs_2d_survey(**query, execution_options=dict(opt, factorization='dense'))
    return {p: len(rows) for p, rows in r['co_solved_samples'].items()}
out['force_dense_solve'] = observe(execute)
args.out.write_text(json.dumps(out, indent=2) + '\n')
