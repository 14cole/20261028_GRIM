# Replay of Claude's release-candidate GUI checks

Claude's unmodified display driver and comparison script at `ced2243a39a62bb5b220160f7110a7a58cc87f0c` ran in fresh Python processes on shipped main `95f8719` and release candidate `6621db2`. Five reports cover the shuffled 53-frequency sweep on each checkout, the full small-case suite on each checkout, and the forced 1-byte fallback on the candidate. All three comparisons between revisions or fallback modes passed. A separate cross-host comparison against Claude's raw results matched every captured output and checkpoint-read count in all five JSONs. This includes every cell fingerprint, plot fingerprint, status string, saved export history, damage/retry result, post-export cleanup result, and numerical export digest present in these reports.

| Large shuffled sweep | Claude main / candidate | Codex main / candidate |
|---|---|---|
| Initial presentation time | 6.75 / 0.50 s | 9.97 / 0.59 s |
| Verified frequency loads | 1,484 / 53 | 1,484 / 53 |
| Sampled incremental peak RSS | 7.46 / 7.81 MiB | 6.46 / 7.57 MiB |
| Additional verified loads during exhaustive inspection | 53 / 53 | 53 / 53 |

The synthetic result contains 53 frequencies, 541 angles per frequency and both polarizations. Every one of the 286,730 formatted cells and all x/y points and labels for 106 curves fed the comparison fingerprints. The fixture used Linux, offscreen Qt and the production complete-run display path. The timed phase covered table/plot preparation, a forced draw, status and automatic-export history. It intercepted the final file writer. The small suite separately checked a real manual GRIM export and cleanup. Each host had one timed trial per variant, with other jobs on this replay host. Native Windows, display-server event latency, and numerical solve duration lie outside this measurement.

Reproduce with the GHOST GUI Python environment, using absolute paths for the three checkouts. The review checkout should be Claude's commit, main should be the baseline above, and the candidate should be its code-only commit above.

```sh
review="$CLAUDE_CHECKOUT/audits/claude-2026-11-28/fresh-run-review"
PYTHON=python bash replay.sh "$review/display" "$MAIN_CHECKOUT" "$CANDIDATE_CHECKOUT" ./replay-output
python compare_hosts.py "$review" ./replay-output ./replay-comparison.json
```

`cross-host.json` records the two hosts, exact script SHA-256 values, timings, memory and any cross-host discrepancies. The entire replay JSONs are under `output/`.
