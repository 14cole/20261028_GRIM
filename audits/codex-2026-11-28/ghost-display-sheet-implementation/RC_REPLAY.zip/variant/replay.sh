#!/usr/bin/env bash
set -eu
qa=$(realpath "$1")
main=$(realpath "$2")
candidate=$(realpath "$3")
output=$(realpath -m "$4")
py=${PYTHON:-python}
mkdir -p "$output"
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export MPLCONFIGDIR=${TMPDIR:-/tmp}/ghost-ced-display-variant-mpl XDG_CACHE_HOME=${TMPDIR:-/tmp}/ghost-ced-display-variant-xdg
"$py" "$qa/verify_display_variant.py" "$main" large "$output/main-large.json"
"$py" "$qa/verify_display_variant.py" "$candidate" large "$output/candidate-large.json"
"$py" "$qa/compare.py" "$output/main-large.json" "$output/candidate-large.json" --one-pass
"$py" "$qa/verify_display_variant.py" "$main" full "$output/main-small.json"
"$py" "$qa/verify_display_variant.py" "$candidate" full "$output/candidate-small.json"
"$py" "$qa/verify_display_variant.py" "$candidate" full "$output/fallback-small.json" --limit-bytes 1
"$py" "$qa/compare.py" "$output/main-small.json" "$output/candidate-small.json" --one-pass
"$py" "$qa/compare.py" "$output/main-small.json" "$output/fallback-small.json"
