"""Compare Claude's archived JSON evidence with a fresh replay of its same drivers."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('claude_review', type=Path)
parser.add_argument('replay_output', type=Path)
parser.add_argument('report', type=Path)
args = parser.parse_args()

def differences(a, b, prefix=''):
    if isinstance(a, dict) and isinstance(b, dict):
        for key in sorted(set(a) | set(b)):
            if key in ('seconds', 'incremental_peak_rss_mib'):
                continue
            yield from differences(a.get(key), b.get(key), '.'.join(filter(None, [prefix, key])))
    elif a != b:
        yield {'path': prefix, 'claude': a, 'replay': b}

report = {}
for slot in ('main-large', 'candidate-large', 'main-small', 'candidate-small', 'fallback-small'):
    original = json.loads((args.claude_review / 'results/display' / f'{slot}.json').read_text())
    replay = json.loads((args.replay_output / f'{slot}.json').read_text())
    old, new = original['results'], replay['results']
    delta = list(differences(old, new))
    report[slot] = {'replay_host': {k: replay[k] for k in ('host', 'numpy', 'python', 'pyside6')},
                    'claude_host': {k: original[k] for k in ('host', 'numpy', 'python', 'pyside6')},
                    'claude_presentation': old['complete']['presentation'],
                    'replay_presentation': new['complete']['presentation'],
                    'nonperformance_differences': delta}
scripts = [args.claude_review / 'display' / s for s in ['compare.py', 'verify_display_variant.py']]
report['script_sha256'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in scripts}
args.report.write_text(json.dumps(report, indent=2) + '\n')
for case, data in report.items():
    if case != 'script_sha256':
        print(case, [(r['path'], str(r['replay'])[:12]) for r in data['nonperformance_differences']])
if any(data['nonperformance_differences'] for case, data in report.items() if case != 'script_sha256'):
    raise SystemExit('Some captured outputs or read counts differ; see report.')
