# Real-size display allowance check

We generated 128 compact per-frequency records with both polarizations, on a shuffled frequency grid, with descending monostatic angles. These are deterministic synthetic data. The production checkpoint writer and loader encoded, indexed and verified the records. Each case drove the Qt completion slot on a new solver tab, with automatic export off, then forced a canvas draw. The existing 16 MiB allowance was left at its shipped value. The fixture skips per-frequency GRIM publication and performs no physics solve.

The independent oracle derived each row's source index from the original shuffled frequency and reversed angle order. It checked every index in the sorted table, every label and coordinate on the 256 plot curves, all four retained numeric columns when present, the status counts, and 35 formatted on-demand cells after actual Qt scroll and paint events at seven positions. An additional ownership check kept the result alive and verified that closing/destroying the tab released every prepared column.

The 2,048-angle grid reaches the cap exactly. Adding a single angle to each frequency/channel produces 256 additional rows. Times describe one Linux host and process per case, including a forced draw and without automatic export. Temporary sort, plotting and heap buffers fall outside the retained-column allowance. No native Windows or real monitor was used.

Run one checkout per fresh interpreter:

```sh
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python boundary.py /path/to/6621db2 2048 candidate-at.json
python boundary.py /path/to/6621db2 2049 candidate-over.json
python boundary.py /path/to/95f8719 2049 main-over.json
```

| Checkout | Polarized rows | Retained display columns | Verified reads during completion | Presentation seconds |
|---|---:|---:|---:|---:|
| Candidate, exactly at cap | 524,288 | 16,777,216 bytes | 128 | 2.30 |
| Candidate, over cap | 524,544 | 0 bytes | 2,560 | 38.20 |
| Main, same over-cap grid | 524,544 | 0 bytes | 2,560 | 37.22 |

All cases produced the expected sorted indices and 256 labeled curves, with zero maximum observed error in plotted dB against the independent formula. Six verified reads occurred when the live table opened and scrolled to the seven sampled positions. The fields remained accessible above the cap. The increased completion delay is user-visible, and the two over-cap trees performed the same number of reads. Each wall time is a single observation during shared-host work.

For a regular two-polarization monostatic grid with 361 directions, 726 complete frequencies fit the current allowance. The 727th crosses it. For 181 directions the corresponding counts are 1,448 and 1,449. These examples refer to display-row counts. They do not limit solver frequency or angle inputs. A further improvement could prepare presentation data in bounded frequency blocks within the current job. Its acceptance criteria should include correctness under corruption, full curve and sort parity, reads, peak RSS and time at and above the boundary.
