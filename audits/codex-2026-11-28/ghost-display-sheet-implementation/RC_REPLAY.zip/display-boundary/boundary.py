"""Replay the real current-view threshold with disk records and the normal GUI completion slot."""
import argparse
from collections import Counter
from contextlib import contextmanager
import gc
import json
import math
import os
from pathlib import Path
import platform
import sys
import tempfile
import time
import weakref
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "ghost-boundary-mpl"))
import numpy as np
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtWidgets import QApplication
import PySide6

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument("checkout", type=Path)
cli.add_argument("angles", type=int, choices=(2048, 2049))
cli.add_argument("output", type=Path)
args = cli.parse_args()
repo = args.checkout.resolve()
sys.path[:0] = [str(repo), str(repo / "tools/GHOST")]
from ghost_backend.execution.recovery import RecoveryRun
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.twod.samples import SampleTable, merge_tables
from ghost_backend.ui import result_table, solver

frequencies = 1 + np.arange(128) / 64
requested = frequencies[np.random.default_rng(20261128).permutation(len(frequencies))].tolist()
angles = -180 + np.arange(args.angles) * 360.0 / args.angles
requested_angles = angles[::-1].copy()
n = len(frequencies) * len(angles) * 2
labels = ["HH", "VV"]
c = 299792458.0

def linear(freq, pol, angle):
    return (.375 if pol == "HH" else .75) + freq / 16 + (angle + 180) / 1024

def log_display(val, freq):
    return 10 * np.log10((2 * np.pi * (freq * 1e9) / c) * val)

def plane(freq):
    by_pol = {}
    for pol in labels:
        val = linear(freq, pol, requested_angles)
        mag = np.sqrt(val * 8 * np.pi * freq * 1e9 / c)
        phase = np.radians(requested_angles)
        data = np.column_stack([np.full(len(angles), freq), requested_angles, requested_angles,
                                val, log_display(val, freq), mag * np.cos(phase), mag * np.sin(phase),
                                requested_angles, np.full(len(angles), 1e-12)])
        by_pol[pol] = dict(samples=SampleTable(data))
    channels, rows = merge_tables(by_pol)
    return dict(samples=rows, co_solved_samples=channels, solver="2d_monostatic_rcs",
                scattering_mode="monostatic", amplitude_convention="synthetic", polarizations=["VV","HH"],
                polarization_mapping={"VV":"TE", "HH":"TM"},
                _recovery_row_counts=dict(samples=2*len(angles), VV=len(angles), HH=len(angles)),
                rcs_linear_quantity="sigma_2d", rcs_log_unit="dBke",
                metadata=dict(geometry_units_in="meters", mesh_convergence_certified=False))

@contextmanager
def measured(out):
    counts = Counter()
    source = RecoveryRun.load
    def counted(run, f):
        counts[f] += 1
        return source(run, f)
    with patch.object(RecoveryRun, "load", counted):
        start = time.perf_counter()
        yield
        out.update(wall_s=time.perf_counter()-start, record_loads=sum(counts.values()),
                   frequencies_loaded=len(counts), loads_per_frequency=sorted(set(counts.values())))

def check_sorted_rows(model):
    # ResultRows presents VV source block then HH, retaining request-order frequencies; the Qt model
    # presents ascending frequencies, HH then VV, with increasing angles within each group.
    offsets = {f: i*len(angles) for i, f in enumerate(requested)}
    group = np.arange(len(angles)-1, -1, -1)
    written = 0
    for freq in frequencies:
        for label in labels:
            start = offsets[freq] + (len(requested)*len(angles) if label == "HH" else 0)
            np.testing.assert_array_equal(model.rows.indices[written:written+len(angles)], start+group)
            written += len(angles)
    assert written == len(model.rows.indices) == n

def check_plot(tab):
    curves = tab.canvas.ax.lines
    assert len(curves) == len(requested)*2
    worst = 0.
    for idx, curve in enumerate(curves):
        frequency, pol = frequencies[idx//2], labels[idx%2]
        expected = log_display(linear(frequency, pol, angles), frequency)
        assert curve.get_label() == f"{frequency:g} GHz, {pol}"
        np.testing.assert_array_equal(curve.get_xdata(), angles)
        np.testing.assert_allclose(curve.get_ydata(), expected, atol=3e-13, rtol=0)
        worst = max(worst, float(np.max(np.abs(curve.get_ydata()-expected))))
    return worst

def main():
    app = QApplication.instance() or QApplication([])
    geometry = build_geometry_snapshot(*parse_geometry((repo / "airfoil.geo").read_text()))
    metrics = dict(python=platform.python_version(), pyside=PySide6.__version__, numpy=np.__version__,
                   platform=platform.platform(), frequencies=len(requested), angles=len(angles), rows=n)
    tab = solver.SolverTab()
    tab.chk_export_after_solve.setChecked(False)
    with tempfile.TemporaryDirectory() as temp:
        run = RecoveryRun.create(temp, dict(geometry_snapshot=geometry, frequencies_ghz=requested,
            elevations_deg=requested_angles.tolist(), geometry_units="meters"), {}, "double", False)
        # Use real compact NPZ checkpoint encoder, manifest/header checks and decoded DiskSamples.
        # Skip the independent save-to-GRIM per-frequency conversion, outside this display check.
        for freq in reversed(requested):
            run.store.save(freq, plane(freq))
        result = run.result()
        assert result["metadata"]["run_recovery"]["completed"] == len(requested)
        metrics["completion"] = {}
        with measured(metrics["completion"]):
            tab._on_solver_finished(result, "")
            tab.canvas.draw()
        model = tab.result_table_model
        assert tab.last_result is result and model.rowCount() == n
        check_sorted_rows(model)
        metrics["largest_plot_db_error"] = check_plot(tab)
        metrics["status"] = tab.lbl_status.text()
        assert str(len(angles)) in metrics["status"] and str(len(requested)) in metrics["status"]
        cols = getattr(model.rows.rows, "_display_columns", {})
        metrics["retained_fields"] = list(cols.keys())
        metrics["retained_display_bytes"] = sum(col.nbytes for col in cols.values())
        cap = getattr(result_table, "_DISPLAY_COLUMN_LIMIT_BYTES", 0)
        expected_bytes = n * 32 if n*32 <= cap else 0
        assert metrics["retained_display_bytes"] == expected_bytes
        if expected_bytes:
            assert metrics["completion"]["record_loads"] == len(requested)
            # Check the entire retained view against original request order and numeric formula.
            pos = 0
            for pol in ("VV", "HH"):
                for f in requested:
                    sl = slice(pos, pos+len(angles))
                    np.testing.assert_array_equal(cols["frequency_ghz"][sl], f)
                    np.testing.assert_array_equal(cols["theta_inc_deg"][sl], requested_angles)
                    np.testing.assert_array_equal(cols["theta_scat_deg"][sl], requested_angles)
                    np.testing.assert_array_equal(cols["rcs_linear"][sl], linear(f, pol, requested_angles))
                    pos += len(angles)
        else:
            assert metrics["completion"]["record_loads"] > len(requested)
        col_weakrefs = [weakref.ref(v) for v in cols.values()]
        del cols
        metrics["interactive"] = {}
        with measured(metrics["interactive"]):
            tab.resize(1024, 768)
            tab.show()
            app.processEvents()
            for row_idx in [0, len(angles)-1, len(angles), n//2, n-1, 9*len(angles)+2, n//4+96]:
                index = model.index(row_idx, 0)
                tab.table_results.scrollTo(index)
                app.processEvents()
                f = frequencies[row_idx//(2*len(angles))]
                p = labels[(row_idx//len(angles))%2]
                a = angles[row_idx%len(angles)]
                v = linear(f, p, a)
                expected = [f"{f:.6g}", p, f"{a:.6g}", f"{v:.6e}", f"{log_display(v, f):.3f}"]
                actual = [model.data(model.index(row_idx, k)) for k in range(model.columnCount())]
                assert actual == expected, (row_idx, actual, expected)
            metrics["interactive"]["sampled_formatted_cells"] = 7*model.columnCount()
        tab.close()
        tab.deleteLater()
        del model, tab
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
        app.processEvents()
        gc.collect()
        assert all(r() is None for r in col_weakrefs)
        metrics["prepared_arrays_held_after_close"] = sum(r() is not None for r in col_weakrefs)
    args.output.write_text(json.dumps(metrics, indent=2)+"\n")
    print(json.dumps(metrics), flush=True)

if __name__ == "__main__":
    main()
