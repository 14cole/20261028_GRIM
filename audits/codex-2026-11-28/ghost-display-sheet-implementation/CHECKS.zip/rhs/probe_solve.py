"""Run one fresh paired solver job; select the implementation using PYTHONPATH."""
import argparse
import hashlib
import json
import platform
import resource
import threading
import time
import weakref
from pathlib import Path
from unittest.mock import patch

import numpy as np
import scipy
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.linalg import dense, refined_lu
from ghost_backend.twod import solver
from ghost_backend.twod.assembly import kernels, session
from ghost_backend.twod.formulations import dielectric


def input_body(panels, regional):
    # A smooth synthetic closed interface with both electric and magnetic loss.
    text = ["Title: allocation check"]
    bodies = 2 if regional else 1
    for i in range(bodies):
        angles = -2 * np.pi * np.arange(panels) / panels
        x = .09 * np.cos(angles) + .23 * i
        y = .07 * np.sin(angles)
        text.extend((f"Segment: component{i} 3", f"properties: 3 1 0 {1+i} 0"))
        points = np.column_stack((x, y))
        for a, b in zip(points, np.roll(points, -1, axis=0)):
            text.append(" ".join(f"{v:.17g}" for v in (*a, *b)))
    text.extend(("IBCS_Resistances:", "", "Dielectrics:"))
    for i in range(bodies):
        text.append(f"{i+1} {2.6+.3*i} -0.03 1.12 -0.01")
    return build_geometry_snapshot(*parse_geometry("\n".join(text) + "\n"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=["spool", "mixed", "mixed_p2", "compressed", "regional", "cancel"])
    parser.add_argument("prefix", type=Path)
    parser.add_argument("--panels", type=int, default=192)
    args = parser.parse_args()
    angles = np.linspace(-90., 90., 181).tolist()
    regional = args.case == "regional"
    shape = input_body(args.panels, regional)
    settings = dict(factorization="compressed" if args.case == "compressed" else "dense",
                    basis_order=2 if args.case == "mixed_p2" else 1, mesh_strategy="global", assembly_threads=1, blas_threads=1,
                    ram_budget_gib=2, angle_batch_size=90, rhs_compression="off",
                    dense_residual_storage="disk" if args.case == "spool" else "memory")
    rhs_calls = []
    weight_reads = []
    factor_events = []
    load_slots = []
    rhs_weak = []
    original_rhs = dielectric.rhs_many
    original_get = kernels._cached_loads
    original_factor = dense.DenseFactor.__init__
    event = threading.Event()
    early_abort = args.case == "cancel"

    def rhs(mesh, k0, theta):
        value = original_rhs(mesh, k0, theta)
        slot = session.current_session().plane_wave_loads
        loads = slot["latest"][2]
        rhs_calls.append(dict(shape=value.shape, shares_u=bool(np.shares_memory(value, loads["u"])),
                              shares_dn=bool(np.shares_memory(value, loads["dn"]))))
        rhs_weak.append(weakref.ref(value))
        return value

    def weights(*a, **kw):
        nonlocal early_abort
        result = original_get(*a, **kw)
        weight_reads.append(dict(hit=result is not None, signed=bool(result and result.get("u_negated"))))
        if early_abort:
            # Trigger an actual cancellation checkpoint after the first live load was looked up.
            early_abort = False
            active = session.current_session()
            load_slots.append(active.plane_wave_loads)
            event.set()
            active.checkpoint()
        return result

    def factor_init(factor, *a, **kw):
        original_factor(factor, *a, **kw)
        # The dense LU is lazy until solve. Keep a reference to its small diagnostics
        # dictionary; never keep the factor or its arrays alive.
        factor_events.append(factor.event)

    def solve():
        return solver.solve_monostatic_rcs_2d(shape, [1.07], angles, geometry_units="meters",
                solver_method="direct" if args.case != "compressed" else "auto",
                compute_condition_number=True, strict_quality_gate=True, abort_event=event,
                execution_options=settings)

    cancel_clean = None
    started = time.monotonic()
    with patch.object(dielectric, "rhs_many", rhs), patch.object(kernels, "_cached_loads", weights), \
            patch.object(dense.DenseFactor, "__init__", factor_init), cpu_allocation_scope(1), \
            refined_lu.linear_precision("mixed" if args.case.startswith("mixed") else "double"):
        if early_abort:
            shared = session.AssemblySession()
            shared.abort_event = event
            with session._SESSION.override(shared):
                try:
                    solve()
                except InterruptedError:
                    pass
                else:
                    raise AssertionError("cancellation was not honored")
                cancel_clean = bool(len(load_slots) == 1 and load_slots[0] == {} and shared.pending is None
                                    and all(ref() is None for ref in rhs_weak))
                assert cancel_clean
                # Same assembly session and same arguments. The restarted solve must match.
                event.clear()
                out = solve()
        else:
            out = solve()

    elapsed = time.monotonic() - started
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024  # Linux
    meta = out["metadata"]
    fields = {}
    for pol in ("VV","HH"):
        rows = out["co_solved_samples"][pol]
        assert [r["theta_inc_deg"] for r in rows] == angles
        fields[pol] = np.array([complex(r["rcs_amp_real"],r["rcs_amp_imag"]) for r in rows])
        assert np.all(np.isfinite(fields[pol]))
    np.savez_compressed(args.prefix.with_suffix(".npz"), angles=angles, **fields)
    if regional:
        assert not rhs_calls and not any(x['signed'] for x in weight_reads)
    else:
        success_calls = rhs_calls[1:] if args.case == "cancel" else rhs_calls
        assert [x["shape"][1] for x in success_calls] == [90,90,1,90,90,1], rhs_calls
        assert all(x["shares_dn"] == x["shares_u"] for x in rhs_calls)
    assert meta["quality_gate"]["passed"]
    assert bool(meta["compressed_factors"]) == (args.case == "compressed")
    backend = {p:m.get("linear_backend") for p,m in meta["channel_metadata"].items()}
    storage = [e.get("residual_storage") for e in factor_events]
    if args.case == "spool":
        assert storage == ["disk","disk"], storage
    if args.case.startswith("mixed"):
        assert all(v == "cpu_mixed_lu" for v in backend.values()), backend
    result = dict(case=args.case, python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                  platform=platform.platform(), panel_count=meta["panel_count_max"], unknowns=meta["dense_largest_system"],
                  residual_max=meta["residual_norm_max"], passed=True, backend=backend, storage=storage,
                  rhs_calls=rhs_calls, weight_reads=weight_reads, cancel_cleanup=cancel_clean,
                  released_rhs=all(ref() is None for ref in rhs_weak), seconds=elapsed, peak_rss_bytes=peak,
                  field_hashes={p:hashlib.sha256(a.tobytes()).hexdigest() for p,a in fields.items()})
    assert result["released_rhs"]
    args.prefix.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
