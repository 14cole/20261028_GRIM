# Dielectric right-hand-side allocation follow-up

The isolated prototype saves 22.50 MiB of live allocation during setup of an 8,192-unknown, 180-column batch. We found no material whole-job peak reduction in seven smaller Linux cases. The largest full test, at 1,536 unknowns, measured 142.14 MiB peak RSS on the baseline and 142.10 MiB on the prototype. Treat this as a bounded per-batch opportunity. Keep the present admission estimate until measurements near the constraint support changing it.

## What ran

We staged the two original trial edits in a private copy of the shipped GHOST directory from main at `95f8719`. One moves a load lookup ahead of a redundant geometry-array constructor. The other lets the single-dielectric formulation use the two halves of its batch RHS as the projection weights, with compensation for the sign on the upper half. The original lookup in the other formulations keeps its own storage. All scratch imports used fresh processes, source-only copies of both variants, one BLAS and assembly thread, a 2 GiB solver budget, and the shipped Linux kernels. The CPU was an AMD EPYC 7763, with a four-core-equivalent quota and a 16 GiB cgroup maximum. Peak RSS includes imports and solve components. Each case and implementation ran once and host load varied. Fields and allocation counts are the basis for the conclusions.

Every full job ran the public paired 2D solver on 181 explicitly supplied directions from −90° through 90°. Each single-dielectric polarization produced RHS batches of 90, 90 and 1. The two-channel complex arrays, angle ordering and reported maximum residual matched exactly between versions on all seven cases. Each arm passed the production discrete quality gate. The 14 channel comparisons assess numerical equivalence to the baseline on these inputs.

| Full job | Unknowns per channel | Signed projections in prototype | Baseline / trial peak RSS, MiB |
|---|---:|---:|---:|
| Dense double P1, residual on disk | 384 | 12 | 102.74 / 102.69 |
| Dense mixed P1 | 384 | 0 | 102.77 / 102.66 |
| Dense mixed P2 | 768 | 12 | 115.53 / 116.42 |
| Compressed P1 | 384 | 12 | 102.89 / 102.77 |
| Dense double, two distinct dielectric regions | 768 | 0 | 112.55 / 112.75 |
| Cancel during projection, restart in same session | 384 | 13 including first interrupted projection | 105.06 / 104.96 |
| Dense double P1, residual on disk, larger mesh | 1,536 | 12 | 142.14 / 142.10 |

We confirmed actual disk storage for both Dense factors in each spooled job, actual mixed LU for both mixed cases, and presence of the Compressed factor in its case. The mixed-P1 path independently projects its fields through the quadrature routine and performs zero lookups of the prepared weights in both versions. The mixed-P2 case uses both signed weights. The regional case created no single-dielectric RHS. The cancellation set the real abort event at the first lookup and called the session checkpoint. The unreferenced arrays were collected and the session’s retained matrix and batch load slot cleared. A subsequent solve in that same session matched a clean disk-backed solve, including all 362 complex samples, in each version.

We also replayed the prior 4,096-panel stage-only check. The RHS and both projected fields matched exactly by SHA-256. Thirteen matched projections performed 13 geometry repacks in shipped code and zero in the trial. A different-frequency and different-angle request deliberately missed, took one geometry pass in each implementation and produced the same field. Live traced allocations following RHS construction fell from 45.01 to 22.51 MiB and the RHS construction peak fell from 48.81 to 28.85 MiB. The isolated additional peak for matched projection fell from 888,288 to 8,928 bytes. The stage-only fixture allocates a deterministic density and performs no factorization.

## Next decision

1. The geometry-lookup reordering can be reviewed independently and has no new array ownership contract. Verify prepared and unprepared bistatic projections and angle, mask and frequency misses before promoting that small edit.
2. For the signed views, have Claude independently check the allocation and cancellation results and inspect every solver that consumes the RHS for in-place writes. The current scaled-LU solve writes into a fresh divided RHS. Mixed P1 also suggests that a route known to bypass the cached projector could omit producing its unused weights. This would need separate coverage of the legacy projection path.
3. For a desktop capacity claim, compare full jobs near a real process or job-memory limit, in reversed order with repeats, and record the stage that sets peak RAM. The avoided payload is 16 bytes × unknowns × active RHS columns on eligible batches. Actual admission, wall time and peak RSS can be governed by factorization or other stages. These runs cover CPU execution on Linux. Hardware GPU and native Windows runs remain open.

## Replay

With the solver’s Python dependencies installed on Linux, run this from the evidence directory. The driver creates and cleans up both temporary source copies and compares every stored complex field value. Scripts and JSON store absolute byte counts. Each NPZ includes all angles and both channels for its own run.

```bash
python replay.py /path/to/checkout/tools/GHOST /tmp/ghost-rhs-results
```

[Raw summary](raw/summary.json)
