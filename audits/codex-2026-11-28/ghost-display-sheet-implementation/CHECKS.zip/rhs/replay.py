"""Compare public fields and stage allocations in independent fresh processes on Linux."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ghost_source", type=Path, help="Baseline checkout's tools/GHOST directory")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    scripts = Path(__file__).resolve().parent
    args.output.mkdir(exist_ok=True, parents=True)
    result = {}
    with tempfile.TemporaryDirectory() as tmp:
        baseline = Path(tmp) / "base"
        shutil.copytree(args.ghost_source.resolve(), baseline, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        trial = Path(tmp) / "solver"
        subprocess.run([sys.executable, scripts/"make_trial.py", baseline, trial], check=True)
        for idx, case in enumerate(["spool", "mixed", "mixed_p2", "compressed", "regional", "cancel", "larger_spool", "stage"]):
            # Alternate version order. Elapsed times and peaks are descriptive only.
            for variant, source in ([("base", baseline), ("trial", trial)][::(-1 if idx % 2 else 1)]):
                env = dict(os.environ, PYTHONPATH=str(source), OPENBLAS_NUM_THREADS="1",
                           OMP_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
                prefix = args.output / f"{variant}-{case}"
                if case == "stage":
                    cmd = [scripts/"wave_load_probe.py", prefix.with_suffix(".json")]
                elif case == "larger_spool":
                    cmd = [scripts/"probe_solve.py", "spool", prefix, "--panels", "768"]
                else:
                    cmd = [scripts/"probe_solve.py", case, prefix]
                subprocess.run([sys.executable, *cmd], check=True, env=env)
            base, candidate = [(args.output / f"{a}-{case}") for a in ("base", "trial")]
            b, c = [json.loads(p.with_suffix(".json").read_text()) for p in (base, candidate)]
            if case == "stage":
                assert b["field_checks"] == c["field_checks"]
                assert b["kernel_paths"]["miss"] == c["kernel_paths"]["miss"] == 1
                result[case] = {k: [b[k],c[k]] for k in ("rhs_traced_live","rhs_traced_peak",
                        "projection_traced_peak","rhs_shares_dn","rhs_shares_u","kernel_paths")}
                continue
            with np.load(base.with_suffix(".npz")) as a, np.load(candidate.with_suffix(".npz")) as t:
                assert a.files == t.files and all(np.array_equal(a[k], t[k]) for k in a.files)
            assert b["residual_max"] == c["residual_max"] and b["field_hashes"] == c["field_hashes"]
            assert all(not x["signed"] for x in b["weight_reads"])
            assert (case not in ("regional","mixed")) == any(x["signed"] for x in c["weight_reads"])
            result[case] = dict(bit_equal=True, unknowns=b["unknowns"], residual_max=b["residual_max"],
                    peak_rss_bytes=[b["peak_rss_bytes"],c["peak_rss_bytes"]],
                    seconds=[b["seconds"],c["seconds"]], hits=sum(x["signed"] for x in c["weight_reads"]))
        # A same-session cancellation/restart should also agree with the clean double-precision disk arm.
        for variant in ("base", "trial"):
            with np.load(args.output / f"{variant}-cancel.npz") as a, np.load(args.output / f"{variant}-spool.npz") as b:
                assert all(np.array_equal(a[k], b[k]) for k in a.files)
    (args.output / "summary.json").write_text(json.dumps(result,indent=2)+"\n")


if __name__ == "__main__":
    main()
