# Separate follow-up for thin dielectric layers

Thin dielectric midsurfaces and ordinary impedance sheets are both drawn with TYPE 1. They use separate formulations. A homogeneous thin-layer solve joins the geometrical endpoints of adjacent sections after the generic interface mesh is built. Desktop and HPC planning, and the initial admission check inside the executing solver, price the earlier mesh. A joint that splits the generic interface mesh by name contributes an extra node to that forecast.

The script ran against main at `95f87190956de9197f0d021b0497772818c6f532` and against the proposed impedance-sheet correction. Forecasts, complex fields and errors agreed across checkouts after excluding the machine's changing available-memory reading. Raw output contains every returned complex sample. Each small solve used 1 GHz, 3 angles, explicit panels, meters, a uniform 10 µm layer and one thread.

| Thin-layer case | Desktop and HPC plan TE / TM | Executing Dense and Compressed |
|---|---:|---|
| 3 named contiguous sections, 9 panels, electric contrast, P1 | 24 / 12 | 20 / 10. Both returned all 6 fields. |
| Same, electric and magnetic contrast | 24 / 24 | 20 / 20 |
| Same, zero contrast | 0 / 0 | 0 / 0, all fields zero |
| Same, certified Automatic mesh | P1 base 24 / 12 and P1 fine 36 / 18 | Certification returned P1 fine fields at 32 / 16 |
| Same, explicit P2 or P3 | P2 42 / 21 or P3 60 / 30 | Both reject unsupported order before producing fields |
| 3-arm junction, P1 | 24 / 12 | Both reject the unsupported thin-layer junction |
| 2 sections, 4,998 panels, 180 directions, P1, 24 GiB admission budget | 10,000 / 5,000, selects Compressed | Forecast-only trial with the actual physical midsurface yields 9,998 / 4,999 and selects Dense |

The threshold trial replaced only the geometry supplied to the resource-pricing function in the test process. The fixture used homogeneous coefficients. It did not allocate or solve the 4,998-panel system, measure RSS, or evaluate execution speed. The maximum absolute Dense/Compressed complex-field difference across the successful small checks was 8.4e-20. This compares the two implementations and does not validate the physical approximation against a bulk-layer reference.

Automatic mesh certification already excludes thin layers from hp candidates and refines P1. The concern for supported P1 runs is unnecessary reservations or a different backend near an admission cutoff. These cases overpredicted the physical dimensions. Larger-system storage and admissibility involve further estimates, so these observations do not establish bounds on host RAM. Explicit higher order and branching still produce an error, but only after the planner reports a usable system.

## Suggested independent follow-up

1. Add a shared preparation step for the P1 thin-layer midsurface. Use the same endpoint welding, orientation, element ordering and unsupported-junction test at planning and execution. Reject explicitly requested P2/P3 before a forecast or a submission succeeds.
2. Price the *projected* mesh through automatic selection, desktop and HPC estimates and each executing memory gate. Preserve frequency- and polarization-specific physical coefficients, zero-contrast analytic handling, 1/2-block projections and any necessary reordering of element information. Compressed pilot sampling, hierarchical coordinates, and the actual assembly should measure the same mesh. A scalar correction to the DOF counter would leave these paths inconsistent.
3. Check one named section versus several in both drawing directions, disconnected components, smooth closed layers, invalid junctions, loss, zero/electric/magnetic contrast, fixed-frequency meshes and both certified phases. Compare full complex fields, rejection timing, forecasted vs assembled shapes and in-process peak memory before changing admission behavior. Retain the 4,998-panel forecast as a boundary control.

Reproduce separately on main and the implementation branch in a Python environment with the GHOST dependencies.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_thin_projection.py /path/to/checkout run.json
```

The assertions record the present deficiency on those two checkouts. Update the expected projected dimensions and earlier rejection conditions when validating a future repair.
