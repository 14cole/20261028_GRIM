"""Compare planner and executing thin-layer meshes on one physical straight screen."""
import argparse
import json
import sys
from contextlib import nullcontext
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch


def thin_geo(names=3, panels=3, branch=False, dielectric='3.0 -0.02 1 0'):
    pieces = []
    for i in range(names):
        pieces.append([f"Segment: section{i} 1", f"properties: 1 {panels} 10 0 0",
                       f"{.003*i:.9f} 0 {.003*(i+1):.9f} 0"])
    if branch:
        pieces.append(["Segment: branch 1", f"properties: 1 {panels} 10 0 0", ".003 0 .003 .003"])
    return "\n".join(["Title: thin layer planning control", *(v for p in pieces for v in p),
                      "IBCs:", "10 thin_dielectric 0.00001 2", "Dielectrics:", "2 " + dielectric]) + "\n"


def run(checkout):
    sys.path.insert(0, str(checkout/'tools/GHOST'))
    from ghost_backend.hpc.scheduler import predict_2d_resources_many
    from ghost_backend.twod import solver
    from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
    from ghost_backend.execution.options import execution_scope, validate_options
    from ghost_backend.execution import selection
    from ghost_backend.twod.formulations.thin_layer import _continuous_oriented_mesh
    from ghost_backend.twod.preparation import preparation_scope

    def config(degree, strategy, backend="automatic"):
        return validate_options(dict(factorization=backend, mesh_strategy=strategy,
                                    basis_order=degree, mesh_grading=False, blas_threads=1, assembly_threads=1))

    def params(text, angles):
        return dict(geometry_snapshot=build_geometry_snapshot(*parse_geometry(text)), geometry_units="meters",
                    frequencies_ghz=[1.], elevations_deg=angles)

    def forecast(call, options, certified=False):
        with preparation_scope():
            p = selection.select_backend(call, options, certified)
        return dict(gib=p['admission_budget_gib'], selected=p['selected'],
                    mesh=[{k:r[k] for k in ('unknowns', 'polarization','polynomial_degree','phase','panels')}
                          for r in p['meshes']])

    original = solver._dense_formulation_resources
    def trial(mesh, infos, pol, *args, **kwargs):
        # Investigation only, homogeneous P1 fixture; preserve every other planner step.
        # All sections have identical physical material and parameters.
        assert all(i.bc_kind == "thin_layer" for i in infos)
        m = _continuous_oriented_mesh(mesh)
        return original(m, infos, pol, *args, **kwargs)

    result = {}
    with TemporaryDirectory() as folder:
        path = Path(folder)/'fixture.geo'
        for name, text, degree, strategy in [
                ('p1',thin_geo(),1,'global'), ('p2',thin_geo(),2,'global'), ('p3',thin_geo(),3,'global'),
                ('automatic_mesh',thin_geo(),1,'adaptive'),
                ('p1_y',thin_geo(names=2,branch=True),1,'global'),
                ('both_contrast',thin_geo(dielectric='2.0 0 1.3 0'),1,'global'),
                ('transparent',thin_geo(dielectric='1 0 1 0'),1,'global')]:
            path.write_text(text)
            call = params(text, [-60.,0.,60.])
            options = config(degree,strategy)
            row = result[name] = {}
            certified = strategy == 'adaptive'
            row['desktop'] = forecast(call,options,certified)
            with execution_scope(options):
                hpc = predict_2d_resources_many(str(path), [1.], ['VV','HH'], 'meters', 1000,
                    fine_factor=1.5 if certified else 1., n_angles=3)
                row['hpc'] = {channel:{k:hpc[1.,channel][k] for k in (
                    'base_polynomial_degree','base_system_dofs','fine_polynomial_degree','fine_system_dofs')}
                    for channel in ['VV','HH']}
            for backend in ('dense','compressed'):
                public = solver.solve_monostatic_rcs_2d_certified if certified else solver.solve_monostatic_rcs_2d_survey
                try:
                    solve = public(**call, execution_options=config(degree,strategy,backend))
                except (ValueError,RuntimeError) as err:
                    row[backend] = dict(error_type=type(err).__name__,error=str(err))
                else:
                    metadata = solve['metadata']
                    row[backend] = dict(thin_unknowns={k:[v['unknowns'] for v in seq]
                        for k,seq in metadata['thin_layer'].items()},
                        field={k:[[r['rcs_amp_real'],r['rcs_amp_imag']] for r in seq]
                               for k,seq in solve['co_solved_samples'].items()})
            if name == 'p1':
                assert row['desktop']['mesh'][0]['unknowns'] == 24
                assert row['dense']['thin_unknowns'] == {'VV':[20],'HH':[10]}
            if name in ('p2','p3'):
                assert 'qualified linear basis' in row['dense']['error']

        call = params(thin_geo(names=2,panels=2499), list(range(-90,90)))
        options = config(1,'global')
        # Pin admission to available headroom typical of a 32 GiB host and obtain equal-condition choices.
        with patch.object(solver,'_solve_memory_limit_gb',return_value=24.):
            for mode, ctx in [('production',nullcontext()),('trial_projected',patch.object(solver,'_dense_formulation_resources',trial))]:
                with ctx:
                    result.setdefault('threshold_forecast_only',{})[mode] = forecast(call, options)
    return result


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument('checkout',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    data=run(args.checkout.resolve())
    args.output.write_text(json.dumps(data,indent=2)+'\n')
