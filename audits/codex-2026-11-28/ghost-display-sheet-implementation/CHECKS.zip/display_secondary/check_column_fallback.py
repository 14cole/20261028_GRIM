"""Exercise the bounded display view against verified frequency files on disk."""
import gc
import json
import sys
import tempfile
import weakref
from pathlib import Path
from unittest.mock import patch

import numpy as np

checkout = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(checkout), str(checkout / "tools/GHOST")]
from ghost_backend.execution.recovery import DiskSamples, FrequencyReader, RecoveryRun
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.ui import result_table, solver
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtWidgets import QApplication
from ghost_backend.twod.samples import SampleTable, FIELDS

def check():
    snapshot = build_geometry_snapshot(*parse_geometry((checkout / "airfoil.geo").read_text()))
    frequencies = [4., 2., 5.]
    report = {}
    with tempfile.TemporaryDirectory() as directory:
        run = RecoveryRun.create(Path(directory), dict(geometry_snapshot=snapshot, geometry_units="meters",
            frequencies_ghz=frequencies, elevations_deg=[0.]), {}, "double", False)
        counts = {}
        for i, f in enumerate(frequencies):
            labels = np.array(["VV"]*(i+1) + ["HH"]*(4-i))
            count = len(labels)
            array = np.arange(count * len(FIELDS), dtype=float).reshape(count, len(FIELDS)) + 1000*i
            array[:, 0] = f
            table = SampleTable(array, labels={"polarization":labels})
            run.store.save(f, {"samples":table, "co_solved_samples":{"VV":[], "HH":[]},
                               "solver":"2d_monostatic_rcs", "metadata":{}})
            counts[f] = {"VV":i+1, "HH":4-i, "samples":count}
        reader = FrequencyReader(run)
        result = {"co_solved_samples":{p: DiskSamples(reader, frequencies, counts, p) for p in ("VV","HH")}}
        with patch.object(run, "load", wraps=run.load) as load:
            view = result_table.ResultRows.for_display(result)
            assert [c.args[0] for c in load.call_args_list] == frequencies
        expected = list(result_table.ResultRows(result))
        for key in result_table._DISPLAY_FIELDS:
            np.testing.assert_array_equal(view.column(key), [r[key] for r in expected])
        report["unequal_channel_rows"] = [len(s) for s in result["co_solved_samples"].values()]
        app = QApplication.instance() or QApplication([])
        tab = solver.SolverTab()
        tab._populate_results_table(result)
        column = weakref.ref(tab.result_table_model.display_rows(result)._display_columns["rcs_linear"])
        tab.close()
        tab.deleteLater()
        del tab
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
        app.processEvents()
        gc.collect()
        assert column() is None
        report["widget_destruction_released_columns_with_result_alive"] = True
        cap = len(expected)*4*np.dtype("float64").itemsize
        for allowance, expected_columns in ((cap, True), (cap-1, False)):
            with patch.object(result_table, "_DISPLAY_COLUMN_LIMIT_BYTES", allowance):
                assert bool(result_table.ResultRows.for_display(result)._display_columns) is expected_columns
        report["budget_boundary"] = cap
        with (patch.object(result_table.np, "empty", side_effect=MemoryError("simulated optional allocation")),
              patch.object(run, "load", wraps=run.load) as load):
            fallback = result_table.ResultRows.for_display(result)
            assert not fallback._display_columns and not load.call_count
        for key in result_table._DISPLAY_FIELDS:
            np.testing.assert_array_equal(fallback.column(key), [r[key] for r in expected])
        report["allocation_failure_falls_back"] = True
        # A verified file can contain an extension schema. The old default for an absent
        # numeric field depends on the calling operation; retain both meanings.
        f = frequencies[-1]
        rows = [{"frequency_ghz":f, "polarization":label} for label in ["VV"]*3 + ["HH"]*2]
        run.store.save(f, {"samples":rows, "co_solved_samples":{"VV":[], "HH":[]}, "metadata":{}})
        reader.frequency, reader.value = None, None
        extension = result_table.ResultRows.for_display(result)
        assert not extension._display_columns
        for default in (-12., 4.):
            np.testing.assert_array_equal(extension.column("rcs_linear", default),
                [row.get("rcs_linear", default) for row in extension])
        report["extension_with_missing_column_falls_back"] = True
        # The default reader may already have this same one-frequency value. Preparation
        # must check the disk record again; its published digest detects intervening damage.
        one = {"co_solved_samples":{p:DiskSamples(reader, [f], counts, p) for p in ("VV","HH")}}
        reader.read(f)
        path = run.store._path(f)
        path.write_bytes(path.read_bytes() + b"bad")
        try:
            result_table.ResultRows.for_display(one)
        except OSError as exc:
            report["corrupt_even_if_reader_preloaded"] = str(exc)
        else:
            raise AssertionError("corrupt record accepted")
    return report

if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
