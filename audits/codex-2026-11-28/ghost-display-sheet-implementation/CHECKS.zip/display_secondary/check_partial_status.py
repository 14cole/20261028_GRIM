"""Pass a partial RecoveryRun and legacy checkpoint metadata through the finished Qt slot."""
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "ghost-display-audit-mpl"))
import numpy as np
from PySide6.QtWidgets import QApplication

checkout = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(checkout), str(checkout / "tools/GHOST")]
from ghost_backend.execution.recovery import RecoveryRun
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.twod.samples import SampleTable, merge_tables
from ghost_backend.ui.solver import SolverTab

def deliver(tab, result, completed, requested, stale=False):
    tab.chk_export_after_solve.setChecked(True)
    tab._pending_solve_context = {"geometry_stale": stale}
    with patch.object(tab, "_export_result_files") as writer:
        tab._on_solver_finished(result, "")
        writer.assert_not_called()
    msg = tab.lbl_status.text()
    assert f"PARTIAL RESULT ({completed}/{requested} frequencies)" in msg, msg
    assert "Data for the remaining frequencies are unavailable" in msg
    assert "Checkpoint storage failed" not in msg and "were not solved" not in msg
    assert ("Use Export Last Result" in msg) == (not stale)
    assert tab.btn_export.isEnabled() == (not stale)
    assert tab.progress.value() == int(100*completed/requested)
    return {"status":msg, "percent":tab.progress.value(), "automatically_exported":False}

app = QApplication.instance() or QApplication([])
tab = SolverTab()
snapshot = build_geometry_snapshot(*parse_geometry((checkout / "airfoil.geo").read_text()))
requested = [4., 2., 7., 6., 5., 1., 3.]
completed = [4., 7., 5., 3.]
with tempfile.TemporaryDirectory() as folder:
    run = RecoveryRun.create(Path(folder), dict(geometry_snapshot=snapshot, geometry_units="meters",
        frequencies_ghz=requested, elevations_deg=[0.]), {}, "double", False)
    for f in completed:
        a = np.array([[f,0.,0.,1.,0.,1.,0.,0.,0.]])
        channels, rows = merge_tables({pol:dict(samples=SampleTable(a.copy())) for pol in ("VV","HH")})
        run.store.save(f, dict(samples=rows, co_solved_samples=channels, metadata={},
            solver="2d_monostatic_rcs", scattering_mode="monostatic", _recovery_row_counts={"VV":1,"HH":1,"samples":2}))
    partial = run.result()
    assert "frequency_checkpoints" not in partial["metadata"]
    reports = {"recovery":deliver(tab, partial, 4, 7)}
    legacy = dict(samples=list(partial["samples"]), metadata=dict(partial_result=True,
        requested_frequency_count=11, frequency_checkpoints=dict(completed=4)))
    reports["legacy"] = deliver(tab, legacy, 4, 11)
    # Current metadata determines both counts even if old counters are also present.
    partial["metadata"].update(requested_frequency_count=11, frequency_checkpoints=dict(completed=2))
    reports["both_formats_stale"] = deliver(tab, partial, 4, 7, stale=True)
tab.close()
print(json.dumps(reports, indent=2))
