"""Solve two frequencies through the desktop worker and check the finished slot, final GRIM and release."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("checkout", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
repo = args.checkout.resolve()
sys.path[:0] = [str(repo / "tools/GHOST"), str(repo)]

import numpy as np
from PySide6.QtWidgets import QApplication
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.ui import solver

def run(app, base, mode):
    tab = solver.SolverTab()
    context = {"uses_geometry_tab": True, "geometry_stale": False}
    tab._pending_solve_context = context
    source = "fixture.geo"
    if mode == "bor":
        body = repo / "tools/GHOST/ghost_backend/geometry/geometries/BOR/pec_cylinder_r4_h10_in.geo"
        geo = build_geometry_snapshot(*parse_geometry(body.read_text()))
        units = "inches"
        frequencies = [.18, .16]
        angles = [30., 60., 90.]
        context.update(solver_kind="bor", snapshot=geo, units=units,
                       radar_grid=dict(azimuths_deg=[0.], elevations_deg=[0., 30., 60.],
                                       axis_az_deg=0., axis_el_deg=90., roll_deg=0.))
    else:
        points = [(i * .004, (i % 2) * .0008) for i in range(5)]
        lines = ["Title: connected sheet"]
        for index, (a, b) in enumerate(zip(points, points[1:])):
            lines.extend([f"Segment: part_{index} 1", "properties: 1 2 10 0 0",
                          f"{a[0]} {a[1]} {b[0]} {b[1]}"])
        geo = build_geometry_snapshot(*parse_geometry("\n".join(lines + ["IBCS_Resistances:", "10 constant 90 -20 0 0", "Dielectrics:"])))
        units = "meters"
        frequencies = [1.1, .97]
        angles = [50., -20., 5.]
    export = base / (mode + ".grim")
    tab.edit_output.setText(str(export))
    errors, published, result_capture = [], [], []
    worker = solver._SolveWorker(
        geo, source, str(base), frequencies, angles, units, {}, mesh_certification=False, cfie_alpha=0.5 if mode == "bor" else 0.,
        solver_method="direct" if mode == "bistatic" else "auto",
        execution_options=dict(factorization="dense" if mode == "bistatic" else "automatic", basis_order=1,
                               mesh_strategy="global", mesh_grading=False, blas_threads=1, assembly_threads=1),
        solver_kind="bor" if mode == "bor" else "2d",
        scattering_mode="bistatic" if mode == "bistatic" else "monostatic",
        observation_angles=[17., -32., 72.] if mode == "bistatic" else None,
        recovery_root=str(base / "recovery"), recovery_context=context)
    worker.error.connect(errors.append)
    worker.canceled.connect(errors.append)
    worker.finished.connect(lambda result, path: result_capture.append((result, path)))
    tab.files_exported.connect(lambda paths, kind: published.extend(paths))
    worker.run()
    assert not errors and len(result_capture) == 1, errors
    folder = worker.recovery.directory
    result, path = result_capture.pop()
    zero_dialog = lambda *args: (_ for _ in ()).throw(AssertionError(str(args[1:])))
    with patch.object(solver.QMessageBox, "warning", zero_dialog), patch.object(solver.QMessageBox, "critical", zero_dialog):
        tab._on_solver_finished(result, path)
    assert published and "Exported" in tab.lbl_status.text(), tab.lbl_status.text()
    table = tab.result_table_model
    samples = {key: [[float(row['frequency_ghz']), float(row['theta_inc_deg']), float(row['theta_scat_deg']),
                      float(row['rcs_amp_real']), float(row['rcs_amp_imag'])] for row in value]
               for key, value in result['co_solved_samples'].items()}
    fields = {}
    for name in sorted(published):
        with np.load(name, allow_pickle=False) as z:
            fields[Path(name).name] = {key: [str(z[key].dtype), list(z[key].shape), hashlib.sha256(z[key].tobytes()).hexdigest()]
                                      for key in sorted(z.files) if z[key].dtype.kind in "fciub"}
            assert np.array_equal(z['frequencies'], sorted(frequencies))
    row_count = table.rowCount()
    assert row_count == sum(map(len, samples.values()))
    tab._on_geometry_changed()
    assert not tab.btn_export.isEnabled() and tab._last_result_stale
    assert folder.exists() and all(Path(name).is_file() for name in published)
    old_frequencies = [row[0] for row in samples['VV']]
    del result
    tab.last_result = {"samples": [{"frequency_ghz": 99., "theta_inc_deg": 1., "theta_scat_deg": 1., "rcs_linear": 2.}]}
    tab._select_result_view("rcs")
    app.processEvents()
    gc.collect()
    assert not folder.exists(), str(folder)
    assert all(Path(name).is_file() for name in published)
    tab.close()
    return dict(rows=row_count, export_files=len(published), arrays=fields, full_sample_fields=samples,
                first_channel_frequency_order=list(dict.fromkeys(old_frequencies)), stale_export_blocked=True,
                complete_recovery_cleaned_on_replacement=True, final_exports_survived=True)

if __name__ == "__main__":
    app = QApplication.instance() or QApplication([])
    results = {}
    with TemporaryDirectory() as tmp:
        for mode in ("monostatic", "bistatic", "bor"):
            results[mode] = run(app, Path(tmp), mode)
            print(mode, results[mode]["rows"], results[mode]["export_files"], flush=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
