# Fresh desktop worker and final export

The test uses the real PySide6 desktop worker synchronously and calls its normal finished slot with automatic export enabled. It uses temporary local recovery/output directories. It solves two frequencies per case on a small 2D sheet and the shipped axisymmetric cylinder, compares every numeric array from the final GRIM files, records every complex sample, marks a geometry-dependent result stale and replaces it. A complete, verified export must survive replacement and its private recovery directory must be released. The tests in ../display separately open partial runs, damage a record, measure presentation, and inspect the visible table and plot.

```sh
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python worker_export.py /path/to/main main-replay.json
python worker_export.py /path/to/candidate candidate-replay.json
cmp main-replay.json candidate-replay.json
```

The artifact hashes cover named numeric arrays including their shape and dtype. Run-specific metadata, timestamps and compression containers are excluded. The published results were byte-equal as JSON on this host. Monostatic, bistatic and BoR produced 1, 3 and 1 final GRIM files. All three also released the completed recovery directory on replacement. The worker was driven in process, so this exercise does not measure interactive thread scheduling or native Windows behavior.
