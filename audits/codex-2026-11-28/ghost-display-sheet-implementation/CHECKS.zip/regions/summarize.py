"""Compare complete fields by channel and report process RSS and time by arm."""
import json
from pathlib import Path
from statistics import median
import sys

import numpy as np


def read(path):
    return json.loads(path.read_text())


def main():
    results = Path(sys.argv[1])
    records = []
    for fixture in ("transmission", "mixed", "medium"):
        cross_backend = []
        for backend in ("dense", "compressed"):
            arrays = []
            measures = {}
            for arm in ("base", "trial"):
                expected_runs = 1 if fixture == "medium" else 3
                paths = sorted(results.glob(f"{arm}-{fixture}-{backend}-*.json"))
                assert len(paths) == expected_runs, (backend, arm, fixture)
                jobs = [read(path) for path in paths]
                for path in paths:
                    with np.load(path.with_suffix(".npz"), allow_pickle=False) as saved:
                        assert saved.files == ["angles", "VV", "HH"]
                        assert np.array_equal(saved["angles"], np.arange(-90,90))
                        arrays.append(np.stack([saved[p] for p in ("VV","HH")]))
                measures[arm] = {}
                for key in ("peak_rss_mib", "seconds"):
                    group = [j[key] for j in jobs]
                    measures[arm][key] = dict(median=median(group), low=min(group), high=max(group))
            assert all(np.isfinite(a).all() for a in arrays)
            assert all(a.tobytes() == arrays[0].tobytes() for a in arrays[1:])
            cross_backend.append(arrays[0])
            records.append(dict(fixture=fixture, backend=backend, runs_each=expected_runs, largest_system=jobs[0]["largest_system"],
                                complex_samples_per_run=arrays[0].size, exact_across_arms_and_repeats=True, measures=measures))
        rel = np.max(abs(cross_backend[1] - cross_backend[0]), axis=1) / np.max(abs(cross_backend[0]), axis=1)
        assert np.max(rel) < 1.e-8
        for rec in records[-2:]:
            rec["dense_compressed_rel_peak"] = dict(zip(("VV","HH"), map(float, rel)))
    for name in ("plans", "bounds", "reach"):
        assert read(results/f"trial-{name}.json") == read(results/f"base-{name}.json")
    large = [read(results/f"{arm}-65k-plan.json")[0] for arm in ("base", "trial")]
    assert large[0]["plan_digest"] == large[1]["plan_digest"]
    two_workers = {}
    for backend in ("dense", "compressed"):
        values = []
        reports = {}
        for arm in ("base", "trial"):
            path = results/"workers"/f"{arm}-{backend}.json"
            reports[arm] = read(path)
            with np.load(path.with_suffix(".npz"), allow_pickle=False) as saved:
                assert np.array_equal(saved["angles"], np.arange(-90,90))
                values.append(np.stack([saved[p] for p in ("VV","HH")]))
        rel = np.max(abs(values[1]-values[0]),axis=1) / np.max(abs(values[0]),axis=1)
        assert np.max(rel) < 1.e-10
        two_workers[backend] = dict(exact=values[0].tobytes() == values[1].tobytes(),
            trial_relative_to_base=dict(zip(("VV","HH"), map(float, rel))), measures=reports)
    data = dict(whole_jobs=records, two_workers=two_workers)
    (results / "summary.json").write_text(json.dumps(data, indent=2) + "\n")


if __name__ == "__main__":
    main()
