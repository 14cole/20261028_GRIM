"""Instrument the two compressed coefficient builders during one complete mixed solve."""
import json
from pathlib import Path
import sys
import tempfile

from ghost_backend.compressed.regional_coefficients import PreparedOracle
from whole_job import main as solve

def main():
    out = Path(sys.argv[1])
    counts = {}
    original_init = PreparedOracle.__init__
    original_get = PreparedOracle.get_with_error

    def init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        counts.setdefault(self.pol, {"instances": 0, "queries": 0})["instances"] += 1

    def get(self, *args, **kwargs):
        counts[self.pol]["queries"] += 1
        return original_get(self, *args, **kwargs)

    PreparedOracle.__init__ = init
    PreparedOracle.get_with_error = get
    with tempfile.TemporaryDirectory() as path:
        sys.argv[1:] = ["mixed", "compressed", str(Path(path)/"result.json")]
        solve()
    assert set(counts) == {"TE", "TM"} and all(v["queries"] > 0 for v in counts.values()), counts
    out.write_text(json.dumps(counts, indent=2) + "\n")

if __name__ == "__main__":
    main()
