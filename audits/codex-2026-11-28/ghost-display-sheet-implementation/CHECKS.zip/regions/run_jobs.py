"""Run both versions serially, reversing ordering on repeat two."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument("released", type=Path, help="tools/GHOST or equivalent package directory")
p.add_argument("trial", type=Path)
p.add_argument("output", type=Path)
args = p.parse_args()
args.output.mkdir(exist_ok=True, parents=True)
for fixture in ("mixed", "transmission"):
    for backend in ("dense", "compressed"):
        for repeat, arms in enumerate((("base", "trial"), ("trial", "base"), ("base", "trial")), 1):
            for arm in arms:
                root = args.released if arm == "base" else args.trial
                name = args.output / f"{arm}-{fixture}-{backend}-{repeat}.json"
                env = dict(os.environ, PYTHONPATH=str(root.resolve()), OPENBLAS_NUM_THREADS="1",
                    OMP_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")
                subprocess.run([sys.executable, Path(__file__).with_name("whole_job.py"), fixture, backend, name],
                               env=env, check=True)
