"""Track aggregate process-tree PSS while a two-worker solve runs on Linux."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import psutil

def main():
    p = argparse.ArgumentParser()
    p.add_argument("source", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("backend", choices=("dense","compressed"))
    args = p.parse_args()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="2",
               OPENBLAS_NUM_THREADS="2", PYTHONPATH=str(args.source.resolve()))
    cmd = [sys.executable, str(Path(__file__).with_name("whole_job.py")), "transmission", args.backend,
           str(args.output), "--panels", "32", "--workers", "2"]
    peak, max_children, samples = 0, 0, 0
    with subprocess.Popen(cmd, env=env) as child:
        root = psutil.Process(child.pid)
        while child.poll() is None:
            try:
                members = root.children(recursive=True) + [root]
                pss = sum(proc.memory_full_info().pss for proc in members)
            except (psutil.NoSuchProcess, psutil.ZombieProcess):
                continue
            max_children = max(max_children, len(members)-1)
            peak = max(peak, pss)
            samples += 1
            time.sleep(.04)
        assert child.returncode == 0
    assert samples > 0
    result = json.loads(args.output.read_text())
    result.update(requested_workers=2, peak_sampled_tree_pss_mib=peak/1048576,
                  maximum_observed_descendants=max_children, samples=samples)
    args.output.write_text(json.dumps(result, indent=2) + "\n")

if __name__ == "__main__":
    main()
