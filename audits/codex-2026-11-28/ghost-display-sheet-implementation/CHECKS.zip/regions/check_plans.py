"""Independently derive each request's memberships and compare both public forecasts."""
import hashlib
import json
from pathlib import Path
import sys

from ghost_backend.execution.options import cpu_allocation_scope, validate_options
from ghost_backend.execution.selection import _forecast_backend
from ghost_backend.twod.formulations import regions
from whole_job import geometry


def independent(layout, plan):
    ifaces = layout["ifaces"]
    properties = layout["region_props"]
    by_k = {}
    partial_unions = 0
    weighted = 0
    for wave, requests in plan:
        for req in requests:
            source = req["source"]
            wanted = [set(), set(), set()]
            per_region = []
            for rid, members in layout["region_ifaces"].items():
                if source not in members or wave != properties[rid]["k"]:
                    continue
                this_region = set()
                for target in members:
                    obs = ifaces[target]
                    if req["kind"] == "weighted" and target != req["observer"]:
                        continue
                    for node, alpha in zip(obs["nodes"], obs["robin_alpha"]):
                        this_region.add(node)
                        wanted[0].add(node)
                        if req["kind"] == "weighted":
                            wanted[1].add(node)
                        elif obs["r_m"] >= 0 and obs["r_p"] >= 0:
                            wanted[1].add(node)
                            wanted[2].add(node)
                        else:
                            is_pec = layout["polarization"] == "TM" and abs(alpha) <= regions.EPS
                            wanted[1 if is_pec else 2].add(node)
                per_region.append(this_region)
            if len(per_region) == 2 and not any(a.issubset(b) for a,b in (per_region, per_region[::-1])):
                partial_unions += 1
            weighted += req["kind"] == "weighted"
            required = [req[key] for key in ("rows", "s_rows", "k_rows")]
            assert all(a == b for a,b in zip(required, wanted))
            key = (repr(wave), source, req["kind"], req["observer"])
            assert key not in by_k
            by_k[key] = [sorted(s) for s in required]
    canonical = sorted((repr(k), v) for k, v in by_k.items())
    return dict(plan_digest=hashlib.sha256(json.dumps(canonical).encode()).hexdigest(), groups=len(plan),
                requests=len(by_k), partial_union_requests=partial_unions, weighted=weighted)


def main():
    records = []
    orig = regions.operator_plan
    summaries = {}
    def check(layout):
        result = orig(layout)
        pol = layout["polarization"]
        current = independent(layout, result)
        assert current == summaries.setdefault(pol, current)
        return result
    regions.operator_plan = check
    for fixture in ("mixed", "transmission"):
        summaries.clear()
        with cpu_allocation_scope(1):
            forecast = _forecast_backend(dict(geometry_snapshot=geometry(fixture), frequencies_ghz=[1.35],
                elevations_deg=list(range(-90,90)), geometry_units="meters"),
                validate_options(dict(basis_order=1, mesh_strategy="global", assembly_threads=1, blas_threads=1,
                    rhs_compression="off", angle_batch_size=31, ram_budget_gib=3)))
        assert set(summaries)=={"TE","TM"}
        for pol in summaries:
            if fixture == "mixed":
                assert summaries[pol]["partial_union_requests"] > 0 and summaries[pol]["weighted"] > 0
        records.append(dict(fixture=fixture, selected=forecast["selected"], membership=summaries.copy(),
            resources=[{key: row[key] for key in ("panels","unknowns","polarization","backend_peak_gib","formulation")}
                       for row in forecast["meshes"]]))
    Path(sys.argv[1]).write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
