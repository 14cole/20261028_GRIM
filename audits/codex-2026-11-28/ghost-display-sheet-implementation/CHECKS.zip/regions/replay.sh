#!/usr/bin/env bash
# Supply the baseline checkout tools/GHOST directory and a new output directory.
set -eu
src=$(realpath "$1")
out=$(realpath -m "$2")
py=$(command -v "${PYTHON:-python}")
case "$py" in /*) ;; *) py=$(realpath "$py");; esac
here=$(cd "$(dirname "$0")" && pwd)
mkdir "$out"
stage=$(mktemp -d)
trap 'rm -rf -- "$stage"' EXIT
cp -a "$src/ghost_backend" "$stage/"
"$py" "$here/stage_shared_rows.py" "$stage"
"$py" "$here/stage_regional.py" "$stage"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
"$py" "$here/run_jobs.py" "$src" "$stage" "$out"
mkdir "$out/workers"
for arm in base trial; do
    path=$src
    if test "$arm" = trial; then path=$stage; fi
    export PYTHONPATH="$path"
    "$py" "$here/check_plans.py" "$out/$arm-plans.json"
    "$py" "$here/regional_bounds.py" "$out/$arm-bounds.json"
    "$py" "$here/reach.py" "$out/$arm-reach.json"
    "$py" "$here/regional_memory.py" "$out/$arm-65k-plan.json" --large --plan
    for backend in dense compressed; do
        "$py" "$here/whole_job.py" transmission "$backend" "$out/$arm-medium-$backend-1.json" --panels 32
        "$py" "$here/run_workers.py" "$path" "$out/workers/$arm-$backend.json" "$backend"
    done
done
"$py" "$here/summarize.py" "$out"
