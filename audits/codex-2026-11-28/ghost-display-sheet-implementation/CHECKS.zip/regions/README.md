# Regional planning and coefficient evaluator follow-up

**Decision.** Sharing the row memberships merits a small, separate implementation for jobs with many distinct dielectric interfaces. Prototype correctness held in 32 fresh whole solves. The strongest savings remain in plan construction. Keep the release's memory limits and backend policy. Review the coefficient evaluator's lifecycle independently before promoting the combined prototype.

This evidence starts from shipped main `95f87190956de9197f0d021b0497772818c6f532`. It stages only the earlier shared-membership and compressed-evaluator prototypes in a disposable copy. A plain request shares immutable memberships across sources in a given region and unions them when adjacent regions have equal wavenumbers. The compressed evaluator drops the request's completed membership sets after extracting its routes. It shares loss-bound vectors by interface and constructs them when attenuation cutoff is enabled on a lossy route. Neither change persists results or requires any extra storage between runs.

## Results

At 65,536 unknowns and 32 distinct dielectric regions, all 64 plan requests retained the identical membership digest. Peak traced allocation for layout and plan fell from **215.04 to 25.44 MiB**. Process RSS growth from immediately before layout to completion of the plan fell from **204.87 to 11.59 MiB**. This measurement ends before a matrix or factor is built.

Every full solve below ran at 1.35 GHz, global specified P1, 180 angles, TE and TM, fixed 31-column maximum batches, and strict discrete-solve checks. Each fixture contains 24 distinct interface pairs. The transmission case has 24 disjoint lossy dielectric polygons in exterior air. The mixed fixture has 12 outer boundaries and 12 internal boundaries, including dielectric transmission, PEC and impedance conductors. Several distinct material labels have the same wavenumber as air and different impedances. The geometry is synthetic. Mesh convergence against an independent continuum reference was outside this comparison.

| Fixture | Unknowns per polarization | Runs per arm | Dense RSS MiB, shipped → prototype | Compressed RSS MiB, shipped → prototype |
|---|---:|---:|---:|---:|
| Transmission, 288 panels | 576 | 3 | 114.25 → 112.88 | 145.33 → 143.38 |
| Mixed, 288 panels | 504 | 3 | 130.67 → 130.32 | 131.36 → 130.24 |
| Transmission, 768 panels | 1,536 | 1 | 186.19 → 184.09 | 201.35 → 197.86 |

These are Linux process-lifetime peak RSS values, medians where there were three runs, with one assembly and BLAS thread. Every complex field sample across versions and repeats matched byte-for-byte on the same backend. The largest Dense/Compressed difference across the three fixtures was 5.41e−14 of that polarization's peak. A separate instrumented mixed solve confirmed TE and TM compressed coefficient evaluators were constructed and queried in both versions. Process timings and ranges are in `results/summary.json`. Timing overlapped other work on this host.

A second single-pair control used two assembly and BLAS threads at 1,536 unknowns. Each full field again matched byte-for-byte. Peak RSS was **179.19 → 179.68 MiB Dense** and **234.15 → 231.86 MiB Compressed**. Sampled process-tree proportional set size was **177.15 → 177.76 MiB Dense** and **221.02 → 226.06 MiB Compressed**. The sampler observed zero descendant processes. The sign of the whole-job memory difference depends on the fixture, metric and concurrent allocator activity. No general end-to-end saving, speedup or larger admissible matrix size has been demonstrated.

A separate scalar traversal derived the expected sets for every request from both public forecasts. The mixed case exercised eight partial equal-wavenumber unions and six weighted requests per polarization. All memberships, automatic decisions and both backend forecast peaks matched. The earlier positively bounded attenuation test was replayed on TE and TM at P1 and P3, with cutoff disabled and enabled. Each cutoff-enabled case produced eight dropped routes and seven positive bounds. Every tested coefficient, error and independently computed active mass bound matched.

## Claude handoff

1. Implement or review plain-row sharing as its own small change. Independently derive the sets on a different overlapping-interface layout. Verify worker consumers treat shared memberships as read-only, including forecast, fused scatter and exact-row paths. Check the full fields before comparing these raw results.
2. Isolate the prepared-evaluator change. At the cutoff crossing, test weighted and unweighted requests, scattering with genuinely separate worker processes, and the lifetime/serialization of shared arrays during cancellation or fallback. Repeat a larger representative many-interface full solve with multiple trials and record process-tree peak RAM. Keep any speed or capacity claim conditional on those data.
3. Evaluate production edits separately from these source-rewrite scripts, which are reproduction aids anchored to the specified commit. Further optimizing single-body jobs on the strength of this many-interface measurement is unsupported.

## Reproduction

Use Linux, the repo's normal solver dependencies and psutil. Give the script the checkout's `tools/GHOST` path and an unused output directory. It stages the two prototype edits in a temporary directory. Use the same Python and native libraries for both arms. The result JSON and paired NPZ files contain the timings, memory, all angles and every complex TE/TM field for each measured run.

```bash
PYTHON=/absolute/path/to/python bash replay.sh /path/to/checkout/tools/GHOST /tmp/regional-replay
```

To check the recorded evidence without rerunning solves, execute `python summarize.py results`. This reads all 32 whole-job field files and writes `results/summary.json`.
