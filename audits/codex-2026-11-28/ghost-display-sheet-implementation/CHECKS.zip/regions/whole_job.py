"""Measure one regional solve in a fresh process and retain every complex sample."""
import argparse
import importlib.metadata
import json
from pathlib import Path
import resource
import sys
from time import perf_counter

import numpy as np

from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.twod.solver import solve_monostatic_rcs_2d


def add_loop(text, name, props, center, radius, panels):
    text.extend([f"Segment: {name} {props[0]}", "properties: " + " ".join(map(str, props))])
    angles = -2 * np.pi * np.arange(panels) / panels
    coords = np.column_stack((radius * np.cos(angles), radius * .87 * np.sin(angles))) + center
    for p, q in zip(coords, np.roll(coords, -1, axis=0)):
        text.append(" ".join(f"{v:.17g}" for v in (*p, *q)))


def geometry(fixture, panels=12):
    text = [f"Title: regional allocation test {fixture}"]
    materials = []
    count = 24 if fixture == "transmission" else 12
    for index in range(count):
        outer = index + 1
        center = (.105 * (index % 6), .13 * (index // 6))
        if fixture == "transmission" or index % 3 == 2:
            eps, mu = 2.1 + .03125 * index, 1.0
            eps_im = -.02
        else:
            # Distinct material IDs, with phase wavenumber equal to exterior air.
            eps, mu, eps_im = 2., .5, 0.
        materials.append(f"{outer} {eps} {eps_im} {mu} 0")
        add_loop(text, f"outer{index}", (3, 1, 0, outer, 0), center, .031, panels)
        if fixture == "mixed":
            if index % 2:
                inner = outer + count
                materials.append(f"{inner} 2.9 -0.11 1.1 0")
                props = (5, 1, 0, outer, inner)
            else:
                props = (4, 1, 30 if index % 4 == 0 else 0, outer, 0)
            add_loop(text, f"inner{index}", props, center, .017, panels)
    text.append("IBCS_Resistances:")
    if fixture == "mixed":
        text.append("30 constant 23 4 0 0")
    text.extend(["", "Dielectrics:", *materials])
    return build_geometry_snapshot(*parse_geometry("\n".join(text) + "\n"))


def main():
    args = argparse.ArgumentParser()
    args.add_argument("fixture", choices=("transmission", "mixed"))
    args.add_argument("backend", choices=("dense", "compressed"))
    args.add_argument("output", type=Path)
    args.add_argument("--panels", type=int, default=12, help="panels per loop")
    args.add_argument("--workers", type=int, default=1)
    options = args.parse_args()
    angles = list(range(-90, 90))
    start = perf_counter()
    snapshot = geometry(options.fixture, options.panels)
    with cpu_allocation_scope(options.workers):
        result = solve_monostatic_rcs_2d(snapshot, [1.35], angles, geometry_units="meters",
            compute_condition_number=True, strict_quality_gate=True,
            execution_options=dict(factorization=options.backend, basis_order=1, mesh_strategy="global",
                assembly_threads=options.workers, blas_threads=options.workers, rhs_compression="off", angle_batch_size=31, ram_budget_gib=3))
    elapsed = perf_counter() - start
    peak_kib = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    assert sys.platform.startswith("linux"), "ru_maxrss is interpreted here in KiB"
    meta = result["metadata"]
    assert meta["quality_gate"]["passed"]
    assert bool(meta["compressed_factors"]) == (options.backend == "compressed")
    fields = {}
    for pol in ("VV", "HH"):
        rows = result["co_solved_samples"][pol]
        assert [r["theta_inc_deg"] for r in rows] == angles
        field = np.array([complex(r["rcs_amp_real"], r["rcs_amp_imag"]) for r in rows])
        assert np.isfinite(field).all() and np.any(field)
        fields[pol] = field
    np.savez_compressed(options.output.with_suffix(".npz"), angles=np.array(angles), **fields)
    data = dict(fixture=options.fixture, backend=options.backend, fields=len(angles)*2,
        panels=meta["panel_count_max"], largest_system=meta["dense_largest_system"], seconds=elapsed,
        peak_rss_mib=peak_kib/1024, quality_gate_passed=meta["quality_gate"]["passed"],
        python=sys.version, numpy=np.__version__, scipy=importlib.metadata.version("scipy"))
    options.output.write_text(json.dumps(data, indent=2)+"\n")
    print(json.dumps(data), flush=True)


if __name__ == "__main__":
    main()
