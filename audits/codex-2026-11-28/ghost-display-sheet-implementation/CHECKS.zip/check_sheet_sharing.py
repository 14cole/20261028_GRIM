"""Observe the public HPC planner's mesh builds and its channel forecasts."""
import argparse
import json
import sys
import tempfile
from contextlib import nullcontext
from pathlib import Path
from unittest.mock import patch


def geometry(kind):
    rows = ["Title: planner topology control"]
    if kind in ("impedance", "mixed", "thin"):
        for i, ends in enumerate(["0 0 .003 0", ".006 0 .003 0", ".006 0 .009 0"]):
            rows += [f"Segment: line{i} 1", "properties: 1 3 10 0 0", ends]
    if kind in ("pec", "mixed"):
        rows += ["Segment: body 2", "properties: 2 3 0 0 0",
                 ".02 .02 .02 .03", ".02 .03 .03 .03", ".03 .03 .03 .02", ".03 .02 .02 .02"]
    rows += ["IBCs:"]
    if kind == "thin":
        rows += ["10 thin_dielectric 0.00001 2", "Dielectrics:", "2 3.0 -0.02 1 0"]
    elif kind != "pec":
        rows += ["10 constant 90 -20 0 0", "Dielectrics:"]
    else:
        rows += ["Dielectrics:"]
    return "\n".join(rows) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("checkout", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    sys.path.insert(0, str(args.checkout.resolve()/"tools/GHOST"))
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.hpc.scheduler import predict_2d_resources_many
    from ghost_backend.twod import solver
    from ghost_backend.execution.options import execution_scope, validate_options
    from ghost_backend.execution import selection
    from ghost_backend.twod.preparation import preparation_scope

    results = {}
    with tempfile.TemporaryDirectory() as root:
        for kind in ("pec", "impedance", "mixed", "thin"):
            path = Path(root)/(kind + ".geo")
            path.write_text(geometry(kind))
            results[kind] = {}
            for scope_name in ("default", "P1", "P2", "P3"):
                degree = 1 if scope_name == "default" else int(scope_name[1])
                options = validate_options(dict(factorization="automatic", basis_order=degree,
                    mesh_grading=False, mesh_strategy="global", blas_threads=1, assembly_threads=1))
                rows = results[kind][scope_name] = []
                for labels in (["VV", "HH"], ["HH", "VV"]):
                    with (nullcontext() if scope_name == "default" else execution_scope(options)):
                        with patch.object(solver, "_build_linear_mesh_interface_aware",
                                          wraps=solver._build_linear_mesh_interface_aware) as capture:
                            records = predict_2d_resources_many(str(path), [1.], labels, "meters", 1000,
                                                                n_angles=180)
                            calls = [c.kwargs.get("polarization") for c in capture.call_args_list]
                    rows.append(dict(order=labels, builds=calls, dofs={k:records[1.,k]['system_dofs'] for k in labels}))
                assert rows[0]['dofs'] == rows[1]['dofs']
                n_builds = 2 if kind in ("impedance", "mixed") else 1
                assert all(len(row['builds']) == n_builds for row in rows)
                if kind == "thin" and scope_name != "default":
                    snap = build_geometry_snapshot(*parse_geometry(path.read_text()))
                    kw = dict(geometry_snapshot=snap, geometry_units="meters", frequencies_ghz=[1.],
                              elevations_deg=[0.,45.])
                    with preparation_scope():
                        plan = selection.select_backend(kw, options, False)
                    pred = {r['polarization']:r['unknowns'] for r in plan['meshes']}
                    try:
                        actual = solver.solve_monostatic_rcs_2d_survey(**kw, execution_options=options)
                        evidence = {k:v[0]['unknowns'] for k,v in actual['metadata']['thin_layer'].items()}
                    except (ValueError, RuntimeError) as err:
                        evidence = dict(error=str(err))
                    results["thin"][scope_name + "_field_gate"] = dict(forecast=pred, execution=evidence)
    args.output.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
