# Current-result Qt verification

This harness runs each checkout in a separate Python process. It creates synthetic complex fields for VV and HH, writes real frequency checkpoints, instantiates the shipped Qt Solver tab and invokes its normal solve-completion slot. The timed full-run phase includes table construction, plotted data, a synchronous canvas draw, status and automatic-export history. Its final writer is intercepted so that display timing excludes file publication. A separate small case runs the actual manual exporter and verifies the resulting GRIM numerical members and cleanup.

The 131-frequency case uses descending frequencies spanning 15 to 2 GHz and 361 angles from 360 to 0 degrees. It validates all 472,910 formatted cells individually, followed by all x/y values and labels of 262 curves. Those exhaustive checks are timed separately. The irregular seven-frequency case also checks reselecting the active RCS view. The partial case opens the recovery dialog with only four completed records saved in reverse order. Corrupting a file after its header was indexed exercises rejection on first display. The extension case stores a record with a missing numeric field and an additional structured field. The two BoR fixtures exercise requested-order and expanded-output channel ordering. These special display fixtures use the recovery checkpoint writer directly.

The fixture generation, recovery creation and OS file-cache warming are outside the full-run timer. The partial dialog timer includes opening the manifest. Verified loads count calls to RecoveryRun.load. Native compressed-file opens for header checks and Matplotlib operations are not counted as frequency loads. RSS is sampled every 4 ms relative to the start of presentation. The large fixture was measured twice per checkout on one Linux host. These timings and RSS samples depend on that host and its concurrent load. Generating the fixture and exhausting the table do not perform an electromagnetic solve.

From this directory run with the normal GHOST GUI/test dependencies and psutil. Use absolute paths for the two checkouts.

```sh
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python verify_display.py "$BASELINE" full main-small.json
python verify_display.py "$CANDIDATE" full candidate-small.json
python verify_display.py "$CANDIDATE" full fallback-small.json --limit-bytes 1
python verify_display.py "$BASELINE" large main-large.json
python verify_display.py "$CANDIDATE" large candidate-large.json
python compare.py main-small.json candidate-small.json --one-pass
python compare.py main-small.json fallback-small.json
python compare.py main-large.json candidate-large.json --one-pass
```

The 1-byte setting is a test override for the 16 MiB display-column budget. It selects the existing row path for every nonempty case. The main and candidate reports record the digest of every formatted table cell, all curve points and labels, status, export histories, and actual exported numerical members. The corrupted-data case compares rejection and additionally requires the previous view to survive on the candidate. Real output-stale protection and removal of a successfully exported recovery folder after its last reader is released are required on both checkouts.


## Verification results

| Presentation case | Main frequency loads | Candidate frequency loads |
|---|---:|---:|
| 7-frequency 2-D completion | 196 | 7 |
| 4 of 7 frequencies through the recovery dialog | 48 | 4 |
| 3-frequency BoR, input order | 84 | 3 |
| 3-frequency BoR, expanded order | 84 | 3 |
| 3-frequency bistatic, 2 incidence groups | 96 | 3 |
| 3-frequency extension containing a missing numeric field | 96 | 97 |
| 131-frequency 2-D completion, 94,582 rows | 3,668 | 131 |

The extension's extra read recognizes that the decoded record uses the extensible row representation. Its original missing-value behavior and all displayed outputs were preserved. The 1-byte fallback reproduced the main read counts for all these small record types.

The retry test successfully reproduced a separate existing recovery defect. After a corrupt read, main returned an empty cached value for the previous valid frequency. After restoring the original bytes, it needed the result to be reopened before it could export. The candidate could read the previous valid frequency, rejected a manual export while a record was corrupt, and could export the restored bytes without reopening. The six numerical members of the real three-frequency GRIM output matched. Replacing the displayed, successfully exported run released its recovery directory on both versions.

In the two large Qt runs, presentation took 18.89 and 22.39 seconds on main and 1.06 and 0.99 seconds on the final candidate. Incremental sampled peak RSS was 11.38–11.43 MiB on main and 13.52–13.61 MiB on the candidate. The four retained float64 columns themselves occupy 2.89 MiB for 94,582 rows. The separate exhaustive cell/curve comparison took 12.08–13.30 seconds on main and 12.80–13.10 seconds on the candidate, with 130 further verified reads on main and 131 on the candidate. Individual cell access continues to use the original sample rows.
