# Sheet forecast validation

The experiment generated straight, connected TYPE 1 sheets at 1 GHz from ordinary geometry text and reversed the input direction of every second piece. It used the public co-polarized single-mesh survey with Automatic backend selection, 180 monostatic angles from −90° through +89°, and one BLAS and assembly thread. Each of the two revisions ran the public solver separately. A wrapper recorded the shape of each fully assembled operator at entry to the common field solver and passed through all arguments. The public HPC planner ran in both request orders through both its configured and default paths. Builder instrumentation counted real constructions.

For a straight sheet of N linear panels distributed over K separately named, joined pieces, the TE chain has N + 1 endpoint nodes. TM keeps K independent endpoints beyond N. Each element then gains one interior node at P2 and two at P3.

| 16 pieces and 16 panels | Baseline desktop TE / TM | Candidate desktop TE / TM | Executing matrix dimension TE / TM |
|---|---|---|---|
| P1 | 32 / 32 | 17 / 32 | 17 / 32 |
| P2 | 48 / 48 | 33 / 48 | 33 / 48 |
| P3 | 64 / 64 | 49 / 64 | 49 / 64 |

The public HPC planner produced those candidate counts in configured runs for single and paired channel requests, including aliases. Its default unconfigured path used grading and created 28 panels. Its TE / TM counts became 29 / 44. For a separate eight-piece automatically sized input, the configured HPC certification planner created 88 panels and built two linear meshes total across **both** candidate polynomial degrees. The resulting counts were 177 / 184 at P2 and 265 / 272 at P3 in either channel order.

All six polarized field arrays agreed exactly across revisions in all nine saved numeric columns, including both components of the complex amplitude, the angles, frequency and residual. Each revision produced 1,080 samples and passed all three discrete quality gates. This checks numerical compatibility across the planner change. These single-mesh solves do not provide a mesh-convergence certificate.

The PEC, closed surface-impedance, bulk dielectric and thin dielectric material controls kept their original system dimensions, backend selections and number of HPC mesh builds. Each paired request on these controls shared one linear mesh. The three-arm ordinary sheet failed at the desktop and HPC forecast boundary with the executing solver's TE branching diagnostic. TM-only planning on the same geometry succeeded.

The 9,992-panel threshold experiment priced the candidate meshes only. With both backends admitted, TE-only Automatic changed from Compressed to Dense when its forecast dropped from 10,000 to 9,993 unknowns. The paired forecast also retained the 10,000-unknown TM system and selected Compressed on both revisions. There was no large numerical solve or timing comparison for that case.

## Replay

Use the GHOST Python environment with NumPy and SciPy installed. The two checkouts should contain the baseline and production candidate commits from the handoff. Run each tree in a fresh interpreter.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python check_planning.py run /path/to/baseline replay/baseline
python check_planning.py run /path/to/candidate replay/candidate
python check_planning.py compare replay/baseline replay/candidate
```

Each output directory contains planning records and observed matrix dimensions in `measurements.json`. The `fields.npz` keys identify polynomial degree and output polarization. For each degree the array's numeric column order is in `measurements.json` under `solve.columns`. The comparison checks algebraic sizes, actual assembled dimensions, channel order, raw numerical equality, error diagnostics and unchanged controls. For the threshold case it checks the backend switch on hosts admitting both modes.
