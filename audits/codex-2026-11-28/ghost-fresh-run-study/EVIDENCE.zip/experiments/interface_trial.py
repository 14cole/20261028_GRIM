"""Process-local experiment. Only constant interface laws are pooled, within one call."""
def install():
    from ghost_backend.twod import solver
    original = solver._build_coupled_panel_info
    def grouped(panels, materials, freq_ghz, pol, k0):
        if any(materials.is_tapered_impedance(flag) for flag in {p.ibc_flag for p in panels if p.ibc_flag > 0}):
            return original(panels, materials, freq_ghz, pol, k0)
        key_index = {}
        representatives = []
        order = []
        for p in panels:
            key = (p.seg_type, p.ibc_flag, p.pos_mat, p.neg_mat, (p.name.strip() or '__type1_sheet__') if p.seg_type == 1 else None)
            i = key_index.get(key)
            if i is None:
                i = len(representatives)
                key_index[key] = i
                representatives.append(p)
            order.append(i)
        records = original(representatives, materials, freq_ghz, pol, k0)
        return [records[i] for i in order]
    solver._build_coupled_panel_info = grouped
    solver._build_linear_coupled_infos = lambda mesh, materials, freq_ghz, pol, k0: grouped(mesh.elements, materials, freq_ghz, pol, k0)
