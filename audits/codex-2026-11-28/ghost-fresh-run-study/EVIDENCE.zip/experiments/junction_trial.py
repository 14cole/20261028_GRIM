"""Trial for real wavenumbers. Reuse quadrature nodes and batch the same segment rules."""
import numpy as np
from ghost_backend.twod.formulations import combined_regions as cr
from ghost_backend.twod.operators import _green_2d_array, NODE_SNAP_TOLERANCE
from ghost_backend.twod.basis import values

def integrate(elements, point, k, degree):
    x,w=(cr._JUNCTION_GAUSS[0]+1)/2,cr._JUNCTION_GAUSS[1]/2
    out=np.empty((len(elements),degree+1) if degree>1 else len(elements),complex)
    groups={}
    for i,e in enumerate(elements):
        d=e.p1-e.p0
        length=float(np.linalg.norm(d))
        if np.linalg.norm(e.p0-point)<=4*NODE_SNAP_TOLERANCE:
            rule=-1
        elif np.linalg.norm(e.p1-point)<=4*NODE_SNAP_TOLERANCE:
            rule=-2
        else:
            s=np.clip(np.dot(point-e.p0,d)/max(float(np.dot(d,d)),1e-300),0,1)
            distance=float(np.linalg.norm(e.p0+s*d-point))
            rule=int(np.clip(np.ceil(2*length/max(distance,1e-300)),1,64))
        groups.setdefault(rule,[]).append(i)
    for rule,ix in groups.items():
        if rule < 0:
            t=x**4 if rule==-1 else 1-x**4
            weights=w*4*x**3
        else:
            t=((np.arange(rule)[:,None]+x[None,:])/rule).ravel()
            weights=np.tile(w/rule,rule)
        deriv=values(t,degree,derivative=True) if degree>1 else None
        batch=max(1,32768//len(t))
        for start in range(0,len(ix),batch):
            pos=ix[start:start+batch]
            p0=np.asarray([elements[i].p0 for i in pos])
            d=np.asarray([elements[i].p1-elements[i].p0 for i in pos])
            y=p0[:,None,:]+t[None,:,None]*d[:,None,:]
            weighted=weights[None,:]*_green_2d_array(k,np.linalg.norm(y-point,axis=2))
            if degree>1:
                out[pos]=weighted @ deriv
            else:
                # Preserve scalar routine's multiplication by the computed length,
                # then its caller's division by the element's public length.
                out[pos]=np.sum(weighted,axis=1)*np.linalg.norm(d,axis=1)/np.asarray([elements[i].length for i in pos])
    return out

def install():
    original=cr._junction_flux_entries
    def entries(mesh,layout,mi,rid,cc,flux_map,flux_weight):
        js=layout.get('combined_junctions',{}).get(rid,())
        k=layout['region_props'][rid]['k']
        if js and k.imag==0 and k.real>0:
            cache=layout.setdefault('combined_junction_green',{})
            for index,j in enumerate(js):
                key=rid,mi,index
                if key in cache or not any(flux_map[end[1]]>=0 for end in j['ends']):
                    continue
                elems=[mesh.elements[i] for i in layout['ifaces'][mi]['eids']]
                cache[key]=integrate(elems,j['point'],k,len(elems[0].node_ids)-1)
        return original(mesh,layout,mi,rid,cc,flux_map,flux_weight)
    cr._junction_flux_entries=entries
