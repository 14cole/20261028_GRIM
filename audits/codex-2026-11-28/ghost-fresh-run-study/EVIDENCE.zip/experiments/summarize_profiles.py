"""Summarize the raw JSON records and compare paired exported fields."""
import argparse
import json
from pathlib import Path
from statistics import median
import numpy as np

def compare(a,b):
    with np.load(a) as x, np.load(b) as y:
        assert np.array_equal(x['frequencies'],y['frequencies']) and np.array_equal(x['incident_angles'],y['incident_angles'])
        field, other = x['field'], y['field']
        assert field.shape==other.shape and np.all(np.isfinite(field)) and np.all(np.isfinite(other))
        return dict(shape=list(field.shape), bit_identical=bool(np.array_equal(field,other)),
                    per_polarization_peak_relative=[float(np.max(abs(other[...,i]-field[...,i]))/np.max(abs(field[...,i]))) for i in range(field.shape[-1])])

def main():
    p=argparse.ArgumentParser();p.add_argument('runs',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
    rows={}
    for path in sorted(args.runs.glob('*.json')):
        j=json.loads(path.read_text())
        if 'per_frequency' not in j:continue
        freqs=[dict(backend=r['backend_choice'],panels=r['panel_count_max'],unknowns=r['dense_largest_system'],certified=r['mesh_convergence_certified'],quality_passed=r['quality_passed'],stage_seconds=r['runtime_profile']['stage_seconds']) for r in j['per_frequency']]
        rows[path.stem]=dict(frequencies=freqs,read=j['read_seconds'],input_capture=j['capture_seconds'],solve_and_recovery=j['solve_and_recovery_seconds'],export=j['final_export_seconds'],total_measured=j['public_workflow_seconds'],rss_MiB=j['peak_rss_mib'])
    compare_set={}
    for name,base in [(n,'ab-base-1') for n in rows if n.startswith('ab-')]+[(n,'airfoil-auto5-360') for n in rows if n.startswith('matched-5-')]:
        compare_set[name]=compare(args.runs/(base+'.npz'),args.runs/(name+'.npz'))
    if 'seg-2-local-check' in rows:
        for name in rows:
            if name.startswith('seg-'):
                compare_set[name]=compare(args.runs/'seg-2-local-check.npz',args.runs/(name+'.npz'))
    medians={k:median([x['solve_and_recovery'] for nm,x in rows.items() if nm.startswith('ab-'+k+'-')]) for k in ('base','interface','junction')}
    args.output.write_text(json.dumps(dict(runs=rows,field_comparisons=compare_set,ab_solve_recovery_medians=medians),indent=2)+'\n')
if __name__=='__main__':main()
