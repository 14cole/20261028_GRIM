"""Paired operator-quadrature checks, including the endpoint and subdivision rules."""
import argparse, json, time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from junction_trial import integrate, cr
from ghost_backend.twod.operators import NODE_SNAP_TOLERANCE
def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);a=p.parse_args()
    rng=np.random.default_rng(4763)
    p0=rng.normal(size=(600,2));p1=p0+rng.normal(size=(600,2))*.025
    pt=np.zeros(2)
    p0[0]=pt;p1[1]=pt
    for i in range(2,70):
        p0[i,:]=[-.1,.4/(i-1)]
        p1[i,:]=[.1,.4/(i-1)]
    for i,f in enumerate([.99,1.,1.01],70):
        p0[i,:]=[4*NODE_SNAP_TOLERANCE*f,0.]
        p1[i,:]=[.03,.005]
    es=[SimpleNamespace(p0=x,p1=y,length=np.linalg.norm(y-x)) for x,y in zip(p0,p1)]
    checks=[]
    for degree in (1,2,3):
        for freq in (1.,15.):
            k=2*np.pi*freq*1e9/299792458
            measurements={'batch':[],'scalar':[]}
            for r in range(3):
                for mode in (('batch','scalar') if r%2==0 else ('scalar','batch')):
                    start=time.perf_counter()
                    if mode=='batch': bat=integrate(es,pt,k,degree)
                    else: ref=np.asarray([cr._segment_green(e.p0,e.p1,pt,k,degree if degree>1 else None)/(e.length if degree==1 else 1) for e in es])
                    measurements[mode].append(time.perf_counter()-start)
                assert np.isfinite(bat).all() and np.isfinite(ref).all()
                assert np.max(np.abs(ref-bat))<1e-12
            checks.append(dict(degree=degree,freq_ghz=freq,records=len(es),timings=measurements,max_absolute_error=float(np.max(abs(bat-ref))),peak_relative=float(np.max(abs(bat-ref))/np.max(abs(ref)))))
    a.out.write_text(json.dumps(checks,indent=2)+'\n')
if __name__=='__main__': main()
