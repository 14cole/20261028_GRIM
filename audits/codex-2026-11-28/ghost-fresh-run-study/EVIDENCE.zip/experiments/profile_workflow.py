"""Point PYTHONPATH at tools/GHOST. Measures one fresh process per invocation."""
import argparse
import cProfile
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import sys
import tempfile
import time

import numpy as np
import scipy
from ghost_backend.execution.options import automatic_run, cpu_allocation_scope, execution_scope
from ghost_backend.execution.fresh_sweep import run_fresh
from ghost_backend.execution.recovery import RecoveryRun
from ghost_backend.execution.recovery_export import export_run
from ghost_backend.io.solver_export import export_solver_result
from ghost_backend.runs.inputs import load_geometry_snapshot
from ghost_backend.runs.quality import accuracy_target_policy
from ghost_backend.twod.solver import solve_monostatic_rcs_2d_certified, solve_monostatic_rcs_2d_survey
import ghost_backend.twod.solver as sol

def slim(meta):
    keep = ['published_mesh','mesh_convergence_certified','panel_count_max','dense_largest_system','condition_est_max','runtime_profile','linear_backend','mesh_strategy','basis_order','frequency_execution']
    result={k:meta.get(k) for k in keep}
    result['quality_passed']=meta.get('quality_gate',{}).get('passed')
    result['backend_choice']=meta.get('backend_selection',{}).get('selected')
    result['channel_meta']={}
    for name,ch in meta.get('channel_metadata',{}).items():
        result['channel_meta'][name]={k:ch.get(k) for k in ('panel_count_max','dense_largest_system','residual_norm_max','condition_est_max','formulation','mesh_convergence_certified')}
    return result

def main():
    p=argparse.ArgumentParser()
    p.add_argument('geometry',type=Path)
    p.add_argument('prefix',type=Path)
    p.add_argument('--frequencies',default='1')
    p.add_argument('--angles',type=int,default=180)
    p.add_argument('--basis',type=int,default=1)
    p.add_argument('--units',default='inches')
    p.add_argument('--workflow',choices=['auto','specified','check'],default='auto')
    p.add_argument('--sizing',choices=['global','local'],default='global')
    p.add_argument('--backend',choices=['automatic','dense','compressed'],default='automatic')
    p.add_argument('--trial',action='store_true')
    p.add_argument('--junction',action='store_true')
    p.add_argument('--trace',action='store_true')
    p.add_argument('--cpu-profile',action='store_true')
    p.add_argument('--threads',type=int,default=1)
    args=p.parse_args()
    if args.trial:
        from interface_trial import install
        install()
    if args.junction:
        from junction_trial import install
        install()
    timings={}
    if args.trace:
        import functools
        from ghost_backend.execution import selection
        from ghost_backend.twod.formulations import regions
        for mod,names in [(sol,['_build_panels','_build_coupled_panel_info','_build_linear_mesh_interface_aware','_build_linear_coupled_infos','_dense_formulation_resources','_build_linear_junction_constraints','_surface_wave_sampling']),
                            (regions,['build_layout']), (selection,['_forecast_backend'])]:
            for name in names:
                orig=getattr(mod,name)
                def make_wrapper(fn,key):
                    @functools.wraps(fn)
                    def timed(*a,**k):
                        t=time.perf_counter()
                        try:return fn(*a,**k)
                        finally:
                            entry=timings.setdefault(key,[0,0.])
                            entry[0]+=1
                            entry[1]+=time.perf_counter()-t
                    return timed
                setattr(mod,name,make_wrapper(orig,name))
    start=time.perf_counter()
    snap,base=load_geometry_snapshot(str(args.geometry.resolve()),{})
    read=time.perf_counter()-start
    controls=automatic_run('monostatic')
    cert=args.workflow in ('auto','check')
    opts=dict(controls['execution_options'],mesh_strategy='adaptive' if args.workflow=='auto' else args.sizing,basis_order=args.basis,
              assembly_threads=args.threads,blas_threads=args.threads,factorization=args.backend)
    frequencies=[float(x) for x in args.frequencies.split(',')]
    angles=np.arange(args.angles,dtype=float) * (360./args.angles if args.angles>180 else 180./args.angles)
    if args.angles<=180: angles-=90.
    kw=dict(geometry_snapshot=snap,material_base_dir=base,frequencies_ghz=frequencies,elevations_deg=angles.tolist(),geometry_units=args.units,
            solver_method=controls['solver_method'],max_panels=100000)
    if cert: kw['mesh_convergence_policy']=accuracy_target_policy('standard')
    prof=cProfile.Profile() if args.cpu_profile else None
    prefix=args.prefix
    prefix.parent.mkdir(exist_ok=True,parents=True)
    with tempfile.TemporaryDirectory() as tmp:
        t=time.perf_counter()
        run=RecoveryRun.create(tmp,kw,opts,controls['lu_precision'],cert,source_path=str(args.geometry.resolve()))
        capture=time.perf_counter()-t
        t=time.perf_counter()
        with cpu_allocation_scope(args.threads),execution_scope(opts,limit_blas=True):
            if prof:prof.enable()
            result=run_fresh(solve_monostatic_rcs_2d_certified if cert else solve_monostatic_rcs_2d_survey,kw,opts,controls['lu_precision'],cert,frequency_workers=1,recovery=run)
            if prof:prof.disable()
        elapsed=time.perf_counter()-t
        if prof:prof.dump_stats(str(prefix)+'.prof')
        export_start=time.perf_counter()
        final_path=Path(tmp)/'final.grim'
        export_run(result,[str(final_path)],lambda single,path:export_solver_result(single,path,source_path=args.geometry.name))
        export_time=time.perf_counter()-export_start
        with np.load(final_path,allow_pickle=False) as f:
            fields=f['rcs_complex'] if 'rcs_complex' in f else f['rcs_amp_real']+1j*f['rcs_amp_imag']
            assert np.all(np.isfinite(fields))
            field_shape=fields.shape
            np.savez_compressed(str(prefix)+'.npz',field=fields,frequencies=f['frequencies'],incident_angles=angles)
        single_meta=[slim(run.load(f)['metadata']) for f in frequencies]
        report=dict(args={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},source_sha256=hashlib.sha256(args.geometry.read_bytes()).hexdigest(),vertices=sum(len(seg.get('points',seg.get('point_pairs',[]))) for seg in snap['segments']),segments=len(snap['segments']),
            file_bytes=args.geometry.stat().st_size,read_seconds=read,capture_seconds=capture,solve_and_recovery_seconds=elapsed,final_export_seconds=export_time,
            public_workflow_seconds=read+capture+elapsed+export_time,peak_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
            final_file_bytes=final_path.stat().st_size,fields_shape=field_shape,full_field_sha256=hashlib.sha256(fields.tobytes()).hexdigest(),per_frequency=single_meta,
            trace_functions_calls_inclusive_seconds=timings,python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform())
        Path(str(prefix)+'.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
        print(prefix.name, 'read',round(read,3),'solve+recovery',round(elapsed,3), 'export',round(export_time,3),'MiB',round(report['peak_rss_mib'],1),flush=True)

if __name__=='__main__':main()
