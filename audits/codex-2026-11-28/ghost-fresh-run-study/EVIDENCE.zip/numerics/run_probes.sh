set -eu
: "${GRIM_ROOT:?Set to the shipped repository root at ed90b65}"
: "${CLAUDE_AUDIT:?Set to the pinned Claude ghost-backend-audit directory}"
py="${PYTHON:-python}"
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1
for pair in 'pec 1536' 'coat 1056' 'star 1536'
do
    set -- $pair
    "$py" source_basis_probe.py "$CLAUDE_AUDIT" "$1$2-ref.json" "$1" "$2"
    "$py" source_basis_probe.py "$CLAUDE_AUDIT" "$1$2-projected.json" "$1" "$2" --substitute
done
