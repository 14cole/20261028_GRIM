"""Observe fully constructed shipped H-matrix operators in an ordinary 180-angle public solve.

The optional numerical substitution materializes projected V rows in their old buffers.
It exercises their coefficients in the public solve while retaining production-sized arrays. See the study note for memory/peak definitions.
Set GRIM_ROOT to the shipped repository root; pass the pinned Claude harness directory.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time
from collections import defaultdict
from unittest.mock import patch

import numpy as np
from scipy import linalg


def errors(a, b):
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), np.finfo(float).tiny))


def coordinates(operator):
    return [int(operator.n), float(operator.tolerance), int(operator.leaf)]


def retained_probe(operator, tolerance, substitute):
    from ghost_backend.compressed.hmatrix import _Fetcher
    # Shipped U is already common to all receiving interactions in a row cluster.
    # Reuse a right basis between receiving row clusters that reference the same source range.
    groups = defaultdict(list)
    rs = []
    for i,row in enumerate(operator.far):
        rs.append(linalg.qr(row.u, mode='r', check_finite=False)[0][:row.rank].copy(order='C'))
        for (lo, hi), off in zip(row.ranges,row.offsets):
            v = row.v[:, int(off):int(off) + hi-lo]
            groups[(lo,hi)].append((i,v))
    rnd=np.random.default_rng(512017)
    x=rnd.normal(size=(operator.n,4))+1j*rnd.normal(size=(operator.n,4))
    baseline=[operator.matmul_positions(x,t) for t in range(3)]
    delta=[np.zeros_like(x) for _ in range(3)]
    bytes_old=sum(row.v.nbytes for row in operator.far)
    total_lr=sum(row.nbytes for row in operator.far)
    operator_bytes=operator.bytes
    packed=[]
    saved=0
    extra_workspace=0
    err_sq=0.
    sum_sq=0.
    accepted=0
    expansions=[]
    descriptors_total=0
    accepted_bytes=0
    largest=0
    for (lo,hi),inputs in sorted(groups.items()):
        # R_i is the thin QR factor of U_i, so vertical stacking here optimizes
        # the same Frobenius energy as stacking U_i @ V_i. No normal equations.
        big=np.concatenate([rs[i] @ v for i,v in inputs],axis=0)
        sqnorm=np.linalg.norm(big)**2
        sum_sq+=sqnorm
        if len(inputs)<2:
            continue
        left,values,right=linalg.svd(big, full_matrices=False, check_finite=False,
                                      lapack_driver='gesdd')
        tails=np.cumsum((values[::-1]**2))[::-1]
        q=int(np.searchsorted(-tails,-(tolerance**2)*float(sqnorm)))
        q=min(len(values),max(1,q))
        qright=right[:q,:].copy(order='C')
        assert qright.flags.owndata
        # Supplementary metadata for this simple packed recipe: a source group
        # header of 4 int64s, and 4 per consuming link. Existing row offsets/ids
        # are already counted by the shipped operator. A packed implementation
        # has to realize this convention to claim these payload sizes.
        old=sum(v.nbytes for i,v in inputs)
        descriptors=32*(1+len(inputs))
        new=qright.nbytes + descriptors + sum(16*v.shape[0]*q for i,v in inputs)
        group_save=old-new
        # Named simultaneous study arrays, including retained original blocks;
        # excludes LAPACK workspace, Python/allocator, work of the full solver.
        largest=max(largest,big.nbytes+left.nbytes+values.nbytes+right.nbytes+qright.nbytes)
        expansions.append({'source':[int(lo),int(hi)],'links':len(inputs),
                           'ranks':[v.shape[0] for _,v in inputs],'q':q,
                           'old_bytes':old,'new_bytes':new,'selected':group_save>0})
        if group_save<=0:continue
        saved+=group_save
        accepted+=1
        accepted_bytes+=old
        descriptors_total+=descriptors
        desc=np.empty((len(inputs)+1,4),np.int64)
        desc[0]=(lo,hi,q,len(inputs))
        links=[]
        projection_input=qright @ x[lo:hi]
        for index,(i,v) in enumerate(inputs,1):
            row=operator.far[i]
            desc[index]=(i,row.start,row.stop,len(links))
            transfer=v @ qright.conj().T
            diff=transfer @ qright - v
            e=rs[i] @ diff
            err_sq+=np.linalg.norm(e)**2
            links.append(transfer)
            v_input=v @ x[lo:hi]
            delta[0][row.start:row.stop]+=row.u @ (transfer @ projection_input-v_input)
            tx=row.u.T @ x[row.start:row.stop]
            hx=row.u.conj().T @ x[row.start:row.stop]
            delta[1][lo:hi]+=qright.T @ (transfer.T @ tx)-v.T @ tx
            delta[2][lo:hi]+=qright.conj().T @ (transfer.conj().T @ hx)-v.conj().T @ hx
            if substitute:
                v[:]=transfer @ qright
            extra_workspace=max(extra_workspace,transfer.nbytes+diff.nbytes+e.nbytes)
        packed.append((qright,links,desc))
    actual_pack=sum(Q.nbytes+sum(w.nbytes for w in links)+desc.nbytes for Q,links,desc in packed)
    assert actual_pack==accepted_bytes-saved
    predicted=operator_bytes-saved
    rhs=operator.sample_values @ x
    fresh=np.random.default_rng(449821).choice(np.setdiff1d(np.arange(operator.n),operator.sample_rows),16,replace=False)
    fresh.sort()
    independent=_Fetcher(operator.oracle,operator.order,operator.checkpoint)(fresh,np.arange(operator.n))[0] @ x
    before_fresh=errors(baseline[0][fresh],independent)
    after_fresh=errors((baseline[0]+delta[0])[fresh],independent)
    if substitute:
        operator._norms()
        operator._validate()
        operator._evidence(operator.evidence['near_coefficients'])
    return {'polarization':getattr(operator.oracle,'pol',None),'system_size':coordinates(operator),'group_count':len(groups),'eligible_multi_receiver_groups':len(expansions),
            'selected_groups':accepted,'all_source_bytes':bytes_old,'selected_original_source_bytes':accepted_bytes,
            'all_far_numeric_and_indices':int(total_lr),'baseline_operator_bytes':int(operator_bytes),
            'existing_basis_row_count':len(operator.far),'saved_operator_payload_bytes':int(saved),
            'proposed_operator_bytes':int(predicted),'retained_net_saving_fraction':saved/max(1,operator_bytes),
            'actually_allocated_compact_payload_and_descriptors':int(actual_pack),'minimum_overlap_bytes_old_operator_plus_selected_packs':int(operator_bytes+actual_pack),
            'fresh_exact_row_indices_permuted':fresh.tolist(),'fresh_exact_row_reference_l2':before_fresh,'fresh_exact_row_projected_l2':after_fresh,
            'scaled_validation_error_after':float(operator.scaled_sampled_row_error),
            'descriptor_bytes_in_new':descriptors_total,'largest_group_named_svd_array_bytes':largest,
            'all_R_factor_bytes_in_probe':sum(r.nbytes for r in rs),
            'largest_link_named_check_workspace_bytes':extra_workspace,
            'relative_far_frobenius_all':float(np.sqrt(err_sq/max(sum_sq,np.finfo(float).tiny))),
            'random_action_relative_l2':[float(np.linalg.norm(d)/np.linalg.norm(b)) for d,b in zip(delta,baseline)],
            'exact_row_probe_reference_l2':errors(baseline[0][operator.sample_rows],rhs),
            'exact_row_probe_projected_l2':errors((baseline[0]+delta[0])[operator.sample_rows],rhs),
            'exact_sample_rows':len(operator.sample_rows),'groups':expansions}


def run(args):
    sys.path.insert(0,str(args.harness.resolve()))
    from harness import cylinder_geo, solve_fixed, fields_of
    from ghost_backend.compressed import hmatrix, hmatrix_factor
    from ghost_backend.compressed.hmatrix import _Fetcher
    solutions=[]
    solution_arrays={}
    raw_solve=hmatrix_factor.HMatrixFactor.solve
    def holdout_solve(factor,rhs):
        result=raw_solve(factor,rhs)
        operator=factor.a
        b=np.asarray(rhs).reshape(operator.n,-1)
        x=np.asarray(result).reshape(operator.n,-1)
        used=np.array(results[-1]['fresh_exact_row_indices_permuted'])
        available=np.setdiff1d(np.arange(operator.n),np.r_[used,operator.sample_rows])
        rows=np.sort(np.random.default_rng(791123).choice(available,16,replace=False))
        exact=_Fetcher(operator.oracle,operator.order,operator.checkpoint)(rows,np.arange(operator.n))[0]
        right=b[operator.order[rows]]
        xp=x[operator.order]
        absolute=np.abs(exact @ xp-right)
        den=np.abs(exact) @ np.abs(xp)+np.abs(right)
        by_angle=np.max(absolute/np.maximum(den,1e-300),axis=0)
        pol=str(operator.oracle.pol)
        k=str(len(solutions))
        solution_arrays['backward_'+k]=by_angle
        solution_arrays['rows_'+k]=operator.order[rows]
        solution_arrays['densities_'+k]=x[operator.order[rows]]
        solutions.append(dict(pol=pol, columns=int(b.shape[1]), physical_row_count=len(rows),
                              error_max=float(by_angle.max()),npz_key_suffix=k))
        return result
    results=[]
    original=hmatrix._assemble
    def observe(oracle,targets):
        val=original(oracle,targets)
        for op in targets:
            results.append(retained_probe(op,args.tolerance,args.substitute))
        return val
    center=(.031,-.017)
    kwargs={'b':.12,'sides':args.sides,'center':center}
    if args.fixture=='coat':kwargs.update(a=.1,eps=2.8-.06j)
    text=cylinder_geo(**kwargs)
    if args.fixture=='star':
        # Unequal harmonics and an offset phase avoid an exact repeated-sector control.
        lines=[]
        for line in text.splitlines():
            tokens=line.split()
            if len(tokens)==4:
                points=np.array(list(map(float,tokens))).reshape(2,2)
                delta=points-np.asarray(center)
                theta=np.arctan2(delta[:,1],delta[:,0])
                radius=1+.17*np.cos(5*theta)+.047*np.sin(2*theta+.27)
                points=np.asarray(center)+radius[:,None]*delta
                line=' '.join(format(v,'.17g') for v in points.ravel())
            lines.append(line)
        text='\n'.join(lines)+'\n'
    import reference
    angles=np.arange(-90.,90.)
    with patch.object(hmatrix,'_assemble',observe), patch.object(hmatrix_factor.HMatrixFactor,'solve',holdout_solve):
        result,_=solve_fixed(text,10.,angles,'compressed',threads=1)
    assert results,'the ordinary public route did not use the H-matrix operator'
    fields=fields_of(result)
    md=result['metadata']
    assert md['quality_gate']['passed'] and set(fields)=={'TE','TM'}
    if args.fixture=='star':
        dense,_=solve_fixed(text,10.,angles,'dense',threads=1)
        assert dense['metadata']['quality_gate']['passed']
        analytic=fields_of(dense)
        ref_kind='shipped_dense_same_mesh'
    else:
        ref_kind='analytical_coated_or_PEC_cylinder'
        analytic={p:reference.stored_amplitude(p,10.,angles,center=center,a=.10 if args.fixture=='coat' else None,
                                           b=.12,eps=2.8-.06j if args.fixture=='coat' else None,mu=1.) for p in fields}
    normed={p:float(np.max(np.abs(fields[p]-analytic[p]))/np.max(np.abs(analytic[p]))) for p in fields}
    np.savez_compressed(args.output.with_suffix('.npz'),angles=angles,**fields,**solution_arrays,**{'analytic_'+p:f for p,f in analytic.items()})
    output=dict(fixture=args.fixture,sides=args.sides,frequency_GHz=10,angles=180,
                operator_probe_relative_tolerance=args.tolerance,substituted_projected_coefficients=args.substitute,field_reference=ref_kind,reference_peak_relative_complex=normed,polarizations=['TE','TM'],
                physical_quality_passed=md['quality_gate']['passed'],
                physical_max_residual=md['residual_norm_max'],panels=md['panel_count'],
                conventional_basis_order=1,random_seed=512017,random_rhs=4,operators=results,exact_rows_of_physical_solves=solutions)
    args.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps([(r['system_size'],r['selected_groups'],r['saved_operator_payload_bytes'],r['retained_net_saving_fraction'],r['relative_far_frobenius_all']) for r in results]))
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('harness',type=Path)
    ap.add_argument('output',type=Path)
    ap.add_argument('fixture',choices=['coat','pec','star'])
    ap.add_argument('sides',type=int)
    ap.add_argument('--tolerance',type=float,default=1e-13)
    ap.add_argument('--substitute',action='store_true')
    run(ap.parse_args())
