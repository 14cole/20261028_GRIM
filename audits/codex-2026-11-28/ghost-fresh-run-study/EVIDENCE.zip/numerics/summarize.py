"""Replay the three paired public solves. Invoke after run_probes.sh."""
from pathlib import Path
import hashlib
import json
import numpy as np

folder = Path(__file__).resolve().parent
out = {}
for name in ('pec1536', 'coat1056', 'star1536'):
    def read(suffix):
        base = folder / (name + '-' + suffix)
        return json.loads(base.with_suffix('.json').read_text()), np.load(base.with_suffix('.npz'))
    origin, old = read('ref')
    trial, new = read('projected')
    assert origin['physical_quality_passed'] and trial['physical_quality_passed']
    assert np.array_equal(new['angles'],np.arange(-90,90)) and np.array_equal(old['angles'],new['angles'])
    assert origin['operator_probe_relative_tolerance'] == trial['operator_probe_relative_tolerance'] == 1e-13
    def peak(a,b):
        return float(np.max(np.abs(a-b))/np.max(np.abs(b)))
    pols = ('TE','TM')
    assert {str(operator['polarization']).upper() for operator in trial['operators']} == set(pols)
    row = {
        'per_polarization_unknowns':trial['operators'][0]['system_size'][0],
        'panels':trial['panels'],'direction_count':len(new['angles']),
        'reference':trial['field_reference'],
        'peak_relative_field_difference':{p:peak(new[p],old[p]) for p in pols},
        'reference_to_anchor_peak_relative':{p:peak(old[p],old['analytic_'+p]) for p in pols},
        'projection_to_anchor_peak_relative':{p:peak(new[p],new['analytic_'+p]) for p in pols},
        'solver_reported_max_residual':[origin['physical_max_residual'],trial['physical_max_residual']],
        'operators':{}
    }
    for left,right in zip(origin['operators'],trial['operators']):
        pol = right['polarization'].upper()
        assert left['polarization'].upper() == pol
        key_fields=('baseline_operator_bytes','proposed_operator_bytes','saved_operator_payload_bytes',
            'selected_groups','retained_net_saving_fraction','minimum_overlap_bytes_old_operator_plus_selected_packs',
            'actually_allocated_compact_payload_and_descriptors','all_R_factor_bytes_in_probe','largest_group_named_svd_array_bytes',
            'largest_link_named_check_workspace_bytes','relative_far_frobenius_all','random_action_relative_l2',
            'fresh_exact_row_reference_l2','fresh_exact_row_projected_l2')
        here={k:right[k] for k in key_fields}
        assert right['saved_operator_payload_bytes']==left['saved_operator_payload_bytes']
        baseline=[s for s in origin['exact_rows_of_physical_solves'] if s['pol'].upper()==pol]
        projected=[s for s in trial['exact_rows_of_physical_solves'] if s['pol'].upper()==pol]
        assert sum(s['columns'] for s in baseline)==sum(s['columns'] for s in projected)==len(new['angles'])
        assert len(baseline)==len(projected)
        differences=[]
        for a,b in zip(baseline,projected):
            ao=a['npz_key_suffix']; bo=b['npz_key_suffix']
            assert np.array_equal(old['rows_'+ao],new['rows_'+bo])
            differences.append(peak(new['densities_'+bo],old['densities_'+ao]))
        here['physical_holdout_sample_density_difference_max_over_batches']=max(differences)
        here['physical_holdout_componentwise_backward_max_main']=max(s['error_max'] for s in baseline)
        here['physical_holdout_componentwise_backward_max_projection']=max(s['error_max'] for s in projected)
        row['operators'][pol]=here
    out[name]=row
(folder/'SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
