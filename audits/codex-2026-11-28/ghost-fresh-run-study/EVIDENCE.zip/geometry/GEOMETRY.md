# GHOST 2D geometry preparation and resource planning

Checked the 2D boundary-element geometry path in main at `95f87190956de9197f0d021b0497772818c6f532`. The experiments stop at mesh construction, formation of constitutive/interface records, or resource forecasting. The field solver was never invoked.

## Correct the topology used to forecast TE impedance sheets

On a 0.10 m straight sheet split into two named TYPE 1 segments with the same impedance, the shared endpoint is one TE/VV trace node. TM/HH keeps a distinct node per segment there. The second segment in this fixture was drawn in the reverse direction. Desktop automatic backend planning and both HPC resource forecasting routines build the interface mesh without its polarization argument. The resulting TE plan splits the node. HPC also permits the two polarizations to reuse a mesh based on the pre-orientation panel signatures.

| Case at 1 GHz, grading off | Desktop forecast | HPC forecast | Execution topology |
|---|---:|---:|---:|
| Two segments, P1 TE, 8 panels | 10 DOFs | 10 | 9 |
| Two segments, P1 TM, 8 panels | 10 | 10 | 10 |
| Two segments, P2 TE, 8 panels | unmeasured | 18 | 17 |
| Two segments, P2 TM, 8 panels | unmeasured | 18 | 18 |
| Three sheets meeting at one point, P1 TE, 12 panels | 15 | 15 | Raises unsupported branching error |
| Same junction, P1 TM | 15 | 15 | 15 |

This can give the user an inflated TE estimate or permit queuing a job whose requested TE solve is unsupported. These fixtures demonstrate a planning discrepancy without showing any change in fields for successfully completed runs. Pass the canonical polarization when building candidate meshes and make HPC sharing respect TE sheet connectivity and orientation. Retain the existing sharing for identical topologies. Test reversed and split sheets, different flags and names, unsupported branching, both request orders, both single-degree and multi-degree HPC routines, and a normal bulk-dielectric or PEC case. [Desktop selection](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/execution/selection.py#L291-L302) · [HPC forecast](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/hpc/scheduler.py#L482-L502) · [HPC multi-degree forecast](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/hpc/scheduler.py#L557-L577) · [Execution topology](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/twod/geometry.py#L2754-L2771)

## Small simplification with measured cost

The routine that rebuilds material and interface records from a mesh first constructs one temporary `Panel` per `LinearElement`. The downstream mapper reads element attributes that both representations already have. Calling it with the existing element list reproduced every field of every returned record for both polarizations on the root airfoil and all 15 distributed material examples. Coverage includes sheets, tapers, CSV materials, thin layers, PEC, IBC, magnetic dielectric and two-dielectric interfaces. This test compares constitutive/interface records at fixed geometry and frequency. [Conversion](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/twod/solver.py#L428-L451) · [Material mapper](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/twod/geometry.py#L3130-L3226)

Eight alternating-order wall-time measurements on a fully built 5 GHz airfoil P1 mesh with 9,448 panels gave 38.83 ms median through the adapter and 26.01 ms using the elements directly. A separate tracemalloc pass saw 4,008,664 versus 2,270,008 peak Python-traced bytes, a reduction of 1.66 MiB while the call ran. The retained allocations differed by 192 bytes. A small implementation can replace the conversion in this routine, while keeping the mapper’s public call and adapting its input type. This is about 13 ms from one invocation in this case. No end-to-end wall time or process RSS saving was established. [Raw paired timings and equivalence checks](element_records.json)

## Stage costs and reuse

Single-threaded CPython 3.12.14, NumPy 2.3.5, SciPy 1.17.0, Linux on AMD EPYC 7763. Reported times in milliseconds. Parsing received in-memory text. The reference airfoil used inches. The synthetic clockwise PEC polygons have radius 0.05 m and use meters. Each used specified P1 global wavelength sizing and grading enabled. The panel cap for these geometry-only tests was 120,000. No benchmark changes that limit in the application. Cold validation was measured once per case, and other stage times are three-trial medians.

| Geometry | Drawn edges | Panels | Parse | Build snapshot | Cold validation | Warm validation | Build panels | Build TE topology |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Airfoil, 1 GHz | 350 | 1,962 | 0.81 | 0.14 | 19.4 | 0.63 | 80.4 | 45.3 |
| Airfoil, 5 GHz | 350 | 9,448 | 0.58 | 0.13 | 17.7 | 0.92 | 205.8 | 178.2 |
| PEC 256-gon, 1 GHz | 256 | 256 | 0.57 | 0.07 | 8.2 | 0.74 | 10.6 | 4.9 |
| PEC 1,024-gon, 1 GHz | 1,024 | 1,024 | 2.37 | 0.28 | 33.3 | 2.87 | 63.8 | 23.9 |

At 5 GHz the interface builder also creates five separate, owning two-float arrays per panel for the element endpoints, center, tangent and normal. On the 9,448-panel airfoil their Python headers and data summed to 6,046,720 bytes (5.77 MiB), including 755,840 bytes of numeric data. None shared memory with the panel arrays. This is a storage inventory, not measured reclaimable process RSS. Any attempt to share that memory has to preserve TE element orientation, mutable-array ownership and polynomial enrichment. The measured parse costs have lower priority than reducing duplicated work in the material and topology stages. [Element allocation](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/twod/geometry.py#L2770-L2791) · [Samples](results.json)

The GUI takes the chosen file if the Solver tab specifies a geometry path, otherwise it uses a fresh Geometry-tab snapshot. In a run, the worker scopes preparation across its setup and solve. The run shares validated geometry, parsed material tables and bounded forecast records. A second solve does not inherit the first run’s accepted adaptive mesh. Caching across runs would need immutable geometry and file-content provenance, units, frequency sizing including fixed-reference sweeps and dispersive material tables, N, polynomial degree, grading, local or global sizing, automatic refinements and the correct TE/TM topology. Existing run-scoped caching already buys most of the measured validation cost here. [GUI inputs](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/ui/solver.py#L1542-L1573) · [Worker scope](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/ui/solver.py#L609-L639) · [Run preparation](https://github.com/14cole/20261028_GRIM/blob/95f87190956de9197f0d021b0497772818c6f532/tools/GHOST/ghost_backend/twod/preparation.py#L152-L194)

The cache probe hit on a content-equivalent copy, rejected a newly fractional N, kept the originally captured CSV material within the active scope, detected the edited CSV on explicit fingerprint verification, and loaded the updated permittivity in a new scope (3.18 to 4.18 real at 1 GHz). [Raw cache checks](cache.json)

## Reproduce

Run the three scripts from this folder with a clean checkout and the project Python environment. Set the BLAS and OpenMP thread counts to one for comparable timings.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python geometry_study.py --root /path/to/checkout --output results.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python element_record_probe.py --root /path/to/checkout --output element_records.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python cache_probe.py --root /path/to/checkout --output cache.json
```
