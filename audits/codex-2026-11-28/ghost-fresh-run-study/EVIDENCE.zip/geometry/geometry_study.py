"""Geometry-only microbenchmarks and resource-forecast cross-check. No field solves."""
import argparse
import gc
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import sys
import time


def fixture_text(count):
    points = [(0.05 * math.cos(2*math.pi*i/count), -0.05 * math.sin(2*math.pi*i/count))
              for i in range(count)]
    return "\n".join(["Title: clockwise PEC reference circle", "Segment: conductor 2",
                      "properties: 2 0 0 0 0"] +
                     [" ".join(repr(float(x)) for x in left + right)
                      for left, right in zip(points, points[1:] + points[:1])])


def timed(function, repeats):
    samples = []
    for i in range(repeats):
        gc.collect()
        start = time.perf_counter()
        value = function()
        samples.append(time.perf_counter() - start)
        if i+1 < repeats:
            del value
    return {"seconds": samples, "median_s": statistics.median(samples)}, value


def study_case(name, text, units, freq, repeats):
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.twod import solver as s
    from ghost_backend.twod.preparation import preparation_scope, prepare_geometry
    stats = {}
    stats['parse'], parsed = timed(lambda: parse_geometry(text), repeats)
    stats['snapshot'], snapshot = timed(lambda: build_geometry_snapshot(*parsed), repeats)
    with preparation_scope() as state:
        stats['cold_validation'], (_, report, library, scale) = timed(
            lambda: prepare_geometry(snapshot, str(args.root), units), 1)
        stats['cached_validation'], _ = timed(
            lambda: prepare_geometry(snapshot, str(args.root), units), repeats)
        stats['validation_hits'] = state['hits']
        wavelength, index, flags = s._mesh_wavelength_for_snapshot(snapshot, library, freq)
        stats['panels'], panels = timed(lambda: s._build_panels(snapshot, scale, wavelength, max_panels=120000,
            segment_wavelengths=s.segment_wavelengths(snapshot,library,[freq],scale,wavelength),
            materials=library, frequencies_ghz=[freq]), repeats)
        k0 = 2 * math.pi * freq * 1e9 / s.C0
        stats['panel_physics'], infos = timed(
            lambda: s._build_coupled_panel_info(panels, library, freq, 'TE', k0), repeats)
        stats['mesh'], (mesh, _) = timed(
            lambda: s._build_linear_mesh_interface_aware(panels, infos, polarization='TE'), repeats)
        def field_records(elements, pol):
            return s._build_coupled_panel_info(elements, library, freq, pol, k0)
        stats['build_via_pseudo_panels'], via = timed(
            lambda: s._build_linear_coupled_infos(mesh, library, freq, 'TE', k0), repeats)
        stats['consume_mesh_elements_directly'], direct = timed(lambda: field_records(mesh.elements, 'TE'), repeats)
        stats['identical_fields_TE'] = via == direct
        stats['identical_fields_TM'] = (s._build_linear_coupled_infos(mesh, library, freq, 'TM', k0)
                                       == field_records(mesh.elements,'TM'))
        # Bounds on the arrays produced when copying the panel's vectors into every element.
        import numpy as np
        vector_names = ('p0','p1','center','tangent','normal')
        arrays = [getattr(el, attr) for el in mesh.elements for attr in vector_names]
        stats['element_vector_bytes_incl_headers'] = sum(sys.getsizeof(a) for a in arrays)
        stats['element_vector_payload_bytes'] = sum(a.nbytes for a in arrays)
        stats['vectors_alias_source'] = sum(np.shares_memory(getattr(panels[el.panel_index], attr),getattr(el,attr))
            for el in mesh.elements for attr in vector_names)
        stats.update(primitives=report['primitive_count'], panels_count=len(panels), nodes=len(mesh.nodes),
               warnings=report['warnings'], material_index=index)
    return dict(name=name,units=units,frequency_GHz=freq,metrics=stats)


def sheet_study(branches=False):
    from ghost_backend.execution.options import execution_scope, efficient_defaults
    from ghost_backend.execution.selection import select_backend
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.hpc import scheduler
    from ghost_backend.twod import solver as s
    from ghost_backend.twod.preparation import preparation_scope, prepare_geometry
    # The middle vertex of the normal fixture joins two differently named sheets.
    # Different orientation on the second segment exercises TE orientation repair.
    text = """Title: two card sheet
Segment: left 1
properties: 1 0 10 0 0
-0.05 0 0 0
Segment: right 1
properties: 1 0 10 0 0
0.05 0 0 0
"""
    if branches:
        text += "Segment: extra 1\nproperties: 1 0 10 0 0\n0 0 0 0.05\n"
    text += "IBCS_Resistances:\n10 constant 75 -20 0 0\nDielectrics:\n"
    snapshot = build_geometry_snapshot(*parse_geometry(text))
    options = dict(efficient_defaults(),mesh_strategy='global',basis_order=1,mesh_grading=False,assembly_threads=1)
    summary = {}
    with execution_scope(options), preparation_scope():
        _, report, lib, scale = prepare_geometry(snapshot, str(args.root), 'meters')
        freq=1.
        pols=[('TE','TE'),('TM','TM')]
        summary['validation_warnings'] = report['warnings']
        kw=dict(geometry_snapshot=snapshot,geometry_units='meters',material_base_dir=str(args.root),
                frequencies_ghz=[freq],elevations_deg=[0.])
        try:
            desktop = select_backend(kw,options,certified=False)
            summary['desktop']={r['polarization']:r['unknowns'] for r in desktop['meshes']}
        except (ValueError,MemoryError) as exc:
            summary['desktop_error']=str(exc)
        try:
            hpc=scheduler._resource_records_for_frequency(s,snapshot,lib,freq,pols,scale,5000)
            summary['hpc']={k:v['system_dofs'] for k,v in hpc.items()}
            hpc_hp=scheduler._resource_records_for_degrees(s,snapshot,lib,freq,pols,scale,5000,
                  {i:dict(options,basis_order=i) for i in [1,2]})
            summary['hpc_degrees']={i:{k:v['system_dofs'] for k,v in records.items()} for i,records in hpc_hp.items()}
        except ValueError as exc:
            summary['hpc_error']=str(exc)
        wavelength,_,_=s._mesh_wavelength_for_snapshot(snapshot,lib,freq)
        panels=s._build_panels(snapshot,scale,wavelength,materials=lib,frequencies_ghz=[freq])
        k0=2*math.pi*freq*1e9/s.C0
        summary['panel_count']=len(panels)
        for degree in (1,2):
            with execution_scope(dict(options,basis_order=degree)):
                record={}
                for pol,_ in pols:
                    infos=s._build_coupled_panel_info(panels,lib,freq,pol,k0)
                    try:
                        mesh,_=s._build_linear_mesh_interface_aware(panels,infos,polarization=pol)
                        info=s._build_linear_coupled_infos(mesh,lib,freq,pol,k0)
                        res=s._dense_formulation_resources(mesh,info,pol,sample_compression=False)
                        record[pol]=res['system_dofs']
                    except ValueError as exc:
                        record[pol]=str(exc)
                summary['execution_topology_p'+str(degree)]=record
    return summary


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--repeats', type=int, default=3)
    ap.add_argument('--output', type=Path, required=True)
    args=ap.parse_args()
    sys.path.insert(0,str(args.root/'tools/GHOST'))
    for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        os.environ[key]='1'
    from ghost_backend.execution.options import execution_scope, efficient_defaults
    import numpy
    import scipy
    import threadpoolctl
    snapshot=args.root/'airfoil.geo'
    result={'host':dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,
                platform=platform.platform(),airfoil_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest()),
            'options':dict(mesh_strategy='global',basis_order=1,mesh_grading=True,assembly_threads=1)}
    with execution_scope(dict(efficient_defaults(),**result['options'])), threadpoolctl.threadpool_limits(limits=1):
        result['cases']=[
            study_case('airfoil',snapshot.read_text(),'inches',freq,args.repeats) for freq in [1.,5.]
        ]+[study_case('PEC clockwise polygon',fixture_text(count),'meters',1.,args.repeats) for count in (256,1024)]
        result['sheet_forecast']=sheet_study()
        result['branched_sheet_forecast']=sheet_study(True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
