"""Check geometry/material invalidation and immutable capture under a run-owned scope."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

ap=argparse.ArgumentParser()
ap.add_argument("--root",type=Path,required=True)
ap.add_argument("--output",type=Path,required=True)
args=ap.parse_args()
sys.path.insert(0,str(args.root/'tools/GHOST'))
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.twod.preparation import preparation_scope,prepare_geometry,material_fingerprints

source=args.root/'tools/GHOST/ghost_backend/geometry/geometries/material_examples'
snapshot=build_geometry_snapshot(*parse_geometry((source/'type3_csv_dielectric.geo').read_text()))
out={}
with TemporaryDirectory() as temp:
    csv=Path(temp)/'radome_material.csv'
    csv.write_bytes((source/csv.name).read_bytes())
    with preparation_scope() as active:
        first=prepare_geometry(snapshot,temp,'meters')
        same=prepare_geometry(deepcopy(snapshot),temp,'meters')
        out['content_equivalent_snapshot_hits']=first is same
        initial=first[2].get_medium(50,1)[0]
        bad=deepcopy(snapshot)
        bad['segments'][0]['properties'][1]='3.25'
        try:
            prepare_geometry(bad,temp,'meters')
            raise AssertionError("fractional N was accepted")
        except ValueError as exc:
            out['changed_geometry_revalidated']=str(exc)
        csv.write_text(csv.read_text().replace('3.18','4.18'))
        again=prepare_geometry(snapshot,temp,'meters')[2].get_medium(50,1)[0]
        out['warm_scope_still_uses_initial_material']=again==initial
        try:
            material_fingerprints(snapshot,temp)
            raise AssertionError("changed material was accepted by fingerprint check")
        except ValueError as exc:
            out['explicit_fingerprint_check_error']=str(exc)
    with preparation_scope():
        new=prepare_geometry(snapshot,temp,'meters')[2].get_medium(50,1)[0]
        out['new_scope_reads_changed_material']=(initial.real==3.18 and new.real==4.18)
        out.update(initial_epsilon=str(initial),new_epsilon=str(new))
assert all(out[k] for k in out)
args.output.write_text(json.dumps(out,indent=2)+'\n')
