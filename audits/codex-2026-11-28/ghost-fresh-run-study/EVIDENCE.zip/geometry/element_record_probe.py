"""Compare resource records produced via temporary Panels or existing LinearElements."""
import argparse
import gc
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time
import tracemalloc

ap=argparse.ArgumentParser()
ap.add_argument("--root",type=Path,required=True)
ap.add_argument("--output",type=Path,required=True)
args=ap.parse_args()
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","BLIS_NUM_THREADS"):
    os.environ[key]="1"
sys.path.insert(0,str(args.root/'tools/GHOST'))
from ghost_backend.execution.options import efficient_defaults,execution_scope
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.twod.preparation import prepare_geometry,preparation_scope
from ghost_backend.twod import solver as s


def funcs(mesh,library,freq,pol,k0):
    yield 'via_pseudo_panels', lambda: s._build_linear_coupled_infos(mesh,library,freq,pol,k0)
    yield 'consume_elements', lambda: s._build_coupled_panel_info(mesh.elements,library,freq,pol,k0)


def paired_time(actions, count=8):
    results={key:[] for key in actions}
    for i in range(count):
        for key in list(actions)[::1 if i%2 == 0 else -1]:
            gc.collect()
            start=time.perf_counter()
            value=actions[key]()
            results[key].append(time.perf_counter()-start)
            del value
    alloc = {}
    for key, func in actions.items():
        gc.collect()
        tracemalloc.start()
        result=func()
        current, peak=tracemalloc.get_traced_memory()
        tracemalloc.stop()
        del result
        alloc[key]={'retained_python_bytes':current,'peak_python_bytes':peak}
    return {'seconds':results,'median_s':{k:statistics.median(v) for k,v in results.items()},
            'tracemalloc':alloc}


def verify(path,units,freq,include_benchmark):
    snapshot=build_geometry_snapshot(*parse_geometry(path.read_text()))
    _,_,library,scale=prepare_geometry(snapshot,str(path.parent),units)
    wavelength,_,_=s._mesh_wavelength_for_snapshot(snapshot,library,freq)
    panels=s._build_panels(snapshot,scale,wavelength,max_panels=120000,materials=library,frequencies_ghz=[freq])
    k0=2*math.pi*freq*1e9/s.C0
    result={'file':path.name,'panels':len(panels),'comparisons':{}}
    for pol in ('TE','TM'):
        info=s._build_coupled_panel_info(panels,library,freq,pol,k0)
        mesh,_=s._build_linear_mesh_interface_aware(panels,info,polarization=pol)
        actions=dict(funcs(mesh,library,freq,pol,k0))
        res=[func() for func in actions.values()]
        result['comparisons'][pol]=res[0]==res[1]
        if include_benchmark and pol=='TE':
            result['paired']=paired_time(actions)
    return result

examples=args.root/'tools/GHOST/ghost_backend/geometry/geometries/material_examples'
with execution_scope(dict(efficient_defaults(),mesh_strategy='global',basis_order=1,mesh_grading=True,assembly_threads=1)):
    results=[]
    for path in [args.root/'airfoil.geo'] + sorted(examples.glob('*.geo')):
        unit,freq=('inches',5.) if path.name=='airfoil.geo' else ('meters',1.)
        with preparation_scope():
            results.append(verify(path,unit,freq,path.name=='airfoil.geo'))
assert all(all(r['comparisons'].values()) for r in results)
args.output.write_text(json.dumps(results,indent=2)+'\n')
