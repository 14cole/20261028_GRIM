from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
expected = json.loads((root / "SHA256.json").read_text())
for name, digest in expected.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != digest:
        raise SystemExit("Checksum failed for " + name)
print(f"Verified {len(expected)} files")
