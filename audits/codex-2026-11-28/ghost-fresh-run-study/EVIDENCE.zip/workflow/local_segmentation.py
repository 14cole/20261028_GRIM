"""Measure the shipped local sizing on the same physical primitives grouped into different segments."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from check_workflow import build_snapshot

def rings(split):
    angle=-np.arange(64)*2*np.pi/64
    def coords(rad,center):
        pts=np.c_[center+rad*np.cos(angle),rad*np.sin(angle)]
        return [' '.join(format(float(v),'.17g') for v in [*a,*b]) for a,b in zip(pts,np.roll(pts,-1,axis=0))]
    pec=coords(.1,0.)
    lines=['Title: separated smooth PEC and solid dielectric polygons at 5 GHz']
    for k,group in enumerate(np.array_split(pec,split)):
        lines+=['Segment: pec_'+str(k)+' 2','properties: 2 -20 0 0 0']+list(group)
    lines+=['Segment: dielectric 3','properties: 3 -20 0 1 0']+coords(.05,1.5)+['IBCS_Resistances:','Dielectrics:','1 16 -0.02 1 0']
    return '\n'.join(lines)+'\n'

def probe(snapshot,base,freq):
    from ghost_backend.execution.options import execution_scope,validate_options
    from ghost_backend.twod import solver as s
    from ghost_backend.twod.preparation import prepare_geometry
    from ghost_backend.geometry.guidance import geometry_refinement_candidates
    materials,scale=prepare_geometry(snapshot,base,'meters')[2:]
    wl=s._mesh_wavelength_for_snapshot(snapshot,materials,freq)[0]
    def bare(seg):
        return min(4.*wl,s._mesh_wavelength_for_snapshot(dict(snapshot,segments=[seg]),materials,freq)[0])
    segs=snapshot['segments']
    coords=[[p[k] for k in ('x1','y1','x2','y2')] for seg in segs for p in seg['point_pairs']]
    out=dict(frequency=freq,ordered_coordinates_sha256=hashlib.sha256(json.dumps(coords).encode()).hexdigest(),
        global_wavelength=wl,material_only_wavelength=[bare(seg) for seg in segs],
        feature_flags=geometry_refinement_candidates(segs,point_tolerance=1e-9/scale))
    for strategy in ('local','global'):
        with execution_scope(validate_options(dict(mesh_strategy=strategy))):
            local=s.segment_wavelengths(snapshot,materials,[freq],scale,wl)
            panels=s._build_panels(snapshot,scale,wl,max_panels=100000,segment_wavelengths=local,materials=materials,frequencies_ghz=[freq])
            out[strategy]=dict(wavelengths=local,panels=len(panels),per_named_segment=dict(Counter(p.name for p in panels)),per_type=dict(Counter(p.seg_type for p in panels)))
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--geometry-dir',type=Path)
    a=p.parse_args();sys.path.insert(0,str(a.source.resolve()/'tools/GHOST'))
    out={}
    for k in (1,2,4):
        txt=rings(k)
        if a.geometry_dir:
            a.geometry_dir.mkdir(exist_ok=True,parents=True);(a.geometry_dir/('split-'+str(k)+'.geo')).write_text(txt)
        out[str(k)]=probe(build_snapshot(txt),str(a.source),5.)
    assert len({v['ordered_coordinates_sha256'] for v in out.values()})==1
    assert len({v['global']['panels'] for v in out.values()})==1
    assert out['1']['local']['panels']<out['2']['local']['panels']
    from ghost_backend.runs.inputs import load_geometry_snapshot
    from ghost_backend.twod.preparation import prepare_geometry
    from ghost_backend.twod import solver as s
    from ghost_backend.execution.options import execution_scope,validate_options
    air,base=load_geometry_snapshot(str(a.source.resolve()/'airfoil.geo'),{})
    _,_,mat,scale=prepare_geometry(air,base,'inches')
    with execution_scope(validate_options({'mesh_strategy':'local'})):
        out['airfoil']=[]
        for f in (1.,5.,10.,15.):
            wl=s._mesh_wavelength_for_snapshot(air,mat,f)[0]
            before=[min(4*wl,s._mesh_wavelength_for_snapshot(dict(air,segments=[seg]),mat,f)[0]) for seg in air['segments']]
            after=s.segment_wavelengths(air,mat,[f],scale,wl)
            out['airfoil'].append(dict(f=f,global_wavelength=wl,segments=len(after),material_only_longer=sum(x>wl*(1.+1.e-12) for x in before),protected_result_longer=sum(x>wl*(1.+1.e-12) for x in after)))
    a.output.write_text(json.dumps(out,indent=2)+'\n')
