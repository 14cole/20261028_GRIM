"""No solves. Exercise real recovery captures, content-addressed identities, execution dispatch and HPC resource builders."""
import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch
from check_workflow import build_snapshot, pec, sheet

def test_identity(work):
    from ghost_backend.execution import timing_history as hist
    from ghost_backend.execution.options import validate_options
    from ghost_backend.execution.recovery import RecoveryRun
    from ghost_backend.twod import preparation
    from ghost_backend.geometry.io import material_filename_from_row
    opts=validate_options({'factorization':'adaptive'})
    medium='frequency_hz,eps_real,eps_imag,mu_real,mu_imag\n5000000000,3,-0.1,1,0\n15000000000,3,-0.1,1,0\n'
    geom=pec(24).replace('Segment: pec 2','Segment: medium 3').replace('properties: 2 1 0 0 0','properties: 3 0 0 1 0')
    original_fingerprints=preparation.material_fingerprints
    def logical_fingerprints(snapshot,base_dir):
        verified=original_fingerprints(snapshot,base_dir)
        names=[material_filename_from_row(row) for kind in ('ibcs','dielectrics') for row in snapshot[kind]]
        return {name:verified[str(Path(base_dir).absolute()/name)] for name in names if name}
    def desc(key):
        return {'exact':str(key),'nearby':key.nearby['family'],'factor':key.factor}
    rows={}
    for label,refs,text,env,delta in [
        ('original',['data.csv'],medium,{},{}),('identical_capture',['data.csv'],medium,{},{}),
        ('renamed',['renamed.csv'],medium,{},{}),('changed_content',['data.csv'],medium.replace('3,-','4,-'),{},{}),
        ('second_flag_same_table',['data.csv','data.csv'],medium,{},{}),
        ('second_flag_copy',['data.csv','copy.csv'],medium,{},{}),
        ('runtime_override',['data.csv'],medium,{'GHOST_FAR_QUADRATURE_ORDER':'4'},{}),
        ('paired_hodlr_threshold',['data.csv'],medium,{'GHOST_HIERARCHICAL_MIN_UNKNOWNS':'12000'},{}),
        ('changed_degree',['data.csv'],medium,{}, {'basis_order':2})]:
        options=dict(opts,**delta)
        base=work/label;base.mkdir()
        for name in refs:(base/name).write_text(text)
        snapshot=build_snapshot(geom+'\n'.join(str(i+1)+' '+name for i,name in enumerate(refs))+'\n')
        args=dict(geometry_snapshot=snapshot,geometry_units='meters',material_base_dir=str(base),frequencies_ghz=[10.],elevations_deg=list(range(180)),solver_method='experimental_cpu',max_panels=100000)
        capture=RecoveryRun.create(work/'recoveries',args,options,'double',False)
        captured=capture.arguments({})
        lib=preparation.prepare_geometry(snapshot,captured['material_base_dir'],'meters')[2]
        with patch.dict(os.environ,env):
            actual=desc(hist.request_key(captured,options,'solve_monostatic_rcs_2d_survey'))
            with patch.object(preparation,'material_fingerprints',logical_fingerprints):
                trial=desc(hist.request_key(captured,options,'solve_monostatic_rcs_2d_survey'))
        rows[label]=dict(current=actual,trial=trial,real_permittivity_at_10GHz=lib.get_medium(1,10.)[0].real)
    expected={'original':(1,1,1),'identical_capture':(1,1,1),'renamed':(0,0,0),'changed_content':(0,0,0),'second_flag_same_table':(0,0,0),'second_flag_copy':(0,0,0),'runtime_override':(0,0,0),'paired_hodlr_threshold':(0,0,1),'changed_degree':(0,0,0)}
    for k,v in rows.items():
        for mode in ('current','trial'):
            v[mode+'_matches_original']={n:h==rows['original'][mode][n] for n,h in v[mode].items()}
        assert tuple(v['trial_matches_original'].values()) == expected[k],(k,v,expected[k])
    assert rows['second_flag_same_table']['trial']!=rows['second_flag_copy']['trial']
    return rows

def test_gates(work):
    from ghost_backend.execution import timing_history as hist, factor_timing,selection
    from ghost_backend.execution.options import configured_execution
    from ghost_backend.twod.preparation import preparation_scope
    def solve_monostatic_rcs_2d_survey(geometry_snapshot,frequencies_ghz,elevations_deg,geometry_units='meters',material_base_dir=None,solver_method='experimental_cpu',max_panels=100000):
        return {'metadata':{}}
    wrapper=configured_execution(solve_monostatic_rcs_2d_survey)
    names=['request_key','read','choices','adjust','record']
    out={}
    for mode in ('automatic','dense','compressed','adaptive'):
        with ExitStack() as s:
            s.enter_context(preparation_scope())
            s.enter_context(patch.dict(os.environ,{'GHOST_TIMING_CACHE_DIR':str(work/'cache')}))
            counts=[]
            for name,mod in zip(names,[hist,hist,factor_timing,hist,hist]):
                counts.append(s.enter_context(patch.object(mod,name,wraps=getattr(mod,name))))
            result=wrapper(build_snapshot(pec(128)),[2.],list(range(180)),material_base_dir=str(work),execution_options={'factorization':mode})
            out[mode]=dict(calls={n:m.call_count for n,m in zip(names,counts)},effective_backend=result['metadata']['execution_options']['factorization'])
    assert all(out[m]['calls'][n]==(m=='adaptive') for m in out for n in names)
    return out

def test_scheduler(work):
    from ghost_backend.hpc import scheduler
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import prepare_geometry,preparation_scope
    from ghost_backend.execution.options import execution_scope,validate_options
    s=build_snapshot(sheet(12))
    scope={degree:validate_options({'factorization':'dense','mesh_strategy':'global','basis_order':degree}) for degree in [1,2,3]}
    def slim(row):
        return {k:{n:r[n] for n in ['panels','nodes','system_dofs']} for k,r in row.items()}
    def corrections():
        store={}
        def info(panels,mats,freq,pol,k):
            preview=old_info(panels,mats,freq,pol,k)
            store[id(preview)]=pol
            return preview
        def mesh(panels,preview):
            return old_mesh(panels,preview,polarization=store[id(preview)])
        ctx=ExitStack()
        old_info=solver._build_coupled_panel_info; old_mesh=solver._build_linear_mesh_interface_aware
        ctx.enter_context(patch.object(solver,'_build_coupled_panel_info',info))
        ctx.enter_context(patch.object(solver,'_build_linear_mesh_interface_aware',mesh))
        ctx.enter_context(patch.object(scheduler,'_same_interface_topology',return_value=False))
        return ctx
    with preparation_scope(),execution_scope(scope[1]):
        _,_,mat,scale=prepare_geometry(s,str(work),'meters')
        args=(solver,s,mat,10.,[('VV','TE'),('HH','TM')],scale,100000)
        def records():
            return {'one':slim(scheduler._resource_records_for_frequency(*args)),
                    'degrees':{k:slim(v) for k,v in scheduler._resource_records_for_degrees(*args,scope).items()}}
        result={'production':records()}
        with corrections():
            result['execution_topology_trial']=records()
        return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();sys.path.insert(0,str(a.source.resolve()/'tools/GHOST'));out={}
    with TemporaryDirectory() as d:
        for name,fn in [('identity',test_identity),('dispatch',test_gates),('scheduler',test_scheduler)]:
            try:out[name]=fn(Path(d))
            except Exception:
                import traceback
                out[name]={'error':traceback.format_exc()}; print(name,out[name])
        a.output.write_text(json.dumps(out,indent=2)+'\n')
        if any('error' in item for item in out.values()): raise SystemExit(1)
