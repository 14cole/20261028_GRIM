"""Compute actual immutable-forecast eviction using desktop setup and sweep planner; no matrices or solves."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,json,os,sys,time
from unittest.mock import patch
from check_workflow import build_snapshot,pec

def trial(snapshot,path,count,cert,step=.05,reverse=False):
    from ghost_backend.runs.setup import RunSetupMixin,two_d_request
    from ghost_backend.twod.preparation import preparation_scope,sweep_mesh_scope,forecast_cache
    from ghost_backend.execution import selection,frequency_sweep
    from ghost_backend.runs.quality import accuracy_target_policy
    from ghost_backend.twod import solver
    freqs=[2.+i*step for i in range(count)]
    setup=two_d_request(freqs,list(range(180)),'meters',cert,'standard','monostatic',[],controls={'mesh_strategy':'adaptive' if cert else 'global'})
    args=dict(geometry_snapshot=snapshot,material_base_dir=str(path),geometry_units=setup['units'],
              frequencies_ghz=freqs,elevations_deg=setup['angles_deg'],solver_method=setup['solver_method'],max_panels=100000,mesh_convergence_policy=accuracy_target_policy('standard'))
    log=[]
    orig=selection.select_backend
    def select(*a,**k):
        v=orig(*a,**k);log.append(bool(v.get('forecast_reused')))
        return v
    with patch.object(selection,'select_backend',select),preparation_scope(),sweep_mesh_scope(freqs):
        cache=forecast_cache()
        t=time.monotonic()
        RunSetupMixin._run_setup_summary(None,snapshot,str(path),setup)
        first=dict(calls=len(log),cache_hits=sum(log),seconds=time.monotonic()-t,retained_entries=len(cache),retained_bytes=cache.retained_bytes)
        log.clear()
        t=time.monotonic()
        result=frequency_sweep._plan(args,setup['execution_options'],cert,list(reversed(freqs)) if reverse else freqs,2,6.,4)
        later=dict(calls=len(log),accepted=len(result),cache_hits=sum(log),seconds=time.monotonic()-t,retained_entries=len(cache),retained_bytes=cache.retained_bytes)
        import hashlib
        schedule_hash=hashlib.sha256(json.dumps([(r['frequency'],r['cost'],r['selection']['selected']) for r in result],separators=(',',':')).encode()).hexdigest()
        return dict(sweep_order_sha256=schedule_hash,reverse_second_pass=reverse,frequencies=count,first_ghz=freqs[0],last_ghz=freqs[-1],step_ghz=step,certified=cert,desktop_preflight=first,parent_sweep_planner=later)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--extended',action='store_true');a=p.parse_args();sys.path.insert(0,str(a.source.resolve()/'tools/GHOST'))
    case=build_snapshot(pec(24).replace('properties: 2 1 0 0 0','properties: 2 0 0 0 0'));rows=[]
    with TemporaryDirectory() as d:
        if a.extended:
            text=pec(24)
            before,coords=text.split('properties: 2 1 0 0 0\n')
            points,after=coords.split('IBCS_Resistances:')
            scaled='\n'.join(' '.join(format(float(v)/10,'.17g') for v in ln.split()) for ln in points.strip().splitlines())
            tiny=build_snapshot(before+'properties: 2 1 0 0 0\n'+scaled+'\nIBCS_Resistances:'+after)
            for reverse in (False,True):
                rows.append(trial(tiny,Path(d),521,True,step=.025,reverse=reverse))
            assert rows[0]['sweep_order_sha256']==rows[1]['sweep_order_sha256']
            a.output.write_text(json.dumps(rows,indent=2)+'\n')
            sys.exit()
        for count,cert in ((8,False),(8,True),(261,True),(261,False)):
            rows.append(trial(case,Path(d),count,cert))
            a.output.write_text(json.dumps(rows,indent=2)+'\n')
