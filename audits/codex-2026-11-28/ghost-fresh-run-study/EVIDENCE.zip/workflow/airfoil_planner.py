"""Run real resource estimators and admission. Never allocate a numerical operator."""
from argparse import ArgumentParser
from contextlib import nullcontext
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

def run(args):
    from ghost_backend.execution.options import automatic_run, cpu_allocation_scope, execution_scope
    from ghost_backend.execution import selection
    from ghost_backend.runs.inputs import load_geometry_snapshot
    from ghost_backend.runs.quality import accuracy_target_policy
    from ghost_backend.twod.preparation import preparation_scope
    snapshot,base=load_geometry_snapshot(str(args.geometry.resolve()),{})
    setting=automatic_run('monostatic')
    rows=[]
    for frequency in (1.,5.,10.,15.):
        for certified in [True,False]:
            for angles in [180,360]:
                if args.local_sizing and (certified or angles!=360): continue
                opts=dict(setting['execution_options'], mesh_strategy='adaptive' if certified else 'local' if args.local_sizing else 'global',assembly_threads=2,blas_threads=2)
                kw=dict(geometry_snapshot=snapshot, material_base_dir=base,frequencies_ghz=[frequency],elevations_deg=list(range(-90,90) if angles==180 else range(360)),geometry_units='inches',solver_method=setting['solver_method'],max_panels=100000)
                if certified: kw['mesh_convergence_policy']=accuracy_target_policy('standard')
                if args.storage_counterfactual and not (frequency in (10.,15.) and not certified and angles==360): continue
                row=dict(frequency=frequency,certified=certified,angles=angles,mesh_strategy=opts['mesh_strategy'],storage_counterfactual=args.storage_counterfactual)
                def rank(result,budget,diagnostics=None):
                    if 'original_costs' not in row:
                        row['original_costs']={k:v['peak_gb'] for k,v in result['candidates'].items()}
                        row['original_budget']=budget
                        row['meshes']=[{k:r[k] for k in ('phase','polarization','polynomial_degree','panels','unknowns','formulation','backend_peak_gib')} for r in result['meshes']]
                        row['memory_plans']=[r['backend_memory_plans'] for r in result['meshes']]
                    return saved_rank(result,budget,diagnostics)
                saved_rank=selection.rank_forecast
                start=time.perf_counter()
                from ghost_backend.execution import dense_memory
                storage_context = patch.object(dense_memory,'scratch_available',return_value=(True,None)) if args.storage_counterfactual else nullcontext()
                with cpu_allocation_scope(2),execution_scope(opts),preparation_scope(),patch.object(selection,'rank_forecast',rank),storage_context:
                    try:
                        result=selection.select_backend(kw,opts,certified)
                        row.update(selected=result['selected'],admitted_budget=result['admission_budget_gib'],admitted_batch=result['angle_batch_size'],admitted_costs={k:v['peak_gb'] for k,v in result['candidates'].items()})
                    except MemoryError as e:
                        row.update(selected=None,error=str(e))
                row['planning_seconds']=time.perf_counter()-start
                rows.append(row)
                args.output.write_text(json.dumps(rows,indent=2)+'\n')
                print(frequency,certified,angles,row['original_costs'],row['selected'],round(row['planning_seconds'],2),flush=True)

if __name__=='__main__':
    p=ArgumentParser();p.add_argument('source',type=Path);p.add_argument('geometry',type=Path);p.add_argument('output',type=Path);p.add_argument('--storage-counterfactual',action='store_true');p.add_argument('--local-sizing',action='store_true')
    a=p.parse_args();sys.path.insert(0,str(a.source.resolve()/'tools/GHOST'));run(a)
