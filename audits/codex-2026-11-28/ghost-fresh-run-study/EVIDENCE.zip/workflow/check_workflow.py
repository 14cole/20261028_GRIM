"""Exercise public setup, captured run identities and forecast builds. No linear solves."""
from argparse import ArgumentParser
from functools import wraps
import json
from pathlib import Path
import sys
import time
from contextlib import ExitStack
from tempfile import TemporaryDirectory
from unittest.mock import patch
import numpy as np

def build_snapshot(text):
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    value = parse_geometry(text)
    return build_geometry_snapshot(*value) if isinstance(value, tuple) else build_geometry_snapshot(value)

def pec(sides):
    phi = -np.arange(sides)*2*np.pi/sides
    points = .12*np.column_stack((np.cos(phi),np.sin(phi)))
    return 'Title: circle\nSegment: pec 2\nproperties: 2 1 0 0 0\n'+'\n'.join(
        ' '.join(format(float(v),'.17g') for v in [*p,*q]) for p,q in zip(points,np.roll(points,-1,axis=0))
    )+'\nIBCS_Resistances:\n\nDielectrics:\n'

def sheet(n):
    lines=['Title: open sheet strip']
    for i in range(n):
        lines.extend([f'Segment: sheet_{i+1} 1',f'properties: 1 4 {i+1} 0 0',f'{i*.008:.6f} 0 {(i+1)*.008:.6f} 0'])
    lines.append('IBCS_Resistances:')
    lines.extend(f'{i+1} constant {150+i} 1 0 0' for i in range(n))
    return '\n'.join(lines+['Dielectrics:',''])

def measure_forecasts(sizes, directory):
    from ghost_backend.execution import selection
    from ghost_backend.execution.options import validate_options
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import preparation_scope
    out={}
    for sides in sizes:
        value=build_snapshot(pec(sides))
        options=validate_options(dict(factorization='automatic',mesh_strategy='global',assembly_threads=1,blas_threads=1))
        base=dict(geometry_snapshot=value, material_base_dir=str(directory),geometry_units='meters',frequencies_ghz=[10.],elevations_deg=list(range(180)),solver_method='experimental_cpu',max_panels=100000)
        with preparation_scope():
            logs=[]
            for label,az in [('cold',list(range(180))),('repeat',list(range(180))),('rotated',list(range(-90,90)))]:
                n={}
                with ExitStack() as stack:
                    for key in ['_build_panels','_build_coupled_panel_info','_build_linear_mesh_interface_aware','_build_linear_coupled_infos','_estimate_memory_gb']:
                        original=getattr(solver,key)
                        def hook(*args,_orig=original,_key=key,**kw):
                            n[_key]=n.get(_key,0)+1
                            return _orig(*args,**kw)
                        stack.enter_context(patch.object(solver,key,hook))
                    start=time.monotonic()
                    result=selection.select_backend(dict(base,elevations_deg=az),options,False)
                    elapsed=time.monotonic()-start
                logs.append(dict(label=label,seconds=elapsed,calls=n,selected=result['selected'],reused=bool(result.get('forecast_reused')),dofs=[i['unknowns'] for i in result['meshes']]))
        out[str(sides)]=logs
    return out

def measure_sheets(directory):
    from ghost_backend.execution import selection
    from ghost_backend.execution.options import validate_options
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import preparation_scope
    options=validate_options(dict(factorization='automatic',mesh_strategy='global',assembly_threads=1,blas_threads=1))
    out={}
    for n in (2,12):
        base=dict(geometry_snapshot=build_snapshot(sheet(n)),material_base_dir=str(directory),geometry_units='meters',frequencies_ghz=[10.],elevations_deg=list(range(180)),solver_method='experimental_cpu')
        pol=['']
        rows=[]
        orig_info=solver._build_coupled_panel_info
        orig_mesh=solver._build_linear_mesh_interface_aware
        def info(*args,**kw):
            pol[0]=args[3]
            return orig_info(*args,**kw)
        def mesh(panels,infos,*args,**kw):
            item=orig_mesh(panels,infos,*args,**kw)
            follow=orig_mesh(panels,infos,polarization=pol[0])
            rows.append(dict(pol=pol[0],panels=len(panels),forecast_nodes=len(item[0].nodes),execution_mesh_nodes=len(follow[0].nodes),execution_split_nodes=follow[1]['split_node_count'],forecast_split_nodes=item[1]['split_node_count']))
            return item
        with preparation_scope(), patch.object(solver,'_build_coupled_panel_info',info),patch.object(solver,'_build_linear_mesh_interface_aware',mesh):
            actual=selection.select_backend(base,options,False)
        out[str(n)]=dict(mesh=rows,estimated_dofs=[m['unknowns'] for m in actual['meshes']])
    return out

if __name__=='__main__':
    a=ArgumentParser();a.add_argument('source',type=Path);args=a.parse_args();sys.path.insert(0,str(args.source.resolve()/'tools/GHOST'))
    with TemporaryDirectory() as d:
        path=Path(d)
        out={}
        for key,fn in [('forecast',lambda:measure_forecasts([128,512],path)),('sheets',lambda:measure_sheets(path))]:
            try:out[key]=fn()
            except Exception as e:
                from traceback import format_exc
                out[key]={'error':format_exc()}
        print(json.dumps(out,indent=2))
        if any('error' in item for item in out.values()):raise SystemExit(1)
