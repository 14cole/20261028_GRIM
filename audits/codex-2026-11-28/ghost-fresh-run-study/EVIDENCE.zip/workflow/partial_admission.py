"""Compare the ordinary desktop setup's all-frequency admission with the worker planner."""
import argparse
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

def probe(a):
    from ghost_backend.runs.inputs import load_geometry_snapshot
    from ghost_backend.runs.setup import RunSetupMixin,two_d_request
    from ghost_backend.runs.quality import accuracy_target_policy
    from ghost_backend.execution.frequency_sweep import _plan
    from ghost_backend.execution.options import memory_allocation_scope
    from ghost_backend.twod.preparation import preparation_scope,sweep_mesh_scope
    snap,base=load_geometry_snapshot(str(a.geometry.resolve()),{})
    freqs=[1.,1.2,5.]
    request=two_d_request(freqs,list(range(-90,90)),'inches',False,'standard','monostatic',[],controls={'mesh_strategy':'global'})
    opts=request['execution_options']
    kw=dict(geometry_snapshot=snap,material_base_dir=base,geometry_units='inches',frequencies_ghz=freqs,elevations_deg=request['angles_deg'],solver_method=request['solver_method'],max_panels=100000,mesh_convergence_policy=accuracy_target_policy('standard'))
    with memory_allocation_scope(1.05),preparation_scope(),sweep_mesh_scope(freqs):
        try:
            setup=RunSetupMixin._run_setup_summary(None,snap,base,request)
        except MemoryError as e:
            setup=dict(type=type(e).__name__,text=str(e))
        plan=_plan(kw,opts,False,freqs,2,1.05,4)
    result=dict(cap_gib=1.05,frequencies=freqs,setup=setup,admitted_by_worker_planner=[{'frequency':r['frequency'],'selection':r['selection']['selected'],'peak_gib':r['selection']['candidates'][r['selection']['selected']]['peak_gb']} for r in plan])
    assert result['setup']['type']=='MemoryError'
    assert set(r['frequency'] for r in result['admitted_by_worker_planner'])=={1.,1.2}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('geometry',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();sys.path.insert(0,str(a.source.resolve()/'tools/GHOST'));a.output.write_text(json.dumps(probe(a),indent=2)+'\n')
