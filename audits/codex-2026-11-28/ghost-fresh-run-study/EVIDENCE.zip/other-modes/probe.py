"""Small current-source 2-D bistatic output, body-of-revolution and packaged-library controls.

python probe.py ROOT {bistatic,bor,material,native} --out OUT
Set OPENBLAS_NUM_THREADS=OMP_NUM_THREADS=MKL_NUM_THREADS=1 before running.
The bistatic vector writer is injected only into the current process, on the compact path.
"""
import argparse
import ctypes
import gc
import hashlib
import inspect
import json
import math
import os
import platform
import sys
import time
from pathlib import Path
from unittest.mock import patch

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("root", type=Path)
parser.add_argument("mode", choices=("bistatic", "bor", "material", "native"))
parser.add_argument("--edges", type=int, default=32, help="2-D circle input edges")
parser.add_argument("--out", type=Path, default=Path("."))
args = parser.parse_args()
ghost = args.root.resolve() / "tools" / "GHOST"
sys.path.insert(0, str(ghost))
out = args.out
out.mkdir(parents=True, exist_ok=True)
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.options import cpu_allocation_scope


def snapshot(points, dielectric=False):
    rows = [" ".join(format(v, ".16g") for v in (*first, *second))
            for first, second in zip(points, points[1:])]
    desc = ("Segment: dielectric 3", "properties: 3 1 0 1 0") if dielectric else ("Segment: pec 2", "properties: 2 1 0 0 0")
    geo = "\n".join(["Title: canonical", *desc, *rows, "IBCS_Resistances:", "", "Dielectrics:",
                     "1 4.0 -0.2 1.0 0.0" if dielectric else "", ""])
    return build_geometry_snapshot(*parse_geometry(geo))


def bistatic():
    from ghost_backend.twod import solver
    from ghost_backend.twod.samples import FIELDS, SampleTable, compact_samples

    # Keep all wrappers, operator assembly, field calculation, mesh handling,
    # residuals, progress and abort checks. Replace only the compact writer.
    original = solver.solve_bistatic_rcs_2d_single_polarization
    source = inspect.getsource(inspect.unwrap(original))
    start = source.index("            for idx, obs_deg in enumerate(obs_angles):")
    end = source.index("\n            done_steps += 1", start)
    bulk = '''            if isinstance(samples, SampleTable):
                count = len(obs_angles)
                assert samples.fields == FIELDS and samples.count + count <= samples.capacity
                target = samples.data[samples.count:samples.count + count]
                target[:, 0] = freq_ghz
                target[:, 1] = inc_deg
                target[:, 2] = obs_angles
                target[:, 3] = rcs_lin
                target[:, 4] = rcs_db
                target[:, 5] = amp.real
                target[:, 6] = amp.imag
                target[:, 7] = np.angle(amp, deg=True)
                target[:, 8] = residual_local
                samples.count += count
            else:
'''
    legacy = "\n".join("    " + line for line in source[start:end].splitlines())
    namespace = dict(vars(solver), FIELDS=FIELDS, SampleTable=SampleTable)
    exec(compile(source[:start] + bulk + legacy + "\n" + source[end:], "<experimental compact writer>", "exec"), namespace)
    prototype = namespace[original.__name__]
    theta = -np.linspace(0, 2 * np.pi, args.edges + 1)
    xy = list(zip(0.08 * np.cos(theta), 0.08 * np.sin(theta)))
    xy[-1] = xy[0]
    geo = snapshot(xy)
    # Different request order tests row ordering and labels after co-polarized merge.
    inc = np.arange(0, 360, 2)[::-1].astype(float).tolist()
    obs = np.roll(np.arange(0, 360, 2), 53).astype(float).tolist()
    def solve(which, i, o):
        with patch.object(solver, original.__name__, which), compact_samples():
            return solver.solve_bistatic_rcs_2d(geo, [1.0], i, o, geometry_units="meters")
    for variant in [original, prototype]:
        solve(variant, [0, 15], [54, 20])
    trials = []
    rows = {}
    labels = {}
    for name in ["scalar","bulk","bulk","scalar","scalar","bulk"]:
        gc.collect()
        t0 = time.perf_counter()
        result = solve(original if name == "scalar" else prototype, inc, obs)
        seconds = time.perf_counter() - t0
        tables = result["samples"]
        if name not in rows:
            rows[name] = [np.copy(t.data[:len(t)]) for t in (tables.first, tables.second)]
            labels[name] = [t.labels for t in (tables.first, tables.second)]
        for t, value in zip((tables.first, tables.second), rows[name]):
            assert np.array_equal(t.data[:len(t)], value)
        trials.append(dict(variant=name, seconds=seconds, panel_count=result["metadata"]["panel_count"],
                           rows=len(tables)))
        del result, tables
    np.savez_compressed(out / ("bistatic_fields.npz" if args.edges == 32 else f"bistatic_{args.edges}_fields.npz"), **{f"{k}_{p}": tab[:, 5] + 1j*tab[:, 6]
                        for k, channels in rows.items() for p,tab in zip(("vv","hh"), channels)},
                        incidence_deg=inc, observation_deg=obs)
    diffs = np.max([np.max(np.abs(left-right), axis=0) for left,right in zip(rows["scalar"], rows["bulk"])], axis=0)
    return dict(trials=trials, input_edges=args.edges, max_abs_difference=dict(zip(FIELDS, map(float, diffs))),
                labels=labels, incidence_angles=len(inc), observation_angles=len(obs),
                compact_bytes_per_polarization=rows["bulk"][0].nbytes,
                note="Same in-process warmed public direct solve, single allocated CPU; no export or plotting included.")


def bor():
    from ghost_backend.bor import dispatch, kernels, streaming
    from ghost_backend.validation.sphere import sigma_pec_sphere
    radius = 0.08
    ka = 3.3
    freq = ka * 299792458 / (2*np.pi*radius)
    theta = np.linspace(0, np.pi, 41)
    coords = list(zip(radius*np.sin(theta), radius*np.cos(theta)))
    coords[0], coords[-1] = (0.0, radius), (0.0, -radius)
    geo = snapshot(coords)
    full = list(range(181))
    subset = [0, 33, 89, 180]
    native = streaming._NATIVE
    assert native is not None
    trials = []
    fields = {}
    mie = float(sigma_pec_sphere(radius, freq))
    for name, aspects, assembly, lib in [
            ("stream_4", subset, "auto", native),
            ("stream_181", full, "auto", native),
            ("table_181", full, "tables", native),
            ("fallback_181", full, "auto", None),
            ("stream_181_replay", full, "auto", native)]:
        gc.collect()
        t0 = time.perf_counter()
        with patch.object(streaming, "_NATIVE", lib):
            near_enabled = kernels._native_entry("near_green_rule") is not None
            assert near_enabled == (lib is not None)
            result = dispatch.solve_monostatic_rcs_bor(geo, [freq/1e9], aspects, geometry_units="meters",
                                                       workers=1, assembly=assembly)
        seconds = time.perf_counter()-t0
        meta = result["metadata"]["per_frequency"][0]
        arr = np.array([[complex(v["rcs_amp_real"],v["rcs_amp_imag"]) for v in result["samples"]
                         if v["polarization"] == channel] for channel in ("VV", "HH")])
        fields[name] = arr
        rcs = np.array([v["rcs_linear"] for v in result["samples"]])
        keep = ("assembly","mesh_elements_total","n_unknowns","modes_used","mode_cap","mode_converged","linear_residual",
                "stream_sampling_backend","linear_backward_error","stream_sweeps","stream_mode_block")
        trials.append(dict(variant=name, seconds=seconds, aspects=aspects, near_native=near_enabled,
                           max_abs_mie_db=float(np.max(np.abs(10*np.log10(rcs/mie)))),
                           metadata={k: meta.get(k) for k in keep}))
    ref = fields["stream_181"]
    rel = {key: float(np.linalg.norm(vals - (ref[:, subset] if key=="stream_4" else ref)) /
                     np.linalg.norm(ref[:, subset] if key=="stream_4" else ref))
           for key,vals in fields.items()}
    np.savez_compressed(out / "bor_fields.npz", **fields)
    return dict(radius_m=radius, ka=ka, frequency_hz=freq, mie_rcs_m2=mie, trials=trials,
                relative_complex_l2_vs_native_stream=rel, note="Single warmed host; one worker. Mixed aspect/timing order, timings descriptive.")


def material():
    from ghost_backend.bor import dispatch, kernels, streaming
    from ghost_backend.validation.sphere import sigma_dielectric_sphere
    from functools import wraps
    radius, ka = 0.08, 3.3
    freq = ka * 299792458 / (2*np.pi*radius)
    theta = np.linspace(0, np.pi, 41)
    coords = list(zip(radius*np.sin(theta), radius*np.cos(theta)))
    coords[0], coords[-1] = (0.0, radius), (0.0, -radius)
    geo = snapshot(coords, dielectric=True)
    aspects = list(range(181))
    original_solve = dispatch.solve_bor_dielectric
    original_build = streaming.StreamingFarBlocks._build_range
    detail = {}
    ranges = []
    sampler_counts = {}
    original_sampler = kernels._native_pair_sampler
    def observe_factory(kind):
        native = original_sampler(kind)
        if native is None:
            return native
        def counted(pair, wavenumber, *args):
            out = native(pair, wavenumber, *args)
            if out is not None:
                key = kind + ("_lossy" if wavenumber.imag else "_exterior")
                sampler_counts[key] = sampler_counts.get(key, 0) + 1
            return out
        return counted
    @wraps(original_solve)
    def observe_solve(*args, **kwargs):
        result = original_solve(*args, **kwargs)
        detail.update(result.get("stream_sampling_backends") or {})
        return result
    @wraps(original_build)
    def observe_build(self, lo, hi):
        t0 = time.perf_counter()
        result = original_build(self, lo, hi)
        ranges.append(dict(medium="lossy" if self.solver.k.imag else "exterior", lo=lo, hi=hi,
                           seconds=time.perf_counter()-t0))
        return result
    with (patch.object(dispatch, "solve_bor_dielectric", observe_solve),
          patch.object(kernels, "_native_pair_sampler", observe_factory),
          patch.object(streaming.StreamingFarBlocks, "_build_range", observe_build)):
        t0 = time.perf_counter()
        result = dispatch.solve_monostatic_rcs_bor(geo, [freq/1e9], aspects, geometry_units="meters", workers=1)
        seconds = time.perf_counter()-t0
    meta = result["metadata"]["per_frequency"][0]
    rcs = np.array([row["rcs_linear"] for row in result["samples"]])
    fields = np.array([[complex(v["rcs_amp_real"],v["rcs_amp_imag"]) for v in result["samples"]
                        if v["polarization"] == p] for p in ("VV","HH")])
    np.savez_compressed(out/"material_fields.npz", fields=fields, aspects=aspects)
    mie = sigma_dielectric_sphere(radius, 4-.2j, 1.0, freq)
    keep = ("modes_used","mesh_elements_total","n_unknowns","mode_converged","assembly","linear_residual",
            "stream_sampling_backend","stream_sampling_backends","stream_sweeps")
    return dict(eps_real=4.0, eps_imag=-0.2, radius_m=radius, ka=ka, mie_rcs_m2=mie,
                freq_hz=freq, aspects=len(aspects), seconds=seconds, max_abs_mie_db=float(np.max(np.abs(10*np.log10(rcs/mie)))),
                far_build_ranges=ranges, native_pair_sampler_successful_calls=sampler_counts, direct_solver_medium_backends=detail,
                geometry_api={k:meta.get(k) for k in keep},
                per_medium_in_public_metadata="stream_sampling_backends" in meta)


def native():
    import importlib.util
    from ghost_backend.twod.assembly.native import near
    spec = importlib.util.spec_from_file_location("check_speed_paths", ghost / "scripts/check_speed_paths.py")
    check = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(check)
    manifest = {}
    for name in ("NATIVE_LIBRARIES.json", "NATIVE_LIBRARIES_LINUX.json"):
        platform_data = json.loads((ghost / name).read_text())
        items = []
        for lib in platform_data["libraries"]:
            path = ghost / lib["path"]
            so = ctypes.CDLL(str(path)) if path.suffix == ".so" and sys.platform == "linux" else None
            sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
            items.append(dict(path=lib["path"], binary_sha256_matches=sha(path)==lib["sha256"],
                              source_sha256_matches=sha(ghost/lib["source"])==lib["source_sha256"],
                              linux_exports_present=(all(hasattr(so, x) for x in lib["required_exports"])
                                                     if so is not None else None)))
        manifest[name]=items
    regular = check.checks()
    with patch.object(near, "_dll", return_value=None):
        masked = check.checks()
        assert not near.available()
    return dict(manifests=manifest, ordinary_diagnostic=regular, diagnostic_with_missing_near=masked,
                diagnostic_rows_unchanged=regular==masked, host_platform=platform.platform())


with cpu_allocation_scope(1):
    data = globals()[args.mode]()
data["environment"] = dict(python=sys.version.split()[0], numpy=np.__version__, platform=platform.platform(),
                           cpus=sorted(os.sched_getaffinity(0)) if hasattr(os,"sched_getaffinity") else None)
file_stem = f"bistatic_{args.edges}" if args.mode == "bistatic" and args.edges != 32 else args.mode
(out/f"{file_stem}.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
print(args.mode, "complete", flush=True)
