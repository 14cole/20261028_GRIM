# GHOST bistatic, bodies of revolution and native-path audit

Tests used the integrated 95f8719 source tree, Linux x86-64, Python 3.12.14, NumPy 2.3.5 and one allocated CPU per process. The scripts timed the public geometry solver with output materialized, excluding GUI, file export and result checks. All changes were confined to the probe process. The accompanying JSON and NPZ files hold the timings, maximum differences and full complex arrays.

## 2D bistatic

A 2D bistatic job has distinct incidence and observation lists. The paired API runs TE and TM, reuses the discretization where valid, solves the incident right-hand sides and projects each solution at all requested observations. Two lists of 180 angles produce 64,800 output rows for one frequency and both polarizations. A 180-angle monostatic run produces 360 rows. The GUI has a bistatic path and supports survey and mesh-check workflows. The monostatic experimental/compressed selection and its growth studies do not establish performance for bistatic. See `ghost_backend/twod/solver.py` at the paired and single-polarization bistatic entry points and `execution/cpu.py::bistatic_kernels`.

The current output writer builds one nine-field dictionary per result row and then extracts those fields again to write the compact application array. The experiment changed only that writer, filling existing preallocated columns for one incidence at a time. It retained the solver, floating-point field calculation, physical order, residual, callback/abort cadence and ordinary list path. These are warmed, in-process scalar/bulk/bulk/scalar/scalar/bulk trials.

| PEC circle, 1 GHz, 0.08 m radius | Angles and channels | Current median | Bulk median | Difference |
| --- | --- | ---: | ---: | ---: |
| 32 panels | 180 × 180 × 2 | 0.2274 s | 0.0712 s | 0.1563 s, 68.7% |
| 256 panels | 180 × 180 × 2 | 0.6661 s | 0.5117 s | 0.1544 s, 23.2% |

The nine numeric columns (including phase in degrees), labels and complex fields were identical in both comparisons on this host. Incidence was reversed and observation order rotated. Retained numeric capacity remained 2,332,800 bytes per channel, 4.45 MiB together. These measurements expose a roughly fixed angular-output cost at these two mesh sizes. They establish neither a reduction in peak RSS nor the quoted percentage on a large mesh. Qualification for shipping should exercise the GUI survey and checked workflows, cancellation, multiple frequencies, wrapped phase including signed zero, unordered inputs and the existing list-return API. A compact append-block method on SampleTable would avoid duplicating the column schema in production. If only wide monostatic sweeps are important, this is a lower priority.

Bistatic's admission also adds `n_inc * n_obs * (1024 * n_freq + 64)` bytes in each single-polarization frequency loop despite the compact application's nine float64 output columns. This is a candidate for measurement only. Per-frequency maps, real and complex projections, temporary sort buffers, legacy dictionary rows, channel merging and certification have different lifetimes. Measure high-water RSS on compact/list and survey/checked jobs before changing the gate. Dense monostatic cached-matrix admission results cannot be generalized to this path.

## BoR

For an axisymmetric generatrix the production geometry API handles monostatic aspect angles from 0° to 180° and can mirror results exactly to 360°. It co-solves VV/HH in modal systems. A checked run adds mesh comparisons. The GUI blocks BoR bistatic jobs. Low-level conductor/IBC, dielectric PMCHWT, coated PEC, partial coating, multilayer, banded-region and patch entry points choose their own modal work, with dense/table, dense/streaming and compressed plans where supported. Local/HPC drivers eventually use these BoR paths. Results from a 2D dense-LU or compressed run do not establish BoR costs. The distinct 2D boundary-density API solves one frequency, aspect and polarization for representation densities used by visualization.

Fresh PEC sphere, radius 0.08 m, ka 3.3 (1.96818 GHz), 40 meridian elements, 82 modal unknowns, 10 modes used and one worker:

| Path | Aspects | Wall time | Relative L2 of both complex channels vs native stream | Maximum absolute RCS error vs Mie series |
| --- | ---: | ---: | ---: | ---: |
| Default streaming, shipped native library | 4 | 2.99 s | 7.47e-16 on shared looks | 0.02197 dB |
| Default streaming, shipped native library | 181 | 2.91 s, 3.21 s on replay | 0 on replay | 0.02197 dB |
| Explicit native tables | 181 | 3.17 s | 5.12e-16 | 0.02197 dB |
| Streaming with BoR native library disabled | 181 | 13.40 s | 8.13e-15 | 0.02197 dB |

This fixture amortizes operator preparation over aspects. Timings at 4 and 181 aspects overlap the native replay spread. The 181-aspect forced NumPy route took 4.2–4.6 times the native wall time. The Mie reference checks absolute RCS magnitude, while the raw complex comparison separately checks agreement between numerical paths. This is a small PEC sphere and one electrical size.

A separate lossy dielectric sphere of the same dimensions and 181 aspects used 164 modal unknowns, relative permittivity 4−0.2j and relative permeability 1. The maximum absolute difference from the dielectric-sphere Mie series was 0.03915 dB. The actual grouped native Green sampler and bracket sampler both returned results for complex interior wavenumbers (five calls apiece), as well as for the exterior. The solver recorded `banded_native_pairs` on each side. The brief README below its junction discussion says a lossy side uses the NumPy sampler. That description applies to some configurations, while the shipped grouped native sampler already handles this case. `BOR_PERFORMANCE.md` describes the newer support. The geometry API preserves only the aggregate sampler name, discarding the per-medium map that the lower-level solver calculated. Correcting the README and forwarding `stream_sampling_backends` would make real runs easier to diagnose.

For this single material run, both far-range builds totaled 0.219 s of the 6.44 s instrumented solve, including just 0.063 s in the lossy interior range. Rewriting only this particular far build could save at most that observed component time on this fixture. A faster general BoR solve remains an open question for larger, layered models. Profile near preparation, modal solves and cross-surface interactions separately before committing to new kernels. The documented BoR adaptive near-quadrature study includes bodies up to ka=30, which bounds that specific experiment.

## Native distribution

All four Windows DLLs and four Linux SO files and their C sources matched the SHA-256 hashes in their respective repository manifests. Each Linux SO loaded and exposed every required manifest symbol. This run exercised the native and fallback BoR solver paths on Linux. A Windows DLL hash check establishes packaged identity, not loader behavior, speed or private committed memory on Windows. Native Windows 32 GB solver validation remains distinct. The Linux binaries target x86-64 / glibc 2.35+ with libgomp for BoR.

The user-facing `scripts/check_speed_paths.py` printed seven OK rows on this host even when the probe forced `near._dll()` to return None and confirmed `near.available()` was false. The script omits 2D near and tests far library loading rather than all required runtime entry points. A small diagnostic fix should check 2D near and the far/scatter exports against the runtime wrappers or distribution manifest. This improves fallback visibility and has no demonstrated numerical or timing effect on a healthy installation.

## Reproduce

Run each command with the Python used by GHOST. For one-thread Linux measurements, set `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1` and pin to an available CPU. No network, new build or source edits are required.

```sh
python probe.py /path/to/repository bistatic --out results
python probe.py /path/to/repository bistatic --edges 256 --out results
python probe.py /path/to/repository bor --out results
python probe.py /path/to/repository material --out results
python probe.py /path/to/repository native --out results
```
