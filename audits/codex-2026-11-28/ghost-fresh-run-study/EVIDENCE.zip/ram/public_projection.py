"""Check the normal Dense and Compressed sweep at both P1 and P2, with multiple angle batches."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.twod.solver import solve_monostatic_rcs_2d
from ghost_backend.twod.assembly import kernels

def geometry(panels):
    angle=-2*np.pi*np.arange(panels)/panels
    points=np.column_stack((.08*np.cos(angle),.061*np.sin(angle)))
    lines=["Title: magnetic dielectric ellipse","Segment: body 3","properties: 3 1 0 1 0"]
    for a,b in zip(points,np.roll(points,-1,axis=0)):
        lines.append(" ".join(f"{v:.17g}" for v in (*a,*b)))
    lines+=["IBCS_Resistances:","","Dielectrics:","1 2.5 -0.04 1.3 -0.02"]
    return build_geometry_snapshot(*parse_geometry("\n".join(lines)+"\n"))

def regional_geometry(panels):
    angle=-2*np.pi*np.arange(panels)/panels
    lines=["Title: four distinct dielectric bodies"]
    for i in range(4):
        lines.extend([f"Segment: body{i} 3",f"properties: 3 1 0 {i+1} 0"])
        points=np.column_stack((.08*np.cos(angle)+i*.3,.061*np.sin(angle)))
        for a,b in zip(points,np.roll(points,-1,axis=0)):
            lines.append(" ".join(f"{v:.17g}" for v in (*a,*b)))
    lines+=["IBCS_Resistances:","","Dielectrics:"]
    lines.extend(f"{i+1} {2.2+i*.1} -0.04 1.3 -0.02" for i in range(4))
    return build_geometry_snapshot(*parse_geometry("\n".join(lines)+"\n"))

def main():
    p=argparse.ArgumentParser()
    p.add_argument("output",type=Path)
    p.add_argument("--extra", action="store_true")
    args=p.parse_args()
    angles=list(range(-90,90))
    records=[]
    orig_cache=kernels._cached_loads
    def observe(*a,**kw):
        value=orig_cache(*a,**kw)
        if value is not None:
            counts["cache_hits"]+=1
            if value.get("u_negated"): counts["alias_hits"]+=1
        return value
    kernels._cached_loads=observe
    fixtures=(("dielectric",1),("dielectric",2)) if not args.extra else (("dielectric",3),("regional",1))
    for name,order in fixtures:
        for method in ("dense","compressed"):
            counts={"cache_hits":0,"alias_hits":0}
            opts=dict(factorization=method,basis_order=order,mesh_strategy="global",
                      assembly_threads=1,blas_threads=1,rhs_compression="on" if args.extra else "off",angle_batch_size=179 if args.extra else 64,ram_budget_gib=3)
            with cpu_allocation_scope(1):
                out=solve_monostatic_rcs_2d(geometry(64) if name=="dielectric" else regional_geometry(24),[1.35],angles,geometry_units="meters",
                    strict_quality_gate=True,compute_condition_number=True,execution_options=opts)
            meta=out["metadata"]
            assert meta["quality_gate"]["passed"]
            assert bool(meta["compressed_factors"])==(method=="compressed")
            fields={}
            for pol in ("VV","HH"):
                rows=out["co_solved_samples"][pol]
                assert [r["theta_inc_deg"] for r in rows]==angles
                a=np.array([complex(r["rcs_amp_real"],r["rcs_amp_imag"]) for r in rows])
                fields[pol]=hashlib.sha256(a.tobytes()).hexdigest()
            records.append(dict(degree=order,method=method,fixture=name,unknowns=meta["dense_largest_system"],
                panels=meta["panel_count_max"],fields=fields,**counts))
            args.output.write_text(json.dumps(records,indent=2)+"\n")
if __name__=="__main__": main()
