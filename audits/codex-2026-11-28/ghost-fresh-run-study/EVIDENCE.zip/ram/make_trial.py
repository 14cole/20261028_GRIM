"""Make an isolated copy of the solver with two monostatic projection experiments.

Usage: python make_trial.py path/to/tools/GHOST output-directory
The checkout stays untouched. Run the paired measurements against each separately.
"""
import argparse
from pathlib import Path
import shutil

def once(text,old,new):
    assert text.count(old)==1,old[:80]
    return text.replace(old,new)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('source',type=Path)
    parser.add_argument('destination',type=Path)
    args=parser.parse_args()
    shutil.copytree(args.source,args.destination,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    path=args.destination/'ghost_backend/twod/assembly/kernels.py'
    kernel=path.read_text()
    start=kernel.index("    plan = prepared_projection if projection == 'grid' else None")
    end=kernel.index('    if projection == "matched":',start)
    prep=kernel[start:end]
    kernel=once(kernel,prep,'')
    kernel=once(kernel,'    result = np.zeros((rho.shape[1],len(dirs))',prep+'    result = np.zeros((rho.shape[1],len(dirs))')
    kernel=once(kernel,"    if weights is not None:\n            if rho.shape[1] == 1:\n                return rho[:, 0] @ weights\n            return np.einsum('na,na->a', rho, weights)","    if weights is not None:\n            field = (rho[:, 0] @ weights if rho.shape[1] == 1\n                     else np.einsum('na,na->a', rho, weights))\n            return -field if potential == 'SLP' and loads.get('u_negated', False) else field")
    # Only single-dielectric RHS uses this new private option. It owns both buffers
    # throughout a batch and its sole post-assembly edit negates the upper half.
    kernel=once(kernel,'element_mask=None, observation_coefficients=None):','element_mask=None, observation_coefficients=None, signed_dielectric_rhs=False):')
    kernel=once(kernel,"loads['u'] = bu.copy()","loads['u'] = bu if signed_dielectric_rhs else bu.copy()\n            loads['u_negated'] = signed_dielectric_rhs")
    kernel=once(kernel,"loads['dn'] = plain_dn if plain_dn is not None else bdn.copy()","loads['dn'] = bdn if signed_dielectric_rhs else (plain_dn if plain_dn is not None else bdn.copy())")
    path.write_text(kernel)
    path=args.destination/'ghost_backend/twod/formulations/dielectric.py'
    path.write_text(once(path.read_text(),'incident_loads(mesh, k0, angles, rhs[:n], rhs[n:])','incident_loads(mesh, k0, angles, rhs[:n], rhs[n:], signed_dielectric_rhs=True)'))
if __name__=='__main__':
    main()
