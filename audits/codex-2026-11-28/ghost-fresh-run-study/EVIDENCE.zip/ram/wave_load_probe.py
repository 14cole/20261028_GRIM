"""Measure real P1 single-dielectric RHS/projection stages, no factorization.

Run in two fresh Python processes, choosing main or the staged trial with PYTHONPATH.
The deterministic nonphysical density isolates the projection independent of a solve.
"""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import time
import tracemalloc
import numpy as np
from ghost_backend.twod.assembly import kernels,session
from ghost_backend.twod.formulations.dielectric import rhs_many
from ghost_backend.twod.geometry import LinearElement,LinearMesh,LinearNode

def geometry(n):
    a=np.linspace(0,2*np.pi,n,endpoint=False)
    xy=np.column_stack((np.cos(a),.7*np.sin(a)))
    edges=np.roll(xy,-1,axis=0)-xy
    length=np.linalg.norm(edges,axis=1)
    tangent=edges/length[:,None]
    normal=tangent[:,[1,0]]*np.array([1,-1])
    nodes=[LinearNode(p,key=(i,0)) for i,p in enumerate(xy)]
    elements=[LinearElement('body',3,0,1,0,(i,(i+1)%n),p,xy[(i+1)%n],p+edges[i]/2,tangent[i],normal[i],length[i],i) for i,p in enumerate(xy)]
    return LinearMesh(nodes,elements)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('output',type=Path)
    p.add_argument('--panels',type=int,default=4096)
    args=p.parse_args()
    n=args.panels
    mesh=geometry(n)
    angles=np.arange(-90.,90.)
    k=43.
    rng=np.random.default_rng(472)
    rho=rng.random((n,len(angles)))+1j*rng.random((n,len(angles)))
    run=session.AssemblySession()
    run.plane_wave_loads['monostatic']=True
    counts={'rhs':0,'cached':0,'miss':0}
    orig=kernels.geometry_arrays
    phase='rhs'
    def observed(*a,**kw):
        counts[phase]+=1
        return orig(*a,**kw)
    kernels.geometry_arrays=observed
    with session._SESSION.override(run):
        gc.collect()
        tracemalloc.start()
        rhs=rhs_many(mesh,k,angles)
        retained,peak=tracemalloc.get_traced_memory()
        tracemalloc.stop()
        loads=run.plane_wave_loads['latest'][2]
        digest=lambda x:hashlib.sha256(x.tobytes()).hexdigest()
        main_hash=digest(rhs)
        cycles=[]
        phase='cached'
        for j in range(6):
            t=time.perf_counter()
            slp=kernels.farfield(mesh,rho,k,angles,'SLP')
            dlp=kernels.farfield(mesh,rho,k,angles,'DLP')
            cycles.append(time.perf_counter()-t)
        tracemalloc.start()
        kernels.farfield(mesh,rho,k,angles,'SLP')
        projection_peak=tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        # Different frequency intentionally misses this cache and checks the fallback code.
        phase='miss'
        different=kernels.farfield(mesh,rho[:,:1],k*1.03,angles[:3],'DLP')
        checks=dict(rhs=main_hash,slp=digest(slp),dlp=digest(dlp),miss=digest(different))
        result=dict(panels=n,unknowns=2*n,angles=len(angles),kernel_paths=counts,rhs_payload=rhs.nbytes,
                    each_load_payload=loads['u'].nbytes, rhs_shares_u=np.shares_memory(rhs,loads['u']),
                    rhs_shares_dn=np.shares_memory(rhs,loads['dn']),rhs_traced_live=retained,
                    rhs_traced_peak=peak,projection_traced_peak=projection_peak,
                    projection_two_potentials_seconds=cycles,field_checks=checks)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))

if __name__=='__main__': main()
