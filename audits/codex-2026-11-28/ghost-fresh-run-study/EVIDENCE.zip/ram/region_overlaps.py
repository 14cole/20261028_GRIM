"""Exercise a coalesced equal-wavenumber source when its two media have different neighbors."""
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from regional_memory import fixture
from ghost_backend.twod import solver as rcs
from ghost_backend.twod.geometry import MaterialLibrary
from ghost_backend.twod.formulations import regions as mr

def one(pol):
    mesh,_=fixture(4,8)
    for i,e in enumerate(mesh.elements):
        if i//8==2:
            e.seg_type,e.neg_mat,e.pos_mat=5,1,3
        if i//8==3:
            e.seg_type,e.pos_mat,e.ibc_flag=2,0,int(i%8<4)
    # Medium 1 and exterior have identical k; they have distinct neighbors (2 and 3).
    mat=MaterialLibrary({1:25+5j},{1:(1+0j,1+0j),2:(2.5-.4j,1+0j),3:(4+0j,1+0j)})
    infos=rcs._build_linear_coupled_infos(mesh,mat,1.35,pol,2*np.pi*1.35e9/299792458)
    layout=mr.build_layout(mesh,infos,pol)
    assert layout['region_props'][0]['k']==layout['region_props'][1]['k']
    plan=mr.operator_plan(layout)
    h=hashlib.sha256()
    selected=None
    for k,reqs in plan:
        for req in reqs:
            h.update(repr((k,req['source'],req['kind'],req['observer'])).encode())
            for key in ('rows','s_rows','k_rows'):
                h.update(np.asarray(sorted(req[key]),dtype='<i8').tobytes())
            if k==layout['region_props'][0]['k'] and req['kind']=='plain':
                iface=layout['ifaces'][req['source']]
                if {iface['r_m'],iface['r_p']}=={0,1}:
                    selected=req
    assert len(selected['rows'])==32
    return dict(pol=pol,groups=len(plan),requests=sum(len(reqs) for _,reqs in plan),
                full_union_rows=len(selected['rows']),full_plan_digest=h.hexdigest())

if __name__=='__main__':
    Path(sys.argv[1]).write_text(json.dumps([one('TE'),one('TM')],indent=2)+'\n')
