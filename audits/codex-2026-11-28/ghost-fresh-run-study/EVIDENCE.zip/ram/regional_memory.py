"""Measure retained Python sets in a real regional plan and setup allocations for its prepared oracle."""
import argparse
import gc
import hashlib
import json
import sys
import time
import tracemalloc
from pathlib import Path
import numpy as np
from ghost_backend.twod.geometry import LinearNode, LinearElement, LinearMesh, MaterialLibrary
from ghost_backend.twod import solver as rcs
from ghost_backend.twod.formulations import regions as mr
from ghost_backend.compressed.regional_coefficients import PreparedOracle

def fixture(bodies, panels):
    nodes=[]
    elements=[]
    a=-np.arange(panels)*2*np.pi/panels
    base=.05*np.column_stack((np.cos(a),.8*np.sin(a)))
    for body in range(bodies):
        coords=base+np.array([body*.125,0])
        edges=np.roll(coords,-1,axis=0)-coords
        length=np.linalg.norm(edges,axis=1)
        tangent=edges/length[:,None]
        normal=tangent[:,[1,0]]*np.array([1,-1])
        idx=len(nodes)
        for i,p in enumerate(coords):
            nodes.append(LinearNode(p,(idx+i,0)))
            elements.append(LinearElement(f"body{body}",3,0,body+1,0,(idx+i,idx+(i+1)%panels),
                p,coords[(i+1)%panels],p+.5*edges[i],tangent[i],normal[i],length[i],idx+i))
    mesh=LinearMesh(nodes,elements)
    materials=MaterialLibrary({}, {i:(complex(2.2+i*.02,-.07*i),1+0j) for i in range(1,bodies+1)})
    infos=rcs._build_linear_coupled_infos(mesh,materials,1.35,'TE',2*np.pi*1.35e9/299792458)
    return mesh,infos

def sets_bytes(requests):
    sets={id(s):s for request in requests for name,s in request.items() if name in ('rows','s_rows','k_rows')}
    return sum(sys.getsizeof(s) for s in sets.values())

def rss_bytes():
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith('VmRSS:'):
            return int(line.split()[1])*1024
    raise RuntimeError("Cannot read Linux RSS")

def one(bodies,panels,oracle,cut=32):
    mesh,infos=fixture(bodies,panels)
    n=len(mesh.nodes)
    out=dict(bodies=bodies,panels=n,nodes=n,unknowns=n*2,cut=cut,stage="oracle" if oracle else "plan")
    gc.collect()
    rss_before=rss_bytes()
    tracemalloc.start()
    t=time.perf_counter()
    if not oracle:
        layout=mr.build_layout(mesh,infos,"TE")
        plan=mr.operator_plan(layout)
        live,peak=tracemalloc.get_traced_memory()
        groups=[r for k,p in plan for r in p]
    else:
        o=PreparedOracle(mesh,infos,'TE',cut=cut)
        live,peak=tracemalloc.get_traced_memory()
        groups=[rec[0] for k,p in o.groups for rec in p]
    rss_after=rss_bytes()
    elapsed=time.perf_counter()-t
    tracemalloc.stop()
    out.update(rss_before_bytes=rss_before,rss_after_bytes=rss_after,set_bytes=sets_bytes(groups),requests=len(groups),live_bytes=live,peak_bytes=peak,seconds=elapsed)
    if not oracle:
        h=hashlib.sha256()
        for k,requests in plan:
            for req in requests:
                h.update(repr((k, req['kind'], req['source'], req['observer'])).encode())
                for key in ('rows','s_rows','k_rows'):
                    h.update(np.asarray(sorted(req[key]),dtype='<i8').tobytes())
        out["plan_digest"]=h.hexdigest()
    if oracle:
        bounds={id(a):a for k,g in o.groups for rec in g for a in rec[-2:] if a is not None}
        out.update(bound_arrays_owned=sum(a.nbytes for a in bounds.values() if a is not o.mass),unique_bound_arrays=len(bounds))
        ids=np.array([0,2,panels//2,panels+2,n+1,2*n-2],dtype=int)
        matrix,error=o.get_with_error(ids,ids[::-1])
        out["matrix_sha256"]=hashlib.sha256(matrix.tobytes()).hexdigest()
        out["error_sha256"]=hashlib.sha256(error.tobytes()).hexdigest()
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument("output",type=Path)
    p.add_argument("--plan",action="store_true")
    p.add_argument("--large", action="store_true",help="one 65,536-unknown plan only")
    args=p.parse_args()
    data=[]
    cases=([(1,2048),(4,512),(16,128),(32,64),(32,256)] if args.plan else [(2,24),(8,32),(16,32)])
    if args.large:
        assert args.plan
        cases=[(32,1024)]
    for n,p in cases:
        data.append(one(n,p,not args.plan))
        args.output.write_text(json.dumps(data,indent=2)+"\n")
        print(n,p,data[-1]["live_bytes"],flush=True)
if __name__=="__main__": main()
