"""Use immutable per-medium row memberships in an isolated tree. Preserve equal-k request unions."""
import sys
from pathlib import Path

def main():
    path=Path(sys.argv[1])/"ghost_backend/twod/formulations/regions.py"
    code=path.read_text()
    start=code.index("        rows = {n for mi in mis",code.index("def operator_plan"))
    stop=code.index("    for mi, ifc in enumerate(ifaces):",start)
    code=code[:start]+'''        rows = frozenset(n for mi in mis for n in ifaces[mi]['nodes'])
        s_rows, k_rows = set(), set()
        for observer in mis:
            target = ifaces[observer]
            nodes = target['nodes']
            if target['r_m'] >= 0 and target['r_p'] >= 0:
                s_rows.update(nodes)
                k_rows.update(nodes)
            else:
                pec = np.abs(target['robin_alpha']) <= EPS if layout['polarization'] == 'TM' else np.zeros(target['n'], bool)
                s_rows.update(n for n,keep in zip(nodes,pec) if keep)
                k_rows.update(n for n,keep in zip(nodes,pec) if not keep)
        s_rows = rows if s_rows == rows else frozenset(s_rows)
        k_rows = rows if k_rows == rows else frozenset(k_rows)
        for mi in mis:
            key = ('plain', mi)
            if key not in slot:
                slot[key] = dict(kind='plain', source=mi, observer=None, rows=rows, s_rows=s_rows, k_rows=k_rows)
            else:
                request = slot[key]
                for name, addition in (('rows', rows), ('s_rows', s_rows), ('k_rows', k_rows)):
                    current = request[name]
                    if not addition.issubset(current):
                        request[name] = addition if current.issubset(addition) else current.union(addition)
'''+code[stop:]
    path.write_text(code)
if __name__=="__main__": main()
