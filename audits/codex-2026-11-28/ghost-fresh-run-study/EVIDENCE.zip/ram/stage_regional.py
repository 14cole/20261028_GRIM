"""Apply the private compressed-oracle experiment to the staged tree from make_trial.py."""
import argparse
from pathlib import Path

def main():
    p=argparse.ArgumentParser()
    p.add_argument("trial",type=Path)
    args=p.parse_args()
    target=args.trial/"ghost_backend/compressed/regional_coefficients.py"
    source=target.read_text()
    source=source.replace("        route_maps = {}","        route_maps = {}\n        source_masses = {}\n        observer_masses = {}")
    a=source.index("                source_mass=np.zeros(nn)")
    b=source.index("                # Nodes that",a)
    source=source[:a]+'''                source_mass=weighted_mass=None
                if self.cut is not None and complex(k).imag < 0:
                    si,oi=request['source'],request['observer']
                    if si not in source_masses:
                        mass=np.zeros(nn)
                        for j in self.layout['ifaces'][si]['eids']:
                            e=mesh.elements[j]
                            np.add.at(mass,np.asarray(e.node_ids),integral_bounds(e))
                        source_masses[si]=mass
                    source_mass=source_masses[si]
                    weighted_mass=self.mass
                    if coefficient is not None:
                        if oi not in observer_masses:
                            mass=np.zeros(nn)
                            for j,e in enumerate(mesh.elements):
                                np.add.at(mass,np.asarray(e.node_ids),abs(coefficient[j])*integral_bounds(e))
                            observer_masses[oi]=mass
                        weighted_mass=observer_masses[oi]
'''+source[b:]
    old="                prepared.append((request,reach,source,coefficient,source_mass,weighted_mass))"
    assert source.count(old)==1
    source=source.replace(old,"                compact = {name:request[name] for name in ('kind','source')}\n                prepared.append((compact,reach,source,coefficient,source_mass,weighted_mass))")
    target.write_text(source)
if __name__=="__main__": main()
