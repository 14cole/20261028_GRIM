# RAM across regional planning, batch setup and monostatic projection

Tests used the current integrated solver on Linux x86-64 with CPython 3.12.14, NumPy 2.3.5, SciPy 1.17.0, and one BLAS thread. Three experimental edits were staged in an isolated copy of the solver. All numbers in MiB use 1,048,576 bytes.

## Repeated row memberships across dielectric interfaces

The regional solver builds a separate assembly request for each source interface. When many distinct dielectric regions share the same exterior, each source requests rows from all the exterior’s interfaces. The released implementation independently builds three Python sets of node indices for each request. The trial computes row memberships once per medium and shares immutable copies. When two media with the same wavenumber contribute to the same source, the trial preserves the union of their required rows.

| P1 panels | Dielectric interfaces | Released plan memberships, MiB | Shared memberships, MiB | Released layout + plan peak, MiB | Trial layout + plan peak, MiB |
|---:|---:|---:|---:|---:|---:|
| 2,048 | 1 | 0.75 | 0.25 | 1.06 | 0.68 |
| 2,048 | 4 | 1.88 | 0.25 | 2.17 | 0.66 |
| 2,048 | 16 | 6.39 | 0.25 | 7.08 | 1.07 |
| 2,048 | 32 | 12.29 | 0.19 | 13.54 | 1.63 |
| 8,192 | 32 | 49.04 | 0.76 | 53.84 | 6.39 |
| 32,768 | 32 | 196.04 | 3.01 | 215.04 | 25.44 |

All six plans produced identical hashes of the wavenumber, interface, request type and sorted contents of all row sets. Set sizes include object overhead and exclude the node integers already owned by the mesh. Set allocation grows in steps. At 65,536 unknowns, the real process RSS increment between mesh preparation and completed layout + plan was 204.61 MiB on the released code and 11.57 MiB on the trial. This roughly 193 MiB stage saving is 0.59% of 32 GiB. The large case allocated the actual plan without constructing the numerical operator. A high interface count represents distinct region pairs. Separate bodies drawn with one material label and the same exterior can share a single interface group.

The partial-overlap control used equal-wavenumber air and dielectric regions with different neighbors, mixed PEC and IBC rows, and TE and TM. The coalesced request preserved all 32 nodes and both complete plan digests matched. Hash inputs include row IDs and route identities.

## Prepared regional coefficient oracle

After turning rows into routes, Compressed retained the entire request through the lifetime of the coefficient oracle. It also materialized two full-node-mass vectors for every request and traversed every element for each, including lossless groups that cannot use the attenuation cutoff. The oracle trial stores the request’s source and kind. It builds loss bounds only for active lossy groups, shares source mass by source interface, uses its existing mesh mass on unweighted observation routes, and shares weighted mass per observer. These bounds preserve conservative error reporting during coefficient truncation.

At 512 panels, 16 distinct dielectric regions and 1,024 unknowns, the released oracle retained 2.78 MiB and peaked at 3.35 MiB during setup. The oracle-only trial retained 0.97 MiB and peaked at 2.68 MiB. Adding shared plan rows reduced the setup peak further to 1.55 MiB. The figures include allocations traced after the mesh and input properties already existed. The three sampled coefficient matrices and error arrays matched exactly. Each variant ran in a separate process.

A separate test included two widely separated islands with the same lossy region and an impedance-lined conducting boundary. TE and TM at P1 and P3 each produced eight actual route drops and seven positive entries across the test tiles with cutoff 32. Every entry of each used mass bound was independently reconstructed, and every complex coefficient and nonzero error-bound digest matched the released code. Cutoff-disabled controls matched as well. A public four-material P1 solve with 96 panels and 180 monostatic angles gave identical complex VV and HH amplitude digests for both Dense and Compressed.

## Monostatic loads and projection

Matched backscatter projects using plane-wave loads already computed for the RHS. The released projection rebuilds five mesh arrays before checking for a cache hit. Moving that check earlier eliminates the geometry pass on a hit. The public single-dielectric RHS also owns both incident load arrays for the full angle batch. Its one post-assembly modification negates the upper block. An opt-in for this formulation lets the cache point to both RHS halves and applies the sign on the SLP projection. The other formulations retain their existing copy and mutation behavior.

The stage probe used 4,096 P1 panels, 8,192 unknowns, 180 monostatic angles, and a deterministic complex density. It measured the production RHS and projection routines.

| Measure | Released | Trial |
|---|---:|---:|
| Independently owned cache payload | 22.50 MiB | 0 |
| Live RHS + projection-load allocations after RHS | 45.01 MiB | 22.51 MiB |
| RHS construction peak | 48.81 MiB | 28.85 MiB |
| Additional matched-projection peak | 888,288 B | 8,928 B |
| Geometry repacks in 13 matched projections | 13 | 0 |
| Geometry repacks on one deliberate cache miss | 1 | 1 |
| Median SLP + DLP projection across six consecutive calls | 14.34 ms | 3.29 ms |

All complex array digests matched for the RHS, both matched potentials, and a different-frequency cache miss. Per-batch independently owned payload savings are 16 × unknowns × batch columns bytes for this single-dielectric formulation. For 65,536 unknowns this is 64 MiB for a 64-column batch or 180 MiB for a full 180-column batch. The forecast currently includes multiple angle work arrays. These figures do not establish a change in full-solve peak, admission limit, factorization time, or RSS savings from every formulation.

The public solver exercised both backends, both polarizations, P1, P2, P3, and 180 distinct incident directions on a magnetic lossy dielectric ellipse. Runs covered forced angle compression on and off, and batches with a single remaining angle. All twelve complete complex channel arrays matched between corresponding versions. Instrumentation counted 64 signed-cache hits across the six single-dielectric runs. A further four regional channel arrays matched and their cache retained its original ownership. The small public runs validate output and reachability. They do not measure large hierarchical factor performance or physical mesh convergence.

## Independent follow-up

1. Reproduce the stateful projection alias tests with the CPU mixed-precision path, spool-backed Dense, and environment-specific GPU paths before broad shipping. Include cancellation and subsequent reuse of an assembly session. The early projection return has a smaller ownership surface and can be reviewed independently.
2. Record physical process or cgroup peak over full mixed-material factorization and sweep, with worker counts representative of users. The isolated planner result quantifies actual memory committed during planning. The full solver can peak later in a different stage.
3. Add a pathological equal-wavenumber multilayer case larger than the small explicit union control. Review all consumers of the plan before adopting immutable shared rows. Confirm public forecast numbers remain unchanged for mixed PEC/IBC and transmission geometries.
4. Treat the per-request loss-bound savings as conditional on the regional path. Preserve every weighted bound test when changing preparation. A single-material linear array or a Dense numerical matrix still has its separate storage cost.

## Reproduction

Run in this evidence directory with an empty trial destination. The source argument is the checkout's tools/GHOST directory. A Python environment containing the solver dependencies is required.

```bash
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
src=/path/to/checkout/tools/GHOST
trial_dir=/tmp/ghost-ram-comparison
python make_trial.py "$src" "$trial_dir"
PYTHONPATH="$src" python wave_load_probe.py baseline.json
PYTHONPATH="$trial_dir" python wave_load_probe.py trial.json
PYTHONPATH="$src" python public_projection.py public_base.json
PYTHONPATH="$trial_dir" python public_projection.py public_trial.json
python stage_regional.py "$trial_dir"
PYTHONPATH="$src" python regional_memory.py regional_base.json
PYTHONPATH="$trial_dir" python regional_memory.py regional_trial.json
python stage_shared_rows.py "$trial_dir"
PYTHONPATH="$trial_dir" python regional_memory.py regional_combined.json
PYTHONPATH="$src" python regional_memory.py regional_plan.json --plan
PYTHONPATH="$trial_dir" python regional_memory.py regional_plan_shared.json --plan
PYTHONPATH="$src" python regional_memory.py regional_large_base.json --plan --large
PYTHONPATH="$trial_dir" python regional_memory.py regional_large_shared.json --plan --large
for suffix in base trial; do
  tree="$src"
  if [ "$suffix" = trial ]; then tree="$trial_dir"; fi
  PYTHONPATH="$tree" python regional_bounds.py "bounds_${suffix}.json"
  PYTHONPATH="$tree" python region_overlaps.py "overlap_${suffix}.json"
  PYTHONPATH="$tree" python public_projection.py "public_extra_${suffix}.json" --extra
done
```

Use the same Python environment and native libraries in both arms. RSS readings use Linux procfs. Absolute timings and allocator watermarks will vary with the machine.
