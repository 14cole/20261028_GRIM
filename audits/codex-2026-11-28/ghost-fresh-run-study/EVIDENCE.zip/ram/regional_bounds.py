"""Exercise nonzero attenuation bounds and weighted routes with inter-island queries."""
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from ghost_backend.compressed.regional_coefficients import PreparedOracle
from ghost_backend.twod import solver as rcs
from ghost_backend.twod.geometry import MaterialLibrary
from ghost_backend.twod import basis
from ghost_backend.execution.options import execution_scope
from regional_memory import fixture

def checks(pol,degree,cut):
    per_loop=8
    mesh,_=fixture(3,per_loop)
    for i in range(3):
        center=np.array([i*.125,0])
        target=np.array(([0,0],[18,0],[0,0])[i])
        scale=.3 if i==2 else 1.
        for j in range(i*per_loop,(i+1)*per_loop):
            e=mesh.elements[j]
            mesh.nodes[j].xy=(mesh.nodes[j].xy-center)*scale+target
            e.p0=(e.p0-center)*scale+target
            e.p1=(e.p1-center)*scale+target
            e.center=(e.center-center)*scale+target
            e.length*=scale
            e.pos_mat=1
            if i==2: e.seg_type,e.ibc_flag=4,1
        # Outer islands have the same lossy dielectric label. The inner conductor
        # is assigned its own impedance flag and lives in the first island.
    with execution_scope(dict(basis_order=degree)):
        basis.enrich(mesh)
    materials=MaterialLibrary({1:complex(20,3)}, {1:(complex(2.5,-.6),complex(1.3,-.02))})
    infos=rcs._build_linear_coupled_infos(mesh,materials,1.35,pol,2*np.pi*1.35e9/299792458)
    oracle=PreparedOracle(mesh,infos,pol,cut=cut)
    sets=[]
    for k,requests in oracle.groups:
        for req,reach,source,coeff,source_mass,weighted_mass in requests:
            if cut is None or complex(k).imag>=0: continue
            sm=np.zeros(len(mesh.nodes));wm=np.zeros(len(mesh.nodes))
            for i,e in enumerate(mesh.elements):
                b=basis.integral_bounds(e)
                if source[i]: np.add.at(sm,e.node_ids if isinstance(e.node_ids,np.ndarray) else list(e.node_ids),b)
                np.add.at(wm,list(e.node_ids),b*(abs(coeff[i]) if coeff is not None else 1))
            assert np.array_equal(sm,source_mass) and np.array_equal(wm,weighted_mass)
            sets.append(req['kind'])
    ids=[]
    for index,iface in enumerate(oracle.layout['ifaces']):
        for side in ("minus","plus"):
            if (index,side) not in oracle.layout["dof_map"]: continue
            offset,_=oracle.layout["dof_map"][index,side]
            for j,node in enumerate(iface['nodes']):
                if node%per_loop==0 and node<3*per_loop:
                    ids.append(offset+j)
    matrix,error=hashlib.sha256(),hashlib.sha256()
    positive=0
    for row in ids:
        for col in ids:
            a,b=oracle.get_with_error([row],[col])
            matrix.update(a.tobytes());error.update(b.tobytes())
            positive+=int(np.count_nonzero(b))
    if cut is not None: assert positive>0 and 'weighted' in sets and 'plain' in sets
    return dict(polarization=pol,degree=degree,cut=cut,active_mass_checks=sets,one_by_one_tiles=len(ids)**2,
                positive_bounds=positive,dropped_routes=oracle.dropped_routes,coefficient_digest=matrix.hexdigest(),error_digest=error.hexdigest())

if __name__=='__main__':
    records=[checks(p,d,c) for p in ('TE','TM') for d in (1,3) for c in (None,32)]
    Path(sys.argv[1]).write_text(json.dumps(records,indent=2)+'\n')
