"""Synthetic GHOST 2D workflow, no solve. Pass repo tree, frequency count and angle count."""
import argparse
import ast
from bisect import bisect_right
from collections.abc import Sequence
from contextlib import contextmanager
import gc
import json
import math
import operator
from pathlib import Path
import sys
import tempfile
import threading
import time

import numpy as np
import psutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('tree', type=Path)
parser.add_argument('freqs', type=int)
parser.add_argument('angles', type=int)
parser.add_argument('--format', type=int, choices=(1,2), default=2)
parser.add_argument('--summary-history', action='store_true')
args = parser.parse_args()
repo = args.tree.resolve()
tools = repo / 'tools/GHOST'
sys.path.insert(0, str(tools))
import os
os.environ['GHOST_GRIM_FORMAT_VERSION'] = str(args.format)
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.recovery import RecoveryRun
from ghost_backend.execution.recovery_export import export_run
from ghost_backend.io.solver_export import export_solver_result
from ghost_backend.twod.samples import SampleTable, merge_tables, sample_column

# Run the unmodified UI data-path definitions headlessly. No Qt drawing or widget timings.
source = tools / 'ghost_backend/ui/result_table.py'
classes = {'ResultRows', 'RowSelection', 'sorted_rows', 'plot_groups'}
nodes = [n for n in ast.parse(source.read_text()).body if getattr(n, 'name', '') in classes]
assert len(nodes) == len(classes)
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'))

ui_source = tools / 'ghost_backend/ui/solver.py'
ui_functions = {'_finite_unique_count','_result_rows','_result_sample_counts','_result_summary','_result_history','_result_kind'}
ui_nodes = [n for n in ast.parse(ui_source.read_text()).body if getattr(n,'name','') in ui_functions]
assert len(ui_nodes) == len(ui_functions)
exec(compile(ast.Module(body=ui_nodes, type_ignores=[]),str(ui_source),'exec'))

report = dict(frequencies=args.freqs, angles=args.angles, format=args.format, numpy=np.__version__, python=sys.version.split()[0])
@contextmanager
def measure(key):
    proc = psutil.Process()
    gc.collect()
    base = proc.memory_info().rss
    peak = [base]
    stop = threading.Event()
    def sample():
        while not stop.is_set():
            peak[0] = max(peak[0], proc.memory_info().rss)
            stop.wait(.002)
    sampler = threading.Thread(target=sample); sampler.start()
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        stop.set(); sampler.join()
        report[key] = dict(seconds=elapsed, base_rss_mib=base/2**20, delta_peak_mib=(peak[0]-base)/2**20)

# Descending angles and frequencies exercise distinctions between requested and plotted order.
angles = np.linspace(90, -90, args.angles) if args.angles == 181 else np.linspace(360, 0, args.angles)
freqs = list(map(float, np.linspace(15, 2, args.freqs)))
def result_for(frequency):
    tables = {}
    for i, name in enumerate(['VV','HH']):
        phase = np.deg2rad(angles)*(1+i) + 0.23*frequency
        amplitude = (1.2+i/3.+np.cos(np.deg2rad(angles))*.9)*np.exp(1j*phase)
        linear = abs(amplitude)**2 / (4*2*np.pi*frequency*1e9/299792458.)
        rows = np.column_stack((np.full(len(angles),frequency),angles,angles,linear,
                       10*np.log10(linear),amplitude.real,amplitude.imag,np.rad2deg(np.angle(amplitude)),np.full(len(angles),1e-13)))
        tables[name] = dict(samples=SampleTable(rows))
    chans, combined = merge_tables(tables)
    return dict(solver='2d_monostatic_rcs',scattering_mode='monostatic',polarizations=['VV','HH'],
                polarization_mapping={'VV':'TE','HH':'TM'}, amplitude_convention='synthetic consistent fields',
                rcs_log_unit='dBke',rcs_linear_quantity='sigma_2d',samples=combined,co_solved_samples=chans,
                metadata=dict(panel_count=1000,mesh_convergence_certified=False,fixture='synthetic'))

# Isolate the data path used by table sorting, plot grouping and the inputs to plotted curves.
def display_views(rows):
    table = sorted_rows(rows, ('frequency_ghz', 'polarization', 'theta_inc_deg','theta_scat_deg'))
    groups = plot_groups(rows)
    return table.indices, {key: block.indices for key,block in groups.items()}, rows.column('theta_scat_deg'), rows.column('rcs_linear')

class CompactDisplayColumns(ResultRows):
    """Candidate: read one frequency once, fill channel-major columns in requested frequency order."""
    def __init__(self, result, run, requested):
        fields = ('frequency_ghz','theta_inc_deg','theta_scat_deg','rcs_linear')
        total = len(result['samples'])
        self.arrays = {key:np.empty(total) for key in fields}
        self.arrays['polarization'] = np.empty(total, dtype='<U2')
        positions = {'VV':0, 'HH':len(result['co_solved_samples']['VV'])}
        for frequency in requested:
            loaded = run.load(frequency)
            for channel, start in positions.copy().items():
                rows = loaded['co_solved_samples'][channel]
                end = start + len(rows)
                for field in fields:
                    self.arrays[field][start:end] = sample_column(rows, field)
                self.arrays['polarization'][start:end] = channel
                positions[channel] = end
    def column(self, field, default=None): return self.arrays[field]
    def __len__(self): return len(self.arrays['rcs_linear'])

with tempfile.TemporaryDirectory() as folder:
    root = Path(folder)
    snapshot = build_geometry_snapshot(*parse_geometry((repo/'airfoil.geo').read_text()))
    run = RecoveryRun.create(root/'recovery', dict(geometry_snapshot=snapshot,frequencies_ghz=freqs,elevations_deg=angles.tolist(),
                                                  geometry_units='inches'),{},'double',False,source_path='test-airfoil.geo')
    with measure('save_and_publish_all_planes'):
        for f in freqs:
            run.save(f, result_for(f))
    report['checkpoint_bytes'] = sum(p.stat().st_size for p in (run.directory/'frequencies').glob('*'))
    report['completed_bytes'] = sum(p.stat().st_size for p in (run.directory/'completed').glob('*'))
    with measure('open_recovered_result'):
        result = run.result()
    reader = result['samples'].reader
    def clear_reader():
        reader.frequency = None
        reader.value = None
    calls = [0]
    orig = run.load
    def load(f):
        calls[0]+=1
        return orig(f)
    run.load = load
    clear_reader()
    with measure('display_baseline'):
        baseline = display_views(ResultRows(result))
    report['display_baseline']['loads'] = calls[0]
    calls[0]=0
    clear_reader()
    with measure('display_singlepass'):
        view = CompactDisplayColumns(result,run,freqs)
        candidate = display_views(view)
    report['display_singlepass']['loads'] = calls[0]
    report['display_singlepass']['column_bytes'] = sum(v.nbytes for v in view.arrays.values())
    assert np.array_equal(baseline[0],candidate[0])
    assert baseline[1].keys() == candidate[1].keys()
    assert all(np.array_equal(baseline[1][key],candidate[1][key]) for key in baseline[1])
    assert all(np.array_equal(a,b) for a,b in zip(baseline[2:],candidate[2:]))
    report['identical_display_arrays'] = True
    if args.summary_history:
        clear_reader()
        calls[0] = 0
        with measure('baseline_summary_and_history'):
            prior_summary,prior_history = _result_summary(result),_result_history(result,units='inches')
        report['baseline_summary_and_history']['loads'] = calls[0]
        with measure('presentation_summary_and_history_cached'):
            original_result_rows = _result_rows
            try:
                _result_rows = lambda _: view
                assert _result_summary(result) == prior_summary
                assert _result_history(result,units='inches') == prior_history
            finally:
                _result_rows = original_result_rows
        report['identical_summary_history'] = True
    del baseline,view,candidate
    run.load=orig
    clear_reader()
    history='Completed frequency from recovery run '+run.manifest['run_id']
    reexport_time = [0.]
    def distribute(single,path):
        start = time.perf_counter()
        paths = export_solver_result(single,path,source_path='test-airfoil.geo',history=history)
        reexport_time[0] += time.perf_counter()-start
        return paths
    initial_manifest = (run.directory/'run.json').read_bytes()
    with measure('baseline_combined_export'):
        export_run(result,[str(root/'baseline.grim')],distribute)
    report['baseline_combined_export']['reencode_seconds'] = reexport_time[0]
    def select_completed(single, path):
        f = single['samples'][0]['frequency_ghz']
        completed = run.directory/'completed'/(run.store._path(f).stem+'.grim')
        return [str(completed)]
    # Reset only this temporary fixture; export provenance records each prior final output.
    (run.directory/'run.json').write_bytes(initial_manifest)
    with measure('reuse_existing_planes'):
        export_run(result,[str(root/'reuse.grim')],select_completed)
    # The projection reuses original history and source on purpose. Ordinary final GUI history is
    # different; production reuse needs provenance overrides, tamper detection and regeneration.
    with np.load(root/'baseline.grim', allow_pickle=False) as a, np.load(root/'reuse.grim',allow_pickle=False) as b:
        assert a.files == b.files
        for key in a.files:
            assert np.array_equal(a[key], b[key]), key
        report['equal_export_members']=len(a.files)
        report['shape'] = list(a['rcs_complex' if 'rcs_complex' in a else 'rcs_amp_real'].shape)
    report['combined_bytes']=(root/'baseline.grim').stat().st_size
print(json.dumps(report,indent=2))
