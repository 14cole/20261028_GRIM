# Reproduce the response to Claude’s November 28 review

Use GHOST main `95f87190956de9197f0d021b0497772818c6f532` and its Python environment, including NumPy, SciPy and PySide6. The `claude/` directory contains all 50 files from Claude’s reviewed folder at `24b403554bc314d70a537b3506fb447c54a207c3`, verified against GitHub blob IDs. New runs used a Linux AMD EPYC 7763 host with a four-core cgroup quota and 16 GiB RAM limit. Use two threads for the airfoil and gap experiments and one for the small planner tests. These are research fixtures and raw output, distributed separately from the application.

Set `GRIM_ROOT` to the absolute main checkout. Run from the root of the extracted checks in a fresh output directory where indicated.

```sh
export GRIM_ROOT=/path/to/20261028_GRIM
export PYTHONPATH="$GRIM_ROOT/tools/GHOST"
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
mkdir -p fresh
for f in 1 10 15; do
  python claude/airfoil_job.py "$f" 180 auto "fresh/f${f}_a180.npz" > "fresh/f${f}_a180.json"
done
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python claude/sheet_unknowns.py fresh/sheet.json
python replay/compare.py claude fresh fresh/aligned.json
python gap-check/compare_gaps.py fresh/gaps
OPENBLAS_NUM_THREADS=1 python sheet-check/planner_probe.py "$GRIM_ROOT" fresh/planner.json
OPENBLAS_NUM_THREADS=1 python sheet-check/hpc_repair_check.py "$GRIM_ROOT" fresh/hpc.json
QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 python display-check/probe_qt.py "$GRIM_ROOT" fresh/qt.json
python field-check/check_tolerances.py "$GRIM_ROOT" claude/results/segment_grouping fresh/tolerances.json
```

For the original two-host field comparison, extract `EVIDENCE.zip` from the original study at `db954eb` and run `python field-check/compare_fields.py claude /path/to/extracted/experiments/runs fresh/original-comparison.json`. The comparison takes an exact intersection of incident angles in the original arrays. The later fresh reruns match Claude's complete half-circle grids directly.

The Linux pressure replay takes the original pinned `DENSE_24K_CHECKS.zip` from commit `43d6c4165cc4e76c54d983f1e5d6b865bb79653d`. Run `python dense-check/replay.py /path/to/DENSE_24K_CHECKS.zip`. For the other pressure pair, call `python dense-check/cross_session.py /path/to/DENSE_24K_CHECKS.zip /path/to/claude-checkout/audits/claude-2026-11-26/ghost-backend-audit/results/c_cand24k` with the directory holding the `current` and `candidate` subdirectories. The paired pressure runs are archival. These two scripts check the counters, physical fields and analytical series without repeating the factorization.

The in-archive `SHA256.json` covers all other files. Raw output times can vary with native libraries, CPU allocation, disk and load. Report numerical comparisons per polarization using complex amplitudes. The 5 GHz full-circle comparisons and every 180-angle comparison identify the actual number of paired directions.
