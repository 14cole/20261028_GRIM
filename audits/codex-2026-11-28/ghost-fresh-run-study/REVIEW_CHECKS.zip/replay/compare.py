"""Compare aligned public reruns against Claude's archives. Provide both absolute directories."""
import argparse
import json
from pathlib import Path
import numpy as np
def main():
    p=argparse.ArgumentParser();p.add_argument('claude',type=Path);p.add_argument('reruns',type=Path);p.add_argument('out',type=Path);args=p.parse_args()
    out={}
    for frequency in [1,10,15]:
        tag=f'f{frequency}_a180'
        reference=args.claude/'results/airfoil'/(tag+'_auto_a')
        current=args.reruns/tag
        baseline=json.loads(reference.with_suffix('.json').read_text())
        run=json.loads(current.with_suffix('.json').read_text())
        assert run['certified'] and run['quality_passed'] and baseline['certified'] and baseline['quality_passed']
        assert (baseline['panels'],baseline['unknowns'])==(run['panels'],run['unknowns'])
        with np.load(reference.with_suffix('.npz'),allow_pickle=False) as x,np.load(current.with_suffix('.npz'),allow_pickle=False) as y:
            assert np.array_equal(x['angles_deg'],np.arange(180.)) and np.array_equal(x['angles_deg'],y['angles_deg'])
            peak={}
            for pol in ('TE','TM'):
                assert x[pol].shape==y[pol].shape==(180,) and np.all(np.isfinite(x[pol])) and np.all(np.isfinite(y[pol]))
                peak[pol]=float(np.max(abs(y[pol]-x[pol]))/np.max(abs(x[pol])))
            out[str(frequency)]=dict(panels=run['panels'],dofs=run['unknowns'],points_per_pol=180,peak_relative_field_difference=peak,certified=True,run_wall_s=run['wall_s'],peak_rss_gib=run['peak_rss_gib'])
    old=json.loads((args.claude/'results/sheet_unknowns.json').read_text());new=json.loads((args.reruns/'sheet.json').read_text())
    assert new==old and len(old)==21 and all(d['outcome']=='solved' for d in new)
    out['sheet_replay']={'complete_records_equal':True,'number':len(old)}
    args.out.write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
