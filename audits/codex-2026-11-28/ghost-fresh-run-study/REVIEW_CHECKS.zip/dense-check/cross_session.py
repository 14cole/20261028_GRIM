"""Check Claude's separate historical pair against the archived exact-patch pair."""
from pathlib import Path
import argparse
import io
import json
import zipfile
import numpy as np
from replay import peak_error, analytic

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('codex_zip',type=Path);p.add_argument('claude_raw_dir',type=Path)
    args=p.parse_args();out={}
    with zipfile.ZipFile(args.codex_zip) as z:
        for claude,codex in [('current','shipped'),('candidate','corrected')]:
            d=args.claude_raw_dir/claude
            row=json.loads((d/'dense.out').read_text())
            assert row['quality_passed'] and row['unknowns_per_system']==23936
            val=out[claude]=dict(claude_solver_wall_s=row['solve_wall_s'],claude_process_physical_reads_B=row['process_io']['read_bytes'])
            with np.load(d/'s8448_a360_t4_dense.npz',allow_pickle=False) as a,np.load(io.BytesIO(z.read('fresh/'+codex+'/fields.npz')),allow_pickle=False) as b:
                assert np.array_equal(a['angles_deg'],b['angles_deg']) and np.array_equal(a['angles_deg'],np.arange(360.))
                val['claude_vs_codex_field_peak_relative']={k:peak_error(a['ghost_'+k],b['ghost_'+k]) for k in ('TE','TM')}
                val['claude_vs_modal_reference_peak_relative']={k:peak_error(a['ghost_'+k],analytic(a['angles_deg'],k,85)) for k in ('TE','TM')}
    print(json.dumps(out,indent=2))
