"""Verify public Linux Dense closeout archive without rerunning the factorization."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from scipy import special

ARCHIVE_GIT_SHA = 'ecee4eee945efdaefa678a13f3368daf44c464cc'

def analytic(angles,pol,top):
    # Eliminate the coating's J/Y coefficients with the core boundary condition.
    # Impedance normalization: tangential derivative weighted by 1/epsilon for TE.
    k = 2*np.pi*1e10/299792458
    eps = 2.8-0.06j
    index = np.sqrt(eps)
    n = np.arange(top+1)
    core, shell, outer = index*k*.1, index*k*.12, k*.12
    cj, cy = (special.jvp(n,core),special.yvp(n,core)) if pol=='TE' else (special.jv(n,core),special.yv(n,core))
    field = cy*special.jv(n,shell) - cj*special.yv(n,shell)
    slope = (index/eps if pol=='TE' else index)*(cy*special.jvp(n,shell)-cj*special.yvp(n,shell))
    a = (slope*special.jv(n,outer)-field*special.jvp(n,outer))/(field*special.h2vp(n,outer)-slope*special.hankel2(n,outer))
    phase = np.exp(2j*k*(.031*np.cos(np.deg2rad(angles))-.017*np.sin(np.deg2rad(angles))))
    return -4j*np.sum(a*np.where(n==0,1,2)*(-1.)**n)*phase

def peak_error(probe,ref):
    assert probe.shape==ref.shape and np.all(np.isfinite(probe)) and np.all(np.isfinite(ref))
    return float(np.max(np.abs(probe-ref))/np.max(np.abs(ref)))

def replay(archive):
    raw = archive.read_bytes()
    digest = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert digest==ARCHIVE_GIT_SHA
    out = {'source_git_blob':digest, 'runs':{}}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert z.testzip() is None
        verified=[]
        for line in z.read('SHA256SUMS').decode().splitlines():
            sha,name=line.split('  ',1)
            assert hashlib.sha256(z.read(name)).hexdigest()==sha
            verified.append(name)
        assert set(verified) == set(z.namelist())-{'SHA256SUMS'}
        out['manifest_members_verified']=len(verified)
        boot_ids=[]; fields={}
        for tag in ('corrected','shipped'):
            prefix='fresh/'+tag+'/'
            def load(file):return json.loads(z.read(prefix+file))
            result=load('dense.json'); status=load('status.json')
            host=load('host-start.json'); boot_ids.append(host['boot_id'])
            samples=[json.loads(line) for line in z.read(prefix+'samples.jsonl').splitlines()]
            assert status['exit']==0 and result['quality_passed'] and result['unknowns_per_system']==23936 and result['angles']==360 and result['threads']==4 and result['panels']==15488 and result['ghz']==10
            plans=[m for m in result['memory_estimates'] if 'residual_storage' in m]
            assert len(plans)==2 and all(m['residual_storage']=='disk' for m in plans)
            with np.load(io.BytesIO(z.read(prefix+'fields.npz')),allow_pickle=False) as data:
                assert np.array_equal(data['angles_deg'],np.arange(360))
                fields[tag]={p:data['ghost_'+p] for p in ('TE','TM')}
            ref={p:analytic(np.arange(360),p,85) for p in ('TE','TM')}
            assert max(peak_error(ref[p],analytic(np.arange(360),p,100)) for p in ('TE','TM'))<1e-13
            rr=out['runs'][tag]=dict(
                public_elapsed_seconds=result['solve_wall_s'], read_bytes=result['process_io']['read_bytes'],
                peak_rss_reported_gib=result['peak_rss_gib'],
                peak_anon_sampled_gib=max(i['cgroup_memstat']['anon'] for i in samples)/2**30,
                angles_per_batch=[m['angle_batch_size'] for m in plans],
                factorization_count=result['rhs_batches']['dense_factorization_count'],rhs_batches=result['rhs_batches']['dense_rhs_batch_count'],
                RHS_total_columns=result['rhs_batches']['dense_rhs_column_count'], max_reported_residual=result['residual_max'],
                field_errors_vs_modal_reference={p:peak_error(fields[tag][p],ref[p]) for p in ref})
            assert rr['factorization_count']==2 and rr['RHS_total_columns']==720 and max(rr['field_errors_vs_modal_reference'].values())<4e-6
        assert len(set(boot_ids))==1 and all(boot_ids)
        out['same_boot']=True
        r=out['runs']
        out['wall_time_ratio']=r['shipped']['public_elapsed_seconds']/r['corrected']['public_elapsed_seconds']
        out['read_bytes_reduction_percent']=100*(1-r['corrected']['read_bytes']/r['shipped']['read_bytes'])
        out['corrected_vs_shipped_peak_relative']={p:peak_error(fields['corrected'][p],fields['shipped'][p]) for p in ('TE','TM')}
        out['bit_identical']={p:fields['corrected'][p].tobytes()==fields['shipped'][p].tobytes() for p in ('TE','TM')}
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('archive',type=Path);args=ap.parse_args()
    print(json.dumps(replay(args.archive),indent=2))
