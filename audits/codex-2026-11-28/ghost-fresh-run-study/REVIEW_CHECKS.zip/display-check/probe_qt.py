"""Exercise the shipped Qt widgets and a one-pass current-result view. Run with REPO and OUT."""
import sys, os, tempfile, hashlib, json, time
from pathlib import Path
from unittest.mock import patch
from contextlib import ExitStack

import numpy as np
repo=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2])
sys.path[:0]=[str(repo),str(repo/'tools/GHOST')]
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtWidgets import QApplication
from ghost_backend.ui import solver, result_table
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.twod.samples import SampleTable, merge_tables, sample_column
from ghost_backend.execution.recovery import RecoveryRun

requested=[4.,1.,6.,2.,7.,3.,5.]
angles=np.array([42.,-70.,-3.,169.,97.,-121.,14.,8.,83.,0.,26.])
def build_sample(freq):
    tables={}
    for i,pol in enumerate(('VV','HH')):
        amp=(1+i+.005*angles+.002*freq)*np.exp(1j*(.07*freq+.01*angles))
        lin=abs(amp)**2/(4*2*np.pi*freq*1e9/299792458.)
        a=np.column_stack([np.full(len(angles),freq),angles,angles,lin,10*np.log10(lin),amp.real,amp.imag,np.angle(amp,deg=True),np.full(len(angles),2e-12)])
        tables[pol]=dict(samples=SampleTable(a))
    cs,s=merge_tables(tables)
    return dict(samples=s,co_solved_samples=cs,solver='2d_monostatic_rcs',scattering_mode='monostatic',
                polarizations=['VV','HH'],polarization_mapping={'VV':'TE','HH':'TM'},amplitude_convention='synthetic consistent fields',
                rcs_log_unit='dBke',rcs_linear_quantity='sigma_2d',metadata=dict(mesh_convergence_certified=False,panel_count=12))
class CurrentDisplay(result_table.ResultRows):
    def __init__(self, result, run):
        super().__init__(result)
        ch=result['co_solved_samples']
        fs=ch['VV'].frequencies
        assert ch['HH'].frequencies==fs
        self.cols={name:np.empty(len(self),dtype=float) for name in ('frequency_ghz','theta_inc_deg','theta_scat_deg','rcs_linear')}
        self.pols=np.empty(len(self),dtype='U2')
        pos={'VV':0,'HH':len(ch['VV'])}
        for f in fs:
            block=run.load(f)['co_solved_samples']
            for pol,start in pos.copy().items():
                stop=start+len(block[pol])
                for key in self.cols:
                    self.cols[key][start:stop]=sample_column(block[pol],key)
                self.pols[start:stop]=pol
                pos[pol]=stop
        assert pos=={'VV':len(ch['VV']),'HH':len(self)}
    def column(self,key,default=0.):
        if key=='polarization': return self.pols
        return self.cols[key] if key in self.cols else super().column(key,default)

def exercise(tab,result,run,trial):
    reads=[]
    original=run.load
    def load(f):
        reads.append(f);return original(f)
    reader=result['samples'].reader
    reader.frequency,reader.value=None,None
    with ExitStack() as contexts:
        contexts.enter_context(patch.object(run,'load',load))
        start=time.perf_counter()
        if trial:
            view=CurrentDisplay(result,run)
            contexts.enter_context(patch.object(solver,'_result_rows',lambda r:view))
            contexts.enter_context(patch.object(result_table,'ResultRows',lambda r:view))
        tab._populate_results_table(result)
        tab._plot_results(result)
        tab.canvas.draw()
        summary=solver._result_summary(result)
        history=solver._result_history(result,units='meters')
        preparation_seconds=time.perf_counter()-start
        prep_reads=list(reads)
        del reads[:]
        table=tab.result_table_model
        headings=tuple(table.headers)
        cells=tuple(tuple(table.data(table.index(r,c)) for c in range(table.columnCount())) for r in range(table.rowCount()))
        curves=tuple((l.get_label(),l.get_xdata().tolist(),l.get_ydata().tolist()) for l in tab.canvas.ax.get_lines())
        st=(headings,cells,curves,summary,history)
        fingerprint=hashlib.sha256(json.dumps(st,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        return dict(prep_reads=prep_reads,prep_seconds=preparation_seconds,cell_verification_reads=list(reads),rows=len(cells),cell_count=sum(map(len,cells)),curves=len(curves),sha256_of_cells_curves_summary_history=fingerprint,summary=summary), st

def main():
    app=QApplication.instance() or QApplication([])
    tab=solver.SolverTab()
    results={}
    snap=build_geometry_snapshot(*parse_geometry((repo/'airfoil.geo').read_text()))
    with tempfile.TemporaryDirectory() as folder:
        for kind,complete in [('full',requested),('partial',[4.,6.,7.,5.])]:
            run=RecoveryRun.create(Path(folder)/kind,dict(geometry_snapshot=snap,frequencies_ghz=requested,elevations_deg=angles.tolist(),geometry_units='meters'),{},'double',False)
            for f in reversed(complete):run.save(f,build_sample(f))
            result=run.result()
            base,base_view=exercise(tab,result,run,False)
            trial,new_view=exercise(tab,result,run,True)
            assert base_view==new_view
            assert trial['prep_reads']==complete and base['rows']==len(complete)*len(angles)*2
            assert base['curves']==len(complete)*2
            info=dict(requested=requested,completed=complete,missing=result['metadata']['run_recovery']['remaining_frequencies_ghz'],baseline=base,one_pass=trial)
            # Corrupt a verified checkpoint after constructing the result but before preparing it.
            path=run.store._path(complete[-1])
            original=path.read_bytes(); path.write_bytes(original+b'x')
            refused={}
            for method in [False,True]:
                try:exercise(tab,result,run,method)
                except OSError as e:refused[str(method)]=str(e)
                else:raise AssertionError('Damaged checkpoint accepted on first display')
            info['corrupt_refusals']=refused
            results[kind]=info
    tab.close()
    out.write_text(json.dumps(results,indent=2)+'\n')
    for k,v in results.items():
        print(k,v['baseline']['rows'],len(v['baseline']['prep_reads']),len(v['one_pass']['prep_reads']),v['baseline']['prep_seconds'],v['one_pass']['prep_seconds'],len(v['one_pass']['cell_verification_reads']),v['corrupt_refusals'])
if __name__=='__main__':main()
