# Qt check on the active result

The unmodified PySide6 `SolverTab` and `SolverResultsTableModel` from main `95f8719` ran offscreen. This checked actual widget model setup, plotting (including a forced canvas draw), result summary and export description. The comparison variant built four numeric columns and channel labels in one pass over the **completed** frequencies, once for the active result, and supplied the same view to these consumers. Each fixture used 11 deliberately unordered angles and two polarizations. Production recovery/export code created the synthetic checkpoints in a temporary directory. The experiment changes no repository or application files.

| Result | Visible rows | Plotted lines | Verified loads during preparation, stock → one-pass | Additional loads while inspecting every formatted cell, both versions |
|---|---:|---:|---:|---:|
| 7 of 7 frequencies | 154 | 14 | 196 → 7 | 7 |
| 4 of 7 frequencies | 88 | 8 | 112 → 4 | 4 |

All 770 and 440 formatted cells, all plotted coordinates and labels, headers, the summary and export description agreed exactly. Damaging a frequency record after result discovery and before display caused both implementations to raise the same missing/corrupt-frequency error. No omitted frequency appeared in the partial output. The table can do additional verified reads for on-demand cell access, so the initial-view result does not imply one read over the lifetime of an interactive session. The experiment did not time a full desktop solve or a native Windows GUI and did not test unbounded caching or damage after an existing view was built.

Run with the project Python environment and a clean checkout:

```sh
QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 python probe_qt.py /path/to/20261028_GRIM qt.json
```
