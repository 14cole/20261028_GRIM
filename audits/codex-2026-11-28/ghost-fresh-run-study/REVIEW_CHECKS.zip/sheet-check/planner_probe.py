"""Planning experiment. Only tiny Y and split straight sheet use field solves."""
from argparse import ArgumentParser
from contextlib import ExitStack
import json
import math
from pathlib import Path
import sys
from unittest.mock import patch

def geometry(groups, panels, branched=False):
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    rows=['Title: planner connectivity comparison']
    for i in range(groups):
        rows.extend([f'Segment: strip_{i} 1', f'properties: 1 {panels} 10 0 0',f'{i*.003:.8f} 0 {(i+1)*.003:.8f} 0'])
    if branched:
        rows.extend(['Segment: branch 1',f'properties: 1 {panels} 10 0 0','.003 0 .003 .003'])
    rows.extend(['IBCS_Resistances:', '10 constant 90 -20 0 0', 'Dielectrics:'])
    return build_geometry_snapshot(*parse_geometry('\n'.join(rows)+'\n'))

def forecast(arguments, options, correct):
    from ghost_backend.execution import selection
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import preparation_scope
    info=solver._build_coupled_panel_info
    mesh=solver._build_linear_mesh_interface_aware
    active=[None]
    def record(panels, materials, f, pol, k):
        active[0]=pol
        return info(panels,materials,f,pol,k)
    def corrected_mesh(panels,infos,*args,**kwargs):
        assert not args and 'polarization' not in kwargs
        return mesh(panels,infos,polarization=active[0])
    with ExitStack() as scope:
        scope.enter_context(preparation_scope())
        if correct:
            scope.enter_context(patch.object(solver,'_build_coupled_panel_info',record))
            scope.enter_context(patch.object(solver,'_build_linear_mesh_interface_aware',corrected_mesh))
        try:
            result=selection.select_backend(arguments,options,False)
        except (ValueError, MemoryError) as e:
            return dict(error=str(e),error_type=type(e).__name__)
        return dict(unknowns={r['polarization']:r['unknowns'] for r in result['meshes']},
                    panels={r['polarization']:r['panels'] for r in result['meshes']},
                    policy=result['ranking'],selected=result['selected'],
                    peaks_gib={mode:row['peak_gb'] for mode,row in result['candidates'].items()})

def solve(arguments,options):
    from ghost_backend.twod import solver as s
    counts=[]
    src=s._dense_formulation_resources
    def hook(mesh,infos,pol,*a,**kw):
        v=src(mesh,infos,pol,*a,**kw)
        # Forecast calls use sample_compression=False; later real solve calls use the default sampling.
        counts.append(dict(pol=pol,unknowns=v['system_dofs'],sample=kw.get('sample_compression',True)))
        return v
    try:
        with patch.object(s,'_dense_formulation_resources',hook):
            r=s.solve_monostatic_rcs_2d_survey(**arguments,execution_options=options)
        return dict(counts=counts, passed=r['metadata']['quality_gate']['passed'], output_rows_by_pol={k:len(v) for k,v in r['co_solved_samples'].items()})
    except (ValueError,RuntimeError,MemoryError) as e:
        return dict(counts=counts,error=str(e),error_type=type(e).__name__)

def main():
    p=ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    sys.path.insert(0,str(a.root.resolve()/'tools/GHOST'))
    from ghost_backend.execution.options import validate_options
    options=validate_options(dict(factorization='automatic',basis_order=1,mesh_grading=False,mesh_strategy='global',blas_threads=1,assembly_threads=1))
    cases=[('sixteen_segments',16,1,False),('three_way',2,2,True),('threshold',8,1249,False)]
    results={}
    for name,n,panels,branched in cases:
        src=geometry(n,panels,branched)
        args=dict(geometry_snapshot=src,geometry_units='meters',frequencies_ghz=[1.],elevations_deg=list(range(-90,90)),solver_method='auto')
        q={}
        for mode in (['TE','paired'] if name=='threshold' else ['paired']):
            kw=dict(args,polarization='TE') if mode=='TE' else args
            q[mode]={m:forecast(kw,options,correct=(m=='polarized')) for m in ['stock','polarized']}
        if name!='threshold':
            q['public_field_solve']=solve(args,options)
        results[name]=q
        print(name,[(m,v['stock'].get('unknowns'),v['polarized'].get('unknowns'),v['stock'].get('selected'),v['polarized'].get('selected')) for m,v in q.items() if m!='public_field_solve'],q.get('public_field_solve'),flush=True)
        a.output.write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
