"""Exercise both HPC planning loops with and without polarizing both build and reuse."""
from argparse import ArgumentParser
from contextlib import ExitStack
import json
from pathlib import Path
import sys
from unittest.mock import patch
from planner_probe import geometry

def run(root):
    sys.path.insert(0,str(root/'tools/GHOST'))
    from ghost_backend.execution.options import execution_scope, validate_options
    from ghost_backend.hpc import scheduler
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import prepare_geometry, preparation_scope
    options=validate_options(dict(factorization='automatic',basis_order=1,mesh_grading=False,mesh_strategy='global',blas_threads=1,assembly_threads=1))
    snapshot=geometry(16,1)
    summary={}
    for method in ('stock','polarized_builder_only','polarized_builder_separate_topologies'):
        by_order={}
        for order in [('TE','TM'),('TM','TE')]:
            channels=[(v,v) for v in order]
            info=solver._build_coupled_panel_info
            mesh=solver._build_linear_mesh_interface_aware
            pol=[None]
            def capture(panels,materials,f,channel,k):
                pol[0]=channel
                return info(panels,materials,f,channel,k)
            def actual_topology(panels,infos):
                return mesh(panels,infos,polarization=pol[0])
            with ExitStack() as scopes:
                scopes.enter_context(preparation_scope())
                scopes.enter_context(execution_scope(options))
                if method!='stock':
                    scopes.enter_context(patch.object(solver,'_build_coupled_panel_info',capture))
                    scopes.enter_context(patch.object(solver,'_build_linear_mesh_interface_aware',actual_topology))
                if method=='polarized_builder_separate_topologies':
                    # Trial for this all-TYPE1 fixture. A production implementation would
                    # preserve cross-channel sharing for polarization-independent topologies.
                    scopes.enter_context(patch.object(scheduler,'_same_interface_topology',return_value=False))
                _,_,material,scale=prepare_geometry(snapshot,str(root),'meters')
                one=scheduler._resource_records_for_frequency(solver,snapshot,material,1.0,channels,scale,1000)
                many=scheduler._resource_records_for_degrees(solver,snapshot,material,1.0,channels,scale,1000,{k:dict(options,basis_order=k) for k in (1,2,3)})
                by_order['+'.join(order)]=dict(single={k:r['system_dofs'] for k,r in one.items()},
                    multiple={k:{channel:r['system_dofs'] for channel,r in row.items()} for k,row in many.items()})
        summary[method]=by_order
    return summary
if __name__=='__main__':
    p=ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    data=run(a.root.resolve());print(json.dumps(data,indent=2));a.output.write_text(json.dumps(data,indent=2)+'\n')
