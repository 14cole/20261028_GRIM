# Connected impedance-sheet planner checks

Pinned source `95f87190956de9197f0d021b0497772818c6f532`, 1 GHz, meters, 180 distinct monostatic directions, P1, manual/global mesh, grading off, Automatic linear solver, one BLAS and assembly thread. A positive geometry N assigns panels per drawn primitive. Each ordinary sheet in the small straight control was 3 mm long and carried the same passive impedance; the virtual interface identifier changed at each separately named segment.

| Fixture | Stock forecast TE / TM | Executing topology TE / TM | Consequence |
|---|---:|---:|---|
| 16 named pieces, one panel each, ordinary dual-polarization survey | 32 / 32 | 17 / 32 | The public run passed its discrete quality gate and returned all 360 polarized samples. The TE overcount was 15/17 = 88.2%. Dense was selected with either forecasting method. |
| Two collinear pieces plus a branch sharing the center point, two panels per piece | 9 / 9 | TE rejected | The stock forecast supplied a backend. The public survey failed with “TE sheet branching junctions require an unsupported junction condition.” A forecast with the actual polarized constructor stopped at the same point. |
| 8 joined pieces, 1,249 panels per piece, TE-only specialist request | 10,000 / — | 9,993 / — | With both backends admitted, the real planner selected Compressed on stock code and Dense using the polarized constructor. |
| Same 9,992 panels, ordinary paired request | 10,000 / 10,000 | 9,993 / 10,000 | Both policies selected Compressed. The paired size cut uses the maximum across polarizations, which remained 10,000. |

For the threshold controls the “executing topology” column uses the actual mesh constructor invoked with the executing polarization inside a temporary planning probe. No large matrix or field solution was built. The small straight and Y cases also ran the stock public survey entry. Runtime and RAM savings, out-of-memory behavior, and field convergence were outside these checks. The TE-only entry is documented as specialist/diagnostic. The 88.2% example is a relative discrepancy of 15 nodes on a very small valid system; the absolute discrepancy scales with the number of welded joints in these fixtures.

Both HPC per-frequency and multi-degree forecasters also need a change to how they decide when to reuse a mesh. On the 16-piece sheet the shipped single-degree planner reports 32 / 32. An experimental change that only passes polarization into the mesh constructor reports 17 / 17 when TE is requested first. TM is then 15 DOFs below its executing dimension. Reversing request order gives 32 / 32 again. Preventing inappropriate cross-polarization sheet mesh sharing reproduced 17 / 32 (P1), 33 / 48 (P2) and 49 / 64 (P3) independent of order. Those are results of trial modifications scoped to the test process. The stock planner exhibited the TE overcount.

Use the same polarization rules as execution in both planning paths. Keep identical topologies shareable. Add the three-arm case, explicit segmentation, reversed order in the HPC planner and the threshold control to the regression tests. This is a setup correctness and diagnostics correction, with a backend-choice effect demonstrated on a specialist single-channel request. Claude's measured size errors describe its own fixtures. They do not establish a universal percentage ceiling or a production memory-safety incident.

Reproduce with the GHOST Python environment:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python planner_probe.py /path/to/checkout planner.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python hpc_repair_check.py /path/to/checkout hpc.json
```
