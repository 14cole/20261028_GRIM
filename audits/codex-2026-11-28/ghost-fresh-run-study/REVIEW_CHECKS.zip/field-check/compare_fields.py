"""Recompute pinned study comparisons from stored complex fields. No solves or interpolation."""
import argparse
import json
from pathlib import Path
from statistics import median
import numpy as np

CHANNELS = ('TE', 'TM')

def read_claude(path):
    with np.load(path, allow_pickle=False) as z:
        angles = z['angles_deg']
        field = np.column_stack([z[pol] for pol in CHANNELS])
    return checked(angles, field)

def read_codex(path, freq):
    with np.load(path, allow_pickle=False) as z:
        angles = z['incident_angles']
        assert np.array_equal(z['frequencies'], [freq])
        assert z['field'].shape == (len(angles),1,1,2)
        # The writer sorts its azimuth axis. Requested angles were sorted for all four airfoil cases.
        assert np.all(np.diff(angles)>0)
        field = z['field'][:,0,0,:]
    return checked(angles, field)

def checked(angles, field):
    assert np.unique(angles).size == len(angles)
    assert np.isfinite(angles).all() and np.isfinite(field).all()
    assert field.shape==(len(angles),2) and np.issubdtype(field.dtype,np.complexfloating)
    return angles, field

def contrast(test, ref):
    ta, tf=test; ra,rf=ref
    common,it,ir=np.intersect1d(ta,ra,assume_unique=True,return_indices=True)
    assert common.size
    delta=tf[it]-rf[ir]
    out={}
    for i,pol in enumerate(CHANNELS):
        peak=np.max(abs(rf[ir,i]))
        assert peak>0
        out[pol]=float(np.max(abs(delta[:,i]))/peak)
    return dict(matched_angles=len(common),first_deg=float(common[0]),last_deg=float(common[-1]),
                peak_relative=out,bit_equal=bool(tf[it].tobytes()==rf[ir].tobytes()))

def read_json(f):
    return json.loads(f.read_text())

def run(claude, runs):
    air=claude/'results'/'airfoil'
    times={}
    for tag, pattern in [('automatic5','f5_a360_auto_*.json'),('compressed5','f5_a360_compressed_*.json'),('dense5','f5_a360_dense_*.json')]:
        q=[read_json(f) for f in sorted(air.glob(pattern))]
        assert q and all(r['certified'] and r['quality_passed'] for r in q)
        times[tag]={'wall_seconds':[r['wall_s'] for r in q],'rss_gib':[r['peak_rss_gib'] for r in q]}
    d,c=times['automatic5'],times['compressed5']
    dt,ct=median(d['wall_seconds']),median(c['wall_seconds'])
    times.update(automatic_dense_seconds_median=dt,compressed_seconds_median=ct,
                 compressed_to_automatic_time_ratio=ct/dt,automatic_time_saving_percent=100*(1-dt/ct),
                 median_peak_rss_difference_gib=median(d['rss_gib'])-median(c['rss_gib']))
    cross={}
    cases={1:('ab-base-1','f1_a180_auto_a'),5:('airfoil-auto5-360','f5_a360_auto_a'),
           10:('matched-10-automatic-1','f10_a180_auto_a'),15:('airfoil-auto15-180','f15_a180_auto_a')}
    for freq,(cx,cl) in cases.items():
        a=read_codex(runs/(cx+'.npz'),freq)
        b=read_claude(air/(cl+'.npz'))
        mx=read_json(runs/(cx+'.json'));ml=read_json(air/(cl+'.json'))
        assert mx['args']['units']=='inches' and ml['ghz']==freq
        assert mx['per_frequency'][0]['panel_count_max']==ml['panels']
        assert mx['per_frequency'][0]['dense_largest_system']==ml['unknowns']
        cross[str(freq)]=dict(claude_vs_codex=contrast(b,a),claude_n=len(b[0]),codex_n=len(a[0]),
                              claude_panels=ml['panels'],unknowns=ml['unknowns'])
    cross['5-compressed']=dict(claude_vs_codex=contrast(read_claude(air/'f5_a360_compressed_a.npz'),
                                               read_codex(runs/'matched-5-compressed-1.npz',5)))
    within={t:contrast(read_claude(air/(i+'.npz')),read_claude(air/(j+'.npz'))) for t,i,j in
            [('compressed_vs_auto','f5_a360_compressed_a','f5_a360_auto_a'),
             ('dense_vs_auto','f5_a360_dense_a','f5_a360_auto_a'),
             ('auto_repeat','f5_a360_auto_b','f5_a360_auto_a'),
             ('compressed_repeat','f5_a360_compressed_b','f5_a360_compressed_a')]}
    sg=claude/'results'/'segment_grouping'
    fixtures={f.stem:read_claude(f) for f in sorted(sg.glob('*.npz'))}
    rg=fixtures['reference_global_80_p2']
    info={r['tag']:r for r in read_json(sg/'summary.json')}
    assert set(info)==set(fixtures)
    group={}
    for n,field in fixtures.items():
        assert np.array_equal(field[0], np.arange(0.,360.,2.))
        e=contrast(field,rg)
        norm=e['peak_relative']; quoted=info[n].get('error_vs_reference',info[n].get('difference_from_reference'))
        if quoted:
            assert all(np.isclose(norm[k],quoted[k],rtol=5e-14,atol=0) for k in CHANNELS)
        assert info[n]['quality_passed']
        group[n]={'panels':info[n]['panels'],'unknowns':info[n]['unknowns'],'peak_relative':norm}
    ratio={k:group['local_1']['peak_relative'][k]/group['global_1']['peak_relative'][k] for k in CHANNELS}
    return dict(error_definition='maximum complex absolute difference per polarization divided by peak reference field over common angles; exact angle intersection, no rotation, nearest matching or resampling',
                time_definition='fresh-process solver-call wall time in Claude JSON, includes constructing source snapshot; separate from prior end-to-end export timers',
                claude_airfoil_cost=times,cross_host_airfoil=cross,claude_airfoil_same_host=within,
                claude_segment_group_vs_global80_P2=group,coarse_local_to_global_P1_error_ratio=ratio)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('claude_dir',type=Path);p.add_argument('codex_runs',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args()
    a.output.write_text(json.dumps(run(a.claude_dir,a.codex_runs),indent=2)+'\n')
