"""Evaluate the archived segment comparisons against the shipped Standard and Tight field tests."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

def samples(path):
    with np.load(path,allow_pickle=False) as d:
        k_air=2*np.pi*6e9/299792458.
        return {p:{'samples':[dict(frequency_ghz=6.,theta_inc_deg=float(t),theta_scat_deg=float(t),
                 rcs_amp_real=float(v.real),rcs_amp_imag=float(v.imag),
                 rcs_linear=float(abs(v)**2/(4*k_air))) for t,v in zip(d['angles_deg'],d[p],strict=True)]}
                for p in ('TE','TM')}
def main():
    p=argparse.ArgumentParser();p.add_argument('repo',type=Path);p.add_argument('segment_results',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
    sys.path.insert(0,str(args.repo/'tools'/'GHOST'))
    from ghost_backend.runs.quality import accuracy_target_policy, evaluate_mesh_convergence
    fine=samples(args.segment_results/'reference_global_80_p2.npz');out={}
    for name in ('local_1','local_2','global_1','reference_global_60_p2_compressed'):
        coarse=samples(args.segment_results/(name+'.npz'))
        out[name]={}
        for target in ('standard','tight'):
            policy=accuracy_target_policy(target);policy.pop('fine_factor')
            out[name][target]={p:evaluate_mesh_convergence(coarse[p],fine[p],**policy) for p in ('TE','TM')}
            assert all(v['passed'] for v in out[name][target].values())
    args.output.write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
