"""Probe shipped local meshing across its one-wavelength proximity threshold. Set PYTHONPATH to tools/GHOST."""
import argparse, json, time
from pathlib import Path
import numpy as np
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.twod import solver
from ghost_backend.twod.constants import C0

FREQUENCY = 5.0
THETA = np.arange(-90., 91.)
def contour(radius,centre,sides):
    ang=-2*np.pi*np.arange(sides)/sides
    return np.stack((radius*np.cos(ang)+centre[0],radius*np.sin(ang)+centre[1]),axis=-1)
def fixture(gap, pieces, density):
    wl=C0/(FREQUENCY*1e9)
    ra,rb=.04,.025
    a=contour(ra,(.011,.019),64)
    b=contour(rb,(.011+ra+rb+gap*wl,.019),64)
    lines=['Title: two translated contours - gap control']
    def add(name,typ,mat,xy,idx):
        lines.extend([f'Segment: {name} {typ}',f'properties: {typ} -{density} 0 {mat} 0'])
        for i in idx:lines.append(' '.join(format(v,'.17g') for v in (*xy[i],*xy[(i+1)%len(xy)])))
    for j,ids in enumerate(np.array_split(np.arange(len(a)),pieces)):add('conductor_'+str(j),2,0,a,ids)
    add('dielectric',3,1,b,range(len(b)))
    lines.extend(['IBCS_Resistances:','','Dielectrics:','1 6.25 -0.07 1 0'])
    return build_geometry_snapshot(*parse_geometry('\n'.join(lines)+'\n'))
def run(gap,n,density,order,sizing,backend):
    g=fixture(gap,n,density)
    opts=dict(factorization=backend,basis_order=order,mesh_strategy=sizing,mesh_grading=True,rhs_compression='off',assembly_threads=2,blas_threads=2)
    t=time.perf_counter()
    with cpu_allocation_scope(2):
        out=solver.solve_monostatic_rcs_2d(g,[FREQUENCY],THETA.tolist(),geometry_units='meters',strict_quality_gate=True,compute_condition_number=True,execution_options=opts)
    m=out['metadata']
    field=[]
    for c in ('VV','HH'):
        rows=out['co_solved_samples'][c]
        assert np.array_equal([r['theta_inc_deg'] for r in rows],THETA)
        field.append(np.asarray([complex(r['rcs_amp_real'],r['rcs_amp_imag']) for r in rows]))
    f=np.stack(field)
    assert np.all(np.isfinite(f)) and m['quality_gate']['passed']
    return f,dict(gap_wavelengths=gap,segments=n,panels_per_wavelength=density,order=order,sizing=sizing,backend=backend,panels=m['panel_count_max'],dofs=m['dense_largest_system'],quality=m['quality_gate']['passed'],seconds=time.perf_counter()-t)
def main():
    p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    rec=[];fields={'angles_deg':THETA}
    for gap in (.70,1.40):
        runs=[('ref',2,56,2,'global','dense'),('ref2',1,40,2,'global','compressed'),('one',1,20,1,'local','dense'),('two',2,20,1,'local','dense')]
        local={}
        for name,npieces,density,order,size,backend in runs:
            f,r=run(gap,npieces,density,order,size,backend)
            key=f'g{round(100*gap)}_{name}';fields[key]=f;local[name]=f
            r['vs_ref_peak_relative']=[float(v) for v in (np.max(abs(f-local['ref']),axis=1)/np.max(abs(local['ref']),axis=1))];r['key']=key;rec.append(r)
            print(key,r['panels'],r['dofs'],r['vs_ref_peak_relative'],flush=True)
        rec[-1]['one_vs_two_by_pol']=(np.max(abs(local['one']-local['two']),axis=1)/np.max(abs(local['two']),axis=1)).tolist()
    np.savez_compressed(a.output/'fields.npz',**fields)
    (a.output/'results.json').write_text(json.dumps(rec,indent=2)+'\n')
if __name__=='__main__':main()
