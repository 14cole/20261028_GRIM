"""Verify every archived result in Claude's review at 50b68bf."""
from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path
import numpy as np

cli = ArgumentParser(description=__doc__)
cli.add_argument("results", type=Path)
cli.add_argument("output", type=Path)
args = cli.parse_args()
root = args.results
col_names = ("frequency_ghz", "linear_residual", "rcs_amp_imag", "rcs_amp_phase_deg",
             "rcs_amp_real", "rcs_db", "rcs_linear", "theta_inc_deg", "theta_scat_deg")
expected = {f"{channel}_{key}" for channel in ("VV", "HH") for key in col_names}

def load(p):
    with np.load(p, allow_pickle=False) as a:
        assert set(a.files) == expected, p
        values = {k:a[k] for k in a}
    assert all(v.dtype == np.float64 and np.isfinite(v).all() for v in values.values()), p
    return values

def same(a,b):
    return all(a[k].dtype == b[k].dtype and a[k].shape == b[k].shape and
               a[k].tobytes() == b[k].tobytes() for k in expected)

def fields(a,ch):
    return a[f"{ch}_rcs_amp_real"] + 1j * a[f"{ch}_rcs_amp_imag"]

def delta(a,b):
    return max(float(np.max(np.abs(fields(a,c)-fields(b,c)))) for c in ("VV", "HH"))

def relative_peak(a,b):
    return delta(a,b) / max(float(np.max(np.abs(fields(a,c)))) for c in ("VV","HH"))

outcomes = Counter()
all_json = sorted(root.glob("*/*.json"))
seen = set()
pairs = {}
peak_exceptions = []
zero_inner = {}
actual_ops = Counter()
rhs_columns = Counter()
paired_rows = 0
max_residual = 0.
mismatches = []
cap_traces = {}
for p in all_json:
    r = json.loads(p.read_text())
    arm = r['tree']
    condition = r['outcome'].split(':',1)[0]
    outcomes[arm,condition] += 1
    if r['ram_cap_gib']:
        cap = float(r['ram_cap_gib'])
        admitted = arm == 'thin' and (r['backend'],cap) in {('dense',0.44),('compressed',0.34)}
        assert condition == ('solved' if admitted else 'refused'), p
        gates = [e['gib'] for e in r['log'] if e.get('source')=='execution' and e['event']=='estimate']
        cap_traces[p.stem] = dict(estimated_first=gates[0], smallest_attempt=min(gates),
                                peak_process_gib=r['peak_rss_gib'], outcome=condition)
    if condition == 'ValueError':
        message = 'qualified linear basis' if '_p2' in p.stem else 'require monostatic'
        assert message in r['outcome'], p
    if condition == 'planned':
        assert r['mode']=='plan_only' and all(isinstance(r[k],dict) for k in ('hpc_VV_HH','hpc_HH_VV'))
    if condition != 'solved':
        continue
    assert r['quality_passed'], p
    field_file = p.with_name(p.stem.split('_cap')[0]+'.npz')
    assert field_file.exists() and field_file not in seen, p
    seen.add(field_file)
    data = load(field_file)
    bistatic = r['mode']=='bistatic'
    if bistatic:
        exp_inc = np.repeat([0.,40.,95.],120)
        exp_scat = np.tile(np.arange(0.,360.,3.),3)
    else:
        exp_inc = exp_scat = np.arange(0.,360.,1.5)
    for c in ('HH','VV'):
        assert np.array_equal(data[f'{c}_theta_inc_deg'],exp_inc), p
        assert np.array_equal(data[f'{c}_theta_scat_deg'],exp_scat), p
        assert all(len(v)==len(exp_inc) for v in data.values()), p
        assert np.all(data[f'{c}_frequency_ghz']==3.)
        max_residual = max(max_residual,float(np.max(data[f'{c}_linear_residual'])))
    key = p.parent.name + '/' + p.stem.split('_',1)[1]
    pairs.setdefault(key,{})[arm]=data
    estimates = [v for v in r['log'] if v.get('source')=='execution' and v['event']=='estimate']
    assert len(estimates)==4, p
    if r['peak_rss_gib']>max(v['gib'] for v in estimates):
        peak_exceptions.append([p.name,r['rss_before_gib'],r['peak_rss_gib'],max(v['gib'] for v in estimates)])
    ops = [v for v in r['log'] if v['event']=='operator']
    if len(ops)==0:
        assert '_zero' in key and all(np.all(fields(data,c)==0) for c in ('HH','VV'))
        zero_inner[arm] = [v['system_dofs'] for v in estimates[1::2]]
        continue
    assert len(ops)==2, p
    for j,(pol,ch) in enumerate([('TE','VV'),('TM','HH')]):
        op=ops[j]
        n=op['shape'][0]
        assert op['shape']==[n,n] and all(q[0]==n for q in op['rhs_shapes'])
        assert sum(q[1] for q in op['rhs_shapes'])==(3 if bistatic else 240), (p,op)
        actual_ops[arm,op['type']] += 1
        rhs_columns[tuple(q[1] for q in op['rhs_shapes'])] += 1
        if arm != 'thin':
            continue
        desktop = [e for e in r['log'] if e.get('source')=='desktop_forecast' and e['event']=='resources' and e.get('pol')==pol]
        assert bool(desktop) == (r['backend']=='automatic')
        assert all(e['system_dofs']==n for e in desktop), p
        assert all(r[order][ch]['system_dofs']==n for order in ['hpc_VV_HH','hpc_HH_VV']), p
        est=estimates[2*j:2*j+2]
        assert all(e['system_dofs']==n for e in est)
        model={'StreamedOperator':'compressed_phase_v2','HMatrixOperator':'compressed_hmatrix_v2','ndarray':'dense_phase_v1'}[op['type']]
        assert all(e['plan_model']==model for e in est), (p,model,est)
        hpc_est = [e for e in r['log'] if e.get('source')=='hpc_forecast' and e['event']=='estimate' and e['system_dofs']==n]
        assert hpc_est and all(e['plan_model']==model for e in hpc_est), (p,model,hpc_est)
        if desktop:
            assert any(e['system_dofs']==n and e['plan_model']==model for e in r['log']
                       if e.get('source')=='desktop_forecast' and e['event']=='estimate'), (p,model)
for key,arms in pairs.items():
    if len(arms)==2:
        if not same(arms['rc'],arms['thin']):
            mismatches.append(key)
        paired_rows+=2*len(arms['rc']['HH_frequency_ghz'])
    else:
        assert key.startswith('q3cap/') and set(arms)=={'thin'}
assert not mismatches and seen==set(root.glob('*/*.npz'))
cap={}
for k in pairs:
    if k.startswith('q3cap/'):
        ample = pairs['q3/'+k.split('/')[1].split('_cap')[0]]
        cap[k] = all(same(pairs[k]['thin'],d) for d in ample.values())
assert len(cap)==2 and all(cap.values())
renaming={}
for b in ['automatic','dense','compressed']:
    a=pairs[f'q1/120_one_{b}_mono']['thin']
    renaming[b]={n:delta(a,pairs[f'q1/120_{n}_{b}_mono']['thin']) for n in ['three','six','six_mixed']}
backend={n:delta(pairs[f'q1/120_{n}_dense_mono']['thin'],pairs[f'q1/120_{n}_compressed_mono']['thin']) for n in ['one','three','six','six_mixed']}
one_dense = pairs['q1/120_one_dense_mono']['thin']
relative = {k:relative_peak(one_dense,pairs['q1/120_'+k+'_mono']['thin']) for k in ['six_mixed_dense','one_compressed']}
result=dict(traces=len(all_json),numeric_archives=len(seen),two_tree_pairs=sum(len(v)==2 for v in pairs.values()),
    numeric_arrays_per_pair=len(expected),polarized_rows_across_two_tree_pairs=paired_rows,
    values_across_pairs=paired_rows*len(col_names),all_paired_bytes_identical=True,
    maximum_linear_residual=max_residual,outcomes={str(k):v for k,v in outcomes.items()},
    candidate_and_baseline_ample_match_admitted=cap,operator_counts={str(k):v for k,v in actual_ops.items()},
    rhs_column_batches={str(k):v for k,v in rhs_columns.items()},peak_hwm_above_largest_execution_estimate=peak_exceptions,
    zero_contrast_inner_dof_label=zero_inner,renaming_max_absolute_complex_delta=renaming,
    dense_vs_compressed_max_absolute_complex_delta=backend, normalized_peak_field_delta=relative,
    capped_trace_details=cap_traces)
args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
