"""Run Claude's original geometric probes in isolated processes, retaining each input."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

CASES = [
    (f"open_{variant}", "q1", f"120:{variant}", "automatic", "mono", {})
    for variant in ("one", "three", "six", "six_mixed")
] + [("open_compressed", "q1", "120:six_mixed", "compressed", "mono", {})] + [
    (f"{variant}_{mode}", "q4", fixture, mode, "mono", {})
    for fixture, variant in (("480:ring", "ring"), ("200:two_strips", "disconnected"))
    for mode in ("dense", "compressed")
] + [
    ("bistatic", "q4", "120:six_mixed", "dense", "bistatic", {}),
    ("magnetic", "q4", "120:six_mixed", "dense", "mono",
     {"THIN_MATERIAL": "3.2 -0.02 1.5 -0.1", "THIN_TAG": "_magnetic"}),
    ("zero", "q4", "120:six_mixed", "automatic", "mono",
     {"THIN_MATERIAL": "1 0 1 0", "THIN_TAG": "_zero"}),
    ("p2", "q4", "120:six_mixed", "dense", "mono",
     {"THIN_BASIS": "2", "THIN_TAG": "_p2"}),
]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ["claude", "release", "prototype", "output"]:
        p.add_argument(n, type=Path)
    args=p.parse_args()
    for name, _, fixture, backend, mode, settings in CASES:
        for tag, source in (("rc", args.release), ("thin", args.prototype)):
            target=(args.output/name/tag).resolve()
            target.mkdir(parents=True, exist_ok=True)
            env={k:v for k,v in os.environ.items() if not k.startswith(("GHOST_", "THIN_"))}
            env.update(GRIM_ROOT=str(source.resolve()), OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
            env.update(settings)
            subprocess.run([sys.executable, str(args.claude.resolve()/"trace_case.py"),
                            tag, fixture, backend, str(target), mode], env=env, check=True)
if __name__=="__main__":
    main()
