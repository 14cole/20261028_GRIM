"""Verify local complete samples, same-host bit equality and cross-host physical field deltas."""
import argparse
import json
from pathlib import Path

import numpy as np
from replay import CASES

CHANNELS = {"VV": "TE", "HH": "TM"}
AXES = ("frequency_ghz", "theta_inc_deg", "theta_scat_deg")

def trace_signature(tr):
    return [(e["event"], e.get("source"), e.get("pol"), e.get("system_dofs"),
             e.get("type"), e.get("shape"), e.get("rhs_shapes"),
             e.get("elements"), e.get("nodes"), e.get("live"), e.get("plan_model"))
            for e in tr["log"] if e["event"] in ("operator", "resources") or e.get("live")]

def axis_and_field(local, other):
    result={}
    for label, pol in CHANNELS.items():
        keys=[label+"_"+a for a in AXES]
        assert all(np.array_equal(local[k], other[k]) for k in keys), keys
        q=local[label+"_rcs_amp_real"] + 1j*local[label+"_rcs_amp_imag"]
        ref=other[label+"_rcs_amp_real"] + 1j*other[label+"_rcs_amp_imag"]
        d=float(np.max(np.abs(q-ref))); peak=float(np.max(np.abs(ref)))
        assert peak or d==0
        result[pol]=d/peak if peak else 0.0
    return result

def analyze(upstream, data):
    summary={}
    rows=0
    max_residual=0.
    for name, subset, fixture, mode, grid, settings in CASES:
        pair={}
        for tag in ("rc", "thin"):
            path=next((data/name/tag).glob("*.json"))
            archived=upstream/"results"/subset/path.name
            tr, ar = [json.loads(p.read_text()) for p in (path, archived)]
            assert tr["outcome"]==ar["outcome"]
            assert trace_signature(tr)==trace_signature(ar), name
            for order in ("hpc_VV_HH", "hpc_HH_VV"):
                if isinstance(tr[order],str):
                    assert tr[order]==ar[order]
                else:
                    assert {c:r["system_dofs"] for c,r in tr[order].items()} == {
                        c:r["system_dofs"] for c,r in ar[order].items()}
            if name=="p2":
                assert "qualified linear basis" in tr["outcome"]
                for order in ("hpc_VV_HH", "hpc_HH_VV"):
                    if tag=="rc":
                        assert [tr[order][p]["system_dofs"] for p in CHANNELS]==[522,261]
                    else:
                        assert "qualified linear basis" in tr[order]
                pair[tag]={"solve":tr["outcome"],"hpc":tr["hpc_VV_HH"]}
                continue
            assert tr["outcome"]=="solved" and tr["quality_passed"]
            hpc={pol:tr["hpc_HH_VV"][channel]["system_dofs"] for channel,pol in CHANNELS.items()}
            assert hpc=={pol:tr["hpc_VV_HH"][channel]["system_dofs"] for channel,pol in CHANNELS.items()}
            evidence={x["polarization"]: x["unknowns"] for x in tr["thin_layer_evidence"]}
            cells={}
            for e in tr["log"]:
                if e["event"]=="resources" and e["source"]=="execution":
                    pol=e["pol"]
                    cells[pol]={"outer_dofs":e["system_dofs"], "panels":e["elements"], "nodes":e["nodes"]}
                elif e["event"]=="estimate" and e["source"]=="execution" and e["live"]:
                    cells[pol].setdefault("checked_dofs",[]).append(e["system_dofs"])
                elif e["event"]=="operator":
                    dim=evidence[pol]
                    assert e["shape"]==[dim,dim]
                    assert all(shape[0]==dim for shape in e["rhs_shapes"])
                    assert sum(shape[1] for shape in e["rhs_shapes"])==(3 if grid=="bistatic" else 240)
                    cells[pol].update(operator_shape=e["shape"],operator=e["type"],rhs=e["rhs_shapes"])
            assert set(cells)=={"TE","TM"}
            if tag=="thin":
                for pol,v in cells.items():
                    assert evidence[pol]==hpc[pol]==v["outer_dofs"]
                    assert v["checked_dofs"]==[evidence[pol],evidence[pol]]
            desktop={e["pol"]:e["system_dofs"] for e in tr["log"] if e["event"]=="resources" and
                     e["source"]=="desktop_forecast"}
            assert bool(desktop)==(mode=="automatic"), name
            if desktop: assert desktop==hpc
            with np.load(path.with_suffix(".npz")) as a, np.load(archived.with_suffix(".npz")) as b:
                assert len(a.files)==18 and set(a.files)==set(b.files)
                cross=axis_and_field(a,b)
                res=max(float(np.max(np.abs(a[k]))) for k in a.files if k.endswith("_linear_residual"))
                max_residual=max(max_residual,res)
            pair[tag]=dict(hpc=hpc,desktop=desktop,system=cells,cross_host_peak_relative=cross,
                           max_abs_stored_residual=res)
        if name!="p2":
            with np.load(next((data/name/"rc").glob("*.npz"))) as a, np.load(next((data/name/"thin").glob("*.npz"))) as b:
                assert set(a.files)==set(b.files)
                assert all(a[k].dtype==b[k].dtype and a[k].shape==b[k].shape and a[k].tobytes()==b[k].tobytes() for k in a.files)
                pair["polarized_rows_compared"]=sum(a[c+"_frequency_ghz"].size for c in CHANNELS)
                rows+=pair["polarized_rows_compared"]
        summary[name]=pair
    naming={}
    for tag in ("rc","thin"):
        with np.load(next((data/"open_one"/tag).glob("*.npz"))) as ref:
            for variant in ("three","six","six_mixed"):
                with np.load(next((data/f"open_{variant}"/tag).glob("*.npz"))) as z:
                    naming[tag+"_"+variant]=axis_and_field(z,ref)
    return dict(cases=summary, local_successful_pairs=sum("polarized_rows_compared" in v for v in summary.values()),
                all_local_paired_columns_bit_identical=True,total_local_polarized_rows_in_pairs=rows,
                max_abs_stored_residual=max_residual,
                max_cross_host_field_difference_relative_to_peak=max(max(t["cross_host_peak_relative"].values())
                for v in summary.values() for k,t in v.items() if k in ("rc","thin") and "cross_host_peak_relative" in t),
                local_renaming_max_difference_relative_to_peak=naming)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for n in ("upstream","replay","output"):p.add_argument(n,type=Path)
    a=p.parse_args()
    result=analyze(a.upstream,a.replay)
    a.output.write_text(json.dumps(result,indent=2)+"\n")
    print({k:v for k,v in result.items() if k not in ("cases","local_renaming_max_difference_relative_to_peak")})
