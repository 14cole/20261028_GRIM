# Fresh geometry and field replay

Twenty-six fresh Linux processes ran Claude’s unmodified trace_case.py at 50b68bf, once per fixture and backend combination on each revision. Twelve pairs completed on both trees. Each of their 18 numeric arrays matched exactly, comparing dtype, shape and bytes. This represents 6,000 polarized output rows per revision, including 720 bistatic rows. The largest stored residual across these new runs was 2.11e−15. The thirteenth pair exercised explicit P2, which the thin-layer formulation rejects on both revisions.

| Geometry or material | Release HPC TE / TM | Prototype HPC TE / TM | Actual TE / TM |
|---|---:|---:|---:|
| Open strip, one name | 258 / 129 | 258 / 129 | 258 / 129 |
| Same strip, three names | 262 / 131 | 258 / 129 | 258 / 129 |
| Same strip, six names | 268 / 134 | 258 / 129 | 258 / 129 |
| Five names, reordered and two reversed | 266 / 133 | 258 / 129 | 258 / 129 |
| Closed ring | 976 / 488 | 960 / 480 | 960 / 480 |
| Two disconnected strips | 440 / 220 | 436 / 218 | 436 / 218 |
| Reordered open strip, magnetic contrast | 266 / 266 | 258 / 258 | 258 / 258 |
| Reordered open strip, zero contrast | 0 / 0 | 0 / 0 | Analytic zero |

Both HPC channel orders produced the same dimensions. For the four Automatic open-strip fixtures and the Automatic zero-contrast case, the desktop forecast also matched the HPC result. For the forced Dense and Compressed runs, the tracer called the public HPC planner and observed actual solve-time admission. The independent desktop selector did not run in the forced-backend cases. The tracer passes a 240-angle monostatic configuration to its separate HPC call even for the Dense bistatic test. Only its dimension is compared for that test. The actual bistatic job solved three incident RHS columns, evaluated at 120 observation angles each. Using three or six names with fixed orientation gave exactly the one-name complex fields. The shuffled/reversed five-name variant differed by at most 1.95e−16 of peak.

On each checkout the fresh operator type/shape, batches of RHS columns, both HPC orders, and the captured estimate signatures agreed with Claude’s archived evidence. All complex field comparisons against Claude used matching frequency, incidence and observation arrays, in their original order. Across these cases the largest complex difference between hosts was 1.85e−15 of that channel’s peak. The P2 HPC test produced a quote of 522 / 261 on the release and rejected the request on the prototype. These measurements support a separate merge of the thin-layer planning change. This test exercises local public planner APIs. It does not submit a cluster job or validate the physical approximation.

## Replay

Use the repository’s normal Linux solver environment with NumPy and SciPy. Give CLAUDE_DIR the location of audits/claude-2026-11-28/thin-layer-review at commit 50b68bfbec49eeb8259927efc7686fca8a94ca04, and use the full exported checkouts for RELEASE (6621db2) and TRIAL (f1564a7).

```sh
python replay.py "$CLAUDE_DIR" "$RELEASE" "$TRIAL" new-results
python compare.py "$CLAUDE_DIR" new-results new-summary.json
```

The SHA-256 of the tracer was e357330ccc8af79619b351943d458d7f1cdc8690408bf82ac618dcedd265d7e2. Each case uses its own working output directory, preserving the matching input geometry for material and basis variants. The wrapper clears solver and thin-layer environment overrides and uses one OpenBLAS and OpenMP thread. The comparator checks the return status, scoping of forecast instrumentation, all angular axes, and the complete returned sample arrays, including residuals. It does not use runtime or RSS equality as a correctness criterion.
