#!/bin/bash
set -eu
out=$1
driver=$2
fixture=$3
backend=$4
label=$5
source_path=$6
python=$7
mkdir -p "$out"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
GRIM_ROOT="$source_path" "$python" "$driver" "$label" "$fixture:six_mixed" "$backend" "$out" mono
