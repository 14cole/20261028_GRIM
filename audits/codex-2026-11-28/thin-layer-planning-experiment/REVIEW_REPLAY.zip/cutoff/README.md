# Independent rerun at the Compressed operator cutoff

The runs use Claude's unmodified tracer from `50b68bfbec49eeb8259927efc7686fca8a94ca04`, Git blob `d565547e7fc504035c3896e3342712930e0915cf`. Each job uses a fresh process, one BLAS/OpenMP thread, both polarizations and 240 monostatic directions. The fixture is an open bent thin dielectric layer at 3 GHz with five segment names, two sections reversed and segments out of order. We replayed both sizes, forced Compressed and Automatic, on both `6621db2` and `f1564a7`. Each release and candidate pair ran concurrently on the common Linux host. The process high-water mark is for the entire job, both polarizations included. The live memory estimate is specific to one polarization and stage.

| TM physical unknowns | Prior public solve, initial / inner memory model | Prototype, initial / inner | Solved operator and RHS on each revision |
|---:|---|---|---|
| 1,023 | Hierarchical at 1,027 / streamed at 1,023 | Streamed at 1,023 / streamed at 1,023 | Streamed, 1,023 by 240 RHS |
| 1,024 | Hierarchical at 1,028 / streamed at 1,024 | Hierarchical at 1,024 / hierarchical at 1,024 | Hierarchical, 1,024 by 240 RHS |

In the public forced-Compressed cases the TE channel had two traces and used streamed tiles at both sizes. The extra desktop pricing records came from separately executed Automatic jobs. Automatic actually selected Dense. The comparison covers forecasts from the HPC planner in both polarization orders and every numerical output column for these eight new runs. None of the cases submitted a batch job to a scheduler.

All eight jobs passed the public quality gate. Every one of the nine saved numeric columns for each polarization was exactly equal between revisions for corresponding runs. The largest fresh-to-Claude complex-field difference over either polarization and any run was 1.385e-15 relative to the peak magnitude for that polarization. At 1,023 physical TM unknowns, the paired forced-Compressed jobs used 0.2178/0.2177 GiB peak process RSS (release/candidate). At 1,024 they used 0.2255/0.2259 GiB. Automatic used 0.2567–0.2577 GiB and selected Dense in all four runs.

The at-cutoff release-candidate inner gate already appeared as a streamed estimate in the earlier Codex compression/README.md and compression/comparison-final.json within REPLAY.zip at `ecc3e1a`. Claude provides independent corroboration using its own geometry, tracer, and higher angle count. The release-candidate outer-to-inner switch at 1,023 unknowns is a discrepancy in the applicable pricing model. The runs give a process high-water mark on each machine and do not alone establish memory sufficiency at other loads.

## Replay

Set RELEASE and PROTOTYPE to exports of the respective commits, UPSTREAM to Claude's thin-layer-review directory containing its tracer and results, and PYTHON to the GHOST environment's Python executable.

```sh
for t in rc thin; do
    tree=$RELEASE
    if test "$t" = thin; then tree=$PROTOTYPE; fi
    for backend in compressed automatic; do
        for n in 1014 1015; do
            bash replay.sh runs "$UPSTREAM/trace_case.py" "$n" "$backend" "$t" "$tree" "$PYTHON"
        done
    done
done
"$PYTHON" compare.py runs "$UPSTREAM/results/q2" summary.json
```
