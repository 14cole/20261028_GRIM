"""Check the complete eight 240-angle runs and compare to Claude's q2 traces."""
from argparse import ArgumentParser
from pathlib import Path
import json
import numpy as np

p = ArgumentParser(description=__doc__)
p.add_argument("local", type=Path)
p.add_argument("reference", type=Path)
p.add_argument("output", type=Path)
args = p.parse_args()
models = {"stream": "compressed_phase_v2", "hier": "compressed_hmatrix_v2", "dense": "dense_phase_v1"}

def stages(report):
    assert report['outcome'] == 'solved' and report['quality_passed'] is True
    assert report['hierarchical_cutoff'] == 1024
    logs = report["log"]
    fields = {}
    for i, event in enumerate(logs):
        if event["event"] != "resources" or event["source"] != "execution":
            continue
        a, b, matrix = logs[i+1:i+4]
        assert a["live"] and b["live"] and matrix["event"] == "operator"
        assert a["factor_mode"] == b["factor_mode"]
        shape = matrix["shape"]
        assert shape[0] == shape[1] and matrix["rhs_shapes"] == [[shape[0], 240]]
        fields[event["pol"]] = {"physical": shape[0], "operator": matrix["type"],
                                "rhs_shape": matrix["rhs_shapes"][0],
                                "live_sizes": [a["system_dofs"], b["system_dofs"]],
                                "live_models": [a["plan_model"], b["plan_model"]],
                                "live_gib": [a["gib"], b["gib"]]}
    assert set(fields) == {"TM", "TE"}
    return fields

def summary(report):
    return {"backend": report["linear_backend"], "live":stages(report),
            "hpc": [report["hpc_"+o] for o in ("VV_HH", "HH_VV")],
            "desktop": [e for e in report["log"] if e.get("source")=="desktop_forecast" and e["event"]=="resources"]}

records = {}
max_rel = 0.
for size in (1014, 1015):
    tm = size + 9
    for backend in ("compressed","automatic"):
        field_sets = {}
        for tree in ("rc","thin"):
            stem = f"{tree}_{size}_six_mixed_{backend}_mono"
            path = args.local/(stem+".json")
            report = json.loads(path.read_text())
            src = json.loads((args.reference/(stem+".json")).read_text())
            obs = summary(report)
            ref = summary(src)
            assert obs["backend"] == ref["backend"] and obs["desktop"] == ref["desktop"]
            same_host = []
            for pol, dim, exp_plan, label in (("TM", tm, tm+4, "HH"), ("TE",2*tm,2*(tm+4), "VV")):
                forecast = exp_plan if tree=="rc" else dim
                for h in obs["hpc"]:
                    assert h[label]["system_dofs"] == forecast
                row = obs["live"][pol]
                for k in ("physical","operator","live_sizes","live_models","rhs_shape"):
                    assert row[k] == ref["live"][pol][k], (stem,pol,k)
                assert row["physical"] == dim and row["live_sizes"] == [forecast,dim]
                if backend == "automatic":
                    assert obs["backend"] == "cpu" and row["live_models"] == [models["dense"]]*2
                    assert row["operator"] == "ndarray"
                    ff = next(e for e in obs["desktop"] if e["pol"] == pol)
                    assert ff["system_dofs"] == forecast and ff["hierarchical_storage_priced"] == (pol=="TM" and forecast>=1024)
                else:
                    assert not obs["desktop"]
                    actual = "hier" if pol=="TM" and dim>=1024 else "stream"
                    outer = "hier" if pol=="TM" and forecast>=1024 else "stream"
                    inner = actual if tree=="thin" else "stream"
                    assert row["live_models"] == [models[outer],models[inner]]
                    assert row["operator"] == {"hier":"HMatrixOperator","stream":"StreamedOperator"}[actual]
                    if tree=="thin":
                        assert row["live_gib"][0] == row["live_gib"][1]
            with np.load(path.with_suffix(".npz")) as a, np.load(args.reference/(stem+".npz")) as b:
                assert set(a.files)==set(b.files) and len(a.files)==18
                field_sets[tree] = {key:a[key] for key in a.files}
                assert all(np.all(np.isfinite(a[k])) and a[k].shape==(240,) for k in a.files)
                peak_rel = {}
                for pol in ("VV","HH"):
                    for axis in ("frequency_ghz","theta_inc_deg","theta_scat_deg"):
                        assert np.array_equal(a[f"{pol}_{axis}"],b[f"{pol}_{axis}"])
                    calc = a[pol+"_rcs_amp_real"]+1j*a[pol+"_rcs_amp_imag"]
                    refamp = b[pol+"_rcs_amp_real"]+1j*b[pol+"_rcs_amp_imag"]
                    peak_rel[pol] = float(np.max(np.abs(calc-refamp))/np.max(np.abs(refamp)))
                    assert peak_rel[pol]<1e-8, (stem,pol,peak_rel[pol])
                    max_rel = max(max_rel, peak_rel[pol])
            records[stem]={"qg_pass":report["quality_passed"], "process_rss_gib":report["peak_rss_gib"],
                          "reference_process_rss_gib":src["peak_rss_gib"], "cross_host_peak_relative":peak_rel,
                          "execution":obs["live"],"seconds":report["wall_s"]}
        for key in field_sets["rc"]:
            assert np.array_equal(field_sets["rc"][key],field_sets["thin"][key]), (size, backend, key)
out = {"public_paired_solves":len(records),"complex_samples_per_tree":1920,
       "sample_columns_per_polarization":9,"all_same_host_sample_columns_exact":True,
       "maximum_cross_host_complex_field_peak_relative":max_rel,"records":records}
args.output.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k!="records"}))
