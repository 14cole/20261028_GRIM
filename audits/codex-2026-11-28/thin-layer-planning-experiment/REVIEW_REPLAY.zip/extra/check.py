"""Recreate zero contrast and explicit high-order runs in distinct fresh directories."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('tracer', type=Path)
parser.add_argument('baseline', type=Path)
parser.add_argument('prototype', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
output = args.output.resolve()
rows = {}
for label, checkout in [('rc', args.baseline), ('thin', args.prototype)]:
    for name,backend,opt in [('zero','automatic',{'THIN_MATERIAL':'1 0 1 0'}),
                             ('p2','dense',{'THIN_BASIS':'2'})]:
        directory=output/name/label
        directory.mkdir(parents=True,exist_ok=True)
        env=dict(os.environ, GRIM_ROOT=str(checkout.resolve()), OPENBLAS_NUM_THREADS='1',
                 OMP_NUM_THREADS='1', THIN_TAG='_'+name, **opt)
        subprocess.run([sys.executable,str(args.tracer.resolve()),label,'120:six_mixed',backend,
                        str(directory)],cwd=directory,env=env,check=True,stdout=subprocess.PIPE,text=True)
        j=json.loads(next(directory.glob('*.json')).read_text())
        ops=[e for e in j['log'] if e['event']=='operator']
        live=[e for e in j['log'] if e['event']=='estimate' and e['live']]
        orders=['hpc_VV_HH','hpc_HH_VV']
        assert not ops
        if name=='zero':
            assert j['outcome'] == 'solved'
            expected_dofs = [0, 0, 0, 0] if label == 'thin' else [0, 129, 0, 129]
            assert [e['system_dofs'] for e in live] == expected_dofs
            with np.load(next(directory.glob('*.npz')),allow_pickle=False) as z:
                for c in ('VV','HH'):
                    for k in ('rcs_amp_real','rcs_amp_imag','rcs_linear','linear_residual'):
                        assert z[c+'_'+k].shape==(240,) and np.all(z[c+'_'+k]==0)
            assert all(j[k][p]['system_dofs']==0 for k in orders for p in ('VV','HH'))
        else:
            assert 'qualified linear basis' in j['outcome'] and not list(directory.glob('*.npz'))
            for k in orders:
                if label=='thin':
                    assert 'qualified linear basis' in j[k]
                else:
                    assert isinstance(j[k],dict)
        rows[label+'_'+name]=dict(outcome=j['outcome'], hpc=j['hpc_VV_HH'],
                    live_estimates=[(e['system_dofs'],e['gib']) for e in live],
                    rss_before_gib=j['rss_before_gib'], peak_process_rss_gib=j['peak_rss_gib'],
                    observed_operator_calls=len(ops))
(output/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
