# Independent replay of Claude’s thin-layer review

All runs used separate Linux solver processes. The original tracer is in the repository 14cole/20261028_GRIM at 50b68bfbec49eeb8259927efc7686fca8a94ca04 under audits/claude-2026-11-28/thin-layer-review/. Use that directory, including its results subdirectory, for CLAUDE_AUDIT in the commands below. RELEASE_TREE is a source export of 6621db27b90f7757606312ec99b8b2727a9e8837 and THIN_TRIAL_TREE is a source export of f1564a770151abd8fa0e98cc95700ca311443cad. Both require the normal GHOST Python and native dependencies.

The raw/, topology/, cutoff/, admission/ and extra/ directories contain the validation scripts and actual results. The 50 fresh process runs include four deliberately repeated boundary checks. See each directory’s README for individual commands where provided. For the archived-field audit and the targeted repeated runs, use the following commands from this archive’s root in an environment with default GHOST and THIN settings.

```sh
python raw/audit.py "$CLAUDE_AUDIT/results" raw/repeated-summary.json
python extra/check.py "$CLAUDE_AUDIT/trace_case.py" "$RELEASE_TREE" "$THIN_TRIAL_TREE" extra/new-run
sha256sum -c SHA256SUMS
```

The absolute checkout paths in the recorded runtime traces identify the environment at the time. Reproduction scripts accept checkout and output paths. The integrity manifest covers each original archive member excluding itself.
