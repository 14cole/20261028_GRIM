"""Validate admission, operators and every saved field and residual column on both hosts."""
import argparse
import json
from pathlib import Path

import numpy as np


def compare_payloads(candidate, reference, *, same_host):
    with np.load(candidate, allow_pickle=False) as left, np.load(reference, allow_pickle=False) as right:
        assert len(left.files) == 18 and set(left.files) == set(right.files)
        unequal = []
        for key in sorted(left.files):
            lhs, rhs = left[key], right[key]
            assert lhs.dtype == rhs.dtype == np.dtype('float64') and lhs.shape == rhs.shape == (240,), key
            assert np.isfinite(lhs).all() and np.isfinite(rhs).all()
            if lhs.tobytes() != rhs.tobytes():
                unequal.append(key)
            if key.endswith(('theta_inc_deg', 'theta_scat_deg', 'frequency_ghz')):
                assert np.array_equal(lhs, rhs)

        fields = {}
        residual_delta = {}
        residual_max = {}
        for pol in ('VV', 'HH'):
            def amplitude(data):
                return data[f'{pol}_rcs_amp_real'] + 1j * data[f'{pol}_rcs_amp_imag']
            ref = amplitude(right)
            fields[pol] = float(np.max(abs(amplitude(left) - ref)) / np.max(abs(ref)))
            lhs, rhs = (data[f'{pol}_linear_residual'] for data in (left, right))
            residual_delta[pol] = float(np.max(abs(lhs - rhs)))
            residual_max[pol] = float(max(np.max(abs(lhs)), np.max(abs(rhs))))
        if same_host:
            assert all(key.endswith('_linear_residual') for key in unequal), unequal
        assert max(fields.values()) < 1e-12 and max(residual_max.values()) < 1e-12
        return dict(candidate=str(candidate), reference=str(reference), unequal_columns=unequal,
                    max_relative_complex_field_by_pol=fields, max_absolute_residual_delta_by_pol=residual_delta,
                    max_absolute_residual_value_by_pol=residual_max)


def compare_all(replay, archives):
    rows = []
    same_host = []
    cross_host = []
    for backend, upper, lower in [('dense', '0.44', '0.42'), ('compressed', '0.34', '0.32')]:
        ample = {}
        for cap in ['ample', upper, lower]:
            for label in ['rc', 'thin']:
                path = replay / backend / cap / label
                prefix = f'{label}_600_many_{backend}_mono'
                suffix = '' if cap == 'ample' else f'_cap{cap}'
                jsonname = f'{prefix}{suffix}.json'
                refdir = archives / ('q3' if cap == 'ample' else 'q3cap')
                data = json.loads((path / jsonname).read_text())
                archived = json.loads((refdir / jsonname).read_text())
                solved = data['outcome'] == 'solved'
                expected = cap == 'ample' or (cap == upper and label == 'thin')
                assert (archived['outcome'] == 'solved') == solved == expected, (cap, label, data['outcome'])
                assert (path / '600_many.geo').read_bytes() == (refdir / '600_many.geo').read_bytes()
                assert data['ram_cap_gib'] == (None if cap == 'ample' else cap)
                for req in ('hpc_HH_VV', 'hpc_VV_HH'):
                    assert data[req]['VV']['system_dofs'] == (1616 if label == 'rc' else 1218)
                    assert data[req]['HH']['system_dofs'] == (808 if label == 'rc' else 609)
                ev = [e for e in data['log'] if e['event'] == 'estimate' and e['source'] == 'execution' and e['live']]
                ops = [e for e in data['log'] if e['event'] == 'operator']
                assert not any(e.get('source') == 'desktop_forecast' for e in data['log'])
                row = dict(backend=backend, cap_gib=cap, tree=label, outcome=data['outcome'],
                           first_activation_gib=ev[0]['gib'], last_activation_gib=ev[-1]['gib'],
                           process_peak_gib=data['peak_rss_gib'], claude_process_peak_gib=archived['peak_rss_gib'],
                           initial_dofs=ev[0]['system_dofs'], operator_shapes=[op['shape'] for op in ops])
                if solved:
                    assert row['operator_shapes'] == [[1218, 1218], [609, 609]]
                    assert all(sum(c for _, c in op['rhs_shapes']) == 240 for op in ops)
                    assert data['quality_passed'] and np.isfinite(data['residual_norm_max'])
                    payload = path / f'{prefix}.npz'
                    if cap == 'ample':
                        ample[label] = payload
                    else:
                        for ref in ample.values():
                            same_host.append(compare_payloads(payload, ref, same_host=True))
                    cross_host.append(compare_payloads(payload, refdir / payload.name, same_host=False))
                else:
                    assert not ops and data['outcome'].startswith('refused:') and not list(path.glob('*.npz'))
                rows.append(row)
        same_host.append(compare_payloads(ample['rc'], ample['thin'], same_host=True))
        archived_payload = archives / 'q3cap' / f'thin_600_many_{backend}_mono.npz'
        for label in ('rc', 'thin'):
            ref = archives / 'q3' / f'{label}_600_many_{backend}_mono.npz'
            same_host.append(compare_payloads(archived_payload, ref, same_host=True))
    largest_field_delta = max(max(r['max_relative_complex_field_by_pol'].values()) for r in cross_host)
    return dict(outcome_rows=rows, same_host=same_host, cross_host=cross_host,
                cross_host_max_complex_peak_relative=largest_field_delta)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('replay', type=Path)
    parser.add_argument('claude_results', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    report = compare_all(args.replay, args.claude_results)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    for r in report['outcome_rows']:
        print(r['tree'], r['backend'], r['cap_gib'], round(r['first_activation_gib'], 5),
              round(r['last_activation_gib'], 5), r['process_peak_gib'], r['outcome'].split(':', 1)[0])
    print('max relative complex-field difference to Claude', report['cross_host_max_complex_peak_relative'])
