# Reservation and field replay

Independent run of Claude's unmodified `trace_case.py` at `50b68bf` with the release candidate `6621db2` and thin-layer planning trial `f1564a7`. Each of the twelve processes generated the same 200-name geometry, byte-for-byte, as Claude's archived input. The operator on every admitted solve had 608 panels, 609 mesh nodes, 1,218 TE unknowns and 609 TM unknowns. Each polarization solved 240 monostatic angles.

| Backend | Explicit cap (GiB) | Release | Trial | Trial process peak (GiB) |
| --- | ---: | --- | --- | ---: |
| Dense | ample | solved | solved | 0.1514 |
| Dense | 0.44 | refused | solved | 0.1282 |
| Dense | 0.42 | refused | refused | 0.0707 |
| Compressed | ample | solved | solved | 0.1429 |
| Compressed | 0.34 | refused | solved | 0.1457 |
| Compressed | 0.32 | refused | refused | 0.0707 |

The trial fixes the initial DOF estimate from 1,616/808 TE/TM to 1,218/609. The first TE estimates in GiB were 0.45224/0.43392 release/trial for Dense and 0.36129/0.32821 for Compressed. Release Compressed retried its estimate at 0.34773 before refusing 0.34. Every refusal occurred before construction of either polarization operator. Ample means no explicit `GHOST_MAX_SOLVE_GB` cap was set.

For each backend, both ample-budget revisions and the admitted constrained trial produced byte-identical complex fields across all 480 polarization-angle samples. All 18 NPZ columns also matched byte-for-byte for Compressed. For Dense the only differences were the two linear-residual columns in capped versus ample runs (maximum absolute difference 2.61e-18, maximum residual 1.29e-15). All 18 columns in the two ample Dense revisions matched. On Claude's host all 18 columns matched between the capped and both ample runs on both backends. The worst fresh versus corresponding archived complex field difference, normalized to the peak reference amplitude in that polarization and run, was 4.23e-16.

The cap is an application reservation read from `GHOST_MAX_SOLVE_GB` as `ram_budget_gib` and compared with modeled requirements before construction. In this run the tracer reported whole-process peak RSS from Linux VmHWM, including Python. Claude's archived constrained peaks were 0.1485 GiB Dense and 0.1679 GiB Compressed. These cap runs exercise an admission decision; they do not establish savings in physical RAM or performance under a kernel-enforced limit. The tracer's separate public HPC forecast uses its default minimum reservation and reports approximately 0.60 GiB here. These explicit-backend runs do not execute desktop Automatic's selection forecast.

From this directory, in a Python environment with the solver dependencies and compatible native libraries, supply the two independent source checkout paths and the archived case directory.

```sh
python replay.py "$CLAUDE_AUDIT/trace_case.py" "$RELEASE_TREE" "$THIN_TRIAL_TREE" raw
python compare.py raw "$CLAUDE_AUDIT/results" summary.json
```

The replay puts each process in its own evidence directory, avoiding collisions between same-name capped and ample field files. The comparison validates operator dimensions, degree-of-freedom forecasts and admitted/refused outcomes, examines all 18 columns and writes numerical errors for every field and residual comparison to `summary.json`.
