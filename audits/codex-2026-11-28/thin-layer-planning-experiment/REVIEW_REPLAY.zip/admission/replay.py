"""Run each of Claude's 200-name thin-layer reservation cases in a fresh process."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument("tracer",type=Path)
p.add_argument("release",type=Path)
p.add_argument("trial",type=Path)
p.add_argument("output",type=Path)
args=p.parse_args()
for backend, caps in [('dense',('ample','0.44','0.42')),('compressed',('ample','0.34','0.32'))]:
    for cap in caps:
        for label,tree in [('rc',args.release),('thin',args.trial)]:
            directory=args.output.resolve()/backend/cap/label
            directory.mkdir(parents=True,exist_ok=True)
            env=dict(os.environ,GRIM_ROOT=str(tree.resolve()),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
            for key in ('GHOST_MAX_SOLVE_GB','THIN_TAG','THIN_BASIS','THIN_MATERIAL'):
                env.pop(key,None)
            if cap!='ample':
                env['GHOST_MAX_SOLVE_GB']=cap
            cmd=[sys.executable,str(args.tracer.resolve()),label,'600:many',backend,str(directory)]
            with (directory/'stdout.txt').open('w') as log:
                subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
            print(label,backend,cap,flush=True)
