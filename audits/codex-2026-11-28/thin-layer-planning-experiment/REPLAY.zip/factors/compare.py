"""Check public forecasts and both executing resource gates against measured field-producing matrices."""
from argparse import ArgumentParser
from pathlib import Path
import json
import numpy as np


def compare(baseline, trial):
    records = [json.loads((path/'trace.json').read_text()) for path in (baseline, trial)]
    expected = {
        'one_section': (42, 21, 42, 21), 'four_sections': (48, 24, 42, 21),
        'four_sections_two_reversed': (48, 24, 42, 21), 'three_bent_sections': (46, 23, 42, 21),
        'codex_nine_panels': (24, 12, 20, 10),
    }
    result = dict(paired_public_solves=0, field_producing_polarization_systems=0,
                  complete_complex_sample_pairs=0, cases={})
    for case, (bt, bm, at, am) in expected.items():
        row = result['cases'][case] = {}
        for i, (arm, checkout) in enumerate(zip(('baseline','prototype'),(baseline,trial))):
            data = records[i][case]
            forecast = dict(TE=bt,TM=bm) if i == 0 else dict(TE=at,TM=am)
            assert data['desktop'] == data['hpc'] == forecast, (case,arm,'forecast',data)
            row[arm] = dict(forecast=forecast, operators={})
            for backend in ('dense','compressed'):
                result['paired_public_solves'] += 1
                gate=data[backend]['outer_execution']['prices']
                assert gate == list(forecast.values()), (case,arm,backend,gate)
                for pol,actual in [('TE',at), ('TM',am)]:
                    rec = data[backend]['channels'][pol]
                    assert rec['operator_shape'] == [actual, actual]
                    assert rec['evidence_unknowns'] == rec['inner_memory_price'] == actual
                    if i:
                        j=0 if pol=='TE' else 1
                        assert rec['inner_peak_gib']==data[backend]['outer_execution']['peak_gib'][j]
                    assert all(pair['solution']==pair['rhs'] and pair['rhs'][0]==actual
                               for pair in rec['factor_solves'])
                    row[arm]['operators'].setdefault(backend,{})[pol]=actual
                    result['field_producing_polarization_systems'] += 1
                if i:
                    with np.load(baseline/f'{case}_{backend}.npz') as b, np.load(checkout/f'{case}_{backend}.npz') as t:
                        assert set(b.files)==set(t.files)
                        for key in b.files:
                            assert np.array_equal(b[key],t[key]), (case,backend,key)
                            if key != 'angles_deg':
                                result['complete_complex_sample_pairs']+=b[key].size
        for pol in ('TE','TM'):
            for backend in ('dense','compressed'):
                rb,rt=(r[case][backend]['channels'][pol] for r in records)
                for field in ('angles','operator_shape','operator_type','operator_lu_shapes','rhs','factor_solves'):
                    assert rb[field]==rt[field], (case,pol,backend,field)
    db,dt=(json.loads((root/'bistatic.json').read_text()) for root in (baseline,trial))
    assert db['outer']==[64,32,64,32]
    assert dt['outer']==[60,30,60,30]
    assert len(db['calls'])==len(dt['calls'])==4
    for a,b in zip(db['calls'],dt['calls']):
        for k in ('polarization','k0','incidence','obs','rhs','inner_gate','physical_nodes','shape','reported_unknowns'):
            assert a[k]==b[k], ('bistatic',k)
        assert [op[0][1] for op in b['rhs']]==[2,2,1]
    with np.load(baseline/'bistatic.npz') as b, np.load(trial/'bistatic.npz') as t:
        assert set(b.files)==set(t.files)=={'VV','HH'}
        assert all(np.array_equal(b[k],t[k]) and b[k].shape==(70,6) for k in b.files)
    result['bistatic'] = dict(complex_sample_pairs=140, baseline_outer=db['outer'],prototype_outer=dt['outer'],
                              factor_dimensions=[r['shape'][0] for r in dt['calls']], angle_batches=[2,2,1])
    cases = {}
    for level in ('ample','constrained','under'):
        reports=[json.loads((root/(level+'.json')).read_text()) for root in (baseline,trial)]
        outcomes = [r['result'] for r in reports]
        assert outcomes == {'ample':['completed','completed'], 'constrained':['refused','completed'],
                            'under':['refused','refused']}[level]
        cases[level] = {'budget_gib':reports[0]['budget_gib'], 'result':outcomes,
                        'first_estimate_gib':[r['execution_prices'][0]['estimated_gib'] for r in reports]}
    for root,level in ((trial,'ample'),(trial,'constrained')):
        with np.load(baseline/'ample.npz') as b, np.load(root/(level+'.npz')) as t:
            assert set(b.files)==set(t.files)=={'VV','HH'}
            assert all(np.array_equal(b[k],t[k]) and b[k].shape==(180,4) for k in b.files)
    result['dense_admission']=cases
    return result

if __name__ == '__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('baseline',type=Path)
    p.add_argument('trial',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    summary=compare(a.baseline,a.trial)
    a.output.write_text(json.dumps(summary,indent=2)+'\n')
    print(summary['paired_public_solves'], summary['field_producing_polarization_systems'],summary['complete_complex_sample_pairs'])
