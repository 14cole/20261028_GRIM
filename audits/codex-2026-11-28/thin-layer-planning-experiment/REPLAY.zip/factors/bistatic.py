"""Trace both admission calls and the actual dense operator for a multibatch bistatic sweep."""
import argparse
import json
from pathlib import Path
import sys
from contextlib import ExitStack
from unittest.mock import patch
import numpy as np


def run(checkout, dst):
    sys.path.insert(0, str(checkout/'tools/GHOST'))
    from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
    from ghost_backend.twod import solver
    from ghost_backend.execution.options import execution_scope,validate_options
    from ghost_backend.linalg import sweep

    # Deliberately scrambled/reversed named sections in two independently connected pieces.
    # All four sections use the same homogeneous isotropic thin-layer material.
    geo = """Title: separate open thin-layer midsurfaces
Segment: right_b 1
properties: 1 7 10 0 0
0.026 0.002 0.018 0
Segment: left_b 1
properties: 1 7 10 0 0
-0.011 0.0001 -0.019 0
Segment: right_a 1
properties: 1 7 10 0 0
0.011 0 0.018 0
Segment: left_a 1
properties: 1 7 10 0 0
-0.027 0 -0.019 0
IBCS_Resistances:
10 thin_dielectric 0.00003 50
Dielectrics:
50 3.1 -0.04 1 0
"""
    snap=build_geometry_snapshot(*parse_geometry(geo))
    incidences = [60., -24., 44., 8., 99.]
    observations = [70., 30., -55., 6., -12., -79., 15.]
    freqs = [2.2, 1.7]
    options=validate_options(dict(factorization='dense',mesh_strategy='global',mesh_grading=False,basis_order=1,
                                  blas_threads=1, assembly_threads=1, angle_batch_size=2))
    trace, active, outer = [], {}, []
    original_layer=solver.solve_thin_layer_fields
    original_fields=solver._solve_fields
    original_sweep=sweep.solve
    original_estimate=solver._estimate_memory_gb

    def layer(mesh,k0,inc,pol,*args,**kwargs):
        row=dict(polarization=pol,k0=float(k0),inputs=len(mesh.nodes),
                 incidence=list(map(float,inc)), obs=list(map(float,kwargs['observation_angles_deg'])),rhs=[])
        trace.append(row)
        active['row']=row
        try:
            outcome=original_layer(mesh,k0,inc,pol,*args,**kwargs)
            row['reported_unknowns']=int(outcome[3]['unknowns'])
            return outcome
        finally:
            active.clear()

    def price(*a,**k):
        if k.get('activate_memory_plan') and (k.get('dense_resources') or {}).get('formulation')=='thin_dielectric_layer':
            if active:
                active['row']['inner_gate']=int(k['system_dofs'])
            else:
                outer.append(int(k['system_dofs']))
        return original_estimate(*a,**k)

    def fields(mesh,m,*a,**k):
        row=active['row']
        row['physical_nodes']=len(mesh.nodes)
        row['shape']=list(m.shape)
        return original_fields(mesh,m,*a,**k)

    def solve(f,b,*a,**k):
        x=original_sweep(f,b,*a,**k)
        if active:
            active['row']['rhs'].append([list(b.shape),list(x.shape)])
        return x

    with ExitStack() as scopes:
        scopes.enter_context(execution_scope(options,limit_blas=True))
        for obj,key,fn in [(solver,'solve_thin_layer_fields',layer),(solver,'_estimate_memory_gb',price),
                           (solver,'_solve_fields',fields),(sweep,'solve',solve)]:
            scopes.enter_context(patch.object(obj,key,fn))
        result=solver.solve_bistatic_rcs_2d_survey(snap,freqs,incidences,observations,'meters',mesh_reference_ghz=max(freqs))

    arrays={}
    for pol,rows in result['co_solved_samples'].items():
        arrays[pol]=np.array([[r[k] for k in ('frequency_ghz','theta_inc_deg','theta_scat_deg',
                                              'rcs_amp_real','rcs_amp_imag','linear_residual')] for r in rows])
        assert len(arrays[pol])==len(freqs)*len(incidences)*len(observations)
    for row in trace:
        dim=row['shape'][0]
        assert row['inner_gate']==row['reported_unknowns']==dim
        assert all(b==x and b[0]==dim for b,x in row['rhs'])
    dst.mkdir(exist_ok=True,parents=True)
    np.savez_compressed(dst/'bistatic.npz',**arrays)
    (dst/'bistatic.json').write_text(json.dumps(dict(outer=outer,calls=trace,channel_rows=len(arrays['VV'])),indent=2)+'\n')
    print('outer',outer,'physical',[(r['polarization'],r['shape']) for r in trace])

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('checkout',type=Path)
    p.add_argument('output',type=Path)
    args=p.parse_args()
    run(args.checkout.resolve(),args.output)
