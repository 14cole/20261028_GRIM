# Physical factors, gate agreement and output comparison

We exercised the release candidate at `6621db2` and the separate thin-layer prototype in fresh Linux Python processes, using one assembly/BLAS thread. The pass-through instrumentation observes the two memory checks in the public solver, the matrix actually used to solve for the requested angles, the shape of every RHS and returned solution batch, and the full complex amplitude returned to the caller. Dense checks also observe the actual LU input. The five P1 fixtures comprise the earlier nine-panel mismatch and Claude's four single/split/reversed/bent layer cases.

| Fixture | Release candidate desktop / HPC TE and TM | Prototype desktop / HPC TE and TM | Dense and Compressed physical dimensions on both |
|---|---:|---:|---:|
| One section, 20 graded panels | 42 / 21 | 42 / 21 | 42 / 21 |
| Four connected sections, 20 graded panels | 48 / 24 | 42 / 21 | 42 / 21 |
| Same, two sections reversed | 48 / 24 | 42 / 21 | 42 / 21 |
| Three bent sections, 20 graded panels | 46 / 23 | 42 / 21 | 42 / 21 |
| Three connected sections, nine ungraded panels | 24 / 12 | 20 / 10 | 20 / 10 |

Twenty public paired monostatic solves produced 40 polarization systems over the two trees. All 588 corresponding complex samples and all incident-angle coordinates matched bit for bit for each backend. The prototype’s inner and outer resource checks agreed on every observed dimension and estimated byte count. This compares runtime field outputs to the existing solver on these particular discretizations.

A new bistatic control used two disconnected open midsurfaces, two individually named sections per midsurface, scrambled/reversed input order, two frequencies on one fixed-reference mesh, five incidence and seven observation angles, and Dense P1. The release candidate priced 64 TE / 32 TM unknowns at the outer gate. The prototype priced 60 / 30, matching both executing operators and the inner admission check. At each frequency and polarization the five RHS columns were solved in batches of 2, 2 and 1 on both trees. All 140 complex samples, frequencies, incidence/observation angles and reported residuals matched exactly.

## Actual memory admission

The 128-panel reservation test runs a real forced-Dense public paired solve on a straight layer with each panel named separately, 1 GHz, 180 angles and both polarizations. The test selects the existing `ram_budget_gib` setting. Only the diagnostic observer wraps the estimator, and it calls the original estimator unchanged.

| Configured per-solve budget | Release candidate | Prototype |
|---|---|---|
| 2 GiB | Completed | Completed |
| 0.411 GiB | Refused before factorization | Completed |
| 0.400 GiB | Refused before factorization | Refused before factorization |

The release candidate priced the initial TE system at 512 unknowns and 0.412796 GiB. The prototype priced the physical system at 258 unknowns and 0.408913 GiB. All 360 angle/polarization complex fields and residuals from the 0.411 GiB trial were bit-identical to the 2 GiB runs. The narrow reservation demonstrates an admission decision on one controlled case. Both arms had ample system RAM, and these numbers are model forecasts rather than measured OS peaks.

## Replay

Use absolute checkout and evidence directories. Run each tree in a fresh process with the normal Linux GHOST runtime.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
for arm in baseline prototype; do
    case "$arm" in
        baseline) source_path="$BASELINE" ;;
        prototype) source_path="$TRIAL" ;;
    esac
    python check.py "$source_path" "new/$arm"
    python bistatic.py "$source_path" "new/$arm"
    python admission.py "$source_path" 2 "new/$arm/ample.json"
    python admission.py "$source_path" .411 "new/$arm/constrained.json"
    python admission.py "$source_path" .4 "new/$arm/under.json"
done
python compare.py new/baseline new/prototype new/comparison.json
```

The two preserved directories contain the measured dimensions, full angles, complex amplitudes and controlled-admission results. `comparison.json` records verified case counts. The admission reproducer is intended for the tested CPU paths, which must have the numeric per-solve headroom specified in the table.
