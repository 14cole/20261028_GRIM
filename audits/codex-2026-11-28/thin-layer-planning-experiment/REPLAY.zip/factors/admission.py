"""Run a complete thin-sheet job with a real configured per-solve memory budget."""
from argparse import ArgumentParser
import json
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np

def run(checkout, budget, out):
    sys.path.insert(0,str(checkout/'tools/GHOST'))
    from ghost_backend.twod import solver
    from ghost_backend.geometry.io import build_geometry_snapshot,parse_geometry
    from ghost_backend.execution.options import validate_options
    points = np.linspace(-.02,.02,129)
    rows=['Title: simply split homogeneous thin layer']
    for i,(x,y) in enumerate(zip(points,points[1:])):
        rows.extend([f'Segment: piece{i} 1','properties: 1 1 10 0 0',f'{x:.17g} 0 {y:.17g} 0'])
    rows+=['IBCs:','10 thin_dielectric 0.00001 2','Dielectrics:','2 3.0 -0.02 1 0']
    s=build_geometry_snapshot(*parse_geometry('\n'.join(rows)+'\n'))
    trace=[]
    estimate=solver._estimate_memory_gb
    def capture(*a,**k):
        measured=estimate(*a,**k)
        if (k.get('dense_resources') or {}).get('formulation')=='thin_dielectric_layer' and k.get('activate_memory_plan'):
            trace.append(dict(nodes=a[0],dofs=k['system_dofs'],estimated_gib=measured))
        return measured
    settings=validate_options(dict(factorization='dense',mesh_strategy='global',basis_order=1,
                 mesh_grading=False,blas_threads=1,assembly_threads=1,ram_budget_gib=budget))
    outcome=dict(budget_gib=budget,execution_prices=trace)
    out.parent.mkdir(parents=True,exist_ok=True)
    with patch.object(solver,'_estimate_memory_gb',capture):
        try:
            r=solver.solve_monostatic_rcs_2d_survey(geometry_snapshot=s,geometry_units='meters',
              frequencies_ghz=[1.0],elevations_deg=list(range(-90,90)),execution_options=settings)
        except MemoryError as exc:
            outcome.update(result='refused',message=str(exc))
        else:
            outcome.update(result='completed',passed=r['metadata']['quality_gate']['passed'])
            fields={key:np.array([[v['theta_inc_deg'],v['rcs_amp_real'],v['rcs_amp_imag'],
                                   v['linear_residual']] for v in vals]) for key,vals in r['co_solved_samples'].items()}
            np.savez_compressed(out.with_suffix('.npz'),**fields)
    print(outcome)
    out.write_text(json.dumps(outcome,indent=2)+'\n')

if __name__=='__main__':
    p=ArgumentParser(description=__doc__)
    p.add_argument('checkout',type=Path);p.add_argument('budget',type=float);p.add_argument('output',type=Path)
    a=p.parse_args();run(a.checkout.resolve(),a.budget,a.output)
