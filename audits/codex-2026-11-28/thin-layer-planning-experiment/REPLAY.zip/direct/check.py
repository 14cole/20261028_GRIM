"""Call the standalone mesh formulation with split/reversed P1 elements."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("checkout", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.checkout.resolve() / 'tools/GHOST'))
from ghost_backend.twod.geometry import LinearMesh, LinearElement, LinearNode
from ghost_backend.twod.formulations import thin_layer
from ghost_backend.execution.options import execution_scope, validate_options

def make_mesh():
    nodes, elems = [], []
    for panel, i in enumerate((2, 0, 4, 1, 3)):
        p0, p1 = (np.array([x * .002, 0.]) for x in ((i, i+1) if panel % 2 == 0 else (i+1, i)))
        first = len(nodes)
        for p in (p0, p1):
            nodes.append(LinearNode(p, tuple(np.rint(p / 1.e-9).astype(int))))
        tangent = (p1-p0) / np.linalg.norm(p1-p0)
        e = LinearElement("section_"+str(panel), 1, 10, 0, 0,
                          (first, first+1), p0, p1, (p0+p1)*.5, tangent,
                          np.array([tangent[1], -tangent[0]]), float(np.linalg.norm(p1-p0)),panel)
        elems.append(e)
    return LinearMesh(nodes, elems)

def run():
    rows, arrays = {}, {}
    for backend in ("dense","compressed"):
        with execution_scope(validate_options(dict(factorization=backend,basis_order=1,
                mesh_strategy='global',mesh_grading=False,assembly_threads=1,blas_threads=1)), limit_blas=True):
            for contrast, eps, mu in [('electric', 2.3-.02j, 1.),('magnetic',1., 1.3-.01j),('transparent',1.,1.)]:
                for pol in ('TE','TM'):
                    mesh = make_mesh()
                    endpoints = [v.node_ids for v in mesh.elements]
                    width, field, resid, evidence = thin_layer.solve_thin_layer_fields(
                        mesh, 20., [-45., 9., 87.], pol, eps, mu, 1.e-5)
                    assert [v.node_ids for v in mesh.elements] == endpoints
                    assert len(mesh.nodes) == 10
                    n=0 if contrast=='transparent' else 6 if (mu if pol=='TM' else eps)==1 else 12
                    assert evidence['unknowns']==n
                    label = f'{backend}_{contrast}_{pol}'
                    rows[label]=dict(raw_nodes=10,unknowns=n,residual=float(resid))
                    arrays[label]=field
                    arrays[label+'_linear']=width
    return rows, arrays

if __name__ == '__main__':
    rows, fields = run()
    args.output.with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
    np.savez_compressed(args.output.with_suffix('.npz'), **fields)
