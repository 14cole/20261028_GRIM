# Standalone mesh formulation

The independent script constructs five P1 elements with ten unjoined endpoints. It deliberately scrambles the input order and reverses two elements. The directly callable thin-layer formulation accepts this raw LinearMesh. It orients and joins it to six physical nodes while preserving all input node IDs.

On each revision, the test ran Dense and Compressed with electric-only, magnetic-only and transparent media, for TE and TM and three requested angles. All 24 amplitude and linear-width arrays and all reported residuals matched the release candidate bit-for-bit. The active physical systems here have six, twelve or zero unknowns. The analytic zero-contrast gate scales with geometry and output size.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python check.py /path/to/release base
python check.py /path/to/prototype trial
```

Raw mesh callers have no outer resource record. They use the previous standalone Compressed storage diagnostic and a fresh inner memory check. These small direct calls establish field and API compatibility. Operator-family consistency across the H-matrix cutoff is tested through normal public 2-D solve entry points in the compression directory. The resource records and live memory checks use estimates.
