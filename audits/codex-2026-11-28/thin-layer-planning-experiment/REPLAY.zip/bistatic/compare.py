"""Assert exact whole-field compatibility and agreement of projected outer/inner gates."""
import argparse
import json
from pathlib import Path
import numpy as np

def compare(base, trial, output):
    b=json.loads((base/'summary.json').read_text())
    t=json.loads((trial/'summary.json').read_text())
    assert set(b)==set(t)
    metrics={"jobs_per_revision":len(t),"sample_rows_per_revision":0,"operators_per_revision":0,
             "baseline_outer_mismatches":0,"trial_outer_mismatches":0,
             "per_tree_renaming_peak_relative":{}, "cross_revision_all_columns_equal":True}
    for k, row in t.items():
        assert row['panel_count_by_frequency']==b[k]['panel_count_by_frequency']
        with np.load(base/(k+'.npz')) as ba,np.load(trial/(k+'.npz')) as ta:
            assert set(ba.files)==set(ta.files)=={'VV','HH'}
            for p in ta.files:
                assert np.array_equal(ba[p],ta[p]),(k,p)
                metrics['sample_rows_per_revision']+=len(ta[p])
        for br,tr in zip(b[k]['channels'],row['channels']):
            metrics['operators_per_revision']+=1
            for key in tr:
                if key!='outer_gate_dofs':
                    assert tr[key]==br[key],(k,key,br,tr)
            if br['outer_gate_dofs']!=br['operator_dofs']:
                metrics['baseline_outer_mismatches']+=1
            if tr['outer_gate_dofs']!=tr['operator_dofs']:
                metrics['trial_outer_mismatches']+=1
    assert metrics['baseline_outer_mismatches']>0 and metrics['trial_outer_mismatches']==0,metrics
    for folder in [base,trial]:
        worst=0
        for mode in ('monostatic','bistatic'):
            for ref in ('None','1.1'):
                with np.load(folder/f'{mode}_{ref}_single.npz') as single:
                    for names in ('split','reversed'):
                        with np.load(folder/f'{mode}_{ref}_{names}.npz') as other:
                            for p in single.files:
                                v=single[p][:,3]+1j*single[p][:,4]
                                w=other[p][:,3]+1j*other[p][:,4]
                                worst=max(worst,float(np.max(np.abs(v-w))/np.max(np.abs(v))))
        metrics['per_tree_renaming_peak_relative'][folder.name]=worst
    assert max(metrics['per_tree_renaming_peak_relative'].values())<1e-12
    output.write_text(json.dumps(metrics,indent=2)+'\n')
    print(json.dumps(metrics))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('baseline',type=Path);p.add_argument('trial',type=Path);p.add_argument('output',type=Path)
    args=p.parse_args();compare(args.baseline,args.trial,args.output)
