# Multi-frequency, fixed-reference and bistatic validation

Both revisions ran 12 fresh public paired Dense jobs each. The fixture is a flat homogeneous thin-dielectric strip with three line primitives. The geometry variants use one named segment, three named segments, and three segments with the middle one reversed. Its material CSV changes with frequency. TM uses a single trace at 0.8 and 1 GHz and two traces at 1.2 GHz. Both monostatic and bistatic calls used three incident directions per frequency. Bistatic used four distinct observation angles in non-sorted order. Each case ran with either frequency-local meshing or an explicit 1.1 GHz mesh reference.

The frequency-local runs built 21, 12 and 15 panels at the three requested frequencies (1.2, 0.8 and 1 GHz). The fixed reference used 21 panels at every frequency while the material, physical operator and scattering fields still varied with frequency. The test records the actual operator dimension at the field solver, the outer and inner admission counts, returned layer evidence and public frequency metadata. It verifies all frequency and angle axes, and saves every complex field sample, linear width and residual.

All seven numeric columns agreed exactly between revisions across 540 polarized rows and 72 actual operators per tree. The baseline overestimated 48 outer counts, all on split or reversed inputs. All 72 prototype outer counts matched the actual operator and inner admission. For example, at 0.8 GHz on a three-piece frequency-local mesh, the baseline outer forecast was 30 TE and 15 TM unknowns against physical dimensions of 26 and 13. At 1.2 GHz the baseline forecast was 48 for both polarizations against 44 for both. Changing segmentation or reversing the middle section changed the complete complex fields by at most 1.03e−15 of the peak of the corresponding channel in either revision. This is numerical equivalence on the tested discretizations. No continuum reference or speed benchmark was part of this check.

## Reproduce

Use the normal solver dependencies. Run main-candidate commit 6621db2 and the separate experimental checkout in different Python processes. The comparison expects the corrected outer dimensions on the experimental checkout.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python check.py /path/to/6621db2 baseline
python check.py /path/to/trial trial
python compare.py baseline trial comparison.json
```
