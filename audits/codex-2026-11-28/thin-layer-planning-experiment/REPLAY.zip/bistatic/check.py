"""Compare public multi-frequency bistatic and monostatic solves on an open homogeneous layer."""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

import numpy as np

FREQ = [1.2, .8, 1.]
INC = [-43., 8., 63.]
OBS = [110., -22., 34., -79.]


def input_text(split, reverse, panels):
    points = [-.06, -.02, .02, .06]
    lines = ["Title: smooth layer"]
    for i, (a,b) in enumerate(zip(points, points[1:])):
        if split or i == 0:
            lines.extend([f"Segment: layer_{i} 1", f"properties: 1 {panels} 10 0 0"])
        if reverse and i == 1:
            a,b = b,a
        lines.append(f"{a:g} 0 {b:g} 0")
    lines += ["IBCS_Resistances:", "10 thin_dielectric 0.00005 2", "Dielectrics:", "2 response.csv"]
    return "\n".join(lines) + "\n"


def run(checkout, output):
    sys.path.insert(0, str(checkout / "tools/GHOST"))
    from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
    from ghost_backend.execution.options import cpu_allocation_scope
    from ghost_backend.twod import solver

    output.mkdir(exist_ok=True, parents=True)
    summary = {}
    with TemporaryDirectory() as tmp:
        base = Path(tmp)
        # At exact table nodes TM uses one trace at .8 GHz and two at 1.2 GHz.
        (base/"response.csv").write_text(
            "frequency_hz,eps_real,eps_imag,mu_real,mu_imag\n"
            "800000000,3,-.01,1,0\n1000000000,3.2,-.012,1,0\n"
            "1200000000,3.4,-.014,1.1,-.002\n")
        for mode in ("bistatic", "monostatic"):
            for ref in (None, 1.1):
                for name, split, reverse in (("single",False,False), ("split",True,False), ("reversed",True,True)):
                    key = f"{mode}_{ref}_{name}"
                    snap = build_geometry_snapshot(*parse_geometry(input_text(split, reverse, 0)))
                    opts = dict(factorization='dense', mesh_strategy='global', mesh_grading=False,
                                basis_order=1, assembly_threads=1, blas_threads=1)
                    records, outer, layer = [], [], []
                    orig_layer = solver.solve_thin_layer_fields
                    orig_est = solver._estimate_memory_gb
                    orig_fields = solver._solve_fields
                    def solve_layer(mesh,k0,inc,pol,*args,**kw):
                        r=dict(pol=pol,freq=round(k0*solver.C0/(2*np.pi*1e9), 8), panels=len(mesh.elements))
                        layer.append(r)
                        try:
                            res=orig_layer(mesh,k0,inc,pol,*args,**kw)
                            r["evidence_dofs"]=res[3]["unknowns"]
                            records.append(r)
                            return res
                        finally:
                            layer.pop()
                    def estimate(*a,**kw):
                        res = kw.get('dense_resources') or {}
                        if res.get("formulation")=='thin_dielectric_layer' and kw.get('activate_memory_plan'):
                            if layer:
                                layer[-1]["inner_gate_dofs"]=kw["system_dofs"]
                            else:
                                outer.append(kw["system_dofs"])
                        return orig_est(*a,**kw)
                    def fields(mesh,matrix,k0,inc,rhs,diag,lab,**kw):
                        assert lab == 'thin dielectric layer'
                        r=layer[-1]
                        r.update(actual_nodes=len(mesh.nodes),operator_dofs=int(matrix.shape[0]))
                        return orig_fields(mesh,matrix,k0,inc,rhs,diag,lab,**kw)
                    with ExitStack() as hooks:
                        hooks.enter_context(patch.object(solver,'_solve_fields',fields))
                        hooks.enter_context(patch.object(solver,'_estimate_memory_gb',estimate))
                        hooks.enter_context(patch.object(solver,'solve_thin_layer_fields',solve_layer))
                        hooks.enter_context(cpu_allocation_scope(1))
                        args=dict(geometry_snapshot=snap, frequencies_ghz=FREQ, geometry_units='meters',
                                  max_panels=2048, material_base_dir=str(base), mesh_reference_ghz=ref, execution_options=opts)
                        if mode=="bistatic":
                            solved = solver.solve_bistatic_rcs_2d(**args, incidence_angles_deg=INC, observation_angles_deg=OBS)
                        else:
                            solved = solver.solve_monostatic_rcs_2d(**args, elevations_deg=INC)
                    assert len(records)==len(outer)==2*len(FREQ), (key,records,outer)
                    assert [(r['freq'],r['pol']) for r in records] == [(f,p) for f in FREQ for p in ('TE','TM')]
                    for r,old_dof in zip(records,outer):
                        r['outer_gate_dofs']=old_dof
                        assert r['operator_dofs']==r['evidence_dofs']==r['inner_gate_dofs']
                        assert r['actual_nodes']==r['panels']+1
                        blocks = 2 if r['pol']=='TE' or r['freq']==1.2 else 1
                        assert r['operator_dofs']==r['actual_nodes']*blocks
                    tables={}
                    for p,seq in solved['co_solved_samples'].items():
                        keys=("frequency_ghz","theta_inc_deg","theta_scat_deg","rcs_amp_real","rcs_amp_imag","rcs_linear","linear_residual")
                        a=np.array([[row[k] for k in keys] for row in seq])
                        assert np.isfinite(a).all()
                        expected = [(f, inc, obs) for f in FREQ for inc in INC
                                    for obs in (OBS if mode=='bistatic' else [inc])]
                        assert np.array_equal(a[:,:3],expected)
                        tables[p]=a
                    meta=solved["metadata"]
                    counts=[(r["frequency_ghz"],r["metadata"]["panel_count"]) for r in meta["frequency_metadata"]]
                    assert counts == [(r["freq"],r["panels"]) for r in records if r["pol"]=="TE"],counts
                    summary[key]=dict(channels=records, panel_count_by_frequency=counts, columns=keys, field_rows_per_channel=len(a))
                    np.savez_compressed(output/(key+".npz"),**tables)
                    print(key,counts, flush=True)
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument('checkout',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();run(a.checkout.resolve(),a.output.resolve())
