"""Compare the default H-matrix boundary in an actual thin-layer solve and in its forecasts."""
import argparse
import json
from contextlib import ExitStack
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('checkout', type=Path)
p.add_argument('results', type=Path)
p.add_argument('--plan-only', action='store_true', help='also show full forecast allowances without solving')
a = p.parse_args()
a.results.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(a.checkout.resolve() / 'tools/GHOST'))
from ghost_backend.compressed import hmatrix
from ghost_backend.execution.options import validate_options, cpu_allocation_scope
from ghost_backend.execution.selection import select_backend
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.twod import solver
from ghost_backend.twod.preparation import preparation_scope

threshold = hmatrix.minimum_unknowns()
assert threshold == 1024, 'Remove threshold overrides. The experiment checks the shipped threshold.'
options = validate_options(dict(factorization='automatic', mesh_strategy='global', basis_order=1,
                                mesh_grading=False, blas_threads=1, assembly_threads=1))
report = {}
for panels in (1022, 1023):
    lines = ['Title: homogeneous electric-contrast thin layer']
    for i, count in enumerate((panels // 2, panels - panels // 2)):
        # Reverse one half. Both shapes require the joined mesh.
        endpoints = '0 0 0.12 0' if i == 0 else '0.24 0 0.12 0'
        lines += [f'Segment: section{i} 1', f'properties: 1 {count} 10 0 0', endpoints]
    lines += ['IBCs:', '10 thin_dielectric 0.00001 2', 'Dielectrics:', '2 3.0 -0.02 1 0']
    geometry = build_geometry_snapshot(*parse_geometry('\n'.join(lines)+'\n'))
    angles = [-83., -22., 9., 47., 114.]
    request = dict(geometry_snapshot=geometry, frequencies_ghz=[0.8], elevations_deg=angles, geometry_units='meters')
    with preparation_scope():
        plan = select_backend(request, options, False)
    rec = report[str(panels)] = dict(threshold=threshold, desktop={}, execution={}, estimates=[])
    for row in plan['meshes']:
        resource = row['resources']
        rec['desktop'][row['polarization']] = dict(dofs=resource['system_dofs'], nodes=resource['nodes'],
                        hmatrix='hmatrix_storage' in resource, model=row['backend_memory_plans']['compressed']['model'])
    if a.plan_only:
        for row in plan['meshes']:
            rec['desktop'][row['polarization']].update(
                operator_bytes=row['backend_memory_plans']['compressed']['operator_bytes'],
                estimated_peak_bytes=row['backend_memory_plans']['compressed']['peak_bytes'])
        (a.results/'plans.json').write_text(json.dumps(report, indent=2)+'\n')
        continue
    estimate = solver._estimate_memory_gb
    layer = solver.solve_thin_layer_fields
    solve_fields = solver._solve_fields
    inside = [None]

    def price(*args, **kwargs):
        result = estimate(*args, **kwargs)
        data = kwargs.get('dense_resources') or {}
        if kwargs.get('activate_memory_plan') and data.get('formulation') == 'thin_dielectric_layer':
            model = data['memory_estimate']
            rec['estimates'].append(dict(inside=inside[0], geometry_nodes=int(args[0]),
                   dofs=kwargs.get('system_dofs'), hmatrix='hmatrix_storage' in data,
                   model=model['model'], operator_allowance=model.get('operator_bytes'),
                   geometry_sample=data.get('compressed_storage', {}).get('method')))
        return result

    def layer_solve(mesh, k0, inc, pol, *args, **kwargs):
        inside[0] = pol
        try:
            return layer(mesh, k0, inc, pol, *args, **kwargs)
        finally:
            inside[0] = None

    def fields(mesh, matrix, k0, inc, rhs, diag, label, **kwargs):
        assert inside[0] and label == 'thin dielectric layer'
        rec['execution'][inside[0]] = dict(nodes=len(mesh.nodes), dofs=matrix.shape[0],
                                             operator=type(matrix).__name__)
        return solve_fields(mesh, matrix, k0, inc, rhs, diag, label, **kwargs)

    with ExitStack() as hooks:
        hooks.enter_context(patch.object(solver, '_estimate_memory_gb', price))
        hooks.enter_context(patch.object(solver, 'solve_thin_layer_fields', layer_solve))
        hooks.enter_context(patch.object(solver, '_solve_fields', fields))
        with cpu_allocation_scope(1):
            result=solver.solve_monostatic_rcs_2d(**request,execution_options=dict(options,factorization='compressed'))
    samples = {'angles': np.array(angles)}
    for label, pol in [('HH','TM'), ('VV','TE')]:
        values = result['co_solved_samples'][label]
        assert list(angles)==[v['theta_inc_deg'] for v in values]
        samples[pol] = np.array([complex(v['rcs_amp_real'],v['rcs_amp_imag']) for v in values])
        assert np.isfinite(samples[pol]).all()
    np.savez_compressed(a.results/f'{panels}.npz', **samples)
    assert rec['execution']['TM']['dofs'] == panels+1 and rec['execution']['TE']['dofs'] == 2*(panels+1)
    assert rec['execution']['TM']['operator'] == ('HMatrixOperator' if panels+1>=threshold else 'StreamedOperator')
    assert rec['execution']['TE']['operator'] == 'StreamedOperator'
    print(panels, rec['desktop'], rec['execution'], flush=True)
    (a.results/'measured.json').write_text(json.dumps(report, indent=2)+'\n')
