# Crossing the default hierarchical operator threshold

We generated a straight homogeneous open dielectric layer in two named sections, reversed the second section, and disabled mesh grading. The electric contrast in this example gives TE two traces and TM one trace per physical node. The experiment uses the shipped 1,024-unknown hierarchical-matrix threshold. Automatic selection produced the desktop forecasts. We separately forced Compressed in fresh public paired single-mesh solves to observe the operator that actually produced every field. Both arms used one BLAS/assembly thread, 0.8 GHz and five angles. The TE operator in this formulation uses streamed tiles at either size.

| Panels | Actual TM size | Baseline TM desktop and outer model | Baseline inner model | Prototype desktop, outer and inner model | Actual TM operator |
|---|---:|---|---|---|---|
| 1,022 | 1,023 | Hierarchical, 1,024 | Tile, 1,023 | Tile, 1,023 | Streamed tiles |
| 1,023 | 1,024 | Hierarchical, 1,025 | Tile, 1,024 | Hierarchical, 1,024 | Hierarchical matrix |

At 1,022 panels, counting an extra node makes the old desktop planner enter a different memory model. Its modeled TM peak is 248,394,144 bytes (236.89 MiB) while the projected forecast is 350,350,208 bytes (334.12 MiB). Those estimates include modeled interpreter and worker costs. An overcount of mesh unknowns can therefore still understate the budget required by the applicable model. This test did not measure actual process peak or prove that either budget is sufficient across other systems.

At 1,023 panels the original inner admission selected the tile model even though the actual operator was hierarchical. The prototype kept its live admission check and priced it with the same physical resource model as the enclosing request. It priced and executed the double-trace TE channel using streamed tiles in all cases. The standalone thin-layer entry point without a surrounding public solve has its own fallback and was outside this experiment.

All 20 complex samples per revision matched exactly between baseline and prototype. The final-source rerun has its own prototype-final directory and comparison-final.json; frozen-source.json pins the five changed Git blobs. Both actual physical operators and dimensions matched across revisions. The regression also checks the execution-side operator-byte allowance agreement across the prototype's outer and inner gates.

## Reproduction

Set BASE and TRIAL to absolute checkout paths. Use the GHOST Python environment with the distribution libraries. Remove any overrides of the hierarchical threshold. The program observes actual operator dimensions in the field solver and records each activating outer/inner memory estimate. It permits normal fallback and asserts the observed operator family for each of these two fixtures. A materially different host that triggers fallback may need additional budget and should record its measured family.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python check.py "$BASE" baseline
python check.py "$TRIAL" prototype-final
python check.py "$BASE" baseline --plan-only
python check.py "$TRIAL" prototype-final --plan-only
python compare.py baseline prototype-final comparison-final.json
```
