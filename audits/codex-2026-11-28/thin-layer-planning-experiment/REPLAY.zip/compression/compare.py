"""Cross-check all computed fields, physical operator family and every tagged pricing call."""
import json
import sys
from pathlib import Path
import numpy as np

roots = [Path(arg) for arg in sys.argv[1:3]]
report = {}
table = [json.loads((root/'measured.json').read_text()) for root in roots]
for panels in (1022, 1023):
    pair = [d[str(panels)] for d in table]
    assert pair[0]['execution'] == pair[1]['execution']
    for tree in pair:
        assert len(tree['estimates']) == 4
    with np.load(roots[0]/f'{panels}.npz') as base, np.load(roots[1]/f'{panels}.npz') as proto:
        assert np.array_equal(base['angles'],proto['angles'])
        diffs = {p: float(np.max(abs(base[p]-proto[p]))) for p in ('TE','TM')}
        assert all(v == 0 for v in diffs.values()), diffs
    for channel, outer_idx in (('TE', 0), ('TM', 2)):
        row = pair[1]['desktop'][channel]
        outer, inner = pair[1]['estimates'][outer_idx:outer_idx+2]
        physical = pair[1]['execution'][channel]
        assert inner['inside']==channel and outer['inside'] is None
        assert outer['dofs']==inner['dofs']==row['dofs']==physical['dofs']
        assert inner['geometry_nodes']==outer['geometry_nodes']==row['nodes']==physical['nodes']
        assert inner['hmatrix']==outer['hmatrix']==row['hmatrix']==(physical['operator']=='HMatrixOperator')
        assert inner['model']==outer['model']==row['model']
        assert inner['operator_allowance']==outer['operator_allowance']
    btm = pair[0]['desktop']['TM']
    assert btm['nodes']==panels+2 and btm['hmatrix']
    assert not pair[0]['estimates'][3]['hmatrix']
    report[str(panels)] = dict(max_abs_field_deltas=diffs,
                               baseline_TM_desktop=btm['model'],
                               baseline_TM_inner=pair[0]['estimates'][3]['model'],
                               prototype_TM_both=pair[1]['estimates'][3]['model'],
                               actual_TM=pair[1]['execution']['TM'])
Path(sys.argv[3]).write_text(json.dumps(report, indent=2)+'\n')
print(report)
