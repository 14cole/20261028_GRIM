"""Public planning, field-output and input-qualification controls on thin layer geometries."""
import argparse
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

import numpy as np

def snapshot_text(contours, flags=(), dielectric="2 2.7 -.02 1 0", definitions=None, reverse=False, n=2):
    lines = ["Title: layer edge cases"]
    j = 0
    for points in contours:
        for a, b in zip(points, points[1:]):
            af, bf = (b, a) if reverse and j % 2 else (a, b)
            lines.extend([f"Segment: part{j} 1", f"properties: 1 {n} {flags[j % len(flags)] if flags else 10} 0 0",
                          " ".join(f"{v:.16g}" for v in (*af,*bf))])
            j += 1
    return "\n".join(lines + ["IBCS_Resistances:",*(definitions or ["10 thin_dielectric 0.00001 2"]), "Dielectrics:",dielectric,""])

def cases():
    curve=[(0.,0.),(.014,0.),(.028,.0007),(.042,.002)]
    offset=[(.002,.06),(.017,.061),(.033,.062),(.047,.063)]
    ring=[(.017*np.cos(i*2*np.pi/24), .017*np.sin(i*2*np.pi/24)) for i in range(24)]
    # Close with the identical tuple and keep geometric inputs in meters.
    ring.append(ring[0])
    def spec(name, text, **kw):
        return dict(name=name, text=text, **kw)
    g=snapshot_text([curve])
    return [
        spec("split",g),
        spec("reversed", snapshot_text([curve],reverse=True)),
        spec("disconnected",snapshot_text([curve,offset],reverse=True)),
        spec("closed",snapshot_text([ring],reverse=True,n=1)),
        spec("magnetic_only",snapshot_text([curve],dielectric='2 1 0 1.6 -.01')),
        spec("both_contrasts",snapshot_text([curve],dielectric='2 2.7 -.02 1.6 -.01')),
        spec("zero",snapshot_text([curve],dielectric='2 1 0 1 0')),
        spec("equal_definitions_different_flags",snapshot_text([curve],flags=(10,11),definitions=['10 thin_dielectric 0.00001 2','11 thin_dielectric 0.00001 2'])),
        spec("two_frequencies",g,frequencies=[1.3,1.1],mesh_reference_ghz=1.4),
        spec("changing_trace_count",snapshot_text([curve],dielectric='2 spectral.csv'),frequencies=[1.3,1.1]),
        spec("certified_fail",g,certified=True),
        spec("certified",snapshot_text([curve],n=6),certified=True),
        spec("p2",g,degree=2),
        spec("p3",g,degree=3),
        spec("branch",snapshot_text([curve,[curve[1],(.014,.012)]])),
        spec("mixed_thickness",snapshot_text([curve],flags=(10,11),definitions=['10 thin_dielectric 0.00001 2','11 thin_dielectric 0.000015 2'])),
        spec("mixed_dielectric",snapshot_text([curve],dielectric='2 2.7 -.02 1 0\n3 2.8 -.01 1 0',flags=(10,11),definitions=['10 thin_dielectric 0.00001 2','11 thin_dielectric 0.00001 3'])),
        spec("mixed_layer_impedance",snapshot_text([curve],flags=(10,11),definitions=['10 thin_dielectric 0.00001 2','11 constant 70 0 0 0'])),
        spec("sharp_turn",snapshot_text([[(0.,0.),(.012,0.),(.012,.012)]])),
        spec("curvature_limit",snapshot_text([[(0.,0.),(.0005,0.),(.001,.0001)]], definitions=['10 thin_dielectric 0.00025 2'])),
        spec("electrical_limit",snapshot_text([curve],definitions=['10 thin_dielectric 0.005 2'])),

        spec("ordinary_impedance",snapshot_text([curve],definitions=['10 constant 70 0 0 0'])),
    ]

def run(repo,out):
    sys.path.insert(0,str(repo/'tools/GHOST'))
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.hpc.scheduler import predict_2d_resources_many
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import preparation_scope
    from ghost_backend.execution.options import execution_scope, validate_options
    from ghost_backend.execution.selection import select_backend

    def observed(fn):
        try:
            return fn()
        except (RuntimeError,ValueError,MemoryError) as e:
            return dict(error=str(e), kind=type(e).__name__)
    data={}; arrays={}
    angles=[-81.,-27.,12.,39.,89.]
    out.mkdir(exist_ok=True,parents=True)
    with TemporaryDirectory() as d:
        path=Path(d)/"input.geo"
        (path.parent/'spectral.csv').write_text("frequency_hz,eps_real,eps_imag,mu_real,mu_imag\n1.1e9,2.7,-0.02,1,0\n1.3e9,1,0,1.6,-0.01\n")
        for case in cases():
            name = case['name']
            freqs=case.get('frequencies',[1.1])
            cert=case.get('certified',False)
            opt=validate_options(dict(blas_threads=1,assembly_threads=1,basis_order=case.get('degree',1),
                factorization='automatic',mesh_strategy='adaptive' if cert else 'global',mesh_grading=False))
            path.write_text(case['text'])
            args=dict(geometry_snapshot=build_geometry_snapshot(*parse_geometry(case['text'])),
                      frequencies_ghz=freqs,elevations_deg=angles,geometry_units='meters',material_base_dir=str(path.parent))
            if 'mesh_reference_ghz' in case:
                args['mesh_reference_ghz']=case['mesh_reference_ghz']
            def desktop():
                with preparation_scope():
                    s=select_backend(args,opt,cert)
                return [dict(phase=row['phase'],pol=row['polarization'],n=row['unknowns'],panels=row['panels'],freq=row['frequency_ghz']) for row in s['meshes']]
            def hpc(pol):
                with execution_scope(opt):
                    h=predict_2d_resources_many(str(path),freqs,pol,'meters',1000,n_angles=len(angles),
                                                 fine_factor=(1.5 if cert else 1.))
                return {f'{f}_{p}':[r['base_system_dofs'],r['fine_system_dofs'],r['base_polynomial_degree'],r['fine_polynomial_degree']]
                        for (f,p),r in h.items()}
            def actual(backend):
                public=solver.solve_monostatic_rcs_2d_certified if cert else solver.solve_monostatic_rcs_2d_survey
                r=public(**args,execution_options=dict(opt,factorization=backend))
                result={}
                for label,pol in [('VV','TE'),('HH','TM')]:
                    rows=r['co_solved_samples'][label]
                    arrays[name+'_'+backend+'_'+pol]=np.array([[s['frequency_ghz'],s['theta_inc_deg'],s['theta_scat_deg'],
                                        s['rcs_amp_real'],s['rcs_amp_imag'],s['linear_residual']] for s in rows],dtype=float)
                    result[pol]=[v['unknowns'] for v in r['metadata'].get('thin_layer',{}).get(label,[])]
                result['quality']=r['metadata']['quality_gate']['passed']
                return result
            r=data[name]=dict(desktop=observed(desktop),
                              hpc_vv_hh=observed(lambda:hpc(['VV','HH'])),
                              hpc_hh_vv=observed(lambda:hpc(['HH','VV'])),
                              dense=observed(lambda:actual('dense')),compressed=observed(lambda:actual('compressed')))
            print(name, r['desktop'],r['dense'], flush=True)
    (out/'summary.json').write_text(json.dumps(data,indent=2)+'\n')
    np.savez_compressed(out/'samples.npz',**arrays)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('repo',type=Path);p.add_argument('out',type=Path);a=p.parse_args()
    run(a.repo.resolve(),a.out)
