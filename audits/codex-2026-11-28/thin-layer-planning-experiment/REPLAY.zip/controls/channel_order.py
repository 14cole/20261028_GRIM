"""Check the per-channel coefficient order through the real HPC mesh-sharing loop."""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from controls import snapshot_text

def run(repo):
    sys.path.insert(0,str(repo/'tools/GHOST'))
    from ghost_backend.twod import solver
    from ghost_backend.hpc.scheduler import predict_2d_resources_many
    from ghost_backend.execution.options import execution_scope, validate_options
    points=[(0,0),(.01,0),(.02,.0001),(.03,.00045),(.04,.001)]
    # One panel per named input segment. Supply the last section first.
    text=snapshot_text([[points[i],points[j]] for i,j in [(4,3),(0,1),(3,2),(2,1)]],n=1)
    opts=validate_options(dict(basis_order=1,mesh_strategy='global',mesh_grading=False,
                               factorization='dense',assembly_threads=1,blas_threads=1))
    orig_coeff=solver._build_coupled_panel_info
    orig_prepare=solver._prepare_formulation_mesh
    output={}
    with TemporaryDirectory() as tmp:
        path=Path(tmp)/'permuted.geo'
        path.write_text(text)
        for request in (['VV','HH'],['HH','VV']):
            captured=[]
            prepared=[]
            def coeff(panels,materials,freq,pol,k):
                values=orig_coeff(panels,materials,freq,pol,k)
                captured.append((pol,list(panels),values))
                return values
            def prepare(mesh, interface_infos, materials, freq):
                matches=[(p,panels) for p,panels,infos in captured if len(infos)==len(interface_infos) and all(a is b for a,b in zip(infos,interface_infos))]
                assert len(matches)==1,matches
                pol,panels=matches[0]
                result,ordered,layer=orig_prepare(mesh,interface_infos,materials,freq)
                # Match original panel and physical element by their unoriented endpoints.
                def edges(p):
                    return tuple(sorted((tuple(p.p0),tuple(p.p1))))
                original={edges(p):i for i,p in enumerate(panels)}
                positions=[original[edges(e)] for e in result.elements]
                assert sorted(positions)==list(range(len(original)))
                assert positions!=sorted(positions)
                assert all(v is interface_infos[i] for v,i in zip(ordered,positions))
                prepared.append(dict(pol=pol,raw_order=positions,mesh_id=id(result),
                                     passed_prepared=mesh is result))
                return result,ordered,layer
            with ExitStack() as s:
                s.enter_context(execution_scope(opts))
                s.enter_context(patch.object(solver,'_prepare_formulation_mesh',prepare))
                s.enter_context(patch.object(solver,'_build_coupled_panel_info',coeff))
                estimates=predict_2d_resources_many(str(path),[1.1],request,'meters',1000,n_angles=5)
            assert len(prepared)==2 and prepared[0]['mesh_id']==prepared[1]['mesh_id'],prepared
            assert [row['passed_prepared'] for row in prepared]==[False,True],prepared
            assert prepared[0]['raw_order']==prepared[1]['raw_order']
            for row in prepared:
                del row['mesh_id']
            output['+'.join(request)]=dict(preparation=prepared,dimensions={p:r['base_system_dofs'] for (_,p), r in estimates.items()})
    return output

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('repo',type=Path);p.add_argument('out',type=Path)
    args=p.parse_args();args.out.write_text(json.dumps(run(args.repo.resolve()),indent=2)+'\n')
