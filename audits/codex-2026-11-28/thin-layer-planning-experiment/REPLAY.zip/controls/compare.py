"""Compare reports and their six-column numerical samples; independently check the topology formula."""
from pathlib import Path
import argparse
import json
import numpy as np

CLOSED = {'closed'}
COMPONENTS = {'disconnected':2}
TRACES = {'magnetic_only':(1,2),'zero':(0,0),'both_contrasts':(2,2)}
def assert_plans(case,data):
    for row in data['desktop']:
        panels=row['panels']
        nodes=panels if case in CLOSED else panels+COMPONENTS.get(case,1)
        trace_counts=(1,2) if case=='changing_trace_count' and row['freq']==1.3 else TRACES.get(case,(2,1))
        factor=trace_counts[int(row['pol']=='TM')]
        assert row['n']==nodes*factor,(case,row,nodes*factor)
    frequencies=list(dict.fromkeys(row['freq'] for row in data['desktop']))
    phases={(row['freq'],row['phase'],row['pol']):row['n'] for row in data['desktop']}
    for order in ['hpc_vv_hh','hpc_hh_vv']:
        for freq_pol,(base,fine,base_deg,fine_deg) in data[order].items():
            pol='TE' if freq_pol.endswith('VV') else 'TM'
            assert base_deg==fine_deg==1
            f=float(freq_pol.split('_')[0]); assert base==phases[f,'base',pol] and fine==phases.get((f,'fine',pol),base),(case,order,base,fine)
    for backend in ['dense','compressed']:
        fields=data[backend]
        if 'error' in fields:
            assert case=='certified_fail' and 'convergence failed' in fields['error']
        else:
            assert fields['quality'] is True
            for pol in ['TE','TM']:
                assert fields[pol]==[phases.get((f,'fine',pol),phases[f,'base',pol]) for f in frequencies],(case,backend,pol)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('output',type=Path)
    args=p.parse_args()
    a,b=[json.loads((s/'summary.json').read_text()) for s in [args.baseline,args.candidate]]
    assert list(a)==list(b)
    successful=[n for n,r in a.items() if 'error' not in r['dense']]
    expected_rejections={'curvature_limit':'thickness','electrical_limit':'electrical thickness','sharp_turn':'sharp/coarsely faceted turn','mixed_thickness':'same thickness','mixed_dielectric':'same thickness',
         'mixed_layer_impedance':'all-layer geometry','p2':'qualified linear basis','p3':'qualified linear basis','branch':'branching'}
    assert len(successful)==12
    for n,r in b.items():
        old=a[n]
        if n in expected_rejections:
            message=expected_rejections[n]
            for domain in ('desktop','hpc_vv_hh','hpc_hh_vv','dense','compressed'):
                assert r[domain]['kind']=='ValueError' and message in r[domain]['error'],(n,domain,r[domain])
            assert message in old['dense']['error']
        elif n=='ordinary_impedance':
            assert old==r
        else:
            assert_plans(n,r)
            for backend in ('dense','compressed'):
                assert r[backend]==old[backend],(n,r[backend],old[backend])
    with np.load(args.baseline/'samples.npz',allow_pickle=False) as old, np.load(args.candidate/'samples.npz',allow_pickle=False) as new:
        assert set(old)==set(new)
        for key in new:
            np.testing.assert_array_equal(old[key],new[key])
            assert old[key].dtype==new[key].dtype and old[key].tobytes()==new[key].tobytes(),key
        for backend in ('dense','compressed'):
            for pol in ('TE','TM'):
                assert not np.any(new['zero_'+backend+'_'+pol][:,3:5])
                for geom in ('reversed','equal_definitions_different_flags'):
                    np.testing.assert_array_equal(new[f'{geom}_{backend}_{pol}'],new[f'split_{backend}_{pol}'])
        samples=sum(len(new[k]) for k in new); channels=len(new.files)
    note=dict(cases=len(b), successful_public_paired_solve_configurations_per_tree=len(successful)*2,
         rejected_public_paired_solve_configurations_per_tree=(len(b)-len(successful))*2,
         field_arrays_compared=channels,polarization_samples_compared=samples,all_six_numeric_columns_bit_equal=True,
         closed_projected=[r['n'] for r in b['closed']['desktop']],disconnected_projected=[r['n'] for r in b['disconnected']['desktop']],
         certified_projected_by_phase=b['certified']['desktop'],sharp_turn_forecast_rejected='error' in b['sharp_turn']['desktop'],
         list_of_six_columns=['frequency_ghz','theta_inc_deg','theta_scat_deg','rcs_amp_real','rcs_amp_imag','linear_residual'])
    args.output.write_text(json.dumps(note,indent=2)+'\n')
if __name__=='__main__':main()
