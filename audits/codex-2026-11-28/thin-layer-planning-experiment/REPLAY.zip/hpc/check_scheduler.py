"""Check per-channel source alignment and shared physical meshes in both scheduler loops."""
import argparse
from contextlib import ExitStack, nullcontext
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch


def run(root):
    sys.path.insert(0, str(root / "tools/GHOST"))
    from ghost_backend.execution.options import validate_options, execution_scope
    from ghost_backend.execution.selection import select_backend
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.twod.preparation import preparation_scope
    from ghost_backend.hpc import scheduler
    from ghost_backend.twod import solver
    data = {}
    frequencies = [1.0, 2.0]
    with TemporaryDirectory() as folder:
        folder = Path(folder)
        text = ["Title: separated thin midsurfaces"]
        # Two disjoint chains have three and two sections, authored in mixed order.
        for index, (ax, bx, y) in enumerate([(2, 1, 0), (5, 6, 2), (0, 1, 0), (7, 6, 2), (2, 3, 0)]):
            text.extend([f"Segment: piece_{index} 1", f"properties: 1 3 {10 + index % 2} 0 0",
                         f"{.003*ax:g} {.003*y:g} {.003*bx:g} {.003*y:g}"])
        text.extend(["IBCS_Resistances:", "10 thin_dielectric 0.00001 50", "11 thin_dielectric 0.00001 50",
                     "Dielectrics:", "50 values.csv"])
        path = folder / "input.geo"
        path.write_text("\n".join(text) + "\n")
        (folder / "values.csv").write_text("frequency_hz,eps_real,eps_imag,mu_real,mu_imag\n"
                                           "1000000000,3,-0.01,1,0\n2000000000,1,0,2,-0.01\n")
        original_resource = solver._dense_formulation_resources
        original_infos = solver._build_coupled_panel_info
        def get_infos(panels, materials, freq, pol, k):
            infos = original_infos(panels, materials, freq, pol, k)
            raw_infos[pol] = dict(freq=freq, records=infos)
            return infos
        def price(mesh, infos, pol, layer, **kw):
            raw = raw_infos[pol]
            expected = [raw["records"][element.panel_index] for element in mesh.elements]
            assert len(expected) == len(infos) and all(a is b for a,b in zip(infos,expected))
            # Keep the objects through the test so identities cannot be recycled.
            if not any(x is mesh for x in captured_meshes):
                captured_meshes.append(mesh)
            rec = original_resource(mesh, infos, pol, layer, **kw)
            nnodes = len(mesh.elements) + 2
            multiplier = 2 if (raw["freq"] == 1) == (pol == "TE") else 1
            instruments.append(dict(channel=pol, freq=raw["freq"], nodes=rec["nodes"],
                panels=len(mesh.elements), unknowns=rec["system_dofs"], geometric_nodes=nnodes,
                physical_unknowns=multiplier*nnodes, source_order_checked=True,
                mesh_serial=next(i for i,m in enumerate(captured_meshes) if m is mesh)))
            return rec

        for mode in ("default", "scoped"):
            for labels in (("VV","HH"),("HH","VV"),("HH",),("VV",)):
                instruments = []
                raw_infos = {}
                captured_meshes = []
                opt = validate_options(dict(factorization="automatic", mesh_strategy="adaptive", basis_order=1,
                                            mesh_grading=False, blas_threads=1, assembly_threads=1))
                with ExitStack() as stack:
                    stack.enter_context(execution_scope(opt) if mode == "scoped" else nullcontext())
                    stack.enter_context(patch.object(solver, "_dense_formulation_resources", price))
                    stack.enter_context(patch.object(solver, "_build_coupled_panel_info", get_infos))
                    info = scheduler.predict_2d_resources_many(str(path), frequencies, labels, 'meters',
                                         4000, fine_factor=1.5, n_angles=180)
                assert len(instruments) == len(labels)*2*2, (mode, len(instruments))
                assert len(captured_meshes) == 4, 'one physical mesh per frequency and phase required'
                records = {f"{f:g}/{l}": [r['base_polynomial_degree'], r['fine_polynomial_degree'],
                           r['base_system_dofs'], r['fine_system_dofs']] for (f,l),r in info.items()}
                assert all(v[:2] == [1,1] for v in records.values()), records
                data[mode+"_"+"_".join(labels)] = dict(resources=instruments, records=records)
        snap = build_geometry_snapshot(*parse_geometry(path.read_text()))
        for mode, ref in (("independent", None), ("fixed_reference", 2.0)):
            for pol in (None, "TM"):
                raw_infos = {}
                instruments = []
                captured_meshes = []
                request = dict(geometry_snapshot=snap, material_base_dir=str(folder), geometry_units="meters",
                               frequencies_ghz=frequencies, elevations_deg=[-70, 0, 50],
                               mesh_reference_ghz=ref, solver_method="auto")
                if pol:
                    request["polarization"] = pol
                with preparation_scope(), patch.object(solver, "_dense_formulation_resources", price), patch.object(
                        solver, "_build_coupled_panel_info", get_infos):
                    result = select_backend(request, opt, True)
                pair = pol is None
                projected = hasattr(solver, "_prepare_formulation_mesh")
                assert len(captured_meshes) == 4 * (2 if pair and not projected else 1)
                assert all(r["polynomial_degree"] == 1 for r in result["meshes"])
                data["desktop_"+mode+"_"+str(pol)] = dict(resources=instruments, records=[
                    {k:r[k] for k in ("polarization","phase","frequency_ghz","panels","unknowns")}
                    for r in result["meshes"]])
    return data

if __name__ == '__main__':
    pa = argparse.ArgumentParser(description=__doc__)
    pa.add_argument("root", type=Path)
    pa.add_argument("output", type=Path)
    pa.add_argument("--check-projected", action="store_true")
    arg=pa.parse_args()
    data=run(arg.root.resolve())
    if arg.check_projected:
        for case in data.values():
            assert all(v['nodes']==v['geometric_nodes'] and v['unknowns']==v['physical_unknowns']
                       for v in case['resources'])
    arg.output.write_text(json.dumps(data,indent=2)+"\n")
    print("12 configurations; all source-index and topology-sharing checks passed")
