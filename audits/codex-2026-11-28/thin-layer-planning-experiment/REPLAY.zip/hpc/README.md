# Independent planning controls

This synthetic fixture contains five named sections in mixed input and orientation order, with three sections in one connected component and two in another. Two distinct input IBC flags resolve to the identical thin layer. A tabulated medium has electric contrast only at 1 GHz and magnetic contrast only at 2 GHz. That reverses the trace multipliers across frequencies. All runs use two independent channels, a 1.5 certification refinement for HPC and automatic P1 mesh certification where supported.

The test recorded 72 prices across twelve configurations of the public desktop and HPC planners. It drove the default unscoped HPC path with grading and the configured adaptive path without grading. It checked both HPC paired orders and single polarizations, and desktop paired and single-TM requests with per-frequency and fixed mesh references. Original panel references must survive physical element reordering by object identity. Paired channels must receive one shared physical mesh for each phase and frequency, while retaining independent material records. Each post-projection unknown count must equal the geometric node count times the independently predicted multiplier. For two nonbranching open components the physical mesh has two more nodes than panels.

At 1 GHz on the configured HPC case the base and fine forecast changed from 40/20 and 60/30 to **34/17 and 54/27 TE/TM**. At 2 GHz the corresponding counts changed from 20/40 and 30/60 to **17/34 and 27/54**. Every tested phase and direction matched the physical geometry. Separate disconnected components and differing frequency materials remained distinguishable. The default HPC layout has more panels due to grading. Each HPC path still uses one physical mesh per phase across the two channel prices.

For the ordinary-material control, the previously reviewed bent alternating-impedance sheet and coated PEC cylinder run at P1 to P3 (4 GHz, 72 monostatic angles). Claude's drivers are copied unchanged from commit ced2243 in ordinary/. ordinary/replay holds the fresh prototype planning records and complete complex fields. ordinary/comparison.json compares all six planning and factorized dimension records and all 864 complex samples with the locally replayed baseline at commit 6621db2 from the release-candidate review.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python check_scheduler.py /absolute/path/to/6621db2 base-replay.json
python check_scheduler.py /absolute/path/to/prototype trial-replay.json --check-projected
cd ordinary
GRIM_ROOT=/absolute/path/to/prototype python sheet_rc.py prototype replay
```

The evidence directories can be reproduced using the project's Python environment with NumPy and SciPy. None of these planning checks submits a cluster job.
