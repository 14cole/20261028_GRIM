"""Independent planner and matrix-shape regression. Usage is in README.md."""
import argparse
from contextlib import nullcontext
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

import numpy as np


def make_sheet(count, panels=1, branch=False, length=0.003):
    rows = ['Title: straight impedance segments']
    for i in range(count):
        # Reverse every second input. TE must orient the chain before welding it.
        a, b = (i + 1, i) if i % 2 else (i, i + 1)
        rows.extend([f'Segment: strip_{i} 1', f'properties: 1 {panels} 10 0 0',
                     f'{length*a:.9f} 0 {length*b:.9f} 0'])
    if branch:
        rows.extend(['Segment: junction 1', f'properties: 1 {panels} 10 0 0',
                     '0.003 0 0.003 0.003'])
    return '\n'.join(rows + ['IBCS_Resistances:', '10 constant 90 -20 0 0', 'Dielectrics:', ''])


def check_source(root, output):
    sys.path.insert(0, str(root / 'tools/GHOST'))
    from ghost_backend.execution.options import execution_scope, validate_options
    from ghost_backend.execution.selection import select_backend
    from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
    from ghost_backend.hpc import scheduler
    from ghost_backend.twod import solver
    from ghost_backend.twod.preparation import preparation_scope

    def settings(degree):
        return validate_options(dict(basis_order=degree, mesh_grading=False,
                                     mesh_strategy='global', factorization='automatic',
                                     blas_threads=1, assembly_threads=1))

    def arguments(path):
        return dict(geometry_snapshot=build_geometry_snapshot(*parse_geometry(path.read_text())),
                    material_base_dir=str(path.parent), geometry_units='meters', frequencies_ghz=[1.0],
                    elevations_deg=list(range(-90, 90)), solver_method='auto')

    def desktop(args, degree, pol=None):
        if pol:
            args = dict(args, polarization=pol)
        with preparation_scope():
            forecast = select_backend(args, settings(degree), False)
        return {'dofs': {r['polarization']: r['unknowns'] for r in forecast['meshes']},
                'panels': {r['polarization']: r['panels'] for r in forecast['meshes']},
                'selected': forecast['selected'], 'admitted': forecast['ranking']['admitted']}

    def hpc(path, order, degree):
        scope = execution_scope(settings(degree)) if degree is not None else nullcontext()
        with scope, patch.object(solver, '_build_linear_mesh_interface_aware',
                                 wraps=solver._build_linear_mesh_interface_aware) as builder:
            result = scheduler.predict_2d_resources_many(str(path), [1.0], list(order), 'meters',
                                                        100000, n_angles=180)
        return {'dofs': {label: r['system_dofs'] for (_, label), r in result.items()},
                'panels': {label: r['panels'] for (_, label), r in result.items()},
                'linear_mesh_builds': builder.call_count}

    def survey(args, degree):
        matrices = []
        underlying = solver._solve_fields
        def observe(mesh, matrix, k0, angles, rhs_builder, diagnostics, label, **kwargs):
            matrices.append({'label': str(label), 'shape': list(matrix.shape),
                             'mesh_nodes': len(mesh.nodes), 'panels': len(mesh.elements)})
            return underlying(mesh, matrix, k0, angles, rhs_builder, diagnostics, label, **kwargs)
        with patch.object(solver, '_solve_fields', observe):
            result = solver.solve_monostatic_rcs_2d_survey(**args, execution_options=settings(degree))
        assert result['metadata']['quality_gate']['passed']
        arrays = {}
        columns = ['frequency_ghz', 'theta_inc_deg', 'theta_scat_deg', 'rcs_amp_real',
                   'rcs_amp_imag', 'rcs_linear', 'rcs_db', 'rcs_amp_phase_deg', 'linear_residual']
        for channel, rows in result['co_solved_samples'].items():
            arrays[channel] = np.array([[row[k] for k in columns] for row in rows])
            assert arrays[channel].shape == (180, len(columns))
            assert np.isfinite(arrays[channel]).all()
        return {'matrices': matrices, 'columns': columns, 'gate': True}, arrays

    def attempt(action):
        try:
            return action()
        except ValueError as exc:
            return {'error': str(exc), 'type': type(exc).__name__}

    material_examples = root / 'tools/GHOST/ghost_backend/geometry/geometries/material_examples'
    result = {}
    records = {}
    with tempfile.TemporaryDirectory() as folder:
        temp = Path(folder)
        sheet = temp/'split.geo'
        sheet.write_text(make_sheet(16))
        args = arguments(sheet)
        for degree in [1, 2, 3]:
            key = f'P{degree}'
            d = result[key] = {}
            d['desktop'] = {str(pol or 'pair'): desktop(args, degree, pol) for pol in [None, 'HH', 'VV']}
            permutations = [('TE','TM'), ('TM','TE'), ('HH','VV'), ('VV',), ('HH',)]
            d['hpc'] = {'+'.join(pols): hpc(sheet, pols, degree) for pols in permutations}
            d['solve'], arrays = survey(args, degree)
            for pol, array in arrays.items():
                records[f'{key}_{pol}'] = array
        result['hpc_without_execution_scope'] = {'+'.join(pols): hpc(sheet, pols, None)
                                                  for pols in [('TE','TM'), ('HH','VV')]}
        adaptive = temp/'adaptive.geo'
        adaptive.write_text(make_sheet(8, panels=0, length=1.2))
        result['certified_hp_pair'] = {}
        for order in [('TE','TM'), ('HH','VV')]:
            with execution_scope(dict(settings(1), mesh_strategy='adaptive')), patch.object(
                    solver, '_build_linear_mesh_interface_aware',
                    wraps=solver._build_linear_mesh_interface_aware) as builder:
                hp_pair = scheduler.predict_2d_resources_many(str(adaptive), [1.0], order, 'meters',
                                                             100000, fine_factor=2., n_angles=180)
            keys = ['panels', 'fine_panels', 'base_polynomial_degree', 'fine_polynomial_degree',
                    'base_system_dofs', 'fine_system_dofs']
            result['certified_hp_pair']['+'.join(order)] = {
                'rows': {p:{k:r[k] for k in keys} for (_,p),r in hp_pair.items()},
                'linear_mesh_builds': builder.call_count,
            }
        result['control'] = {}
        for name in ('type2_pec', 'type2_ibc', 'type3_bulk_dielectric'):
            path = material_examples / (name+'.geo')
            result['control'][name] = {
                'desktop': desktop(arguments(path), 1),
                'hpc_p2_TE_first': hpc(path, ['TE','TM'], 2),
                'hpc_p2_TM_first': hpc(path, ['TM','TE'], 2),
                'hpc_without_scope': hpc(path, ['VV','HH'], None),
            }
        fork = temp/'fork.geo'
        fork.write_text(make_sheet(2, 2, branch=True))
        a = arguments(fork)
        result['fork'] = {
            'desktop': attempt(lambda: desktop(a, 1)),
            'desktop_TM': desktop(a, 1, 'TM'),
            'hpc_TE_first': attempt(lambda: hpc(fork, ['VV','HH'], 2)),
            'hpc_TE_last': attempt(lambda: hpc(fork, ['HH','VV'], None)),
            'hpc_TM_only': hpc(fork, ['HH'], 1),
            'solve': attempt(lambda: survey(a, 1)[0]),
        }
        threshold = temp/'threshold.geo'
        threshold.write_text(make_sheet(8, 1249))
        a = arguments(threshold)
        result['threshold'] = {p or 'pair': desktop(a, 1, p) for p in ['TE', None]}
    output.mkdir(parents=True, exist_ok=True)
    (output/'measurements.json').write_text(json.dumps(result, indent=2)+'\n')
    np.savez_compressed(output/'fields.npz', **records)


def compare(baseline, candidate):
    left = json.loads((baseline/'measurements.json').read_text())
    right = json.loads((candidate/'measurements.json').read_text())
    assert left == right, [key for key in right if left[key] != right[key]]
    with np.load(baseline/'fields.npz') as a, np.load(candidate/'fields.npz') as b:
        assert a.files == b.files and all(np.array_equal(a[k], b[k]) for k in a.files)
        print(sum(len(a[k]) for k in a.files), 'rows match; all non-layer planner records match')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    subs = parser.add_subparsers(dest='command', required=True)
    measure = subs.add_parser('run')
    measure.add_argument('checkout', type=Path)
    measure.add_argument('output', type=Path)
    compare_parser = subs.add_parser('compare')
    compare_parser.add_argument('baseline', type=Path)
    compare_parser.add_argument('candidate', type=Path)
    args = parser.parse_args()
    if args.command == 'run':
        check_source(args.checkout.resolve(), args.output)
    else:
        compare(args.baseline, args.candidate)
