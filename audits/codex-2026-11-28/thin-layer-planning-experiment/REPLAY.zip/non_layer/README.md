# Ordinary geometry regression

This is the original impedance-sheet planning harness with the separately tested thin dielectric control removed. The comparison now requires the two revisions to match. Run in the solver's Python environment.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python check_planning.py run /path/to/6621db2 baseline
python check_planning.py run /path/to/prototype candidate
python check_planning.py compare baseline candidate
```

The runs agreed on every collected planning record and all nine numerical columns for 1,080 polarized samples.
