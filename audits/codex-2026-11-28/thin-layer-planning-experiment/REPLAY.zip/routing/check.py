"""Measure the real planner on a controlled thin-layer backend-selection boundary."""
import argparse
import json
from pathlib import Path
import sys
import time
import resource
from unittest.mock import patch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("checkout", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--one-case", action="store_true", help="Time one cold 4,998-panel/two-name forecast in this process")
args = parser.parse_args()
sys.path.insert(0, str(args.checkout.resolve() / "tools/GHOST"))
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.execution import selection
from ghost_backend.execution.options import validate_options
from ghost_backend.twod import solver
from ghost_backend.twod.preparation import preparation_scope

def geometry(panels, names):
    lines = ["Title: split homogeneous midsurface"]
    for i in range(names):
        count = panels // names + int(i < panels % names)
        left = .006 * i / names
        right = .006 * (i + 1) / names
        lines += [f"Segment: section{i} 1", f"properties: 1 {count} 10 0 0",
                  f"{left:.12f} 0 {right:.12f} 0"]
    lines += ["IBCs:", "10 thin_dielectric 0.00001 2", "Dielectrics:", "2 3.0 -0.02 1 0"]
    return build_geometry_snapshot(*parse_geometry("\n".join(lines) + "\n"))

options = validate_options(dict(factorization="automatic", mesh_strategy="global",
                                basis_order=1, mesh_grading=False, blas_threads=1, assembly_threads=1))
records = []
cases = ((4998, 2),) if args.one_case else ((4997, 2), (4998, 1), (4998, 2), (4998, 17), (4999, 1), (4999, 2))
for panels, names in cases:
    request = dict(geometry_snapshot=geometry(panels, names), geometry_units="meters",
                   frequencies_ghz=[1.], elevations_deg=list(range(-90, 90)))
    with preparation_scope(), patch.object(solver, "_solve_memory_limit_gb", return_value=24.0):
        start = time.perf_counter()
        plan = selection.select_backend(request, options, False)
        elapsed = time.perf_counter() - start
    counts = {r['polarization']: r['unknowns'] for r in plan['meshes']}
    assert all(r['panels'] == panels for r in plan['meshes'])
    records.append(dict(panels=panels, names=names, unknowns=counts, selected=plan['selected'],
                        physical_TE=2*(panels+1), physical_TM=panels+1,
                        seconds=elapsed, linux_process_peak_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
                        admitted_budget_gib=plan['admission_budget_gib']))
args.output.write_text(json.dumps(records, indent=2)+'\n')
