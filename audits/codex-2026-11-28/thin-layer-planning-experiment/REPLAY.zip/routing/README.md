# Automatic backend cutoffs and planning overhead

All forecasts use the shipped Automatic policy, with an injected 24 GiB available solver budget, at 1 GHz and 180 directions. This controls admission for a decision-boundary test. Every fixture is the same 6 mm straight uniform thin dielectric surface. For a given panel count, the only input difference is its subdivision into named segments. Repartitioning can change rounding of physical element lengths for uneven partitions. The exact node and field-trace counts follow from connectivity and are independent of those names.

```sh
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
python check.py /path/to/6621db2 baseline.json
python check.py /path/to/prototype trial.json
python bench.py /path/to/6621db2 /path/to/prototype repeats
```

The 4,998-panel, two-name case was also timed in three fresh Linux interpreters per arm, reversing order on the second pair. The timed operation is the complete select_backend forecast call. The process lifetime peak includes imports. Other work ran on the host. None of the approximately ten-thousand-unknown systems in this directory was factorized. The separate factors and compression directories contain executed numerical jobs.
