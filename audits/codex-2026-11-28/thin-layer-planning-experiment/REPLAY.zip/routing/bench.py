"""Three fresh processes per arm; reverse order on the second pair."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("baseline", type=Path)
p.add_argument("candidate", type=Path)
p.add_argument("output", type=Path)
args = p.parse_args()
args.output.mkdir(exist_ok=True, parents=True)
env = dict(os.environ, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
results = []
for i, order in enumerate((("baseline","candidate"),("candidate","baseline"),("baseline","candidate")), 1):
    for arm in order:
        out = args.output / f"{arm}-{i}.json"
        subprocess.run([sys.executable, str(Path(__file__).with_name("check.py")),
                        str(getattr(args, arm)), str(out), "--one-case"], env=env, check=True)
        results.append(dict(arm=arm, repeat=i, **json.loads(out.read_text())[0]))
(args.output / "summary.json").write_text(json.dumps(results, indent=2)+"\n")
