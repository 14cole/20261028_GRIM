"""Fresh actual geometry/cluster reconstruction; offline 24 GiB pricing, no solve."""
import hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
P=Path(__file__).resolve().parent;root=Path(sys.argv[1]);sys.path.insert(0,str(root/'tools/GHOST'))
from geometry_cases import build
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.twod import solver as S
from ghost_backend.execution.options import execution_scope,cpu_allocation_scope
from ghost_backend.compressed.runtime import planned_forecast
spec=dict(material='coated',shape='circle',length_m=6.096,frequency_ghz=10.)
text,g=build(spec);snapshot=build_geometry_snapshot(*parse_geometry(text));captured=[];original=S._dense_formulation_resources
class ForecastCaptured(Exception):pass
def capture(*args,**kwargs):
 r=original(*args,**kwargs);captured.append(r);raise ForecastCaptured()
with cpu_allocation_scope(4),patch.object(S,'_dense_formulation_resources',side_effect=capture):
 try:S.solve_monostatic_rcs_2d_survey(snapshot,[10.],[0.],geometry_units='meters',max_panels=150000,execution_options=dict(factorization='compressed',ram_budget_gib=8.,assembly_threads='auto',blas_threads='auto',compressed_storage_mib=0))
 except ForecastCaptured:pass
assert len(captured)==1
r=captured[0];assert r['system_dofs']==69036
with cpu_allocation_scope(4),execution_scope(dict(factorization='compressed',ram_budget_gib=24.,assembly_threads='auto',blas_threads='auto',compressed_storage_mib=0)),patch.object(S,'_solve_memory_limit_gb',return_value=24.):
 p=planned_forecast(r['nodes'],r['system_dofs'],19,19,4,r)
assert p['storage_fits'] and not p['paired_assembly'] and p['peak_bytes']<=24*2**30
out=dict(spec=spec,geometry_sha256=hashlib.sha256(text.encode()).hexdigest(),resources=r,plan=p,executed_solve=False,assumed_reservation_gib=24.)
(P/'fresh-coating-plan.json').write_text(json.dumps(out,indent=2)+'\n')
print('Fresh plan:',r['system_dofs'],'DOFs; peak',p['peak_bytes']/2**30,'GiB; payload cap',p['storage_limit_bytes']/2**30,'GiB')
