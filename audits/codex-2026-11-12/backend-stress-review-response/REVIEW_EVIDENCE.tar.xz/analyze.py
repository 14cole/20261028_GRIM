import hashlib,json
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent
catalog=json.loads((P/'catalog.json').read_text()); summary=[]
for c in catalog:
 n=c['case'];r=json.loads((P/'results'/f'{n}.json').read_text());m=json.loads((P/'results'/f'{n}.metadata.json').read_text());i=json.loads((P/'results'/f'{n}.imports.json').read_text())
 assert r['error'] is None and m['quality_gate']['passed'] and not i['wrong']
 fields=np.load(P/'results'/f'{n}.npz')['field'];assert np.all(np.isfinite(fields))
 estimates=m.get('experimental_cpu',{}).get('memory_estimates',[])
 summary.append(dict(case=n,wall_seconds=r['wall'],parent_peak_rss_gib=r['peak_gib'],selected=r.get('selected'),dense_forecast_gib=r.get('dense_forecast'),backend=r['backend'],quality_gate_passed=True,field_count=len(fields),pairing_plans=[e.get('paired_assembly') for e in estimates],profiler_paired_flag=r['paired'],imported_modules=len(i['modules'])))
comparisons=[]
for a,b in [('auto181-2.3','auto181-2.6'),('auto181-2.3','auto181-2.6-disk'),('coated-dense','coated-paired'),('coated-dense','coated-separate'),('coated-separate-previous','coated-separate')]:
 x=np.load(P/'results'/f'{a}.npz')['field'];y=np.load(P/'results'/f'{b}.npz')['field'];assert x.shape==y.shape
 sx=json.loads((P/'results'/f'{a}.samples.json').read_text());sy=json.loads((P/'results'/f'{b}.samples.json').read_text())
 keys=('frequency_ghz','theta_inc_deg','theta_scat_deg','polarization','elevation_deg','azimuth_deg')
 assert [[s.get(k) for k in keys] for s in sx]==[[s.get(k) for k in keys] for s in sy]
 comparisons.append(dict(reference=a,candidate=b,field_count=len(x),bitwise_equal=bool(np.array_equal(x,y)),max_absolute_difference=float(np.max(np.abs(x-y))),relative_max_norm=float(np.max(np.abs(x-y))/np.max(np.abs(x)))))
identity=[]
for root in sorted(set(c['root'] for c in catalog)):
 h=hashlib.sha256();p=Path(root)
 for f in sorted((p/'tools/GHOST/ghost_backend').rglob('*.py')):
  h.update(f.relative_to(p).as_posix().encode()+b'\0'+f.read_bytes()+b'\0')
 identity.append(dict(root=root,source_sha256=h.hexdigest()))
out=dict(cases=summary,comparisons=comparisons,identity=identity)
(P/'SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
