"""Sequential bounded reproductions against current and preceding production."""
import json,os,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent;current=Path(sys.argv[1]);previous=Path(sys.argv[2]);(P/'results').mkdir(exist_ok=True)
cases=[('auto181-2.3',current,dict(body='diel',n=4000,mode='automatic',options=dict(ram_budget_gib=2.3))),
 ('auto181-2.6',current,dict(body='diel',n=4000,mode='automatic',options=dict(ram_budget_gib=2.6))),
 ('auto181-2.6-disk',current,dict(body='diel',n=4000,mode='automatic',storage='disk',options=dict(ram_budget_gib=2.6))),
 ('auto19-2.3',current,dict(body='diel',n=4000,angles=19,mode='automatic',options=dict(ram_budget_gib=2.3))),
 ('coated-dense',current,dict(body='coated',n=6120,mode='dense',options=dict(ram_budget_gib=8))),
 ('coated-paired',current,dict(body='coated',n=6120,mode='compressed',options=dict(ram_budget_gib=2.8))),
 ('coated-separate',current,dict(body='coated',n=6120,mode='compressed',options=dict(ram_budget_gib=1.9))),
 ('coated-separate-previous',previous,dict(body='coated',n=6120,mode='compressed',options=dict(ram_budget_gib=1.9)))]
(P/'catalog.json').write_text(json.dumps([dict(case=n,root=str(r),spec=s) for n,r,s in cases],indent=2))
env={k:v for k,v in os.environ.items() if not k.startswith('GHOST_')};env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for name,root,spec in cases:
 file=P/'results'/(name+'.json')
 if file.exists():continue
 spec=dict(spec,out=str(P/'results'/(name+'.npz')))
 done=subprocess.run([sys.executable,str(P/'run_profile.py'),str(root),json.dumps(spec)],env=env,capture_output=True,text=True,timeout=240)
 (P/'results'/(name+'.stdout')).write_text(done.stdout);(P/'results'/(name+'.stderr')).write_text(done.stderr)
 records=[json.loads(line) for line in done.stdout.splitlines() if line.startswith('{')]
 assert done.returncode==0 and records,(name,done.stderr)
 file.write_text(json.dumps(records[-1],indent=2)+'\n')
 print(name,records[-1]['error'],records[-1].get('selected'),records[-1].get('dense_forecast'),flush=True)
