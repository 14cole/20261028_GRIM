"""Run corrected far-rule regression, prove every imported solver module's origin."""
import json,os,runpy,sys
from pathlib import Path
P=Path(__file__).resolve().parent;root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);os.environ['GHOST_AUDIT_ROOT']=str(root)
script=P/'claude/audits/claude-2026-11-10/regression/test_s1_s2_w_far_rule.py';sys.path.insert(0,str(script.parent))
try:runpy.run_path(str(script),run_name='__main__')
finally:
 files={name:str(Path(m.__file__).resolve()) for name,m in sys.modules.items() if name.startswith('ghost_backend') and getattr(m,'__file__',None)}
 wrong={k:v for k,v in files.items() if not Path(v).is_relative_to(root/'tools/GHOST')}
 out.write_text(json.dumps(dict(root=str(root),loaded=len(files),wrong=wrong,modules=files),indent=2)+'\n')
 assert not wrong,wrong
