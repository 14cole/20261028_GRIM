"""Run Claude's pinned profiler with full metadata and import provenance."""
import atexit,json,runpy,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve();spec=json.loads(sys.argv[2]);out=Path(spec['out']);P=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools/GHOST'))
from ghost_backend.twod import solver as S
from ghost_backend.execution.options import cpu_allocation_scope
original=S.solve_monostatic_rcs_2d_survey
def observed(*args,**kwargs):
 r=original(*args,**kwargs)
 out.with_suffix('.metadata.json').write_text(json.dumps(r['metadata'],default=str))
 out.with_suffix('.samples.json').write_text(json.dumps(r['samples'],default=str))
 return r
S.solve_monostatic_rcs_2d_survey=observed
def provenance():
 files={name:str(Path(m.__file__).resolve()) for name,m in sys.modules.items() if name.startswith('ghost_backend') and getattr(m,'__file__',None)}
 wrong={k:v for k,v in files.items() if not Path(v).is_relative_to(root/'tools/GHOST')}
 out.with_suffix('.imports.json').write_text(json.dumps(dict(root=str(root),modules=files,wrong=wrong),indent=2))
 assert not wrong,wrong
atexit.register(provenance)
script=P/'claude/audits/claude-2026-11-12/backend-stress-improvements-review/profile_dense.py'
sys.argv=[str(script),str(root),json.dumps(spec)]
with cpu_allocation_scope(4):runpy.run_path(str(script),run_name='__main__')
