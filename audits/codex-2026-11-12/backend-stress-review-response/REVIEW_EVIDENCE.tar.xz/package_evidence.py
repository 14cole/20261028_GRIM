"""Package complete independent review evidence with reproducible content hashes."""
import hashlib,json,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent
for name in ('current','previous'):
 log=(P/f'far-{name}.log').read_text();assert sum(line.startswith('PASS ') for line in log.splitlines())==36 and '0 failure(s)' in log and not any(line.startswith('FAIL ') for line in log.splitlines()),log[-500:]
 record=json.loads((P/f'far-{name}.imports.json').read_text());assert not record['wrong'] and record['loaded']>0
summary=json.loads((P/'SUMMARY.json').read_text());assert len(summary['cases'])==8
for c in summary['cases']:assert c['quality_gate_passed']
files=[]
for f in sorted(P.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or f.name in ('REVIEW_EVIDENCE.tar.xz','EVIDENCE_MANIFEST.json','PUBLICATION_ASSETS.json','PUBLISHED.json'):continue
 files.append(f)
archive=P/'REVIEW_EVIDENCE.tar.xz';members=[]
with tarfile.open(archive,'w:xz') as t:
 for f in files:
  data=f.read_bytes();name=f.relative_to(P).as_posix();t.add(f,arcname=name,recursive=False);members.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive,'r:xz') as t:
 for r in members:
  data=t.extractfile(r['path']).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
manifest=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=members)
(P/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
assets=[]
for name in ['RESPONSE_TO_CLAUDE_REVIEW.md','SUMMARY.json','fresh-coating-plan.json','EVIDENCE_MANIFEST.json','REVIEW_EVIDENCE.tar.xz']:
 f=P/name;b=f.read_bytes();assets.append(dict(path='audits/codex-2026-11-12/backend-stress-review-response/'+name,local=str(f),bytes=len(b),sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()))
(P/'PUBLICATION_ASSETS.json').write_text(json.dumps(assets,indent=2)+'\n')
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(members),assets=len(assets))))
