import os,signal,time
def compute(payload):
 from ghost_backend.execution.frequency_sweep import _compute
 if payload['frequency']==2.:
  time.sleep(2)
  os.kill(os.getpid(),signal.SIGKILL)
 return _compute(payload)
