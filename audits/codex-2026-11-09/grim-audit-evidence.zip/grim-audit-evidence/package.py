from pathlib import Path
import csv,json,re,hashlib,shutil,zipfile
root=Path('/workspace/audit')
import sys
sys.path.insert(0,str(root));from coverage_data import rows

def readable(s):
 s=re.sub(r'\b([A-Za-z]{2,})(?=\d)',r'\1 ',s)
 s=re.sub(r'(\d)(?=(?:s\b|dB\b|GB\b|GiB\b|MB\b|GHz\b|ns\b|ohm\b|CPU\b|m\b))',r'\1 ',s)
 return s.replace('atka','at ka').replace('givescondition','gives condition')
# REPORT.txt is edited as prose; do not normalize identifiers in it.
with (root/'coverage.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['ID','Disposition','Evidence and qualification','Artifacts / source locations'])
 for i,status,notes,refs in rows:w.writerow([i,status,readable(notes),refs])
original=Path('/workspace/review/tools/GHOST')
source=root/'source'
shutil.copytree(original,source,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.so','*.dll','*.pyc'))
manifest={'repository':'14cole/20261028_GRIM','main_commit':'f207c61529c706b9f98990ffa23c0b878f3590e0','audit_commit':'f5c2f4cdcc7254af2ffa759b3e1da144e097b564','atomic_findings':len(rows),'source_sha256':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
