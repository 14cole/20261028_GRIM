import sys,time,resource,json
sys.path.insert(0,'/workspace/audit');from run_case import geometry
from ghost_backend.twod.solver import solve_bistatic_rcs_2d
from ghost_backend.twod.samples import compact_samples
from contextlib import nullcontext
compact=sys.argv[1]=='compact';g=geometry(68);t=time.perf_counter()
with compact_samples() if compact else nullcontext():
 x=solve_bistatic_rcs_2d(g,[1.5],list(range(361)),list(range(361)),geometry_units='meters')
print(json.dumps(dict(compact=compact,wall=time.perf_counter()-t,rss_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,samples=len(x['samples']))))
