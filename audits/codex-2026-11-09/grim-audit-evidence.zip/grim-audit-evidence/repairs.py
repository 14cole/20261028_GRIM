import pathlib,json,sys
for file,key,function in [('extended','S13_storage','storage'),('cert_invariants','2D_invariants','invariants'),('last_checks','C3_actual_solver','condition')]:
 ns={};source=pathlib.Path('/workspace/audit/'+file+'.py').read_text().split("if __name__=='__main__':")[0].split('for name,fn in [')[0];exec(compile(source,file+'.py','exec'),ns)
 ns['out']=json.load(open('/workspace/audit/results/'+file+'.json'))
 recorder=ns.get('test',ns.get('record'));recorder(key,ns[function])
