import os,sys,json,time,resource,traceback
sys.path.insert(0,'/workspace/review/tools/GHOST')
if hasattr(os,'sched_setaffinity'): os.sched_setaffinity(0, sorted(os.sched_getaffinity(0))[:4])
import numpy as np
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.execution.options import execution_scope

def geometry(n=120,kind='pec',bor=False,radius=0.1,eps=4-0.2j,zs=37+0j,sliver=False,core_ratio=.7):
    t=np.linspace(0,np.pi if bor else -2*np.pi,n+1)
    r=radius if bor else radius*np.sqrt((2*np.pi/n)/np.sin(2*np.pi/n))
    p=np.column_stack((r*np.sin(t),r*np.cos(t))) if bor else np.column_stack((r*np.cos(t),r*np.sin(t)))
    if sliver:p[1]=p[0]+1e-4*(p[1]-p[0])
    def segment(name,typ,points,ibc=0,pos=0,neg=0):
        return f'Segment: {name} {typ}\nproperties: {typ} 1 {ibc} {pos} {neg}\n'+'\n'.join(' '.join(map(str,(*a,*b))) for a,b in zip(points[:-1],points[1:]))+'\n'
    s='Title: audit\n'+segment('body',3 if kind in ('dielectric','coat') else 1 if kind=='sheet' else 2,p,1 if kind in ('ibc','sheet') else 0,1 if kind in ('dielectric','coat') else 0)
    if kind=='coat':s+=segment('core',4,p*core_ratio,0,1)
    s+=f'IBCS_Resistances:\n1 constant {zs.real} {zs.imag} 0 0\n\nDielectrics:\n1 {eps.real} {eps.imag} 1 0\n'
    return build_geometry_snapshot(*parse_geometry(s))

def disable_native():
    from ghost_backend.twod.assembly.native import far,near,table
    for mod in (far,near,table):
        for name in ('library','scatter_library','tile_library'):
            if hasattr(mod,name):setattr(mod,name,lambda:None)
    from ghost_backend.bor import streaming
    streaming._NATIVE=None

def run(c):
    if c.get('fallback'):disable_native()
    if 'w_floor' in c:
        from ghost_backend.twod import operators
        operators._W_FAR_FLOOR[1]=c['w_floor']
    if c.get('far_uniform'):
        import inspect
        from ghost_backend.twod import operators
        source=inspect.getsource(operators._assemble_multi).replace('w_far_floor, int(obs_order), int(src_order)', 'w_far_floor')
        exec(compile(source,'<audit_uniform_far>','exec'),operators.__dict__)
        operators._W_FAR_FLOOR[1]=c['far_uniform']
        operators._graded_far_order=lambda *args,**kwargs:c['far_uniform']
    bor=c.get('bor',False);n=c.get('n',120);kind=c.get('kind','pec');ka=c.get('ka',3.);radius=c.get('radius',.1)
    g=geometry(n,kind,bor,radius,complex(*c.get('eps',[4,-.2])),complex(*c.get('zs',[37,0])),c.get('sliver',False),c.get('core_ratio',.7))
    freq=ka*299792458/(2*np.pi*radius)/1e9
    angles=c.get('angles',list(np.linspace(0,180 if bor else 360,c.get('angle_count',5),endpoint=bor)))
    kw=dict(geometry_units='meters')
    if bor:
        from ghost_backend.bor.dispatch import solve_monostatic_rcs_bor as solve
        if c.get('bor_options'):kw['bor_options']=c['bor_options']
        if c.get('assembly'):kw['assembly']=c['assembly']
        if c.get('table_precision'):kw['table_precision']=c['table_precision']
        kw.update(workers=c.get('workers',1),mode_tol=c.get('mode_tol',1e-6),stream_budget_gb=c.get('budget',1.))
        if 'n_modes' in c:kw['n_modes']=c['n_modes']
    else:
        from ghost_backend.twod.solver import solve_monostatic_rcs_2d as solve
        kw['solver_method']=c.get('method','direct')
    if bor and c.get('options',{}).get('rhs_compression'):
        kw['bor_options']={'rhs_compression':c['options']['rhs_compression']}
    if c.get('near_coarse'):
        from coarse_probe import install
        install()
    options=c.get('options')
    if c.get('capture'):
        from ghost_backend.linalg.dense import DenseFactor
        original=DenseFactor.__init__; counter=[0]
        def capture(self,matrix,*args,**kwargs):
            np.save(c['capture']+str(counter[0])+'.npy',matrix);counter[0]+=1
            return original(self,matrix,*args,**kwargs)
        DenseFactor.__init__=capture
    profiler=None
    if c.get('profile'):
        import cProfile
        profiler=cProfile.Profile();profiler.enable()
    start=time.perf_counter();cpu=time.process_time()
    if options:
        with execution_scope(options,limit_blas=True):res=solve(g,[freq],angles,**kw)
    else:res=solve(g,[freq],angles,**kw)
    if profiler:
        profiler.disable();profiler.dump_stats(c['profile'])
    return dict(config=c,wall=time.perf_counter()-start,cpu=time.process_time()-cpu,rss_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,result=res)

def encode(x):
    if isinstance(x,complex):return [x.real,x.imag]
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    return str(x)
if __name__=='__main__':
    c=json.loads(sys.argv[1]);out=sys.argv[2]
    try:r=run(c)
    except Exception as e:r=dict(config=c,error=repr(e),traceback=traceback.format_exc())
    with open(out,'w') as f:json.dump(r,f,default=encode)
    print(json.dumps({k:v for k,v in r.items() if k!='result'},default=encode),flush=True)
