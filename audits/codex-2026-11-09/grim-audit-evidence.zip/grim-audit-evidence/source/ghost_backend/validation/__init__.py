"""GHOST validation services."""

