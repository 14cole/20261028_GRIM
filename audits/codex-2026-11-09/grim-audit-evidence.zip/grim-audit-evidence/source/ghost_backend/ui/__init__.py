"""GHOST ui services."""

