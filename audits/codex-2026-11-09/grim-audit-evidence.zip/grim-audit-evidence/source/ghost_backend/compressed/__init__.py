"""GHOST compressed services."""

