"""GHOST hpc services."""

