"""GHOST geometry services."""

