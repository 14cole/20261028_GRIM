"""GHOST assembly services."""

