"""GHOST io services."""

