"""GHOST linalg services."""

