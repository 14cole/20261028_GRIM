"""GHOST bor services."""

