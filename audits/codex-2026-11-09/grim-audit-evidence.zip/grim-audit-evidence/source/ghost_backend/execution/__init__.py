"""GHOST execution services."""

