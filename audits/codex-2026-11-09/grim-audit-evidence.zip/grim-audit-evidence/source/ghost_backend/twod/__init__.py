"""GHOST twod services."""

