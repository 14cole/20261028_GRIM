Audit evidence bundle

Start with REPORT.txt and coverage.csv. coverage.csv gives a disposition for
all 54 atomic findings, including source-only and not-reproduced qualifications.
The source/ directory contains the reviewed GHOST Python/C/docs snapshot.
manifest.json pins the Git commits and hashes the source files.
No changes were pushed to GitHub.

Scripts and raw data:
- run_case.py: individual co-polarized solver cases, geometry generation,
  native/fallback controls, optional isolated in-memory optimization variants.
- batch.py, batch_extra.py, followup.py, final_checks.py: case schedules.
- micro.py: quadrature, RNG, warning race, concurrent solves, native kernels.
- extended.py, cert_invariants.py, last_checks.py, physics_extended.py:
  geometry/certification/recovery/physics tests.
- native_bench.py: standalone C optimization, lossy tables, DCT benchmarks.
- factor_memory.py and storage_case.py: isolated memory measurements.
- repairs.py: reruns corrected harness cases, preserving composite results.
- analyze.py: analytic-reference calculations and results/summary.json.
- results/: raw JSON, sampled profiles, matrices, cProfile files.

Original harness prerequisites:
Python, NumPy, SciPy, psutil, threadpoolctl and a C compiler for native tests.
Use the versions in REPORT.txt for the closest environment match.
Build the native libraries before running native/fallback comparisons:
  python source/ghost_backend/twod/assembly/native/build.py
  python source/ghost_backend/bor/native/build_kernel.py

The original scripts use /workspace/audit and /workspace/review/tools/GHOST
paths. portable/ contains the same scripts adapted to their enclosing bundle
location. Set AUDIT_ROOT to this extracted bundle and GHOST_SOURCE to its
source/ directory when using portable scripts:
  export AUDIT_ROOT=/absolute/path/to/extracted/bundle
  export GHOST_SOURCE="$AUDIT_ROOT/source"
  OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python portable/run_case.py \
    '{"n":1200,"ka":60,"angle_count":61,"fallback":false}' /tmp/case.json

Raw cpu values in individual case records are parent CPU only. rss_peak is
parent ru_maxrss. Use the runtime_profile's process-tree RSS field when tile
workers are active. Profiling sums are inclusive and overlap.

Some original harness attempts used unsupported keyword arguments. Those
were fixed and the relevant composite JSON results replaced by repairs.py.
Historical logs retain the initial harness errors for transparency; they are
not solver findings. The ineffective W_FAR_FLOOR-only experiment is also kept:
uniform_*.json contains the subsequent effective uniform-rule experiment.

batch schedules skip existing case JSON files. To rerun all timings, use a
fresh copy of results/ or run individual cases with new output names. Do not
run performance suites concurrently. Repeated timings are not formal
confidence intervals and do not justify globally changing numerical defaults.

Bundle verification: all portable scripts parsed successfully, both native
builders succeeded from source/, and a portable native 120-panel solver case
completed. bundle_sha256.json hashes the included files. Native binaries are
excluded deliberately and must be rebuilt on the target machine.
