import sys,json,pathlib,statistics
sys.path.insert(0,'/workspace/review/tools/GHOST')
import numpy as np
from ghost_backend.validation import cylinder as C,sphere as B
def sheet_sigma(radius,zs,f,pol):
 from scipy import special as sp
 k=2*np.pi*f/299792458.;z=k*radius;order=int(z+4*z**(1/3)+16);total=0j
 for n in range(-order,order+1):
  j=sp.jv(n,z);h=sp.hankel2(n,z);jp=sp.jvp(n,z);hp=sp.h2vp(n,z)
  if pol=='TM':
   gamma=1j*376.730313668/zs;matrix=[[h,-j],[hp-gamma*h,-jp]];rhs=[-j,-jp+gamma*j]
  else:
   gamma=1j*zs/376.730313668;matrix=[[hp,-jp],[hp-gamma*h,gamma*j]];rhs=[-jp,-jp+gamma*j]
  a=np.linalg.solve(matrix,rhs)[0];total+=a*(-1.)**n
 return 4*abs(total)**2/k
root=pathlib.Path('/workspace/audit/results');out={};rows=[]
for p in sorted(root.glob('*.json')):
 try:r=json.load(open(p))
 except:continue
 if 'config' not in r:continue
 row=dict(name=p.stem,config=r['config'],wall=r.get('wall'),cpu=r.get('cpu'),rss=r.get('rss_peak'),error=r.get('error'))
 if 'result' in r:
  x=r['result'];m=x.get('metadata',{});row['profile']=m.get('runtime_profile',{});row['panels']=m.get('panel_count');row['gate']=m.get('quality_gate',{}).get('passed')
  if p.stem.startswith(('physics','weak','lowbor','hp')):
   c=r['config'];kind=c.get('kind','pec');bor=c.get('bor',False);radius=c.get('radius',.1);eps=complex(*c.get('eps',[4,-.2]));zs=complex(*c.get('zs',[37,0]));errs=[];amp_err=[]
   for s in x['samples']:
    f=s['frequency_ghz']*1e9;pol='TE' if s['polarization']=='VV' else 'TM'
    try:
     if bor:
      if kind=='pec':ref=B.sigma_pec_sphere(radius,f)
      elif kind=='ibc':ref=B.sigma_impedance_sphere(radius,f,zs)
      elif kind=='sheet':ref=B.sigma_electric_sheet_sphere(radius,f,zs)
      elif kind=='dielectric':ref=B.sigma_dielectric_sphere(radius,eps,1,f)
      else:ref=B.sigma_coated_pec_sphere(.7*radius,radius,eps,1,f)
     else:
      if kind=='pec':
       ref=C.sigma_pec_cylinder(radius,f,pol);ar=C.pec_cylinder_backscatter_amplitude(radius,f,pol);amp_err.append(abs(complex(s['rcs_amp_real'],s['rcs_amp_imag'])-ar)/abs(ar))
      elif kind=='ibc':ref=C.sigma_impedance_cylinder(radius,zs,f,pol)
      elif kind=='dielectric':ref=C.sigma_dielectric_cylinder(radius,eps,1,f,pol)
      elif kind=='coat':ref=C.sigma_coated_pec_cylinder(.7*radius,radius,eps,1,f,pol)
      else:ref=sheet_sigma(radius,zs,f,pol)
     errs.append(10*np.log10(s['rcs_linear']/ref))
    except Exception as e:row['reference_error']=repr(e)
   row['max_db_error']=max(map(abs,errs),default=None);row['signed_db_errors']=errs;row['max_amp_error']=max(amp_err,default=None)
 rows.append(row)
out['runs']=rows
for prefix in ['native2d','nativebor','floor','floor_ibc','coarsebor','blasbor']:
 groups={}
 for r in rows:
  if r['name'].startswith(prefix+'_') and r['wall'] is not None:
   c=r['config'];k=str(c.get('fallback',c.get('w_floor',c.get('near_coarse',c.get('options',{}).get('blas_threads')))))
   if prefix=='floor' and r['name'].startswith('floor_ibc'):continue
   groups.setdefault(k,[]).append(r['wall'])
 out[prefix]={k:{'median':statistics.median(v),'values':v} for k,v in groups.items()}
with open('/workspace/audit/results/summary.json','w') as f:json.dump(out,f,indent=2,default=str)
for r in rows:
 if r.get('error') or r.get('max_db_error') is not None:print(r['name'],r.get('error') or {'db':r['max_db_error'],'amp':r['max_amp_error']})
print({k:v for k,v in out.items() if k!='runs'})
