import os,sys,time,json,threading,gc
sys.path.insert(0,'/workspace/review/tools/GHOST')
import numpy as np,psutil
from scipy.linalg import lu_factor
from ghost_backend.linalg.hierarchical import HierarchicalFactor
n=6000;p=psutil.Process();a=np.empty((n,n),complex);grid=np.arange(n)/n
for i in range(0,n,64):a[i:i+64]=np.exp(-10*np.abs(grid[i:i+64,None]-grid[None,:]))
a.flat[::n+1]+=1
gc.collect();base=p.memory_info().rss;peak=[base];stop=threading.Event()
def sample():
 while not stop.wait(.005):peak[0]=max(peak[0],p.memory_info().rss)
t=threading.Thread(target=sample);t.start();start=time.perf_counter()
if sys.argv[1]=='hodlr':f=HierarchicalFactor(a);details=f.evidence
else:f=lu_factor(a);details={}
stop.set();t.join();print(json.dumps(dict(backend=sys.argv[1],n=n,matrix_bytes=a.nbytes,baseline=base,peak=peak[0],extra_matrix_units=(peak[0]-base)/a.nbytes,seconds=time.perf_counter()-start,details=details)))
