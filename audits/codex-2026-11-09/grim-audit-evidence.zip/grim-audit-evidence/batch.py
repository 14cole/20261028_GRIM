import subprocess,json,os,time,pathlib
root=pathlib.Path('/workspace/audit/results');env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
cases=[]
for rep in range(3):
 for fb in [False,True]:cases.append((f'native2d_{rep}_{fb}',dict(n=1200,ka=60,angle_count=61,fallback=fb)))
 for floor in [8,6]:cases.append((f'floor_{rep}_{floor}',dict(n=1600,ka=80,angle_count=5,w_floor=floor)))
for n in [300,1280,3000,5120,6144,8448]:
 for method in ['direct','auto']:
  cases.append((f'backend_{n}_{method}',dict(n=n,ka=n/20,angle_count=61,method=method)))
for bor in [False,True]:
 for kind in ['pec','ibc','dielectric','sheet','coat']:
  for n in ([120,240,360] if not bor else [30,60,120]):
   cases.append((f'physics_{bor}_{kind}_{n}',dict(n=n,bor=bor,kind=kind,ka=3)))
for rep in range(3):
 for fb in [False,True]:cases.append((f'nativebor_{rep}_{fb}',dict(n=60,bor=True,ka=6,fallback=fb)))
for bt in [1,4]:
 for rep in range(3):cases.append((f'blasbor_{bt}_{rep}',dict(n=60,bor=True,ka=3,options=dict(blas_threads=bt))))
for budget in [.06,.25,1.]:cases.append((f'budgetbor_{budget}',dict(n=120,bor=True,ka=10,budget=budget)))
for rhs in ['auto','off']:cases.append((f'rhsbor_{rhs}',dict(n=120,bor=True,ka=10,angle_count=181,options=dict(rhs_compression=rhs))))
for tol in [1e-3,1e-6,1e-13]:cases.append((f'modebor_{tol}',dict(n=60,bor=True,ka=6,mode_tol=tol)))
for ka in [.01,5]:cases.append((f'weak_{ka}',dict(n=360,kind='dielectric',ka=ka,eps=[1.0001,0])))
for ka in [1e-4,.01]:cases.append((f'lowbor_{ka}',dict(n=60,bor=True,kind='ibc',ka=ka)))
for name,c in cases:
 path=root/(name+'.json')
 if path.exists():continue
 print('START',name,flush=True)
 try:subprocess.run(['python','/workspace/audit/run_case.py',json.dumps(c),str(path)],env=env,timeout=420,check=True)
 except Exception as e:path.write_text(json.dumps(dict(config=c,error=repr(e))))
print('COMPLETE',len(cases),flush=True)
