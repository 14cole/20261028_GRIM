import sys,os,json,time,traceback,copy,resource
sys.path.insert(0,'/workspace/audit');from run_case import *
from ghost_backend.twod import solver as S
from ghost_backend.execution.options import validate_options,execution_scope
out={}
def test(name,fn):
 try:out[name]=fn()
 except Exception as e:out[name]={'error':repr(e),'traceback':traceback.format_exc()}
 print(name,str(out[name])[:700],flush=True)
 with open('/workspace/audit/results/last_checks.json','w') as f:json.dump(out,f,default=encode)
def condition():
 g=geometry(600,radius=.05);other=copy.deepcopy(g['segments'][0]);other['name']='other'
 for p in other['point_pairs']:
  for key in ['x1','x2']:p[key]=str(float(p[key])+.10025)
 g['segments'].append(other);rows=[]
 for method in ['experimental_cpu','direct']:
  for seed in [1,2,3,4,5,6]:
   np.random.seed(seed);before=np.random.get_state()
   x=S.solve_monostatic_rcs_2d_single_polarization(g,[10.],[0.],polarization='TM',geometry_units='meters',solver_method=method,compute_condition_number=True,execution_options={'factorization':'compressed' if method=='experimental_cpu' else 'dense'})
   after=np.random.get_state();m=x['metadata'];rows.append(dict(method=method,seed=seed,condition=m['condition_est_max'],rng_changed=not np.array_equal(before[1],after[1]) or before[2]!=after[2]))
 return rows

def killworker():
 from ghost_backend.execution import frequency_sweep as f
 import crash_worker
 old=f._compute;f._compute=crash_worker.compute
 try:
  return f.compute_parallel(S.solve_monostatic_rcs_2d,dict(geometry_snapshot=geometry(68),frequencies_ghz=[1.,2.],elevations_deg=[0.,90.],geometry_units='meters',solver_method='direct'),None,None,{},'double',False,2,8.)
 finally:f._compute=old

def planners():
 from ghost_backend.execution.selection import select_backend
 from ghost_backend.execution import frequency_sweep as f
 from ghost_backend.twod.solver import _allocation_rss_bytes
 rows=[]
 for n in [1280,5120,6144,7936,8448]:
  args=dict(geometry_snapshot=geometry(n),frequencies_ghz=[1.5],elevations_deg=[0.,90.],geometry_units='meters')
  t=time.perf_counter();r=select_backend(args,validate_options({}),False)
  rows.append(dict(n=n,seconds=time.perf_counter()-t,candidates=r['candidates']))
 args=dict(geometry_snapshot=geometry(1280),frequencies_ghz=[.5,1.,1.5,2.,2.5,3.,3.5,4.],elevations_deg=[0.,90.],geometry_units='meters')
 t=time.perf_counter();p=f._plan(args,validate_options({}),False,args['frequencies_ghz'],2,10.,4);planning=time.perf_counter()-t
 os.environ['SLURM_JOB_ID']='audit-test'
 t=time.process_time()
 for _ in range(100):_allocation_rss_bytes(['SLURM_JOB_ID'])
 probe=(time.process_time()-t)/100;os.environ.pop('SLURM_JOB_ID')
 return dict(forecasts=rows,eight_frequency_planning_seconds=planning,slurm_probe_seconds=probe)

def mode_retry():
 from ghost_backend.bor.dispatch import solve_monostatic_rcs_bor
 rows=[]
 for n in [36,37]:
  text=f'Title: cone\nSegment: body 2\nproperties: 2 {n} 0 0 0\n0 .2 .1 .1\n.1 .1 .1 -.1\n.1 -.1 0 -.1\nIBCS_Resistances:\n\nDielectrics:\n'
  g=build_geometry_snapshot(*parse_geometry(text))
  for cap in [None,31]:
   try:
    r=solve_monostatic_rcs_bor(g,[3.],[0.,45.,90.,135.,180.],geometry_units='meters',workers=1,mode_tol=1e-13,n_modes=cap)
    rows.append(dict(n=n,cap=cap,rcs=[x['rcs_db'] for x in r['samples']],modes=r['metadata']['per_frequency'][0]['modes_used']))
   except Exception as e:rows.append(dict(n=n,cap=cap,error=repr(e)))
 return rows

if __name__=='__main__':
 for name,fn in [('C4_retry_larger_radius',mode_retry),('C3_actual_solver',condition),('R3a_killed_worker',killworker),('M1_M2_S14_S15_planning',planners)]:test(name,fn)
