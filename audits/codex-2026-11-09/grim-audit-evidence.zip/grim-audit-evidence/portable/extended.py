# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,sys,time,json,traceback,tempfile,threading,resource
sys.path.insert(0,_AUDIT_ROOT+'/portable');from run_case import *
from ghost_backend.twod import solver as S
from ghost_backend.bor import dispatch as B
out={}
def test(name,f):
 t=time.perf_counter()
 try:out[name]=f()
 except Exception as e:out[name]={'error':repr(e),'traceback':traceback.format_exc()}
 print(name,str(out[name])[:800],flush=True)
 with open(_AUDIT_ROOT+'/results/extended.json','w') as h:json.dump(out,h,default=encode)
def geo(points,n=20,typ=2,material=0):
 s=f'Title: cone\nSegment: body {typ}\nproperties: {typ} {n} 0 {material} 0\n'+'\n'.join(' '.join(map(str,(*a,*b))) for a,b in zip(points[:-1],points[1:]))+'\nIBCS_Resistances:\n\nDielectrics:\n1 16 0 1 0\n'
 return build_geometry_snapshot(*parse_geometry(s))
def cone():
 r=[]
 for n in [20,30]:
  g=geo([(0,.2),(.05,.1),(.05,-.1),(0,-.1)],n)
  for cap in [None,31]:
   try:
    x=B.solve_monostatic_rcs_bor(g,[3.],[0.,45.,90.,135.,180.],geometry_units='meters',workers=1,mode_tol=1e-13,n_modes=cap)
    r.append(dict(n=n,cap=cap,rcs=[s['rcs_db'] for s in x['samples']],metadata=x['metadata']['per_frequency']))
   except Exception as e:r.append(dict(n=n,cap=cap,error=repr(e)))
 return r

def highindex():
 r=[];g=geo([(0,.01),(.1,.01),(.1,-.01),(0,-.01)],20,3,1)
 for freq in [1.,1.5,2.]:
  for cap in [None,int(4*2*np.pi*freq*1e9/299792458*.1+10)]:
   try:x=B.solve_monostatic_rcs_bor(g,[freq],[30.,90.],geometry_units='meters',workers=1,n_modes=cap);r.append(dict(freq=freq,cap=cap,rcs=[s['rcs_db'] for s in x['samples']]))
   except Exception as e:r.append(dict(freq=freq,cap=cap,error=repr(e)))
 return r

def meshref():
 g=geo([(-.05,-.03),(-.05,.03),(.05,.03),(.05,-.03),(-.05,-.03)],-20)
 r=[]
 for fs in [[.8],[.8,3.]]:
  x=S.solve_monostatic_rcs_2d(g,fs,[0.,90.],geometry_units='meters',mesh_reference_ghz=1.5,solver_method='direct');r.append(dict(freq=fs,panels=x['metadata']['panel_count'],samples=x['samples']))
 return r

def open_surfaces():
 g=geo([(-.05,0),(.05,0)],-20)
 r={}
 try:S.solve_monostatic_rcs_2d(g,[1.5],[0.],geometry_units='meters',solver_method='direct');r['2d']='accepted'
 except Exception as e:r['2d']=repr(e)
 for typ in [2,1]:
  g=geo([(.05,.1),(.05,-.1)],10,typ)
  try:x=B.solve_monostatic_rcs_bor(g,[1.],[90.],geometry_units='meters',workers=1);r[str(typ)]=[s['rcs_db'] for s in x['samples']]
  except Exception as e:r[str(typ)]=repr(e)
 return r

def spool():
 from ghost_backend.linalg.residual_spool import ResidualSpool
 rng=np.random.default_rng(1);a=rng.normal(size=(600,600)).astype(complex);restored=np.zeros_like(a)
 with tempfile.TemporaryDirectory() as d:
  s=ResidualSpool(a,d,lambda:None);s.restore_into(restored);s.close();return dict(bitwise=np.array_equal(a,restored),remaining=os.listdir(d))

def invalid_env():
 from ghost_backend.linalg.dense import DenseFactor
 os.environ['GHOST_HIERARCHICAL_MIN_UNKNOWNS']='bad'
 try:DenseFactor(np.eye(3));return 'accepted'
 except Exception as e:return repr(e)
 finally:os.environ.pop('GHOST_HIERARCHICAL_MIN_UNKNOWNS',None)

def storage():
 from ghost_backend.twod.samples import compact_samples
 from contextlib import nullcontext
 r=[]
 for compact in [False,True]:
  t=time.perf_counter()
  with compact_samples() if compact else nullcontext():
   x=S.solve_bistatic_rcs_2d(geometry(68),[1.5],list(np.arange(361.)),list(np.arange(361.)),geometry_units='meters')
  r.append(dict(compact=compact,seconds=time.perf_counter()-t,samples=len(x['samples']),rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024))
  del x
 return r

def forecasts():
 r=[]
 for n in [60,120,250]:
  g=geometry(n,bor=True);p=B.estimate_bor_resources(g,1.5,[0.,90.],geometry_units='meters',mesh_certification=False)
  r.append(dict(n=n,forecast=p))
 return r

def aborted():
 e=threading.Event();e.set();t=time.perf_counter()
 try:S.solve_monostatic_rcs_2d(geometry(120),[1.5],[0.],geometry_units='meters',solver_method='direct',abort_event=e);return 'accepted'
 except Exception as exc:return dict(error=repr(exc),seconds=time.perf_counter()-t,threads=[x.name for x in threading.enumerate()])
for name,fn in [('C4_cone_mode_retry',cone),('C6a_high_index_disk',highindex),('R3f_mesh_reference',meshref),('R3h_R3k_open_surfaces',open_surfaces),('residual_spool',spool),('R3l_invalid_environment',invalid_env),('S13_storage',storage),('M3a_forecasts',forecasts),('abort',aborted)]:test(name,fn)
