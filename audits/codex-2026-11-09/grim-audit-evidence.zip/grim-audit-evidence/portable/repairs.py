# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import pathlib,json,sys
for file,key,function in [('extended','S13_storage','storage'),('cert_invariants','2D_invariants','invariants'),('last_checks','C3_actual_solver','condition')]:
 ns={'__file__':str(_AuditPath(_AUDIT_ROOT)/'portable'/(file+'.py'))};source=pathlib.Path(_AUDIT_ROOT+'/portable/'+file+'.py').read_text().split("if __name__=='__main__':")[0].split('for name,fn in [')[0];exec(compile(source,file+'.py','exec'),ns)
 ns['out']=json.load(open(_AUDIT_ROOT+'/results/'+file+'.json'))
 recorder=ns.get('test',ns.get('record'));recorder(key,ns[function])
