# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,signal,time
def compute(payload):
 from ghost_backend.execution.frequency_sweep import _compute
 if payload['frequency']==2.:
  time.sleep(2)
  os.kill(os.getpid(),signal.SIGKILL)
 return _compute(payload)
