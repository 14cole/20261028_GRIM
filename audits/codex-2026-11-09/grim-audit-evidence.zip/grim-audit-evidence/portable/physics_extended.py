# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,sys,json,time,copy,tempfile,traceback
sys.path.insert(0,_AUDIT_ROOT+'/portable');from run_case import *
from ghost_backend.twod import solver as S
from ghost_backend.validation import cylinder as C
from ghost_backend.linalg.refined_lu import linear_precision
out={}
def record(name,fn):
 try:out[name]=fn()
 except Exception as e:out[name]={'error':repr(e),'traceback':traceback.format_exc()}
 print(name,str(out[name])[:700],flush=True)
 with open(_AUDIT_ROOT+'/results/physics_extended.json','w') as f:json.dump(out,f,default=encode)
def layers():
 result=[]
 for core in [1+0j,8-.1j]:
  g=geometry(240,kind='dielectric');inner=copy.deepcopy(g['segments'][0]);inner.update(name='core',seg_type=5,properties=['5','1','0','1','2'])
  for pair in inner['point_pairs']:
   for k in ['x1','y1','x2','y2']:pair[k]=str(float(pair[k])*.5)
  g['segments'].append(inner)
  # Obtain the parser's material representation from a complete text geometry.
  t=np.linspace(0,-2*np.pi,241);r=.1*np.sqrt((2*np.pi/240)/np.sin(2*np.pi/240));p=np.column_stack((r*np.cos(t),r*np.sin(t)))
  text='Title: layers\n'
  for name,typ,pts,pos,neg in [('outer',3,p,1,0),('core',5,p*.5,1,2)]:
   text+=f'Segment: {name} {typ}\nproperties: {typ} 1 0 {pos} {neg}\n'+'\n'.join(' '.join(map(str,(*a,*b))) for a,b in zip(pts[:-1],pts[1:]))+'\n'
  text+=f'IBCS_Resistances:\n\nDielectrics:\n1 4 -.2 1 0\n2 {core.real} {core.imag} 1 0\n';g=build_geometry_snapshot(*parse_geometry(text));freq=3*299792458/(2*np.pi*.1)/1e9
  x=S.solve_monostatic_rcs_2d(g,[freq],[0.,45.,90.],geometry_units='meters',solver_method='direct');err=[]
  for sample in x['samples']:
   pol=sample['polarization_internal'];ref=C.two_layer_dielectric_cylinder_amplitude(.05,.1,4-.2j,1,core,1,freq*1e9,pol)
   err.append(abs(complex(sample['rcs_amp_real'],sample['rcs_amp_imag'])-ref)/abs(ref))
  result.append(dict(core=str(core),max_complex_error=max(err)))
 return result

def invariance():
 g=geometry(120);freq=1.5;k=2*np.pi*freq*1e9/299792458;angles=[0.,45.,90.];kw=dict(geometry_units='meters',solver_method='direct');base=S.solve_monostatic_rcs_2d(g,[freq],angles,**kw);z=lambda s:complex(s['rcs_amp_real'],s['rcs_amp_imag']);result={}
 for name in ['translation','units','rotation']:
  h=copy.deepcopy(g)
  for seg in h['segments']:
   for p in seg['point_pairs']:
    for suffix in ['1','2']:
     x,y=float(p['x'+suffix]),float(p['y'+suffix])
     if name=='translation':x+=.03;y-=.02
     elif name=='units':x/=.0254;y/=.0254
     else:x,y=(x-y)/np.sqrt(2),(x+y)/np.sqrt(2)
     p['x'+suffix]=str(x);p['y'+suffix]=str(y)
  x=S.solve_monostatic_rcs_2d(h,[freq],angles,geometry_units='inches' if name=='units' else 'meters',solver_method='direct');errors=[]
  for a,b in zip(base['samples'],x['samples']):
   phase=np.exp(2j*k*(.03*np.cos(np.deg2rad(a['theta_inc_deg']))-.02*np.sin(np.deg2rad(a['theta_inc_deg'])))) if name=='translation' else 1.
   errors.append(abs(z(b)-phase*z(a))/max(abs(z(a)),1e-300))
  result[name]=max(errors)
 return result

def recovery():
 from ghost_backend.twod.checkpoints import FrequencyCheckpoints
 x=S.solve_monostatic_rcs_2d(geometry(68),[1.5],[0.,90.],geometry_units='meters',solver_method='direct')
 with tempfile.TemporaryDirectory() as d:
  c=FrequencyCheckpoints(d,'audit',False);c.save(1.5,x);y=c.load(1.5)
  return dict(available=c.available(1.5),samples_equal=list(x['samples'])==list(y['samples']))

def mixed():
 with linear_precision('mixed'):
  return run(dict(n=120,ka=3))
for name,fn in [('annulus_and_two_layer',layers),('translation_rotation_units',invariance),('checkpoint_roundtrip',recovery),('mixed_precision',mixed)]:record(name,fn)
