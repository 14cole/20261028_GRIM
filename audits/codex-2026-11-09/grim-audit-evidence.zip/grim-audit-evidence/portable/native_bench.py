# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,sys,json,time,ctypes,pathlib,subprocess
sys.path.insert(0,_SOURCE_ROOT)
import numpy as np
from ghost_backend.twod.assembly.native import far
from ghost_backend.twod.assembly.kernels import KernelTable,Rejected
from ghost_backend.twod.assembly.native.build import build_one
root=pathlib.Path(_AUDIT_ROOT+'/native_variant');root.mkdir(exist_ok=True)
s=pathlib.Path(_SOURCE_ROOT + '/ghost_backend/twod/assembly/native/far.c').read_text()
s=s.replace('int *hint, double *out)', 'int *hint, double *out, int want_k)').replace('for (int c = 0; c < 2; ++c)', 'for (int c = 0; c < (want_k ? 2 : 1); ++c)').replace('kernel(&table, dist, &hint, value)', 'kernel(&table, dist, &hint, value, want_k)')
(root/'far.c').write_text(s);lib=build_one(root,'far')
original_dll=far._dll
rng=np.random.default_rng(1);m=64;n=64;q=8;x,w=np.polynomial.legendre.leggauss(q);phi=np.array([(1-x)/2,(1+x)/2]).T
obs=np.stack((rng.random((m,q)),rng.random((m,q))),axis=-1);src=np.stack((3+rng.random((n,q)),rng.random((n,q))),axis=-1);normal=np.tile([0.,1.],(m,1));mask=np.ones((m,n),bool)
table=KernelTable(30,5.)
results={};values=[]
for patch in [False,True]:
 far._dll=(lambda:ctypes.CDLL(str(lib))) if patch else original_dll;far.library.cache_clear()
 times=[]
 for i in range(6):
  t=time.perf_counter();v=far.far_block(table,30,obs,src,w/2,phi,normal,normal,mask,True,True,False,False);times.append(time.perf_counter()-t)
 values.append(v[0]);results[str(patch)]={'times':times,'median_ns_per_sample':np.median(times[1:])*1e9/(m*n*q*q)}
results['bitwise_equal']=np.array_equal(*values);results['relative_error']=float(np.max(abs(values[0]-values[1]))/np.max(abs(values[0])))
far._dll=original_dll;far.library.cache_clear()
results['lossy_tables']=[]
for eps in [1-10j,1-100j,1-1000j]:
 for k0 in [1.,10.,100.,300.]:
  for upper in [.01,.1,1.]:
   row={'eps':str(eps),'k0':k0,'upper':upper}
   for degree in [12,16]:
    try:t=KernelTable(k0*np.sqrt(eps),upper,degree=degree);row[str(degree)]=t.evidence
    except Rejected as e:row[str(degree)]={'rejected':str(e)}
   results['lossy_tables'].append(row)
results['fft']=[]
for n in [1024,1184,1312,1888,2048]:
 from scipy import fft
 a=rng.normal(size=(32,n//2+1))+1j*rng.normal(size=(32,n//2+1));t=time.perf_counter()
 for i in range(100):fft.dct(a,type=1,axis=-1,workers=1)
 results['fft'].append({'n':n,'ns_per_sample':(time.perf_counter()-t)*1e9/(100*a.size)})
with open(_AUDIT_ROOT+'/results/native_bench.json','w') as f:json.dump(results,f,default=str)
print('native',results['False'],results['True'],'bitwise',results['bitwise_equal'],flush=True)
