# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,sys,json,subprocess,pathlib
sys.path.insert(0,_AUDIT_ROOT+'/portable');from run_case import *
from ghost_backend.twod import solver as S
from ghost_backend.linalg.dense import DenseFactor
from ghost_backend.twod.geometry import _build_panels
out={}
import warnings
with warnings.catch_warnings(record=True):
 f=DenseFactor(np.zeros((3,3)));x=f.solve(np.ones(3));out['C2']=dict(nonfinite=int(np.count_nonzero(~np.isfinite(x))),event=f.event)
f=DenseFactor(np.eye(3));out['C2_zero_rhs']=dict(solution=f.solve(np.zeros(3)),event=f.event)
text='Title: floor\nSegment: s 2\nproperties: 2 -1 0 0 0\n0 0 0 10\n0 10 10 10\n10 10 10 0\n10 0 0 0\nIBCS_Resistances:\n\nDielectrics:\n'
p=_build_panels(build_geometry_snapshot(*parse_geometry(text)),1.,1.);out['C5_negative_N']=dict(panels=len(p),max_kL=2*np.pi*max(x.length for x in p))
g=geometry(240);strip=build_geometry_snapshot(*parse_geometry('Title: strip\nSegment: s 2\nproperties: 2 -20 0 0 0\n.25 -.05 .25 .05\nIBCS_Resistances:\n\nDielectrics:\n'))['segments'][0];g['segments'].append(strip)
r=[]
for ka in [2.404,2.4048255577,2.406]:
 try:
  x=S.solve_monostatic_rcs_2d_single_polarization(g,[ka*299792458/(2*np.pi*.1)/1e9],[0.],polarization='TM',geometry_units='meters',solver_method='direct',compute_condition_number=True,strict_quality_gate=False)
  r.append(dict(ka=ka,condition=x['metadata']['condition_est_max'],warnings=x['metadata']['warnings'],formulation=x['metadata']['formulation']))
 except Exception as e:r.append(dict(ka=ka,error=repr(e)))
out['R3g_TM_resonance']=r
with open(_AUDIT_ROOT+'/results/final_checks.json','w') as f:json.dump(out,f,default=encode)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
cases=[('largebor_budget06',dict(n=600,bor=True,ka=3,budget=.06)),('largebor_budget025',dict(n=600,bor=True,ka=3,budget=.25))]
for i,zs in enumerate([[0,100],[0,-100],[50,-200],[.0001,0]]):cases.append((f'lowbor_zs{i}',dict(n=60,bor=True,kind='ibc',ka=.0001,zs=zs)))
for ka in [.001,1.841,2.405,3.832,5.520,10.]:cases.append((f'physics_resonance_{ka}',dict(n=360,ka=ka)))
for name,c in cases:
 subprocess.run(['python',_AUDIT_ROOT + '/portable/run_case.py',json.dumps(c),_AUDIT_ROOT+'/results/'+name+'.json'],env=env,timeout=420,check=True)
