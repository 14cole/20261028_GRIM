# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import subprocess,json,os,pathlib
root=pathlib.Path(_AUDIT_ROOT+'/results');env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
cases=[]
for rep in range(3):
 for floor in [8,6]:cases.append((f'floor_ibc_{rep}_{floor}',dict(kind='ibc',n=1600,ka=80,angle_count=5,w_floor=floor)))
 for coarse in [False,True]:cases.append((f'coarsebor_{rep}_{coarse}',dict(bor=True,n=120,ka=10,near_coarse=coarse)))
for sliver in [False,True]:cases.append((f'sliver_ibc_{sliver}',dict(kind='ibc',n=1200,ka=60,sliver=sliver)))
for basis in [2,3]:cases.append((f'hp_{basis}',dict(n=60,kind='dielectric',ka=3,options=dict(basis_order=basis))))
for n in [5120,8448]:cases.append((f'backend_lowka_{n}',dict(n=n,ka=3,method='auto')))
cases += [('profile_thin',dict(kind='coat',n=700,ka=35,core_ratio=.9973,profile=_AUDIT_ROOT+'/results/thin.pstats')),('profile_bor',dict(bor=True,n=120,ka=10,profile=_AUDIT_ROOT+'/results/bor.pstats'))]
for fb in [False,True]:cases.append((f'capture_{fb}',dict(n=360,ka=18,fallback=fb,capture=f'{_AUDIT_ROOT}/results/matrix_{fb}_')))
for name,c in cases:
 path=root/(name+'.json')
 if path.exists():continue
 print('START',name,flush=True)
 try:subprocess.run(['python',_AUDIT_ROOT + '/portable/run_case.py',json.dumps(c),str(path)],env=env,timeout=420,check=True)
 except Exception as e:path.write_text(json.dumps(dict(config=c,error=repr(e))))
for script in ['micro.py','extended.py','native_bench.py','cert_invariants.py']:
 print('START',script,flush=True)
 try:subprocess.run(['python',_AUDIT_ROOT+'/portable/'+script],env=env,timeout=900,check=True)
 except Exception as e:print(script,repr(e),flush=True)
