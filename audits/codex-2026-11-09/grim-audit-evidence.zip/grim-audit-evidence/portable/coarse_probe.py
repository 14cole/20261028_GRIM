# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import numpy as np
from ghost_backend.bor import kernels as k
def install():
 original=k._refine_near_chunk
 def patched(kind,arrays,ids,stable,base_orders,evaluate,next_orders,out,offset=0):
  stride=k._near_check_stride();fine_orders=next_orders(np.asarray(base_orders))
  if stride>0 and len(ids)>=2*stride and fine_orders is not None:
   coarse=evaluate(ids,base_orders,stable);probe=np.arange(0,len(ids),stride);fine=evaluate(ids[probe],fine_orders,stable);bracket=kind!='g'
   cp=(coarse[0][probe],coarse[1][probe]) if bracket else coarse[probe]
   error,scale=k._near_check(kind,fine,cp)
   if np.all(np.isfinite(error)&(error<=k.NEAR_ANGULAR_RTOL*np.maximum(scale,1e-280))):
    if bracket:out[0][ids]=coarse[0][:,:,offset:];out[1][ids]=coarse[1][:,:,offset:]
    else:out[ids]=2*(coarse[:,0][:,offset:]+1j*coarse[:,1][:,offset:])
    return
  return original(kind,arrays,ids,stable,base_orders,evaluate,next_orders,out,offset)
 k._refine_near_chunk=patched
