# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import os,sys,json,time,traceback,warnings,threading,concurrent.futures
sys.path.insert(0,_SOURCE_ROOT);sys.path.insert(0,_AUDIT_ROOT+'/portable')
import numpy as np
from run_case import geometry,encode
from ghost_backend.twod import operators as op
from ghost_backend.twod.geometry import LinearElement
out={}
def test(name,f):
 try:out[name]=f()
 except Exception as e:out[name]={'error':repr(e),'traceback':traceback.format_exc()}
 print(name, str(out[name])[:500],flush=True)
 with open(_AUDIT_ROOT+'/results/micro.json','w') as h:json.dump(out,h,default=encode)
def elem(a,b,i=0):
 a=np.array(a,float);b=np.array(b,float);d=b-a;L=np.linalg.norm(d);t=d/L
 return LinearElement('t',2,0,0,0,(i,i+1),a,b,(a+b)/2,t,np.array([t[1],-t[0]]),L,i)
def quad():
 a=elem([0,0],[1,0]);b=elem([0,4],[1,4],2);r=[]
 for k in [3,6,8,12,20]:
  lo=op._integrate_linear_pair_box_sk_vectorized(a,b,k,True,(0,1),(0,1),8,8)
  hi=op._integrate_linear_pair_box_sk_vectorized(a,b,k,True,(0,1),(0,1),80,80)
  d={'kL':k,'far':[float(np.max(abs(x-y))/np.max(abs(y))) for x,y in zip(lo,hi)]}
  for angle in [90,150]:
   c=elem([0,0],[np.cos(np.deg2rad(angle)),np.sin(np.deg2rad(angle))],2)
   lo=op._integrate_linear_touching_duffy_sk_vectorized(a,c,k,True,(0,1),(0,1),True,True,20)
   hi=op._integrate_linear_touching_duffy_sk_vectorized(a,c,k,True,(0,1),(0,1),True,True,100)
   d[str(angle)]=[float(np.max(abs(x-y))/max(np.max(abs(y)),1e-300)) for x,y in zip(lo,hi)]
  r.append(d)
 return r

def rng():
 from scipy.sparse.linalg import LinearOperator,onenormest
 from ghost_backend.twod.solver import _deterministic_onenormest
 a=np.random.default_rng(17).normal(size=(60,60));a=np.linalg.inv(a);o=LinearOperator(a.shape,matvec=lambda x:a@x,rmatvec=lambda x:a.T@x,matmat=lambda x:a@x,rmatmat=lambda x:a.T@x)
 result=[]
 for seed in range(6):
  np.random.seed(seed);before=np.random.get_state();raw=float(onenormest(o));after=np.random.get_state();stable=_deterministic_onenormest(o)
  result.append(dict(seed=seed,raw=raw,stable=stable,rng_changed=not np.array_equal(before[1],after[1]) or before[2]!=after[2]))
 return {'exact':np.linalg.norm(a,1),'estimates':result}

def warning_race():
 from ghost_backend.linalg.hierarchical import HierarchicalFactor
 import ghost_backend.linalg.hierarchical as h
 # Exercise the real _lu method with deterministic overlap at its LAPACK call.
 orig=h.la.lu_factor;filters=list(warnings.filters);entered=threading.Event();leave=threading.Event()
 def lu(*args,**kwargs):
  if threading.current_thread().name=='audit-A':entered.set();leave.wait(5)
  else:leave.set();time.sleep(.05)
  return orig(*args,**kwargs)
 h.la.lu_factor=lu
 class Dummy:
  def _reserve(self,count):pass
 def f():HierarchicalFactor._lu(Dummy(),np.eye(3))
 try:
  a=threading.Thread(target=f,name='audit-A');b=threading.Thread(target=f,name='audit-B');a.start();entered.wait(5);b.start();a.join();b.join()
  return {'filters_changed':warnings.filters!=filters,'first_filter':str(warnings.filters[0])}
 finally:h.la.lu_factor=orig;warnings.filters[:]=filters

def concurrency():
 from ghost_backend.twod.solver import solve_monostatic_rcs_2d
 barrier=threading.Barrier(3);g=geometry(68)
 def f(i):
  barrier.wait()
  try:r=solve_monostatic_rcs_2d(g,[1.5],[0.,90.],geometry_units='meters',solver_method='direct');return 'ok'
  except Exception as e:return repr(e)
 with concurrent.futures.ThreadPoolExecutor(3) as ex:return list(ex.map(f,range(3)))

def duplicate():
 from ghost_backend.twod.solver import solve_monostatic_rcs_2d
 r=[]
 for angles in [[0.,0.],[0.,360.]]:
  try:v=solve_monostatic_rcs_2d(geometry(68),[1.5],angles,geometry_units='meters',solver_method='direct');r.append({'angles':angles,'samples':len(v['samples'])})
  except Exception as e:r.append({'angles':angles,'error':repr(e)})
 return r

def bor_kernels():
 from ghost_backend.bor import kernels as k,streaming
 native=streaming._NATIVE;r=[]
 from scipy.integrate import quad_vec
 for gap in [.1,.001,1e-7]:
  args=(np.array([1.]),np.array([0.]),np.array([1.]),np.array([gap]),3.,12)
  streaming._NATIVE=native;a=k.modal_kernels_near(*args)
  streaming._NATIVE=None;b=k.modal_kernels_near(*args)
  # G_m convention is integral over phi, checked against explicit 3D Green function.
  def integrand(phi):
   R=np.sqrt(gap*gap+4*np.sin(phi/2)**2)
   return np.exp(-3j*R)/(4*np.pi*R)*np.cos(np.arange(14)*phi)
  ref=2*quad_vec(integrand,0,np.pi,epsabs=1e-11,epsrel=1e-11,points=[gap,10*gap,100*gap])[0]
  r.append(dict(gap=gap,native_fallback=float(np.max(abs(a-b))/np.max(abs(a))),reference_error=float(np.max(abs(a-ref))/np.max(abs(ref)))))
 streaming._NATIVE=native
 return r

def probes():
 from ghost_backend.execution.options import physical_core_count,_usable_logical_cpus
 from ghost_backend.execution.metrics import SolveMetrics
 import psutil
 r=dict(cpu_count=os.cpu_count(),usable=_usable_logical_cpus(),physical=physical_core_count(),cpu_max=open('/sys/fs/cgroup/cpu.max').read())
 p=psutil.Process()
 for name,fun in [('rss',p.memory_info),('full',p.memory_full_info),('metrics',SolveMetrics().sample_memory)]:
  t=time.process_time()
  for i in range(300):fun()
  r[name+'_us']=(time.process_time()-t)*1e6/300
 return r
def wcheck():
 rng=np.random.default_rng(44);rows=[]
 for kl in [.31,1.,1.5,3.]:
  worst=0.
  for i in range(20):
   angle=rng.uniform(0,2*np.pi);a=elem([0,0],[1,0]);b=elem([0,4],[np.cos(angle),4+np.sin(angle)],2)
   low=op._integrate_linear_pair_box_sk_vectorized(a,b,kl,True,(0,1),(0,1),6,6)[0]
   high=op._integrate_linear_pair_box_sk_vectorized(a,b,kl,True,(0,1),(0,1),48,48)[0]
   lo=op._hypersingular_block_from_s_block(low,kl,a.normal,b.normal,a.length,b.length)
   hi=op._hypersingular_block_from_s_block(high,kl,a.normal,b.normal,a.length,b.length)
   worst=max(worst,float(np.max(abs(lo-hi))/np.max(abs(hi))))
  rows.append(dict(kL=kl,worst_relative_error=worst))
 return rows
for name,fn in [('S1_W_quadrature',wcheck),('C5_quadrature',quad),('C3_rng',rng),('R2_warning_race',warning_race),('R1_concurrency',concurrency),('R3b_duplicate',duplicate),('BOR_kernel_reference',bor_kernels),('S17_S18_R3e_probes',probes)]:test(name,fn)
