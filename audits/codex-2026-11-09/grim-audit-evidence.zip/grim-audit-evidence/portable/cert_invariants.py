# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import sys,os,json,copy,traceback
sys.path.insert(0,_AUDIT_ROOT+'/portable');from run_case import *
from ghost_backend.twod import solver as S
from ghost_backend.bor import dispatch as B
out={}
def record(name,fn):
 try:out[name]=fn()
 except Exception as e:out[name]={'error':repr(e),'traceback':traceback.format_exc()}
 print(name,str(out[name])[:900],flush=True)
 with open(_AUDIT_ROOT+'/results/cert_invariants.json','w') as h:json.dump(out,h,default=encode)
def cert():
 def rect(x0,y0,x1,y1):
  p=[(x0,y0),(x0,y1),(x1,y1),(x1,y0),(x0,y0)]
  return '\n'.join(f'{a[0]} {a[1]} {b[0]} {b[1]}' for a,b in zip(p[:-1],p[1:]))
 head='Title: t\nSegment: d 3\nproperties: 3 -20 0 1 0\n'+rect(-.05,-.03,.05,.03)+'\n'
 tail='IBCS_Resistances:\n\nDielectrics:\n1 3 -.1 1 0\n'
 bodies=['-.05 .08 .05 .08',rect(-.05,.0799,.05,.0801)]
 r=[]
 for body in bodies:
  g=build_geometry_snapshot(*parse_geometry(head+'Segment: s 2\nproperties: 2 -20 0 0 0\n'+body+'\n'+tail))
  x=S.solve_monostatic_rcs_2d_certified(g,[1.5],[0.,45.,90.,135.,270.],geometry_units='meters',solver_method='direct');r.append(x)
 return r

def invariants():
 g=geometry(120);kw=dict(geometry_units='meters',solver_method='direct');angles=[0.,45.,90.]
 a=S.solve_monostatic_rcs_2d(g,[1.5],angles,**kw)
 b=S.solve_bistatic_rcs_2d(g,[1.5],angles,angles,geometry_units='meters')
 def amp(s):return complex(s['rcs_amp_real'],s['rcs_amp_imag'])
 bdiag=[s for s in b['samples'] if s['theta_inc_deg']==s['theta_scat_deg']]
 key=lambda s:(s['polarization'],s['theta_inc_deg']);aa=sorted(a['samples'],key=key);bb=sorted(bdiag,key=key)
 r={'bistatic_diagonal':max(abs(amp(x)-amp(y)) for x,y in zip(aa,bb))/max(abs(amp(x)) for x in aa)}
 for pol in ['TE','TM']:
  x=S.solve_monostatic_rcs_2d_single_polarization(g,[1.5],angles,polarization=pol,**kw)
  matches=[s for s in a['samples'] if s['polarization_internal']==pol]
  r[pol]=max(abs(amp(u)-amp(v)) for u,v in zip(matches,x['samples']))/max(abs(amp(u)) for u in matches)
 # Frequency ordering with fixed mesh primitives.
 f=S.solve_monostatic_rcs_2d(g,[1.,1.5],angles,**kw)
 single=[s for s in f['samples'] if s['frequency_ghz']==1.5]
 r['frequency']=max(abs(amp(u)-amp(v)) for u,v in zip(a['samples'],single))/max(abs(amp(u)) for u in a['samples'])
 return r

def leak():
 import psutil,threading,gc
 r=[];g=geometry(120);p=psutil.Process()
 for i in range(6):
  x=S.solve_monostatic_rcs_2d(g,[1.5],[0.,90.],geometry_units='meters',solver_method='direct');del x;gc.collect()
  r.append(dict(rss=p.memory_info().rss,threads=threading.active_count(),fds=p.num_fds(),children=len(p.children())))
 return r
for name,fn in [('C1_certified',cert),('2D_invariants',invariants),('M3d_repeated_solves',leak)]:record(name,fn)
