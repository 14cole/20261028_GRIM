# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
import sys,time,resource,json
sys.path.insert(0,_AUDIT_ROOT+'/portable');from run_case import geometry
from ghost_backend.twod.solver import solve_bistatic_rcs_2d
from ghost_backend.twod.samples import compact_samples
from contextlib import nullcontext
compact=sys.argv[1]=='compact';g=geometry(68);t=time.perf_counter()
with compact_samples() if compact else nullcontext():
 x=solve_bistatic_rcs_2d(g,[1.5],list(range(361)),list(range(361)),geometry_units='meters')
print(json.dumps(dict(compact=compact,wall=time.perf_counter()-t,rss_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,samples=len(x['samples']))))
