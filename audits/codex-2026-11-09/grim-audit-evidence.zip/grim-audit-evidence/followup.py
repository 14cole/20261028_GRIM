import subprocess,json,os,pathlib
root=pathlib.Path('/workspace/audit/results');env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
for rep in range(3):
 for q in [8,6]:
  c=dict(n=1600,ka=80,kind='ibc',far_uniform=q);p=root/f'uniform_{rep}_{q}.json'
  subprocess.run(['python','/workspace/audit/run_case.py',json.dumps(c),str(p)],env=env,check=True)

extra=[('large2d',dict(n=12000,ka=3,method='auto')),('largebor',dict(n=600,bor=True,ka=3)),('bor_workers2',dict(n=60,bor=True,ka=3,workers=2)),('bor_tables',dict(n=60,bor=True,ka=3,assembly='tables')),('bor_single',dict(n=60,bor=True,ka=3,assembly='tables',table_precision='single')),('bor_compressed',dict(n=60,bor=True,ka=3,bor_options=dict(factorization='compressed')))]
for name,c in extra:
 p=root/(name+'.json')
 try:subprocess.run(['python','/workspace/audit/run_case.py',json.dumps(c),str(p)],env=env,check=True,timeout=420)
 except Exception as e:p.write_text(json.dumps(dict(config=c,error=repr(e))))
subprocess.run(['python','/workspace/audit/last_checks.py'],env=env,check=True,timeout=420)
subprocess.run(['python','/workspace/audit/repairs.py'],env=env,check=True,timeout=120)
