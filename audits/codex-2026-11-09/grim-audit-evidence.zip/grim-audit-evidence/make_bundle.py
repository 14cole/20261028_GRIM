from pathlib import Path
import ast
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
portable = root / 'portable'
portable.mkdir(exist_ok=True)
scripts = [p for p in root.glob('*.py') if p.name not in {'package.py', 'make_bundle.py', 'coverage_data.py'}]
header = '''# Portable copy; only filesystem locations differ from the original harness.
import os as _audit_os
from pathlib import Path as _AuditPath
_AUDIT_ROOT = _audit_os.environ.get('AUDIT_ROOT', str(_AuditPath(__file__).resolve().parent.parent))
_SOURCE_ROOT = _audit_os.environ.get('GHOST_SOURCE', str(_AuditPath(_AUDIT_ROOT) / 'source'))
'''
for path in scripts:
    s = path.read_text()
    s = s.replace("'/workspace/review/tools/GHOST'", '_SOURCE_ROOT')
    s = s.replace("'/workspace/review/tools/GHOST/", "_SOURCE_ROOT + '/")
    s = s.replace("f'/workspace/audit/", "f'{_AUDIT_ROOT}/")
    for other in scripts:
        s = s.replace("'/workspace/audit/" + other.name + "'", "_AUDIT_ROOT + '/portable/" + other.name + "'")
    s = s.replace("'/workspace/audit/'+file", "_AUDIT_ROOT+'/portable/'+file")
    s = s.replace("'/workspace/audit/'+script", "_AUDIT_ROOT+'/portable/'+script")
    s = s.replace("'/workspace/audit/'", "_AUDIT_ROOT+'/'")
    s = s.replace("'/workspace/audit/", "_AUDIT_ROOT+'/")
    s = s.replace("'/workspace/audit'", "_AUDIT_ROOT+'/portable'")
    if path.name == 'repairs.py':
        s = s.replace('ns={};', "ns={'__file__':str(_AuditPath(_AUDIT_ROOT)/'portable'/(file+'.py'))};")
    s = header + s
    assert '/workspace/' not in s, path
    ast.parse(s, filename=str(path))
    (portable / path.name).write_text(s)

report = root / 'REPORT.txt'
s = report.read_text()
for a, b in {
    'festive-keller-nj 5bje': 'festive-keller-nj5bje',
    'a3.0667': 'a 3.0667', "Claude's3.4x": "Claude's 3.4x",
    'a10x10': 'a 10x10', '2D1200': '2D 1200', '2D360': '2D 360',
    'at|k|L20': 'at |k|L=20', 'at|k|L3': 'at |k|L=3', 'at|k|L1': 'at |k|L=1',
    'were~': 'were ~', 'versus~': 'versus ~', 'within~': 'within ~',
    'S-11:600': 'S-11: 600', 'S-13:260642': 'S-13: 260642',
    'budget,23': 'budget, 23', 'at.25': 'at .25', 'at.06': 'at .06',
    "report's1.28": "report's 1.28", 'a1.35': 'a 1.35',
    'decimalGB': 'decimal GB', 'versus.946': 'versus .946',
    'ka.001': 'ka .001', 'ka.01': 'ka .01', 'from.1': 'from .1',
    'workers 1/2,12000': 'workers 1/2, 12000',
    '0.1 m cone-cylinder,3 GHz,N=37 per primitive,mode_tol': '0.1 m cone-cylinder, 3 GHz, N=37 per primitive, mode_tol',
    'pair(0,3),order 192,relative': 'pair (0,3), order 192, relative',
}.items():
    s = s.replace(a, b)
report.write_text(s)

excluded = {'__pycache__', 'portable_smoke.json'}
files = [p for p in root.rglob('*') if p.is_file() and not any(x in excluded for x in p.parts) and p.suffix not in {'.so', '.dll', '.pyc', '.zip'} and p.name != 'bundle_sha256.json']
hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(root/'bundle_sha256.json').write_text(json.dumps(hashes, indent=2))
files.append(root/'bundle_sha256.json')
output = root.parent/'grim-audit-evidence.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, 'grim-audit-evidence/' + str(p.relative_to(root)))
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
print(json.dumps({'bundle': str(output), 'files':len(files), 'bytes':output.stat().st_size, 'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
