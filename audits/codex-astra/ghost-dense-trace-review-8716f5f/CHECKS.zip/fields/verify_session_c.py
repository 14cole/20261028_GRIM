"""Verify host-C field archives and solver times against previous sessions.
Usage: python verify_session_c.py <path-to-ghost-backend-audit>
The independent reference solves the electromagnetic boundary equations mode by mode.
"""
import argparse
import hashlib
import json
from collections import Counter
from itertools import combinations
from pathlib import Path
import subprocess
import sys

import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp


def solve_analytic(polarization, angles):
    k = 2*np.pi*10e9 / 299792458.0
    eps = 2.8 - 0.06j
    refractive_index = np.sqrt(eps)
    q = refractive_index / (1. if polarization == "TM" else eps)
    a, b = k*refractive_index*.100, k*refractive_index*.120
    x = k*.120
    solution = []
    for n in range(91):
        # Three unknowns: outgoing field and the two annular Bessel amplitudes.
        # Continuity of field and scaled radial flux, then PEC core condition.
        aj, ay = (jv(n, a), yv(n, a)) if polarization == "TM" else (jvp(n, a), yvp(n, a))
        mat = np.array([[hankel2(n,x), -jv(n,b), -yv(n,b)],
                        [h2vp(n,x), -q*jvp(n,b), -q*yvp(n,b)], [0., aj, ay]])
        scale = np.max(np.abs(mat), axis=0)
        s = np.linalg.solve(mat/scale, [-jv(n,x), -jvp(n,x), 0.])[0]/scale[0]
        solution.append(s*(-1)**n * (1 if n == 0 else 2))
    phi = np.deg2rad(angles)
    shift = np.exp(2j * k * (.031*np.cos(phi) -.017*np.sin(phi)))
    return -4j * sum(solution) * shift


def metric(test, ref):
    assert test.shape == ref.shape and np.isfinite(test).all() and np.isfinite(ref).all()
    d = abs(test - ref)
    return dict(bit_identical=test.tobytes()==ref.tobytes(), max_over_peak=float(d.max()/max(abs(ref))),
                rel_l2=float(np.linalg.norm(d)/np.linalg.norm(ref)), angle_of_max_deg=int(d.argmax()))


def fields(path, keys):
    with np.load(path, allow_pickle=False) as z:
        assert np.array_equal(z['angles_deg'], np.arange(360.))
        return {k:z[k] for k in keys}


def compare(a, b):
    return {p:metric(a['ghost_'+p], b['ghost_'+p]) for p in ('TM', 'TE')}


def run(audit):
    results = audit/'results'
    rebuilt = subprocess.check_output([sys.executable, str(audit/'summarize.py'), str(results)])
    archived = (results/'summary.json').read_bytes()
    assert rebuilt == archived
    summary=json.loads(rebuilt)
    counts=Counter()
    for row in summary['C_timing']:
        counts[row['host'][0]] += row['runs']
    archives = sorted(p for p in results.glob("c*/*.npz"))
    assert counts == {'A':46,'B':14,'C':5} and len(archives)==65
    modes=['dense_paired_memory','dense_unpaired_memory','dense_disk','compressed']
    labels=modes+['traced_dense']
    pin={label:('c_pairing',f's4224_a360_t4_{label}',label) for label in modes}
    pin['traced_dense']=('c_trace24k','s8448_a360_t4_dense','dense')
    assert set(p for p in archives if p.parent.name in ('c_pairing','c_trace24k')) == {
        results/folder/(name+'.npz') for folder,name,_ in pin.values()}
    keys=[f'{kind}_{p}' for kind in ('ghost','analytic') for p in ('TM','TE')]
    exact={p:solve_analytic(p,np.arange(360.)) for p in ('TM','TE')}
    rows={}
    raw={}
    for label, (folder, stem, logstem) in pin.items():
        log=json.loads((results/folder/(logstem+'.out')).read_text())
        assert log['quality_passed'] and log['angles']==360 and log['threads']==4
        z=fields(results/folder/(stem+'.npz'),keys)
        raw[label]=z
        older_dirs=['c_part2','c_part3','c_drift','c_residual'] if label in modes else ['c_large']
        oldpaths=sorted(p for d in older_dirs for p in (results/d).glob('*.npz')
                        if 'a360_t4' in p.name and p.name.startswith(stem.split('_')[0]+'_')
                        and ('compressed' in p.name)==(label=='compressed'))
        assert oldpaths
        analytic={p:metric(z['ghost_'+p], exact[p]) for p in ('TE','TM')}
        assert all(abs(analytic[p]['max_over_peak']-log['error_'+p])<2e-14 for p in analytic)
        rows[label]=dict(s=log['solve_wall_s'],rss_gib=log['peak_rss_gib'],
            residual=log['residual_max'],storage_reads_bytes=log['process_io']['read_bytes'],
            analytic=analytic, archived_reference_vs_ours={p:metric(z['analytic_'+p],exact[p]) for p in exact},
            against_earlier={str(p.relative_to(results)):compare(z,fields(p,keys)) for p in oldpaths})
        matching=[r for r in summary['C_timing'] if r['host'].startswith('C') and
                  r['unknowns']==log['unknowns_per_system'] and r['requested']==('dense' if label=='traced_dense' else label.replace('_',' '))]
        assert len(matching)==1 and matching[0]['runs']==1 and matching[0]['wall_s']==[rows[label]['s']]
        assert matching[0]['peak_rss_gib']==[rows[label]['rss_gib']] and matching[0]['quality']
    deltas={}
    for a,b in [('dense_unpaired_memory','dense_paired_memory'),('dense_disk','dense_unpaired_memory'),
                ('dense_disk','dense_paired_memory'),('compressed','dense_paired_memory')]:
        deltas[a+' vs '+b]=dict(time_delta_s=rows[a]['s']-rows[b]['s'],
              time_difference_percent=100*(rows[a]['s']/rows[b]['s']-1),
              rss_reduction_gib=rows[b]['rss_gib']-rows[a]['rss_gib'],
              rss_reduction_percent=100*(1-rows[a]['rss_gib']/rows[b]['rss_gib']))
    return dict(summary_sha256=hashlib.sha256(rebuilt).hexdigest(), summary_rebuilt_byte_for_byte=True,
                timing_archive_counts=counts, host_c_in_backend_difference_map=any(k.startswith('C_') for k in summary['C_dense_vs_compressed_max']),
                individual=rows, host_c_all_12k_pairs={a+' vs '+b:compare(raw[a],raw[b]) for a,b in combinations(modes,2)}, costs=deltas)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('audit', type=Path)
    print(json.dumps(run(parser.parse_args().audit),indent=2))

