"""Exercise actual DenseFactor residual/refinement and retained-buffer restore on a tiny disk-backed matrix."""
import argparse
import json
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np


def run(root, mode):
    sys.path.insert(0, str(root / "tools" / "GHOST"))
    from ghost_backend.execution import options
    from ghost_backend.linalg.dense import DenseFactor
    from ghost_backend.linalg.residual_spool import ResidualSpool

    rng = np.random.default_rng(772011)
    n = 96
    matrix = rng.normal(size=(n,n)) + 1j*rng.normal(size=(n,n))
    matrix += (2*n) * np.eye(n)
    check_matrix = matrix.copy()
    want = rng.normal(size=(n, 12)) + 1j*rng.normal(size=(n, 12))
    rhs = matrix @ want
    result = {}

    for width in (1, 4, 12):
        matrix_copy = np.array(matrix, dtype=complex, order="F", copy=True)
        calls = dict(inverse=0, reads_for_residual=0, reads_for_restore=0)
        original_inverse = DenseFactor._apply_inverse
        original_product = ResidualSpool.__matmul__
        original_restore = ResidualSpool.restore_into

        def count_inverse(self, b, return_residual=False):
            calls["inverse"] += 1
            result = original_inverse(self,b,return_residual)
            if mode == "perturb" and return_residual:
                x, inner = result
                assert inner is None
                # Deliberately degraded first estimate. Production's correction is left untouched.
                x = x.copy()
                x[0, :] += 1e-3
                return x, inner
            return result

        def product(self, value):
            calls["reads_for_residual"] += 1
            return original_product(self, value)

        def restore(self, target):
            calls["reads_for_restore"] += 1
            return original_restore(self, target)

        solved = []
        with (options.execution_scope({"factorization": "dense", "dense_residual_storage": "disk", "blas_threads": 1}),
              patch.object(DenseFactor, "_apply_inverse", count_inverse),
              patch.object(ResidualSpool, "__matmul__", product),
              patch.object(ResidualSpool, "restore_into", restore)):
            f = DenseFactor(matrix_copy, owned_matrix=True, force_double=True)
            try:
                assert f.event["residual_storage"] == "disk"
                for start in range(0, rhs.shape[1], width):
                    solved.append(f.solve(rhs[:,start:start+width]))
                # Mirrors successful retained-matrix cleanup in twod/fields.py.
                f.restore_original()
                assert np.array_equal(matrix_copy,check_matrix)
                calls["rhs_groups"] = f.event["rhs_batches"]
                calls["max_backward_error"] = f.event["max_backward_error"]
            finally:
                f.close()
        actual = np.column_stack(solved)
        calls["solution_relative_l2_error"] = float(np.linalg.norm(actual-want)/np.linalg.norm(want))
        scans = calls["reads_for_restore"] + calls["reads_for_residual"]
        calls["logical_coefficient_bytes_read"] = scans * n*n*16
        assert calls["reads_for_restore"] == 1
        assert calls["reads_for_residual"] == calls["inverse"]
        assert calls["rhs_groups"] == 12//width
        if mode == "perturb":
            assert calls["inverse"] > calls["rhs_groups"]
        assert calls["solution_relative_l2_error"] < 1e-13
        result[str(width)] = calls
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("solver_checkout", type=Path)
    a = p.parse_args()
    print(json.dumps({key:run(a.solver_checkout, key) for key in ("unmodified", "perturb")},indent=2))
