# Check the full-residual read count

Run on Linux with NumPy, SciPy and the shipped GHOST source at ed90b65. The synthetic 96-by-96 matrix is diagonally dominant, contains complex doubles, and has 12 independently generated right-hand sides with known solutions.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python refinement_control.py /path/to/ed90b65
```

The test uses the production dense factor, selected disk-backed storage, ordinary residual checks and actual matrix restoration. Counters wrap the inverse, full spool product and restore methods. The first scenario uses the original solver throughout. The second scenario adds a small error to the initial inverse inside the diagnostic so that the shipped refinement loop must correct the solution and check its new residual. Both scenarios verify the known solutions and the restored matrix. Logical bytes count the whole-file products and the final restore from the code path, independently of the operating system cache. This small test measures call counts and numerical correctness. The 24k performance evidence is Claude's trace.
