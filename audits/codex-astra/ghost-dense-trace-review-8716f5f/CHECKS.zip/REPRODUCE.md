# Reproduce the third-host trace review

Set GRIM_ROOT to a checkout or archive of shipped solver revision `ed90b65ff89826274adacae01bcfbafe143e9819` and AUDIT to `audits/claude-2026-11-26/ghost-backend-audit` at commit `8716f5f22cc76e9f792eaa742be2a669c70e501e`. Extract CHECKS.zip to a new directory. Use Python with NumPy, SciPy and GHOST’s normal Linux dependencies. The commands below rerun the numerical analyses and small public-solver controls. The full-size planner probe stops before matrix allocation. Use fresh output paths when rerunning.

```sh
export GRIM_ROOT=/path/to/ed90b65
export AUDIT=/path/to/8716f5f/ghost-backend-audit
export PYTHONPATH="$AUDIT"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
sha256sum -c SHA256SUMS
mkdir -p fresh
python fields/verify_session_c.py "$AUDIT" > fresh/fields.json
python trace/check_trace.py "$AUDIT" > fresh/trace.json
python group/probe_handoff.py "$AUDIT" > fresh/plan.json
python group/real_handoff.py "$AUDIT" fresh/handoff-fields.npz > fresh/handoff.json
python methods/refinement_control.py "$GRIM_ROOT" > fresh/refinement.json
for width in 1 32 256; do python sector/check_sector.py "$width" fresh/sector; done
python sector/check_sector.py compare fresh/sector > fresh/sector-summary.json
```

- **fields** checks the summary against the original run folders and reconstructs an independent cylindrical-wave solution. TE and TM amplitudes are complex. Differences are normalized to peak reference amplitude. The 5 new workers are host C.
- **trace** computes I/O and phase statistics from 114 samples in the original 24k trace and the completed process counters. Kernel storage read bytes are process-attributed. Memory and cache samples refer to the cgroup. The major-fault and pressure columns in Claude’s sampler are system-wide. The late steady-state window is 522–2,267 s.
- **group** runs two pricing probes, one on the full geometry with synthetic headroom and a supplied buffer-size hint, and one with a real retained matrix and controlled headroom. The latter exercises both polarizations numerically. The per-polarization budget in the historical trace is unrecorded. See the REPLAY.md alongside the scripts.
- **methods** directly counts residual and restoration scans using the shipped factor. A test-only perturbation of the first answer forces a refinement in one scenario. The raw output demonstrates that checking a corrected solution causes an additional file scan.
- **sector** performs three fresh, single-threaded, dual-polarization public solves on a 10 GHz PEC cylinder of radius 0.10 m with a coating of outer radius 0.12 m and relative permittivity 2.8 − 0.06i. The 528 outer and 440 inner edges yield 968 panels and 1,496 unknowns per polarization. All 180 monostatic directions run from −90° through +89°. The diagnostic counts full-file product and restore calls and can only narrow the planner-admitted width for the second polarization. A requested cap of 256 gives an effective width of 180. The residual algorithm, quality gate and native solver execute normally in all three trials. The smaller coefficient file can fit in the Linux file cache. These single runs validate numerical behavior and read counts. They do not time the 24k problem.

provenance.json records the verified Git revisions and file counts. environment.json describes the local control worker. Claude’s trace, environment and raw fields remain in the pinned parent repository.
