"""Real TE/TM matrix handoff under controlled TM planning headroom.

Set GRIM_ROOT to shipped ed90b65 and pass Claude's audit folder from 8716f5f.
Two identical 728-unknown solves use disk residuals and the real retained
matrix, session key and production geometric/material ownership check. A
controlled live-availability cap is injected at TM plan construction and its
admission check. All other live allocation checks run normally.
"""
import argparse
import json
import sys
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

import numpy as np

GIB = 2**30


def run(audit, include_credit):
    sys.path.insert(0, str(audit.resolve()))
    from harness import cylinder_geo, fields_of, solve_fixed
    from ghost_backend.twod import solver
    from ghost_backend.twod.assembly import session
    from ghost_backend.execution import dense_memory

    info = {"pol": None, "apply_to_gate": False}
    lookup = session.reusable_dense_bytes
    original_resources = solver._dense_formulation_resources
    original_limit = solver._solve_memory_limit_gb
    original_forecast = dense_memory.forecast
    original_pair = session.plan_paired_assembly
    plans = []

    def resources(mesh, interfaces, polarization, *args, **kwargs):
        result = original_resources(mesh, interfaces, polarization, *args, **kwargs)
        info["pol"] = polarization
        info["owned"] = lookup(mesh, interfaces, polarization, result["formulation"], result["system_dofs"])
        return result

    def limit(resident_gb=0.):
        normal = original_limit(resident_gb)
        if info["apply_to_gate"]:
            return min(normal, info["test_cap"] + resident_gb)
        return normal

    def forecast(dofs, count, width, assembly, solve, extra, eligible, **kwargs):
        args = (dofs, count, width, assembly, solve, extra, eligible)
        first = original_forecast(*args, **kwargs)
        if not kwargs.get("execution") or info["pol"] != "TM":
            return first
        assert info["owned"] == first["matrix_bytes"] and first["residual_storage"] == "disk"
        floor = max(first["phase_bytes"]["assembly"],
                    first["phase_bytes"]["solve"] - 16*12*dofs*(width-1))
        info["test_cap"] = (floor - 1024**2) / GIB
        info["apply_to_gate"] = True
        forecast_credit = info["owned"] / GIB if include_credit else 0.
        with patch.object(solver, "_solve_memory_limit_gb", lambda: limit(forecast_credit)):
            return original_forecast(*args, **kwargs)

    def pair(pol, formulation, dofs, peak, available):
        result = original_pair(pol, formulation, dofs, peak, available)
        plan = dense_memory.current(dofs)
        plans.append(dict(pol=pol, dofs=dofs, batch=plan["angle_batch_size"],
                          matrix_bytes=plan["matrix_bytes"], verified_reusable_bytes=info["owned"],
                          plan_target_gib=plan["selection_target_bytes"]/GIB,
                          gate_target_gib=available, estimated_gib=peak,
                          tile_recovery_setting=plan["assembly_tile"],
                          paired_assembly=plan["paired_assembly"], storage=plan["residual_storage"]))
        info["apply_to_gate"] = False
        return result

    angles = np.arange(-16., 16.)
    text = cylinder_geo(sides=256, a=.10, b=.12, eps=2.8-.06j, mu=1., center=(.031,-.017))
    with ExitStack() as stack:
        for target, name, f in ((solver, "_dense_formulation_resources", resources),
                                (solver, "_solve_memory_limit_gb", limit),
                                (dense_memory, "forecast", forecast), (session, "plan_paired_assembly", pair)):
            stack.enter_context(patch.object(target, name, f))
        # Same explicit tile keeps cache identity identical in both controls.
        result,_ = solve_fixed(text,10.,angles,"dense",threads=1,batch=32,assembly_tile=128,dense_residual_storage="disk")
    fields = fields_of(result)
    meta = result["metadata"]
    assert meta["quality_gate"]["passed"] and len(plans)==2
    for row in plans:
        if row["pol"]=="TE":
            del row["plan_target_gib"],row["gate_target_gib"] # ambient, outside the controlled phase
    stats = dict(plans=plans, stage_calls=meta["runtime_profile"]["stage_calls"], gate_passed=True,
                 max_reported_residual=meta["residual_norm_max"], exact_test_cap_gib=info["test_cap"],
                 retained_matrix_reuses=meta["assembled_system_reuses"])
    return stats,fields


def compare(audit, out):
    first,f = run(audit,False)
    second,s = run(audit,True)
    assert [r["batch"] for r in first["plans"]] == [32,1]
    assert [r["batch"] for r in second["plans"]] == [32,32]
    assert first["retained_matrix_reuses"] == second["retained_matrix_reuses"] == 1
    result=dict(uncorrected=first, owned_credit_in_forecast=second,
                maximum_peak_normalized_difference={p:float(np.max(abs(v-s[p]))/np.max(abs(v))) for p,v in f.items()})
    np.savez_compressed(out, angles_deg=np.arange(-16.,16.), TE_baseline=f["TE"], TM_baseline=f["TM"],
                        TE_repriced=s["TE"], TM_repriced=s["TM"])
    return result


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audit",type=Path)
    parser.add_argument("fields_npz",type=Path)
    opts=parser.parse_args()
    print(json.dumps(compare(opts.audit, opts.fields_npz),indent=2))
