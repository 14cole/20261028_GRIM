# Reproduce the polarization handoff controls

Use Python with NumPy, SciPy and the shipped Linux GHOST dependencies. Set GRIM_ROOT to an ed90b65 production export and AUDIT to the ghost-backend-audit directory from Claude commit 8716f5f. From this directory, run the following.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python probe_handoff.py "$AUDIT" > plan-replay.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python real_handoff.py "$AUDIT" fresh-fields.npz > real-replay.json
```

The first probe uses the public solve entry and full historical 23,936-unknown mesh. It stops at the first TE or TM plan, before allocating a matrix. The historical cohort capacity is archived. The 5 GiB no-credit headroom value and reusable TM hint are supplied by the test. The decision trace identifies the budget received at pricing and admission. The archive shows the observed batch counts and read traffic, but lacks the historical per-polarization headroom measurements.

The second control actually solves both polarizations on 728 unknowns, 32 angles from −16° through +15°, and real disk residuals. It sets TM's uncredited cap 1 MiB below its minimum phase forecast. In both runs the production session checks cache identity and reports the bytes of the real retained TE matrix. In one test the forecast receives the same owned credit as the final gate. For both tests the explicit effective assembly tile is 128, independent of the recovery flag. Both full matrix assembly, LU and the numerical residual checks run. Headroom injection is limited to plan construction and the corresponding admission test. The regular runtime allocation safeguards remain active. Compare the per-channel plans and stage counts in real_handoff.json and the raw fields in real_handoff_fields.npz. Timings of these controls do not estimate a 24k speedup.
