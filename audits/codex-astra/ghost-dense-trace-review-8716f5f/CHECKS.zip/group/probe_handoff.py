"""Exercise the released per-polarization plan before matrix allocation.

Set GRIM_ROOT to ed90b65. Pass the ghost-backend-audit folder from 8716f5f.
The 5 GiB live no-credit value and reusable-buffer hint are controlled inputs.
The archived trace contains no per-polarization live headroom or selected plans.
"""
import argparse
import json
import math
import sys
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

import numpy as np

GIB = 2**30
DOFS = 23936
MATRIX = 16 * DOFS**2


class PlanReached(Exception):
    pass


def run_probe(audit, *, pol, live_gib, include_owned_in_forecast=False):
    from harness import cylinder_geo, solve_fixed
    from ghost_backend.execution import dense_memory
    from ghost_backend.execution.cpu import configured_batch_size
    from ghost_backend.twod import solver
    from ghost_backend.twod.assembly import session

    log = json.loads((audit / "results/c_trace24k/dense.out").read_text())
    budget = log["memory_accounting"]["cohort_capacity_gib"]
    retained = MATRIX if pol == "TM" else 0
    stages = {}
    phase = {"active": False}
    events = []
    old_single = solver.solve_monostatic_rcs_2d_single_polarization
    old_estimate = solver._estimate_memory_gb
    old_forecast = dense_memory.forecast

    def select_channel(*args, **kwargs):
        kwargs["polarization"] = pol
        return old_single(*args, **kwargs)

    def limit(resident_gb=0.):
        if not phase["active"]:
            return budget
        current = min(budget, live_gib + resident_gb)
        events.append({"event": "memory limit", "resident_hint_gib": resident_gb, "limit_gib": current})
        return current

    def forecast(*args, **kwargs):
        if include_owned_in_forecast and phase["active"]:
            with patch.object(solver, "_solve_memory_limit_gb", lambda: limit(retained / GIB)):
                return old_forecast(*args, **kwargs)
        return old_forecast(*args, **kwargs)

    def estimate(*args, **kwargs):
        if kwargs.get("activate_memory_plan"):
            phase["active"] = True
        return old_estimate(*args, **kwargs)

    def reusable(mesh, infos, polarization, formulation, dofs):
        assert (polarization, formulation, dofs) == (pol, "multi_region", DOFS)
        events.append({"event": "verified reusable matrix bytes (simulated)", "bytes": retained})
        return retained

    def capture(polarization, formulation, dofs, estimated, admitted):
        assert (polarization, formulation, dofs) == (pol, "multi_region", DOFS)
        plan = dense_memory.current(dofs)
        width = configured_batch_size()
        assert width == plan["angle_batch_size"]
        stages.update(angle_batch_size=width, hypothetical_outer_calls=math.ceil(360/width),
                      admitted_gib=admitted, forecast_gib=estimated, events=events,
                      forecast_target_gib=plan["selection_target_bytes"]/GIB,
                      predicted_assembly_gib=plan["phase_bytes"]["assembly"]/GIB,
                      predicted_solve_gib=plan["phase_bytes"]["solve"]/GIB,
                      assembly_tile=plan["assembly_tile"], residual_storage=plan["residual_storage"])
        assert estimated <= admitted
        raise PlanReached()

    text = cylinder_geo(sides=8448, center=(.031, -.017), a=.100, b=.120, eps=2.8-.06j, mu=1.)
    with ExitStack() as stack:
        for target, name, override in (
            (solver, "solve_monostatic_rcs_2d_single_polarization", select_channel),
            (solver, "_estimate_memory_gb", estimate),
            (solver, "_solve_memory_limit_gb", limit),
            (dense_memory, "forecast", forecast),
            (dense_memory, "scratch_available", lambda required: (True, None)),
            (session, "reusable_dense_bytes", reusable),
            (session, "plan_paired_assembly", capture),
        ):
            stack.enter_context(patch.object(target, name, override))
        try:
            solve_fixed(text, 10., np.arange(360.), "dense", threads=4)
        except PlanReached:
            pass
    assert stages
    return stages


def calculate(audit):
    sys.path.insert(0, str(audit.resolve()))
    hist = json.loads((audit/"results/c_trace24k/dense.out").read_text())
    summary = {"historical_cohort_capacity_gib":hist["memory_accounting"]["cohort_capacity_gib"],
               "scope":"Planner probe with footprint and admission hints supplied; no numerical matrix allocated."}
    summary["TE_initial"] = run_probe(audit, pol="TE", live_gib=summary["historical_cohort_capacity_gib"])
    summary["TM_tight_uncorrected"] = run_probe(audit, pol="TM", live_gib=5.)
    summary["TM_same_inputs_with_owned_credit_in_forecast"] = run_probe(audit, pol="TM", live_gib=5., include_owned_in_forecast=True)
    outer = hist["stage_calls"]["linear_solve"]
    inner = hist["stage_calls"]["rhs_solve"]
    summary["trace_counts"] = {"outer_rhs_batches":outer, "lu_applications":inner,
                               "extra_refinement_attempts":inner-outer,
                               "bytes_per_coefficient_file":MATRIX,
                               "device_writes_in_matrix_equivalents":hist["process_io"]["write_bytes"]/MATRIX,
                               "device_reads_in_matrix_equivalents":hist["process_io"]["read_bytes"]/MATRIX,
                               "expected_residual_passes":inner, "expected_TE_restore_passes":1}
    assert [summary[k]["angle_batch_size"] for k in ("TE_initial","TM_tight_uncorrected","TM_same_inputs_with_owned_credit_in_forecast")] == [256,1,256]
    assert summary["TE_initial"]["hypothetical_outer_calls"] + summary["TM_tight_uncorrected"]["hypothetical_outer_calls"] == outer
    widened_calls = (summary["TE_initial"]["hypothetical_outer_calls"] +
                     summary["TM_same_inputs_with_owned_credit_in_forecast"]["hypothetical_outer_calls"])
    # DenseFactor.solve tests one full residual and up to five refinements per call.
    low, high = widened_calls+1, widened_calls*6+1
    summary["conditional_wide_batch_spool_bounds"] = {
        "assumptions": "Two disk LU systems, four outer batches, one TE restore, unchanged all-row residual checks",
        "full_logical_reads": [low, high],
        "logical_gib": [low*MATRIX/GIB, high*MATRIX/GIB],
        "lower_bound_percent_fewer_logical_scan_bytes": 100*(1.-high/(inner+1)),
    }
    return summary


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("audit", type=Path)
    print(json.dumps(calculate(p.parse_args().audit), indent=2))

