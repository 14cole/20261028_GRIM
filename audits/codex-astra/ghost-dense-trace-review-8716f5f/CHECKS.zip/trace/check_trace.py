"""Check the third-host 24k Dense trace in Claude's 8716f5f archive."""
import argparse
import json
from pathlib import Path
from statistics import median

GIB = 1024**3


def inspect(audit):
    root = audit / "results"
    trace = root / "c_trace24k"
    dense = json.loads((trace / "dense.out").read_text())
    small = json.loads((root / "c_pairing/dense_disk.out").read_text())
    prior = json.loads((root / "c_large/dense.out").read_text())
    lines = (trace / "samples.txt").read_text().splitlines()
    header = lines[0].split()
    rows = []
    for line in lines[1:]:
        values = line.split()
        assert len(values) == len(header)
        rows.append({k: (v if k.startswith("psi_") else int(v)) for k, v in zip(header, values)})
    stages = dense["stage_seconds"]
    calls = dense["stage_calls"]
    matrix = 16 * dense["unknowns_per_system"]**2
    intervals = []
    for a, b in zip(rows, rows[1:]):
        elapsed = b["t_s"] - a["t_s"]
        assert elapsed > 0
        rates = {k: (b[k] - a[k])/GIB for k in ("read_bytes", "write_bytes", "rchar")}
        assert all(n >= 0 for n in rates.values())
        intervals.append(dict(start=a["t_s"], end=b["t_s"], elapsed_s=elapsed,
                              reads_gib=rates["read_bytes"], writes_gib=rates["write_bytes"],
                              read_gib_per_second=rates["read_bytes"]/elapsed))
    writes = [v for v in intervals if v["writes_gib"]*GIB > matrix/2]
    assert len(writes) == 2
    second = next(r for r in rows if r["t_s"] == writes[1]["start"])
    # Cut the long uninterrupted read phase after its first whole sample interval.
    plateau = [v for v in intervals if v["start"] >= 522]
    plateau_rows = [r for r in rows if r["t_s"] >= 522]
    assert plateau and len(plateau_rows)==len(plateau)+1
    rate = [v["read_gib_per_second"] for v in plateau]
    io = dense["process_io"]
    read = io["read_bytes"]
    stage = stages["linear_solve"]
    rhs = stages["rhs_solve"]
    scratch_writes = [[v["start"], v["end"], v["writes_gib"]] for v in writes]
    bounds = lambda values: [min(values), max(values)]
    return dict(
        trace_count=len(rows), sample_window_s=[rows[0]["t_s"], rows[-1]["t_s"]],
        solve_seconds=dense["solve_wall_s"], host_a_seconds=prior["solve_wall_s"],
        inclusive_linear_s=stage, triangular_seconds=rhs, linear_excluding_nested_rhs_s=stage-rhs,
        inclusive_linear_percent=100*stage/dense["solve_wall_s"],
        non_linear_wall_s=dense["solve_wall_s"]-stage,
        outer_linear_batches=calls["linear_solve"], inverse_applications=calls["rhs_solve"],
        inferred_refinement_attempts=calls["rhs_solve"]-calls["linear_solve"],
        scratch_gib=matrix/GIB, process_lifetime_io=io,
        storage_layer_read_gib=read/GIB, logical_read_gib=io["rchar"]/GIB,
        physical_over_logical_read_fraction=read/io["rchar"],
        physical_full_matrix_equivalents=read/matrix,
        logical_full_matrix_equivalents=io["rchar"]/matrix,
        physical_write_gib=io["write_bytes"]/GIB,
        full_solve_mean_read_gib_s=read/GIB/dense["solve_wall_s"],
        large_write_intervals_s_and_gib=scratch_writes,
        physical_read_equivalents_before_second_write=second["read_bytes"]/matrix,
        physical_read_equivalents_after_second_write=(read-second["read_bytes"])/matrix,
        share_physical_reads_after_second_write=(read-second["read_bytes"])/read,
        sustained_phase_from_s=plateau[0]["start"], sustained_phase_to_s=plateau[-1]["end"],
        sustained_phase_mean_gib_s=sum(v["reads_gib"] for v in plateau)/sum(v["elapsed_s"] for v in plateau),
        sustained_phase_median_gib_s=median(rate), sustained_phase_rate_bounds_gib_s=bounds(rate),
        sustained_cgroup_usage_bounds_gib=bounds([r["cg_usage"]/GIB for r in plateau_rows]),
        sustained_cgroup_file_cache_bounds_gib=bounds([r["cg_cache"]/GIB for r in plateau_rows]),
        sustained_process_rss_bounds_gib=bounds([r["rss_kb"]/1024**2 for r in plateau_rows]),
        max_sampled_cgroup_cache_gib=max(r["cg_cache"] for r in rows)/GIB,
        small_logical_matrix_equivalents=small["process_io"]["rchar"]/(16*small["unknowns_per_system"]**2),
        small_storage_read_bytes=small["process_io"]["read_bytes"],
        small_storage_read_gib=small["process_io"]["read_bytes"]/GIB,
        small_linear_batches=small["stage_calls"]["linear_solve"],
        small_rhs_apply_calls=small["stage_calls"]["rhs_solve"],
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audit", type=Path, help="Path to the pinned ghost-backend-audit directory")
    print(json.dumps(inspect(parser.parse_args().audit), indent=2))
