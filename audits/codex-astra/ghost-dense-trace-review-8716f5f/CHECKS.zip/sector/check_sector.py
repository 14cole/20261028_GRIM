"""Vary only the admitted angle batch upper bound for TM in a fixed-mesh public GHOST solve.

Set GRIM_ROOT to ed90b65 and PYTHONPATH to Claude's pinned audit directory.
Run each width in a fresh Linux process. Count actual residual and restore scans.
"""
import argparse
from collections import Counter
from contextlib import ExitStack
import json
from pathlib import Path
import resource
from unittest.mock import patch

import numpy as np
from harness import cylinder_geo, fields_of, solve_fixed
from reference import stored_amplitude
from ghost_backend.twod import solver, fields
from ghost_backend.linalg.residual_spool import ResidualSpool


def solve(width, out):
    totals = {"TE": Counter(), "TM": Counter()}
    admitted_width = fields.configured_batch_size
    original_solve = solver._solve_multi_region_indirect
    product = ResidualSpool.__matmul__
    restore = ResidualSpool.restore_into

    def by_pol(mesh, infos, pol, *args, **kwargs):
        counts = totals[pol]
        def choose_width():
            planned = admitted_width()
            chosen = min(planned, width) if pol == "TM" else planned
            counts["planned_width"] = planned
            counts["tested_width"] = chosen
            return chosen

        def count_product(spool, rhs):
            counts["residual_scans"] += 1
            return product(spool, rhs)

        def count_restore(spool, matrix):
            counts["restore_scans"] += 1
            return restore(spool, matrix)

        with ExitStack() as stack:
            stack.enter_context(patch.object(fields, "configured_batch_size", choose_width))
            stack.enter_context(patch.object(ResidualSpool, "__matmul__", count_product))
            stack.enter_context(patch.object(ResidualSpool, "restore_into", count_restore))
            return original_solve(mesh, infos, pol, *args, **kwargs)

    shape = dict(a=.10, b=.12, center=(.031, -.017), eps=2.8-.06j, mu=1.)
    angles = np.arange(-90.,90.)
    geometry = cylinder_geo(sides=528, **shape)
    with patch.object(solver, "_solve_multi_region_indirect", by_pol):
        result, elapsed = solve_fixed(geometry, 10., angles, "dense", threads=1, dense_residual_storage="disk")
    metadata = result["metadata"]
    assert metadata["quality_gate"]["passed"]
    numerical = fields_of(result)
    arrays = {"angles_deg":angles}
    errs = {}
    for pol in totals:
        exact = stored_amplitude(pol,10.,angles,**shape)
        arrays["ghost_"+pol] = numerical[pol]
        arrays["analytic_"+pol] = exact
        errs[pol] = float(np.max(np.abs(numerical[pol]-exact))/np.max(np.abs(exact)))
    assert totals["TE"]["restore_scans"] == 1 and totals["TM"]["restore_scans"] == 0
    assert totals["TE"]["tested_width"] >= len(angles), totals
    assert totals["TM"]["tested_width"] == min(width, totals["TM"]["planned_width"]), totals
    assert totals["TM"]["planned_width"] >= len(angles), totals
    sysinfo = metadata["experimental_cpu"]["systems"]
    assert len(sysinfo)==2 and all(x["residual_storage"]=="disk" for x in sysinfo)
    out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out/f"tm_{width}.npz",**arrays)
    raw = {"tm_cap":width,"stage_calls":metadata["runtime_profile"]["stage_calls"],
           "quality_passed":metadata["quality_gate"]["passed"],"systems":sysinfo,
           "panels":metadata["panel_count"],"dofs":metadata["dense_largest_system"],
           "residual_max":metadata["residual_norm_max"],"observed_scans":totals,
           "max_vs_reference":errs,"solve_s":elapsed,
           "peak_process_rss_gib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2}
    (out/f"tm_{width}.json").write_text(json.dumps(raw,indent=2,default=str)+"\n")
    print(width,raw["dofs"],totals,raw["solve_s"])


def compare(out):
    rows = []
    with np.load(out/"tm_256.npz") as ref:
        for width in (1,32,256):
            table = json.loads((out/f"tm_{width}.json").read_text())
            counts = table["observed_scans"]
            with np.load(out/f"tm_{width}.npz") as z:
                assert np.array_equal(z["angles_deg"],np.arange(-90.,90.))
                delta = {p:float(np.max(np.abs(z["ghost_"+p]-ref["ghost_"+p]))/np.max(np.abs(ref["ghost_"+p]))) for p in ("TE","TM")}
            rows.append(dict(tm_width=width,max_vs_full_width=delta,observed_scans=counts,
                             total_scans=sum(v.get("restore_scans",0)+v["residual_scans"] for v in counts.values()),
                             rhs_applications=table["stage_calls"]["rhs_solve"],outer_calls=table["stage_calls"]["linear_solve"],
                             residual_max=table["residual_max"],err_vs_circle=table["max_vs_reference"],
                             solve_s=table["solve_s"],rss_gib=table["peak_process_rss_gib"]))
    print(json.dumps(rows,indent=2))


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=["1","32","256","compare"])
    p.add_argument("output",type=Path)
    opt=p.parse_args()
    if opt.action=="compare": compare(opt.output)
    else: solve(int(opt.action),opt.output)
