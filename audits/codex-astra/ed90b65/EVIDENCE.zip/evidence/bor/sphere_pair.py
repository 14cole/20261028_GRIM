"""Compare fresh BoR processes on a PEC sphere with and without its shared library."""
import json
import sys
from common import bor_sphere, scene
from ghost_backend.bor import dispatch, kernels, streaming
from ghost_backend.validation.sphere import sigma_pec_sphere

mode = sys.argv[1]
assert streaming._NATIVE is not None
if mode == "fallback":
    streaming._NATIVE = None
assert (kernels._native_entry("near_green_rule") is None) == (mode == "fallback")
radius = 0.08
ka = 3.3
frequency_hz = ka * 299792458 / (2 * 3.141592653589793 * radius)
geometry = scene([("sphere", 2, "2 1 0 0 0", bor_sphere(radius, 60))])
result = dispatch.solve_monostatic_rcs_bor(
    geometry, [frequency_hz / 1e9], [0, 33, 89, 180],
    geometry_units="meters", workers=1
)
samples = [float(sample["rcs_linear"]) for sample in result["samples"]]
with open(mode + "-sphere.json", "w") as out:
    json.dump(dict(ka=ka, radius_m=radius, meridian_segments=60,
                   angles_deg=[0,33,89,180], samples=samples,
                   mie=float(sigma_pec_sphere(radius, frequency_hz))), out, indent=2)
