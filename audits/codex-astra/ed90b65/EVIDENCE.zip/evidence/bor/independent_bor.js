/* Independent full-circle reference versus two orders of meridian quadrature for the published two-pair stress case. */
const evidence = (function () {
function legendre(n){const nodes=[];for(let i=1;i<=Math.ceil(n/2);i++){let x=Math.cos(Math.PI*(i-.25)/(n+.5)),d;for(let it=0;it<15;it++){let prev=0,cur=1;for(let j=1;j<=n;j++){let next=((2*j-1)*x*cur-(j-1)*prev)/j; prev=cur;cur=next;}d=n*(x*cur-prev)/(x*x-1);let dx=cur/d;x-=dx;if(Math.abs(dx)<2e-16)break;}let w=2/((1-x*x)*d*d);nodes.push([.5*(1+x),.5*w]);if(Math.abs(x)>1e-16)nodes.push([.5*(1-x),.5*w]);}return nodes.sort((a,b)=>a[0]-b[0]);}
function projected(r,z,mode){const k=80, top=93, a=2*r, delta=z/a, xi=2*Math.asin(.25),intervals=[],P=Math.PI;
if(mode==="periodic"){for(let j=0;j<4096;j++){intervals.push([2*P*j/4096,2*P/4096]);}}
else{if(Math.ceil(Math.log2(.25/(20*delta)))>0)throw Error("fixture expected empty middle");const grow=mode==="fine"?1.5:1,order=(base,slope,phase)=>Math.ceil(grow*4*Math.ceil((base+slope*phase+2*Math.cbrt(phase))/4));const levels=[order(12,.42,top*xi+k*a*.25),order(10,.25,top*(P-xi)+k*a*.75)],vmax=Math.asinh(.25/delta);
for(let [u,w] of legendre(levels[0])){const v=u*vmax,s=delta*Math.sinh(v);intervals.push([2*Math.asin(s),4*w*vmax*delta*Math.cosh(v)/Math.sqrt(1-s*s)]);}
for(let [u,w] of legendre(levels[1]))intervals.push([xi+u*(P-xi),2*w*(P-xi)]);}
let acc=Array.from({length:top+1},()=>[0,0]);for(const [ang,wt] of intervals){const R=Math.hypot(z,a*Math.sin(ang/2)),f=wt/(4*P*R),re=f*Math.cos(k*R),im=-f*Math.sin(k*R);for(let m=0;m<=top;m++){let c=Math.cos(m*ang);acc[m][0]+=re*c;acc[m][1]+=im*c;}}return acc;}
function delta(f,t){return Math.max(...f.map(([re,im],i)=>Math.hypot(re-t[i][0],im-t[i][1])))/Math.max(...t.map(([a,b])=>Math.hypot(a,b)));}
const result={};for(let [key,r,z] of [["probed",1.0140625,.1017733529476957],["unprobed",1.1390625,.11898510425967053]]){let exact=projected(r,z,"periodic"),coarse=projected(r,z,"coarse"),fine=projected(r,z,"fine");result[key]={coarse_against_periodic:delta(coarse,exact),fine_against_periodic:delta(fine,exact),coarse_fine:delta(coarse,fine)};}return result;
})();
console.log(JSON.stringify(evidence,null,2));
