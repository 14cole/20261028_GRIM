"""Reproduce GHOST packaging and speed diagnostic findings on Linux x86-64.

Run using a Python with GHOST's runtime dependencies, setuptools and wheel:
    python reproduce_distribution.py /path/to/GRIM --output /tmp/new-output

Copies tools/GHOST to a temporary directory. Original libraries are untouched.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile


def process(args, cwd, env, *, check=True):
    return subprocess.run([sys.executable, "-B", *map(str, args)], cwd=cwd, env=env,
                          check=check, capture_output=True, text=True)


def check_paths(stage, env, label):
    diagnostic = process([stage / "scripts/check_speed_paths.py"], stage, env, check=False)
    code = """import json
from ghost_backend.twod.assembly.native import far, near
print(json.dumps([near.available(), far.library() is not None,
                  far.scatter_library() is not None, far.tile_library() is not None]))
"""
    actual = json.loads(process(["-c", code], stage, env).stdout)
    return {"case": label, "diagnostic_exit": diagnostic.returncode,
            "diagnostic_stdout": diagnostic.stdout.splitlines(),
            "actual_near_far_scatter_tile": actual}


def archive_record(path):
    notice = b"Copyright (c) 2019, threadpoolctl contributors"
    if path.suffix == ".gz":
        with tarfile.open(path) as archive:
            payload = {m.name: archive.extractfile(m).read()
                       for m in archive.getmembers() if m.isfile()}
    else:
        with zipfile.ZipFile(path) as archive:
            payload = {n: archive.read(n) for n in archive.namelist()}
    return {"artifact": path.name,
            "vendored_module": [n for n in payload if n.endswith("/_threadpoolctl.py")],
            "upstream_notice": [n for n, data in payload.items() if notice in data],
            "kernels": [n for n in payload if n.endswith((".so", ".dll"))]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--output", required=True, type=Path,
                        help="New directory for raw build log and JSON results")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    with tempfile.TemporaryDirectory(prefix="astra-ghost-distribution-") as temp:
        stage = Path(temp) / "GHOST"
        shutil.copytree(args.repo.resolve() / "tools/GHOST", stage,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".venv",
                                                     "build", "dist", "*.egg-info"))
        env["PYTHONPATH"] = str(stage)
        native = stage / "ghost_backend/twod/assembly/native"
        records = [check_paths(stage, env, "shipped libraries")]
        if not all(records[0]["actual_near_far_scatter_tile"]):
            raise RuntimeError(f"Host cannot exercise shipped native paths: {records[0]}")
        near = native / "libghost_near.so"
        near.rename(near.with_suffix(".hidden"))
        records.append(check_paths(stage, env, "missing 2-D near library"))
        near.with_suffix(".hidden").rename(near)
        far = native / "libghost_far.so"
        far.rename(far.with_suffix(".hidden"))
        shutil.copyfile(native / "libghost_table.so", far)
        records.append(check_paths(stage, env, "loadable far library missing its exports"))
        far.unlink()
        far.with_suffix(".hidden").rename(far)
        build_dir = Path(temp) / "dist"
        build = process([stage / "scripts/build_distribution.py", "--native", "--output",
                         build_dir], stage, env, check=False)
        (out / "build.log").write_text(build.stdout + build.stderr)
        build.check_returncode()
        archives = [archive_record(p) for p in sorted(build_dir.iterdir())
                    if p.suffix in (".whl", ".zip", ".gz")]
    report = {"diagnostic": records, "packages": archives}
    (out / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(out / "results.json")


if __name__ == "__main__":
    main()
