"""Reproduce the Linux memory probe for a root and nested cgroup without allocating RAM.

Usage: python probe_nested_cgroup.py path/to/tools/GHOST/ghost_backend/twod/solver.py
The only source executed is the three release functions named below, selected from a
Git-blob-verified module. Hardware, scheduler, RSS, and the proc/cgroup filesystem
are deterministic test doubles.
"""
import ast
from hashlib import sha1
import io
import json
import pathlib
import sys

SOURCE_SHA = "8e15267ce9c7444d599cca5e6ec0e03934861e19"
GIB = 2**30
PATH = "/sys/fs/cgroup"
READS = {"_cgroup_available_bytes", "_detect_available_gb", "_read_cgroup_int"}

def load_source(path):
    content = path.read_bytes()
    digest = sha1(b"blob " + str(len(content)).encode("ascii") + b"\0" + content).hexdigest()
    if digest != SOURCE_SHA:
        raise ValueError(f"Expected {SOURCE_SHA}, got {digest}. Use the pinned source.")
    tree = ast.parse(content)
    observed = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in READS]
    assert {node.name for node in observed} == READS
    return compile(ast.Module(body=observed, type_ignores=[]), str(path), "exec")

def run_case(source, name, limits, usage, self_group, expected):
    files = {"/proc/self/cgroup": f"0::{self_group}\n",
             "/proc/self/mountinfo": "32 31 0:28 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n"}
    for group, limit in limits.items():
        files[PATH + group + "/memory.max"] = str(limit) + "\n"
        files[PATH + group + "/memory.current"] = str(usage[group]) + "\n"
    reads = []
    def read(path):
        reads.append(path)
        if path not in files:
            raise FileNotFoundError(path)
        return io.StringIO(files[path])
    ns = {"open": read, "_psutil_available_bytes": lambda: 24*GIB,
          "_slurm_available_bytes": lambda: None, "_process_rss_bytes": lambda: GIB//4,
          "_BYTES_PER_GIB": GIB}
    exec(source, ns)
    actual = ns["_detect_available_gb"]()
    return {"case": name, "expected_available_gib": expected, "detected_available_gib": actual,
            "overestimated_gib": actual - expected, "cgroup_path": self_group,
            "fixture": files, "paths_read": reads}

def main():
    probe = load_source(pathlib.Path(sys.argv[1]))
    root = run_case(probe, "control: process and finite limit at mount root",
                    {"": 2*GIB}, {"": GIB}, "/", 1)
    nested = run_case(probe, "process in child with finite limit",
                      {"": "max", "/job": 2*GIB}, {"": 8*GIB, "/job": GIB}, "/job", 1)
    ancestor = run_case(probe, "tight parent with uncapped child and finite mount root",
                        {"":32*GIB, "/job": 2*GIB, "/job/worker": "max"},
                        {"":8*GIB, "/job":GIB, "/job/worker":GIB//4}, "/job/worker", 1)
    assert root["detected_available_gib"] == 1
    assert nested["detected_available_gib"] == ancestor["detected_available_gib"] == 24
    print(json.dumps({"main": "ed90b65ff89826274adacae01bcfbafe143e9819",
                      "source_blob": SOURCE_SHA, "cases": [root, nested, ancestor]}, indent=2))

if __name__ == "__main__":
    main()
