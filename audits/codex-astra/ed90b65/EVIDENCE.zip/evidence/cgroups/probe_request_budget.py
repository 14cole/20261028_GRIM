"""Probe the intact GHOST memory ledger using the saved procfs fixture.

Set PYTHONPATH to the pinned release's tools/GHOST directory. Run the
standalone probe first and pass its JSON as this script's only argument.
Requires Linux, NumPy and SciPy; never allocates the tested RAM.
"""
from contextlib import ExitStack
import hashlib
import io
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

from ghost_backend.execution.memory_budget import MemoryBudget
from ghost_backend.twod import solver

def run():
    fixture = json.loads(Path(sys.argv[1]).read_text())
    data = Path(solver.__file__).read_bytes()
    sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert sha == fixture["source_blob"] and sys.platform.startswith("linux")
    cases = []
    for case in fixture["cases"]:
        def read(path):
            try:
                value = case["fixture"][path]
            except KeyError:
                raise FileNotFoundError(path) from None
            return io.StringIO(value)

        with ExitStack() as stack:
            stack.enter_context(patch.dict(os.environ, {}, clear=True))
            stack.enter_context(patch.object(solver, "open", read, create=True))
            stack.enter_context(patch.object(solver, "_psutil_available_bytes", return_value=24*2**30))
            budget = MemoryBudget()
            actual = budget.limit()
            assert abs(actual - 0.9 * case["detected_available_gib"]) < 1e-10
            cases.append({"case": case["case"], "true_headroom_gib": case["expected_available_gib"],
                          "expected_budget_gib": 0.9 * case["expected_available_gib"],
                          "detected_available_gib": budget.last["available_gib"],
                          "actual_budget_gib": actual})
    print(json.dumps({"solver_blob":sha,"request_budget_cases":cases},indent=2))

if __name__ == "__main__":
    run()
