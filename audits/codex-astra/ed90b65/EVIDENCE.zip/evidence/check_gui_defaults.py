"""Check the default GUI controls, real automatic mesh run and ranking at its threshold.

PYTHONPATH=<repo>/tools/GHOST QT_QPA_PLATFORM=offscreen python check_gui_defaults.py
"""
import json
import math
import time
from pathlib import Path
from tempfile import TemporaryDirectory

from PySide6.QtWidgets import QApplication, QMessageBox
from ghost_backend.execution.policy import rank_automatic
from ghost_backend.ui.solver import SolverTab


class ObservedTab(SolverTab):
    def _on_solver_progress(self, pct, message):
        super()._on_solver_progress(pct, message)
        self.ranges.add((self.progress.minimum(), self.progress.maximum()))
        if self._is_solving:
            self.callbacks += 1


def main():
    app = QApplication([])
    tab = ObservedTab()
    tab.ranges = set()
    tab.callbacks = 0
    errors = []
    QMessageBox.critical = lambda _, title, message: errors.append([title, message])
    QMessageBox.warning = lambda _, title, message: errors.append([title, message])
    choices = tab.twod_options_widget.value()
    assert choices['factorization'] == 'automatic'
    assert choices['mesh_strategy'] == 'adaptive' and tab.cmb_mesh_workflow.currentData() == 'automatic'
    candidates = {'dense': {'peak_gb': 3, 'cost': 1}, 'compressed': {'peak_gb': 2, 'cost': 1}}
    ranks = [rank_automatic(candidates, budget, n)[0] for budget, n in ((10,9999), (10,10000), (2.5,9999))]
    assert ranks == ['dense', 'compressed', 'compressed']
    with TemporaryDirectory() as directory:
        geo = Path(directory) / 'regular-polygon.geo'
        phis = [-math.tau * i / 32 for i in range(32)]
        points = [(0.2*math.cos(phi),0.2*math.sin(phi)) for phi in phis]
        rows = [' '.join(map(str, (*a, *b))) for a, b in zip(points, points[1:] + points[:1])]
        geo.write_text('Title: regular PEC polygon\nSegment: body 2\nproperties: 2 -200 0 0 0\n'+'\n'.join(rows)+'\n')
        tab.edit_geo_path.setText(str(geo))
        tab.cmb_units.setCurrentText('meters')
        tab.cmb_freq_mode.setCurrentIndex(0)
        tab.edit_freq_list.setText('1')
        tab.cmb_elev_mode.setCurrentIndex(0)
        tab.edit_elev_list.setText(','.join(map(str, range(-90,90))))
        tab.chk_export_after_solve.setChecked(False)
        tab._run_solver()
        assert tab._solve_thread is not None, errors
        deadline = time.monotonic()+300
        while tab._job_is_active() or tab._solve_thread is not None:
            app.processEvents()
            if time.monotonic() > deadline:
                raise RuntimeError('default automatic run timed out')
            time.sleep(.005)
        assert not errors, errors
        md = tab.last_result['metadata']
        mesh = md['mesh_convergence']
        report = dict(startup=choices, rank_controls=ranks, ranges=sorted(tab.ranges),
                      callbacks=tab.callbacks, terminal_value=tab.progress.value(),
                      gate=md['quality_gate']['passed'], certified=md['mesh_convergence_certified'],
                      mesh={channel: {k: data[k] for k in ('base_panel_count','fine_panel_count',
                            'base_polynomial_degree','fine_polynomial_degree','refinement_kind','published_mesh')}
                            for channel, data in mesh['channels'].items()})
        print(json.dumps(report,indent=2))
        assert report['gate'] and report['certified'] and report['terminal_value']==100
        assert tab.ranges == {(0, 0)} and set(mesh['channels']) == {'VV', 'HH'}
        assert all(data['fine_polynomial_degree'] > 1 for data in mesh['channels'].values())
    tab.close()


if __name__ == '__main__':
    main()
