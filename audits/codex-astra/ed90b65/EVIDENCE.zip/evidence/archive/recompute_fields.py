"""Recompute paired comparisons from Claude's hash-pinned scale/sweep arrays.

Supply the four *65536.npz arrays and fields_and_row_checks.npz from the
audits/claude-2026-11-14 and -11-15 results directories, in any order.
"""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

HASHES = {
    "cap-only-65536.npz": "8e4751334fe15a0c518d68953f2a4df2f7219697",
    "combined-65536.npz": "cc04e677293722bf3683dea57a470ddbfffa4cb9",
    "mixed-65536.npz": "8ba0dce509a5b17e53ee3177033432108583206e",
    "fmm-65536.npz": "aa51670f9fde6963b321f6b5debb4481b63e54df",
    "fields_and_row_checks.npz": "b1916d603fd523032d7bd971476a9631fcf3fed4",
}

def compare(candidate, reference):
    assert candidate.shape == reference.shape
    assert np.isfinite(candidate).all() and np.isfinite(reference).all()
    delta = candidate - reference
    return {"shape": list(reference.shape),
            "relative_max": float(np.max(np.abs(delta))/np.max(np.abs(reference))),
            "relative_2": float(np.linalg.norm(delta.ravel())/np.linalg.norm(reference.ravel()))}

def main(files):
    paths = {p.name: p for p in map(Path, files)}
    assert set(paths) == set(HASHES)
    for name, path in paths.items():
        data = path.read_bytes()
        sha = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert sha == HASHES[name], (name, sha)

    results = {}
    base = "cap-only-65536.npz"
    with np.load(paths[base], allow_pickle=False) as ref:
        for case in ("combined-65536.npz", "mixed-65536.npz", "fmm-65536.npz"):
            with np.load(paths[case], allow_pickle=False) as cmp:
                for key in ("rhs", "angles", "observation"):
                    np.testing.assert_array_equal(cmp[key], ref[key])
                results[case+" vs "+base] = {key: compare(cmp[key],ref[key]) for key in ("field", "density")}
    with np.load(paths["fields_and_row_checks.npz"], allow_pickle=False) as ds:
        a, b = "c32k-fmm-rightblock-v2-tol1e-4-180", "c32k-compressed-180"
        np.testing.assert_array_equal(ds["angles/"+a], ds["angles/"+b])
        np.testing.assert_array_equal(ds["angles/"+b], np.arange(-90,90))
        results["32k FMM v2 vs Compressed"] = compare(ds[a+"/field"],ds[b+"/field"])
    print(json.dumps({"source_ref":"7a5e9fdabe0e22de1fd74ef01bb4a22f07567733",
                      "verified_blobs":HASHES, "comparisons":results},indent=2))

if __name__ == "__main__":
    main(sys.argv[1:])
