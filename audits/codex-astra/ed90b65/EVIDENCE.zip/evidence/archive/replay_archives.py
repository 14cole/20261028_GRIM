"""Replay pinned Claude JSON records; all benchmark timing comes from those records.

Run with --cache PATH for an offline mirror of the input paths, or omit it
to download the pinned public JSON files. The comparison needs NumPy/SciPy.
"""
import argparse
import json
from pathlib import Path
from urllib.request import urlopen
import numpy as np
from scipy import special

COMMIT = "7a5e9fdabe0e22de1fd74ef01bb4a22f07567733"
ROOT = f"https://raw.githubusercontent.com/14cole/20261028_GRIM/{COMMIT}/"
INTEGRATION = "audits/claude-2026-11-17/hmatrix-production-integration-review/results/"
FEW = "audits/claude-2026-11-14/fmm-scale-response-review/results/"
MANY = "audits/claude-2026-11-15/monostatic-sweep-review/results/"
CASES = ("pec-circle-TE","pec-cavity-TM","coated-TE","partial-TE","partial-TM","multilayer-TM")


def fields(rows):
    angles = np.array([r["theta_inc_deg"] for r in rows])
    values = np.array([complex(r["rcs_amp_real"], r["rcs_amp_imag"]) for r in rows])
    assert len(np.unique(angles)) == len(angles) == 180 and np.isfinite(values).all()
    return angles, values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--output", type=Path, default=Path("archive_replay.json"))
    args = parser.parse_args()
    def read(path):
        if args.cache:
            return json.loads((args.cache/path).read_text())
        with urlopen(ROOT+path, timeout=60) as f:
            return json.load(f)
    result = {"review":COMMIT, "hmatrix":[], "timing_records":{}}
    for case in CASES:
        old, new = [read(INTEGRATION+stage+"-"+case+"-compressed.json")
                    for stage in ("old","new")]
        oa, of = fields(old["samples"])
        na, nf = fields(new["samples"])
        assert np.array_equal(oa, na)
        same = of.tobytes() == nf.tobytes()
        assert same and new["metadata"]["quality_gate"]["passed"]
        result["hmatrix"].append(row := {"case":case,"angles":len(na),
            "fields_identical":same,"unknowns":new["metadata"]["dense_largest_system"],
            "old_peak_GiB":old["peak_gib"],"new_peak_GiB":new["peak_gib"]})
        if case in CASES[:3]:
            dense = read(INTEGRATION+"dense-"+case+".json")
            da, df = fields(dense["samples"])
            assert np.array_equal(da, na)
            row["vs_dense_peak_normalized_max"] = float(np.max(abs(nf-df))/np.max(abs(df)))
        if case == "pec-circle-TE":
            # 3 m diameter, 5 GHz, circular PEC with Neumann boundary.
            x = np.pi*dense["spec"]["frequency_ghz"]*1e9*dense["spec"]["length_m"]/299792458
            def reference(last_mode):
                n = np.arange(last_mode+1)
                coefficients = -special.jvp(n,x)/special.h2vp(n,x)
                return -4j*np.sum(coefficients * np.where(n==0, 1, 2*(-1.)**n))
            ref = reference(226)
            assert abs(ref - reference(256)) < 1e-12
            row["analytic_complex_amplitude"] = [ref.real,ref.imag]
            row["max_relative_analytic_field_error"] = float(np.max(abs(df-ref))/abs(ref))
    for label, folder, file in (
        ("65536_2rhs_compressed_cap",FEW,"cap-only-65536.time"),
        ("65536_2rhs_compressed_combined",FEW,"combined-65536.time"),
        ("65536_2rhs_fmm_mixed",FEW,"mixed-65536.time"),
        ("32768_180rhs_compressed",MANY,"c32k-compressed-180.time.json"),
        ("32768_180rhs_fmm",MANY,"c32k-fmm-rightblock-v2-tol1e-4-180.time.json"),
    ):
        rec = read(folder+file)
        assert rec["rc"] == 0
        result["timing_records"][label] = {"seconds":rec.get("wall_seconds",rec.get("wall_s")),
                                            "peak_GiB":rec["peak_gib"],"path":folder+file}
    star = read(INTEGRATION+"new-star32768-cap2900.json")
    result["capped_hmatrix_32768"] = {"angles":len(star["angles"]),
                                     "peak_GiB":star["peak_gib"],
                                     "mesh_certified":star["mesh_certified"],
                                     "production_certified":star["production_certified"],
                                     "rhs_columns":star["event"]["max_rhs_columns"]}
    args.output.write_text(json.dumps(result, indent=2)+"\n")


if __name__ == "__main__":
    main()
