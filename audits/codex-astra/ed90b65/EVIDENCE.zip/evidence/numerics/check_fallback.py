"""Use an isolated source copy without GHOST's shipped binaries.

Pass --ghost-source /path/to/tools/GHOST, then --native-results pointing
to the output directory of cylinder_check.py, run with the native libraries.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import numpy as np


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ghost-source", type=Path, required=True)
    p.add_argument("--native-results", type=Path, required=True)
    p.add_argument("--output", type=Path, default=Path("fallback"))
    args = p.parse_args()
    output = args.output.resolve()
    script = Path(__file__).resolve().with_name("cylinder_check.py")
    output.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory() as tmp:
        source = Path(tmp) / "ghost_backend"
        shutil.copytree(args.ghost_source / "ghost_backend", source, ignore=
            shutil.ignore_patterns("*.so", "*.dll", "*.dylib", "__pycache__", "*.pyc"))
        env = dict(os.environ, PYTHONPATH=tmp, OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
        subprocess.run([sys.executable, str(script), "--materials", "magnetic_dielectric",
                        "--panels", "512", "--output", str(output)], env=env, check=True)
    native = json.loads((args.native_results/"numerical_results.json").read_text())
    fallback = json.loads((output/"numerical_results.json").read_text())
    assert all(native["can_load_native"].values()) and not any(fallback["can_load_native"].values())
    with np.load(args.native_results/"complex_fields.npz") as a, np.load(output/"complex_fields.npz") as b:
        diffs = {k: float(np.linalg.norm(b[k]-a[k])/np.linalg.norm(a[k])) for k in b.files}
    assert len(diffs) == 4 and max(diffs.values()) < 1e-10
    (output/"comparison.json").write_text(json.dumps(diffs, indent=2)+"\n")


if __name__ == "__main__":
    main()
