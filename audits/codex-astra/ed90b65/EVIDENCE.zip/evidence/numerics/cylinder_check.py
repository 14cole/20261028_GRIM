"""Compare GHOST's public solver to a cylindrical-wave boundary match.

Run from an empty output directory with the tested tools/GHOST on PYTHONPATH.
Inputs are analytic polygons generated below. No expected outputs are read.
"""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from scipy import special
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.twod.solver import solve_monostatic_rcs_2d
from ghost_backend.twod.assembly.native import far, near, table

RADIUS = 0.08
FREQ_GHZ = 1.35
EPS = complex(2.5, -0.04)
MU = complex(1.3, -0.02)
ANGLES = list(range(-90, 90))


def geometry(material, panels):
    theta = -2 * np.pi * np.arange(panels) / panels
    points = RADIUS * np.column_stack((np.cos(theta), np.sin(theta)))
    typ = 2 if material == "pec" else 3
    lines = ["Title: analytic circle polygon", f"Segment: body {typ}",
             f"properties: {typ} 1 0 {int(typ==3)} 0"]
    for a, b in zip(points, np.roll(points, -1, axis=0)):
        lines.append(" ".join(f"{v:.17g}" for v in (*a, *b)))
    lines += ["IBCS_Resistances:", "", "Dielectrics:"]
    if typ == 3:
        lines.append(f"1 {EPS.real} {EPS.imag} {MU.real} {MU.imag}")
    return build_geometry_snapshot(*parse_geometry("\n".join(lines) + "\n"))


def analytic_amplitude(material, channel, modes):
    """Enforce tangential boundary conditions mode by mode, summing n and -n."""
    x = 2 * np.pi * FREQ_GHZ * 1e9 * RADIUS / 299792458
    m = np.sqrt(EPS * MU)
    total = 0j
    for n in range(modes + 1):
        j, jp = special.jv(n, x), special.jvp(n, x)
        h, hp = special.hankel2(n, x), special.h2vp(n, x)
        if material == "pec":
            coeff = -jp / hp if channel == "VV" else -j / h
        else:
            inside = special.jv(n, m*x)
            normal = m * special.jvp(n, m*x) / (EPS if channel == "VV" else MU)
            # Unknowns are the outgoing scattered coefficient and interior field.
            coeff, _ = np.linalg.solve([[h, -inside], [hp, -normal]], [-j, -jp])
        total += (1 if n == 0 else 2) * (-1)**n * coeff
    return -4j * total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--panels", nargs="+", type=int, default=[96, 512])
    parser.add_argument("--materials", nargs="+", choices=["pec", "magnetic_dielectric"],
                        default=["pec", "magnetic_dielectric"])
    parser.add_argument("--output", type=Path, default=Path("."))
    args = parser.parse_args()
    output = args.output
    output.mkdir(parents=True, exist_ok=True)
    arrays = {}
    report = {"fixture": {"radius_m": RADIUS, "freq_GHz": FREQ_GHZ,
                          "angles_deg": ANGLES, "dielectric_epsilon_r": str(EPS),
                          "dielectric_mu_r": str(MU)}, "runs": [],
              "cross_backend": [], "python": sys.version, "numpy": np.__version__,
              "can_load_native": {"far":far._dll() is not None, "near":near._dll() is not None,
                                  "table":table.library() is not None}}
    for material in args.materials:
        refs = {pol: analytic_amplitude(material, pol, 30) for pol in ("VV","HH")}
        for pol, ref in refs.items():
            assert abs(ref - analytic_amplitude(material, pol, 20)) < 1e-12
        for panels in args.panels:
            for method in ("dense", "compressed"):
                opts = {"factorization":method, "basis_order":1, "mesh_strategy":"global",
                        "assembly_threads":1,"blas_threads":1,"rhs_compression":"off",
                        "angle_batch_size":64, "ram_budget_gib":3}
                with cpu_allocation_scope(1):
                    response = solve_monostatic_rcs_2d(geometry(material, panels),
                        [FREQ_GHZ], ANGLES, geometry_units="meters",
                        strict_quality_gate=True, compute_condition_number=True,
                        execution_options=opts)
                meta = response["metadata"]
                assert meta["panel_count_max"] == panels, meta["panel_count_max"]
                assert meta["quality_gate"]["passed"]
                factor_records = meta.get("compressed_factors", [])
                assert bool(factor_records) == (method == "compressed")
                record = {"material": material, "panels": panels, "method": method,
                          "largest_system": meta["dense_largest_system"],
                          "backend":meta["linear_backend"],
                          "compressed_factor_records":len(factor_records),
                          "condition_estimate":meta["condition_est_max"],
                          "discrete_gate_passed":meta["quality_gate"]["passed"],
                          "mesh_certified":meta.get("mesh_convergence_certified",False),
                          "channels":{}}
                for pol, ref in refs.items():
                    rows = response["co_solved_samples"][pol]
                    assert [row["theta_inc_deg"] for row in rows] == ANGLES
                    a = np.array([complex(row["rcs_amp_real"], row["rcs_amp_imag"]) for row in rows])
                    key = f"{material}_{panels}_{method}_{pol}"
                    arrays[key] = a
                    rel = np.max(abs(a - ref)) / abs(ref)
                    assert np.isfinite(rel)
                    record["channels"][pol] = {"ref":[ref.real, ref.imag],
                                               "max_rel_complex_error":float(rel)}
                    if method == "compressed":
                        d = arrays[f"{material}_{panels}_dense_{pol}"]
                        rel_dc = np.linalg.norm(a-d) / np.linalg.norm(d)
                        report["cross_backend"].append({"material":material, "panels":panels,
                                                        "channel":pol, "rel_l2":float(rel_dc)})
                report["runs"].append(record)
                print(json.dumps(record), flush=True)
                (output / "numerical_results.json").write_text(json.dumps(report, indent=2) + "\n")
                np.savez_compressed(output / "complex_fields.npz", **arrays)
    errors = [v["max_rel_complex_error"] for r in report["runs"] if r["panels"] == max(args.panels)
              for v in r["channels"].values()]
    assert max(errors) < 0.002, errors
    assert all(row["rel_l2"] < 1e-8 for row in report["cross_backend"])


if __name__ == "__main__":
    main()
