"""Measure one public Dense job per fresh Linux process; full residuals on memory/disk.

Run beside cylinder_check.py with production tools/GHOST on PYTHONPATH. Timings
are descriptive for this fixture, with two processes per policy, in ABBA order.
"""
import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import numpy as np
from cylinder_check import ANGLES, FREQ_GHZ, geometry
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.linalg.residual_spool import ResidualSpool
from ghost_backend.twod.solver import solve_monostatic_rcs_2d


def run(policy, path):
    spool_bytes = []
    original = ResidualSpool.__init__
    def observed(self, matrix, directory, checkpoint):
        original(self, matrix, directory, checkpoint)
        spool_bytes.append(matrix.nbytes)
    ResidualSpool.__init__ = observed
    options = dict(factorization="dense",basis_order=1,assembly_threads=1,blas_threads=1,
                   rhs_compression="off",angle_batch_size=90,ram_budget_gib=4,
                   dense_residual_storage=policy)
    start = time.perf_counter()
    with cpu_allocation_scope(1):
        value = solve_monostatic_rcs_2d(geometry("magnetic_dielectric", 1792), [FREQ_GHZ],
                    ANGLES, geometry_units="meters", strict_quality_gate=True,
                    compute_condition_number=True, execution_options=options)
    elapsed = time.perf_counter() - start
    m = value["metadata"]
    d = dict(wall_sec=elapsed, process_peak_RSS_GiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/2**20,
             panels=m["panel_count_max"], largest_system=m["dense_largest_system"], policy=policy,
             spool_matrix_bytes=spool_bytes, gate=m["quality_gate"]["passed"])
    assert d["gate"] and d["largest_system"] == 3584
    assert bool(spool_bytes) == (policy == "disk")
    fields = {p:np.array([complex(r["rcs_amp_real"], r["rcs_amp_imag"]) for r in s])
              for p,s in value["co_solved_samples"].items()}
    np.savez_compressed(path.with_suffix(".npz"), **fields)
    path.with_suffix(".json").write_text(json.dumps(d,indent=2)+"\n")


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--one", choices=["disk","memory"])
    p.add_argument("--output", type=Path, default=Path("dense_spool"))
    args=p.parse_args()
    if args.one:
        run(args.one,args.output)
        return
    args.output.mkdir(exist_ok=True,parents=True)
    records=[]
    baseline=None
    for i,policy in enumerate(("memory","disk","disk","memory")):
        path=args.output/f"{i}_{policy}"
        subprocess.run([sys.executable,__file__,"--one",policy,"--output",str(path)],check=True,
                       env=dict(os.environ,OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1"))
        row=json.loads(path.with_suffix(".json").read_text())
        with np.load(path.with_suffix(".npz")) as z:
            if baseline is None:
                baseline={k:z[k] for k in z}
            row["field_relative_L2"]={k:float(np.linalg.norm(z[k]-v)/np.linalg.norm(v))
                                      for k,v in baseline.items()}
        assert max(row["field_relative_L2"].values()) < 1e-9
        records.append(row)
        (args.output/"summary.json").write_text(json.dumps(records,indent=2)+"\n")
        print(json.dumps(row),flush=True)


if __name__ == "__main__":
    main()
