import hashlib,json,math,os,time,sys
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt,QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QMessageBox
from ghost_backend.ui import solver as ui
from ghost_backend.io.grim import load_grim_npz
r=Path(__file__).resolve().parent
data=Path(ui.__file__).read_bytes()
blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
assert blob=='6887a1b71569c23183ad696ea5f7033f7573f7a5',blob
geometry=r/'pec.geo'
n=1024
pts=[(.09*math.cos(-2*math.pi*i/n),.09*math.sin(-2*math.pi*i/n)) for i in range(n)]
geometry.write_text('Title: GUI retest PEC circle\nSegment: body 2\nproperties: 2 1 0 0 0\n'+'\n'.join('%.17g %.17g %.17g %.17g'%(*a,*b) for a,b in zip(pts,pts[1:]+pts[:1]))+'\n')
app=QApplication([])
t=ui.SolverTab()
t.resize(1250,950);t.show();app.processEvents()
notes=[]
def watch():
    box=app.activeModalWidget()
    if not isinstance(box,QMessageBox):return
    notes.append(dict(title=box.windowTitle(),text=box.text(),bar=t.progress.value(),finishing=bool(t._solver_finishing)))
    b=box.button(QMessageBox.StandardButton.No) or box.button(QMessageBox.StandardButton.Ok)
    if b:QTest.mouseClick(b,Qt.MouseButton.LeftButton)
    else:box.reject()
timer=QTimer();timer.timeout.connect(watch);timer.start(20)
def choose(combo,key):
    index=combo.findData(key)
    assert index>=0,(key,[(combo.itemText(i),combo.itemData(i)) for i in range(combo.count())])
    combo.setCurrentIndex(index)
def config(mode,freq,export=True):
    t.edit_geo_path.setText(str(geometry));t.cmb_units.setCurrentText('meters');t.cmb_freq_mode.setCurrentIndex(0);t.edit_freq_list.setText(freq)
    t.cmb_elev_mode.setCurrentIndex(0);t.edit_elev_list.setText(','.join(map(str,range(-90,90))))
    choose(t.cmb_mesh_workflow,mode);choose(t.twod_options_widget.factorization,'compressed')
    t.chk_export_after_solve.setChecked(export);t.edit_output.setText(str(r/'actual-output.grim'))
def go(cancel=False):
    prior=t.last_result;start=time.monotonic();clicked=None;values=[];labels=[];cleanup=None;entry=len(notes)
    QTest.mouseClick(t.btn_run,Qt.MouseButton.LeftButton)
    assert t._is_solving and t.btn_cancel.isEnabled(),(t.lbl_status.text(),notes)
    during=[]
    while t._is_solving or t._solve_thread is not None:
        app.processEvents()
        if t._is_solving:
            if t._solver_finishing:continue
            if not clicked:
                values.append((t.progress.maximum(),t.progress.value()))
                if not labels or labels[-1]!=t.lbl_status.text():labels.append(t.lbl_status.text())
            if cancel and not clicked and ('assem' in t.lbl_status.text().lower() or 'solv' in t.lbl_status.text().lower() and ' at ' in t.lbl_status.text().lower()) and t.btn_cancel.isEnabled():
                clicked=time.monotonic()
                stage=t.lbl_status.text()
                QTest.mouseClick(t.btn_cancel,Qt.MouseButton.LeftButton)
                assert t._abort_event.is_set() and not t.btn_cancel.isEnabled()
        assert time.monotonic()-start<150,(t.lbl_status.text(),notes)
        time.sleep(.003)
    app.processEvents()
    rec=dict(elapsed_s=time.monotonic()-start,active_samples=len(values),last_stages=labels[-5:],clicked_stage=stage if clicked else None,cancel_to_idle_s=(time.monotonic()-clicked) if clicked else None,dialogs=notes[entry:],bar=[t.progress.minimum(),t.progress.maximum(),t.progress.value(),t.progress.format()],prior_preserved=t.last_result is prior,run_enabled=t.btn_run.isEnabled(),cancel_disabled=not t.btn_cancel.isEnabled(),status=t.lbl_status.text())
    print(json.dumps(rec),flush=True)
    assert rec['cancel_disabled'] and rec['run_enabled'] and t._abort_event is None
    assert not [x for x in rec['dialogs'] if 'Replace' not in x['title']]
    if cancel:
        assert clicked and t.last_result is prior and rec['bar'][3]=='Canceled' and rec['bar'][2]<100
        assert all(mx==0 for mx,val in values)
    else:
        assert t.last_result is not None and t.last_result is not prior and rec['bar'][2]==100
        assert all(mx==100 and val<100 for mx,val in values) and all(a[1]<=b[1] for a,b in zip(values,values[1:]))
        meta=t.last_result['metadata'];rec['gate']=meta.get('quality_gate',{}).get('passed')
        rec['backend']=meta.get('execution_options',{}).get('factorization');rec['metadata_keys']=list(meta)
        rec['per_freq']=meta.get('frequency_metadata')
        rec['frequencies']=list(t.last_result.get('frequencies_ghz',[]))
        print('Completed backend',rec['backend'],'gate',rec['gate'],flush=True)
        assert rec['gate'],rec
    return rec
p=r/'actual-output.grim'
if p.exists():p.unlink()
config('single','1.1');a=go()
assert p.is_file();d=load_grim_npz(str(p))
valid=np.asarray(d['rcs_power'])
print('GRIM keys',list(d.keys()),'shape',valid.shape,flush=True)
assert np.isfinite(valid).all() and valid.size>=2*180 and np.any(valid>0)
real=np.asarray(d['rcs_amp_real']);imag=np.asarray(d['rcs_amp_imag']);axes=list(np.asarray(d['azimuths']));pols=list(map(str,np.asarray(d['polarizations'])));errors=[]
print('grid axes and pols',axes[:5],pols,flush=True)
for pol,rows in t.last_result['co_solved_samples'].items():
    for row in rows:
        deg=float(row['theta_scat_deg'])
        idx=min(range(len(axes)),key=lambda k:abs((axes[k]-deg+180)%360-180))
        assert abs((axes[idx]-deg+180)%360-180)<1e-8
        ref=complex(float(row['rcs_amp_real']),float(row['rcs_amp_imag'])); exported=complex(real[idx,0,0,pols.index(pol)],imag[idx,0,0,pols.index(pol)])
        errors.append(abs(exported-ref))
assert len(errors)==360 and max(errors)<1e-12,max(errors)
a['export_field_max_abs_difference']=max(errors)
sig=hashlib.sha256(p.read_bytes()).hexdigest()
config('check','1.1',False);b=go(cancel=True)
config('single','1.3');c=go()
assert hashlib.sha256(p.read_bytes()).hexdigest()==sig
assert 'export was canceled' in c['status'] and len(c['dialogs'])==1 and c['dialogs'][0]['bar']<100 and c['dialogs'][0]['finishing']
report={'ui_git_blob':blob,'native_gui_platform':app.platformName(),'original':a,'cancel':b,'restart_decline_export':c,'export_shape':valid.shape,'export_sha256':sig,'fixture':dict(pec_circle_diameter_m=.18,panels=n,monostatic_angles=180)}
(r/'observations.json').write_text(json.dumps(report,indent=2,default=str))
timer.stop();t.close()

