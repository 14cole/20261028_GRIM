import hashlib,json,math,os,time,sys
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt,QTimer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QMessageBox
from ghost_backend.ui import solver as ui
from ghost_backend.io.grim import load_grim_npz
r=Path(__file__).resolve().parent
data=Path(ui.__file__).read_bytes()
blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
assert blob=='6887a1b71569c23183ad696ea5f7033f7573f7a5',blob
geometry=r/'pec.geo'
n=192
pts=[(.09*math.cos(-2*math.pi*i/n),.09*math.sin(-2*math.pi*i/n)) for i in range(n)]
geometry.write_text('Title: GUI retest PEC circle\nSegment: body 2\nproperties: 2 1 0 0 0\n'+'\n'.join('%.17g %.17g %.17g %.17g'%(*a,*b) for a,b in zip(pts,pts[1:]+pts[:1]))+'\n')
app=QApplication([])
t=ui.SolverTab()
t.resize(1250,950);t.show();app.processEvents()
notes=[]
def watch():
    box=app.activeModalWidget()
    if not isinstance(box,QMessageBox):return
    notes.append(dict(title=box.windowTitle(),text=box.text(),bar=t.progress.value(),finishing=bool(t._solver_finishing)))
    b=box.button(QMessageBox.StandardButton.No) or box.button(QMessageBox.StandardButton.Ok)
    if b:QTest.mouseClick(b,Qt.MouseButton.LeftButton)
    else:box.reject()
timer=QTimer();timer.timeout.connect(watch);timer.start(20)
def choose(combo,key):
    index=combo.findData(key)
    assert index>=0,(key,[(combo.itemText(i),combo.itemData(i)) for i in range(combo.count())])
    combo.setCurrentIndex(index)
from shutil import copyfile
g=r/'cylinder.geo'
copyfile(Path(ui.__file__).parents[1]/'geometry/geometries/BOR/pec_cylinder_r4_h10_in.geo',g)
choose(t.cmb_solver_kind,'bor');t.edit_geo_path.setText(str(g));t.cmb_units.setCurrentText('inches')
t.cmb_freq_mode.setCurrentIndex(0);t.edit_freq_list.setText('0.3')
t.cmb_elev_mode.setCurrentIndex(0);t.edit_elev_list.setText('30,60')
t.cmb_bor_elev_mode.setCurrentIndex(0);t.edit_bor_elev_list.setText('10')
choose(t.cmb_mesh_workflow,'single');t.chk_export_after_solve.setChecked(False)
QTest.mouseClick(t.btn_run,Qt.MouseButton.LeftButton)
assert t._is_solving and t.btn_cancel.isEnabled() and t.progress.maximum()==0
start=time.monotonic();values=[];stages=[]
while t._is_solving or t._solve_thread is not None:
    app.processEvents()
    if t._is_solving and not t._solver_finishing:
        values.append(t.progress.maximum())
        if not stages or t.lbl_status.text()!=stages[-1]:stages.append(t.lbl_status.text())
    if time.monotonic()-start>90 and t._is_solving and t.btn_cancel.isEnabled():
        QTest.mouseClick(t.btn_cancel,Qt.MouseButton.LeftButton)
    assert time.monotonic()-start<150
    time.sleep(.003)
status=t.lbl_status.text();res=t.last_result
report=dict(blob=blob,status=status,sample_count=0 if res is None else len(res['samples']),pct_end=t.progress.value(),all_indeterminate=all(v==0 for v in values),n_observations=len(values),elapsed_s=time.monotonic()-start,stages=stages,dialogs=notes,can_restart=t.btn_run.isEnabled())
print(json.dumps(report),flush=True)
(r/'observations.json').write_text(json.dumps(report,indent=2))
assert res is not None and t.progress.value()==100 and values and all(val==0 for val in values) and not notes and t.btn_run.isEnabled()
timer.stop();t.close()

