"""Reproduce public Line Expansion workflows on a checked-out GHOST tree.

    PYTHONPATH=/path/to/repo/tools/GHOST OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python line_checks.py --output line_results.json

Uses the production section solver, decoder and on-disk exporter. No mock or source patch.
"""
import argparse
import hashlib
import json
import platform
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import scipy
from ghost_backend.assembly.expand_wing_sections import expand_wing_sections
from ghost_backend.assembly.fields import load_body_requested_radar_grid
from ghost_backend.data_tools.cem_tools.native_samples import decode_native_samples, raw_amplitude
from ghost_backend.geometry.occlusion import Occluder
from ghost_backend.io.grim import _save_grim_npz


def shadow_probe(n):
    vertices = np.linspace(-1, 1, n + 1)
    triangles = []
    for x, xx in zip(vertices, vertices[1:]):
        for y, yy in zip(vertices, vertices[1:]):
            a, b, c, d = (x,y,0), (xx,y,0), (xx,yy,0), (x,yy,0)
            triangles.extend(((a,b,c),(a,c,d)))
    body = Occluder(np.array(triangles))
    try:
        _,lo,hi = body.visible_line_intervals(np.array([[-2.,-1.37,-1.]]),
                                                np.array([[2.,1.43,-1.]]), np.array([0.,0.,1.]))
        visible = float(np.sum(hi-lo))
        error = None
    except TypeError as exc:
        visible, error = None, repr(exc)
    return dict(triangles=len(triangles), expected_visible_fraction=0.5, visible_fraction=visible, error=error)


def read(path):
    with np.load(path, allow_pickle=False) as archive:
        return decode_native_samples({key: archive[key] for key in archive.files})


def probe(directory):
    geo = directory/'circle.geo'
    phi = np.linspace(0, -2*np.pi, 129)
    points = np.column_stack((0.1*np.cos(phi), 0.1*np.sin(phi)))
    points[-1] = points[0]
    geo.write_text('Title: circular section\nSegment: boundary\nproperties: 2 1 0 0 0\n'
                   + '\n'.join(' '.join(map(str,np.r_[a,b])) for a,b in zip(points,points[1:]))
                   + '\nIBCS_Resistances:\nDielectrics:\n')
    section = dict(geometry=str(geo), root=(0.,0.,0.), tip=(.19,.03,.06), normal=(0.,2.,1.))
    def expand(name, **kwargs):
        return expand_wing_sections([section], output_grim=str(directory/(name+'.grim')),
                                    coordinate_units='meters', geometry_units='meters',
                                    section_angle_step_deg=15., shadow=False, **kwargs)
    grid = dict(frequencies_ghz=[.3], azimuths_deg=[10.,55.], elevations_deg=[17.])
    attitude = dict(axis_az_deg=32., axis_el_deg=8., roll_deg=9.)
    first = expand('first', **grid, **attitude)
    p = read(first['output'])
    expect = 2 * raw_amplitude(p)
    def chain_error(record):
        return float(np.max(np.abs(raw_amplitude(read(record['output']))-expect)) / np.max(np.abs(expect)))
    inherited = expand('inherited', body_grim=first['output'])
    explicit = expand('explicit', body_grim=first['output'], **attitude)
    radians_file = directory/'radian_input.grim'
    with np.load(first['output'], allow_pickle=False) as saved:
        radians_base = {key:saved[key] for key in saved.files}
    units = json.loads(str(radians_base['units']))
    units.update(azimuth='rad', elevation='rad')
    radians_base.update(azimuths=np.deg2rad(radians_base['azimuths']),
                        elevations=np.deg2rad(radians_base['elevations']), units=np.array(json.dumps(units)))
    with radians_file.open('wb') as file:
        np.savez(file, **radians_base)
    try:
        radians = expand('rad_output', body_grim=str(radians_file), **attitude)
        convention = dict(accepted=True, warnings=radians['warnings'], relative_complex_error=chain_error(radians))
    except ValueError as exc:
        convention = dict(accepted=False, error=str(exc))
    zeros = np.zeros(expect.shape[:-1]+(4,), dtype=float)
    field_base = dict(p, polarizations=np.array(['VV','HH','VH','HV']),
                      rcs_amp_real=zeros, rcs_amp_imag=zeros, rcs_phase=zeros, rcs_power=zeros)
    for key in ('rcs_complex', 'grim_format_version', 'storage_kind', 'storage_domain'):
        field_base.pop(key, None)
    path = directory/'four_pol.grim'
    _save_grim_npz(field_base,str(path))
    pol = expand('pol', body_grim=str(path), **attitude)
    projected = raw_amplitude(read(pol['output']))
    reference = raw_amplitude(p)[...,2]
    return dict(imported_radian_axes=convention, shadow=[shadow_probe(1), shadow_probe(18)],
                nonzero_attitude=dict(base_attitude=attitude,
                                      stored_radar_grid=load_body_requested_radar_grid(first['output']),
                                      inherited_relative_complex_error=chain_error(inherited),
                                      explicit_relative_complex_error=chain_error(explicit),
                                      warnings=inherited['warnings']),
                four_polarizations=dict(reference_cross_pol_max=float(np.max(np.abs(reference))),
                                        vh_error=float(np.max(np.abs(projected[...,2]-reference))),
                                        hv_error=float(np.max(np.abs(projected[...,3]-reference))),
                                        hv_max=float(np.max(np.abs(projected[...,3]))),
                                        warnings=pol['warnings']),
                provenance_in_file='line_expansion_provenance_json' in p)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    options=parser.parse_args()
    with TemporaryDirectory() as name:
        result=probe(Path(name))
    result['environment']=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform())
    result['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    options.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
