# Effective tile and retained-matrix identity

Use Claude’s pinned ghost-backend-audit folder at `5e1c947`, shipped main `ed90b65`, and an isolated copy of main with only Claude’s second-polarization-credit.patch applied. The two source checkouts supply the solver; the pinned audit supplies the fixture and the solve wrapper. Run from this directory.

```sh
export PYTHONPATH=/path/to/ghost-backend-audit
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export GRIM_ROOT=/path/to/main
python check_identity.py auto tighten > main-replay.json
export GRIM_ROOT=/path/to/candidate
python check_identity.py auto tighten > tighten-replay.json
python check_identity.py auto relax > relax-replay.json
python check_identity.py 128 tighten > fixed-replay.json
```

The four jobs use GHOST’s public solver at 10 GHz on a translated coated PEC cylinder of 0.10 m core radius, 0.12 m coating radius and relative permittivity 2.8 − 0.06i. There are 2,992 unknowns per polarization and 180 one-degree monostatic incident angles from −90° through +89°. Each uses disk-backed residuals on one thread.

Only the capacity read is controlled while pricing the second or first polarization. The test derives the specified price point from the actual unconstrained estimates, so the effective automatic assembly tile crosses the recovery boundary. All geometry, matrices, key construction, session lookup, actual consumption, assembly, LU and residual checks are real. Both versions call their normal final admission gate. Physical RAM is plentiful on the test worker. A rejection tests the memory admission rule rather than simulating a real OOM. The reported ambient unconstrained capacity varies with worker load.

| Control | Actual retained tile → requested TM tile | TM allowance | Actual outcome |
|---|---:|---:|---|
| Main, tightening, automatic tile | 0 → 128 | 0 B | Rejected at admission |
| Candidate, tightening, automatic tile | 0 → 128 | 143,233,024 B | Admitted. Cache miss |
| Candidate, relaxing, automatic tile | 128 → 0 | 143,233,024 B | Admitted. Cache miss |
| Candidate, tightening, explicit 128 | 128 → 128 | 143,233,024 B | Admitted. Cache hit |

In the tightening candidate, the live uncredited budget was 0.491141 GiB. The TM forecast and final gate used 0.624538 GiB after counting the 0.133396 GiB matrix. The forecast was 0.596232 GiB. The eventual session key differed only in the tile. Main computed its allowance after plan activation and correctly declined the credit. These tests establish inappropriate credit for an allocation which was not reused and a changed admission decision. They do not establish that the operating system would kill either process. A cache miss releases the unclaimed retained entry before this fixture assembles the replacement.

The public monostatic code paths for the three supported reuse formulations call their assembly wrappers with the default observer/source quadrature orders 8/8. A far-quadrature option affects kernels within assembly and is shared for both polarizations during a request. These controls observed 8/8 directly on the coated fixture. If the public rule selection changes, both preflight and consumption must derive their keys from the same effective order values.

A regression check should require every nonzero credited plan to match its final execution key and final live limit. A proposed plan can be checked again immediately after activation. Reprice with zero allowance if the confirmed buffer or key changes, bound the number of passes, and re-evaluate admission. Preserve the same genuine-identity, shared-request, memory-budget and live RAM/commit tests. The discrete physics on the completed candidate runs passed.

## Revised prototype controls

Use the revised audit patch instead of Claude's original prototype, point GRIM_ROOT to its isolated checkout, and run the last three commands again. The archived outputs have a `revised_` prefix. In the automatic tightening test the phase plan now withdraws the 0.133396 GiB hint and final admission rejects the solve. A sufficiently relaxed budget can still admit a freshly assembled TM operator with zero hint; an explicit matching tile can still receive credit for the matrix it actually consumes. These tests address identity and the admission gate. The 24k elapsed time of this revised version still requires a same-host benchmark.
