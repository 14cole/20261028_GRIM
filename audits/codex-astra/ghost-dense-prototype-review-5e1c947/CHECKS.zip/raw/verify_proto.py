"""Recompute the 24k prototype A/B benchmark using the pinned ghost-backend-audit directory.

Usage: python verify_proto.py /path/to/ghost-backend-audit
Requires NumPy and SciPy. No GHOST solve is executed.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp


GIB = 1024**3


def solve_analytic(polarization, angles):
    k = 2*np.pi*10e9 / 299792458.0
    eps = 2.8 - 0.06j
    refractive_index = np.sqrt(eps)
    q = refractive_index / (1. if polarization == "TM" else eps)
    a, b = k*refractive_index*.100, k*refractive_index*.120
    x = k*.120
    solution = []
    for n in range(91):
        # Three unknowns: outgoing field and the two annular Bessel amplitudes.
        # Continuity of field and scaled radial flux, then PEC core condition.
        aj, ay = (jv(n, a), yv(n, a)) if polarization == "TM" else (jvp(n, a), yvp(n, a))
        mat = np.array([[hankel2(n,x), -jv(n,b), -yv(n,b)],
                        [h2vp(n,x), -q*jvp(n,b), -q*yvp(n,b)], [0., aj, ay]])
        scale = np.max(np.abs(mat), axis=0)
        s = np.linalg.solve(mat/scale, [-jv(n,x), -jvp(n,x), 0.])[0]/scale[0]
        solution.append(s*(-1)**n * (1 if n == 0 else 2))
    phi = np.deg2rad(angles)
    shift = np.exp(2j * k * (.031*np.cos(phi) -.017*np.sin(phi)))
    return -4j * sum(solution) * shift


def metric(test, ref):
    assert test.shape == ref.shape and np.isfinite(test).all() and np.isfinite(ref).all()
    d = abs(test - ref)
    return dict(bit_identical=test.tobytes()==ref.tobytes(), max_over_peak=float(d.max()/max(abs(ref))),
                rel_l2=float(np.linalg.norm(d)/np.linalg.norm(ref)), angle_of_max_deg=int(d.argmax()))


def fields(path, keys):
    with np.load(path, allow_pickle=False) as z:
        assert np.array_equal(z['angles_deg'], np.arange(360.))
        return {k:z[k] for k in keys}


def compare(a, b):
    return {p:metric(a['ghost_'+p], b['ghost_'+p]) for p in ('TM', 'TE')}


def samples(path):
    lines = path.read_text().splitlines()
    columns = lines[0].split()
    frames = []
    for line in lines[1:]:
        values = line.split()
        assert len(columns) == len(values)
        frames.append({k: (float(v.split('=')[1]) if k == 'psi_some_avg10' else int(v))
                       for k, v in zip(columns, values)})
    assert all(a['t_s'] < b['t_s'] for a, b in zip(frames, frames[1:]))
    assert all(a['read_bytes'] <= b['read_bytes'] for a,b in zip(frames,frames[1:]))
    return frames


def report(audit):
    folder = audit/'results'/'c_proto24k'
    old = fields(audit/'results'/'c_trace24k'/'s8448_a360_t4_dense.npz', ('ghost_TE','ghost_TM'))
    exact = {p: solve_analytic(p, np.arange(360.)) for p in ('TE','TM')}
    arrays, results = {}, {}
    for tag in ('current','candidate'):
        run = folder/tag
        assert (run/'status.txt').read_text().split()[0] == 'rc=0'
        assert not (run/'dense.err').read_text().strip()
        d = json.loads((run/'dense.out').read_text())
        assert (d['quality_passed'] and d['requested']=='dense' and d['rhs_compression']=='off'
                and d['threads']==4 and d['angles']==360 and d['unknowns_per_system']==23936
                and d['ghz']==10. and d['panels']==15488 and not d['warnings'])
        arrays[tag] = fields(run/'s8448_a360_t4_dense.npz', ('ghost_TE','ghost_TM','analytic_TE','analytic_TM'))
        plans = [e for e in d['memory_estimates'] if e.get('model')=='dense_phase_v1']
        assert len(plans)==2 and all(p['residual_storage']=='disk' for p in plans)
        batch = [p['angle_batch_size'] for p in plans]
        b = d['rhs_batches']
        s = d['stage_calls']
        assert sum((360+w-1)//w for w in batch)==b['dense_rhs_batch_count']==s['linear_solve']
        assert b['dense_rhs_column_count']==720 and b['assembled_system_reuses']==1 and b['dense_factorization_count']==2
        assert len({p['matrix_bytes'] for p in plans})==1
        filesize = plans[0]['matrix_bytes']
        assert filesize == 16*d['unknowns_per_system']**2
        samples_ = samples(run/'samples.txt')
        high = lambda key: max(r[key] for r in samples_)
        sample_peaks = {k:high(k)/GIB for k in ('cg_usage','cg_rss','cg_cache','cg_inactive_file','cg_active_file')}
        io = d['process_io']
        plans_out = [dict(planned_capacity_gib=p['capacity_bytes']/GIB,
                          peak_forecast_gib=p['peak_bytes']/GIB, batch=p['angle_batch_size'],
                          recovery=p['memory_recovery'],tile=p['assembly_tile'],
                          matrix_credit_gib=p.get('reused_matrix_credit_bytes',0)/GIB)
                     for p in plans]
        checks = {}
        for p in ('TE','TM'):
            f = arrays[tag]['ghost_'+p]
            a = arrays[tag]['analytic_'+p]
            errors = metric(f,exact[p])
            refcheck = metric(a, exact[p])
            assert refcheck['max_over_peak'] < 2e-14
            assert abs(errors['max_over_peak']-d['error_'+p]) < 2e-14
            checks[p] = dict(analytic_vs_independent=refcheck, solver_vs_independent=errors,
                             vs_earlier_current_trace=metric(f,old['ghost_'+p]))
        results[tag] = dict(solve_wall_s=d['solve_wall_s'], peak_rss_gib=d['peak_rss_gib'],
                            residual_max=d['residual_max'],factor_count=b['dense_factorization_count'],
                            batch_column_count=b['dense_rhs_column_count'], matrix_reuse_count=b['assembled_system_reuses'],
                            plans=plans_out, measured_stages=d['stage_seconds'],stage_calls=s,
                            additional_inverse_applications=s['rhs_solve']-s['linear_solve'],
                            matrix_bytes=filesize, logical_read_equivalents=io['rchar']/filesize,
                            physical_read_equivalents=io['read_bytes']/filesize,
                            process_read_bytes=io['read_bytes'], process_write_bytes=io['write_bytes'],
                            sampled_peak_gib=sample_peaks, sampled_system_psi_max=high('psi_some_avg10'),
                            sampled_system_psi_nonzero_points=[(r["t_s"],r["psi_some_avg10"]) for r in samples_ if r["psi_some_avg10"] > 0.],
                            sampled_count=len(samples_), sampled_last_seconds=samples_[-1]['t_s'],
                            errors=checks)
    a,b = results['current'],results['candidate']
    dt=a['solve_wall_s']-b['solve_wall_s']
    diff = dict(speedup=a['solve_wall_s']/b['solve_wall_s'],elapsed_reduction_s=dt,
                elapsed_reduction_pct=dt/a['solve_wall_s']*100,
                inclusive_linear_reduction_s=a['measured_stages']['linear_solve']-b['measured_stages']['linear_solve'],
                physical_reads_reduction_pct=100*(1-b['process_read_bytes']/a['process_read_bytes']),
                peak_rss_delta_gib=b['peak_rss_gib']-a['peak_rss_gib'],
                peak_rss_delta_pct=(b['peak_rss_gib']/a['peak_rss_gib']-1)*100,
                sampled_anon_delta_gib=b['sampled_peak_gib']['cg_rss']-a['sampled_peak_gib']['cg_rss'])
    return dict(runs=results,change=diff,field_change=compare(arrays['candidate'],arrays['current']))


if __name__=='__main__':
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('audit',type=Path)
    print(json.dumps(report(arg.parse_args().audit), indent=2))
