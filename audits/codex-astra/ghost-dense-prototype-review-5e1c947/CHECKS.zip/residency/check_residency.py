"""Measure physical residency of an allocated zero-filled array and the public budget's hint on Linux.

The observer runs in its own process, touches only page-aligned interior pages of the test
array, and uses MADV_DONTNEED only on known-zero anonymous memory. Available-RAM readings
are deterministic inputs. RSS, page residency, data ownership and the admission arithmetic
are real. This check exercises the ledger contract without forcing system memory pressure.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np

GIB = 2**30


def run(checkout):
    sys.path.insert(0, str(checkout / "tools/GHOST"))
    from ghost_backend.execution import memory_budget, dense_memory
    from ghost_backend.twod import solver

    libc = ctypes.CDLL(None, use_errno=True)
    libc.mincore.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]
    libc.madvise.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    page = os.sysconf("SC_PAGE_SIZE")
    supplied_available = [2.]
    with patch.object(solver, "_detect_available_gb", lambda: supplied_available[0]), memory_budget.scope() as budget:
        matrix = np.empty((2048,2048), dtype=np.complex128, order="F")
        matrix.fill(0.)
        assert matrix.flags.owndata and matrix.flags.f_contiguous
        base = matrix.ctypes.data
        start = ((base + page - 1) // page) * page
        length = ((base + matrix.nbytes - start) // page) * page
        pages = length // page
        assert pages > 0
        bitmap = (ctypes.c_ubyte * pages)()

        def sample():
            if libc.mincore(start, length, bitmap) != 0:
                raise OSError(ctypes.get_errno(), "mincore failed")
            resident = sum(x & 1 for x in bitmap) * page
            empty = budget.limit()
            claimed = budget.limit(matrix.nbytes/GIB)
            rss = budget.last_process_sample[0]
            revision = getattr(dense_memory, "bounded_reuse_hint", None)
            hint = revision(matrix.nbytes) if revision else matrix.nbytes
            used = budget.limit(hint/GIB)
            return dict(revision_bounded_hint_bytes=hint if revision else None,
                        scoped_hint_allowance_gib=used, interior_resident_bytes=resident, matrix_bytes=matrix.nbytes,
                        process_rss_growth_bytes=rss-budget.baseline_rss,
                        no_hint_gib=empty, full_hint_gib=claimed,
                        additional_allowance_bytes=round((claimed-empty)*GIB))

        supplied_available[0] = .7
        full = sample()
        if libc.madvise(start, length, 4) != 0:   # MADV_DONTNEED on Linux
            raise OSError(ctypes.get_errno(), "madvise failed")
        reclaimed = sample()
        # An unrelated resident allocation illustrates the scope of aggregate RSS measurements.
        other = np.empty_like(matrix)
        other.fill(1.)
        unrelated = sample()
        assert full["interior_resident_bytes"] == length and reclaimed["interior_resident_bytes"] == 0
        assert unrelated["interior_resident_bytes"] == 0
        assert np.count_nonzero(matrix)==0
    return dict(page_bytes=page, measured_interior_bytes=length, initial_available_input_gib=2.,
                live_available_input_gib=.7, all_pages_touched=full,
                interior_reclaimed=reclaimed, unrelated_array_resident=unrelated)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("checkout",type=Path)
    print(json.dumps(run(p.parse_args().checkout.resolve()),indent=2))
