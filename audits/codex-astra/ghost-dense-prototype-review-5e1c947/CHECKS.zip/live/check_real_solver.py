"""Compare actual GHOST trees with controlled TM headroom on a public solve.

Choose the tree with GRIM_ROOT, and add the pinned audit folder to PYTHONPATH
for harness.py. Run each record in a new process. The test only lowers the
queried headroom when TM is being priced and admitted; all other hooks observe
the normal plan, real matrix ownership, and residual file scans.
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
import resource
from unittest.mock import patch

import numpy as np

GIB = 2**30
MODES = {"ambient": None, "tight": .42866719514131546, "too_small": .411}


def run(mode, label, out):
    from harness import cylinder_geo, fields_of, solve_fixed
    from reference import stored_amplitude
    from ghost_backend.twod import solver
    from ghost_backend.twod.assembly import session
    from ghost_backend.execution import dense_memory
    from ghost_backend.linalg.residual_spool import ResidualSpool

    cap = MODES[mode]
    cursor = {"pol": None, "gate": False}
    credit_checks, limits, pairs, takes, scans = [], [], [], [], []
    orig_limit = solver._solve_memory_limit_gb
    orig_estimate = solver._estimate_memory_gb
    orig_resources = solver._dense_formulation_resources
    orig_pair = session.plan_paired_assembly
    orig_reuse = session.reusable_dense_bytes
    orig_take = session.AssemblySession.take
    product, restore = ResidualSpool.__matmul__, ResidualSpool.restore_into

    def resources(mesh, infos, pol, *args, **kwargs):
        ret = orig_resources(mesh, infos, pol, *args, **kwargs)
        cursor["pol"] = pol
        return ret

    def estimate(*args, **kwargs):
        if kwargs.get("activate_memory_plan") and cursor["pol"] == "TM":
            cursor["gate"] = True
        return orig_estimate(*args, **kwargs)

    def limit(resident_gb=0.):
        ret = orig_limit(resident_gb)
        if cursor["gate"] and cap is not None:
            ret = min(ret, cap + resident_gb)
            limits.append({"resident_gib": resident_gb, "gib": ret})
        return ret

    def reusable(*args, **kwargs):
        owned = orig_reuse(*args, **kwargs)
        credit_checks.append({"pol": args[2], "bytes": owned})
        return owned

    def take(sess, key, pol):
        ret = orig_take(sess, key, pol)
        takes.append({"pol": pol, "consumed": ret is not None, "key_tile": key[-1]})
        return ret

    def pair(pol, formulation, dofs, peak, available):
        ret = orig_pair(pol, formulation, dofs, peak, available)
        p = dense_memory.current(dofs)
        pairs.append({"pol": pol, "dofs": dofs, "width": p["angle_batch_size"],
                      "credit_bytes_in_forecast": p.get("reused_matrix_credit_bytes", 0),
                      "plan_gib": p["selection_target_bytes"] / GIB,
                      "gate_gib": available, "peak_gib": peak,
                      "storage": p["residual_storage"], "paired": ret,
                      "recovery_tile": p["assembly_tile"]})
        cursor["gate"] = False
        return ret

    def scan(spool, rhs):
        scans.append((cursor["pol"], "residual"))
        return product(spool,rhs)

    def restored(spool,matrix):
        scans.append((cursor["pol"], "restore"))
        return restore(spool,matrix)

    case = dict(a=.10, b=.12, eps=2.8-.06j, mu=1., center=(.031,-.017))
    text = cylinder_geo(sides=256, **case)
    angles = np.arange(-16.,16.)
    row = {"label": label, "mode": mode, "uncredited_tm_headroom_gib": cap,
           "caps_applied": limits, "verified_reuse": credit_checks,
           "plans": pairs, "assembly_take": takes}
    out.mkdir(parents=True, exist_ok=True)
    with ExitStack() as stack:
        for obj, key, sub in ((solver,"_dense_formulation_resources",resources),
                              (solver,"_estimate_memory_gb",estimate),
                              (solver,"_solve_memory_limit_gb",limit),
                              (session,"plan_paired_assembly",pair),
                              (session,"reusable_dense_bytes",reusable),
                              (session.AssemblySession,"take",take),
                              (ResidualSpool,"__matmul__",scan),
                              (ResidualSpool,"restore_into",restored)):
            stack.enter_context(patch.object(obj,key,sub))
        try:
            result,elapsed = solve_fixed(text,10.,angles,"dense",threads=1,batch=32,
                dense_residual_storage="disk",assembly_tile=128)
        except MemoryError as exc:
            if mode!="too_small":
                raise
            row["memory_error"] = str(exc)
        else:
            if mode=="too_small":
                raise AssertionError("Expected rejection at the recorded TM cap")
            meta = result["metadata"]
            assert meta["quality_gate"]["passed"] and meta["dense_largest_system"] == 728
            data = {"angles":angles}
            for pol,field in fields_of(result).items():
                data[pol] = field
                data["ref_"+pol] = stored_amplitude(pol,10.,angles,**case)
            np.savez_compressed(out / f"{label}_{mode}.npz",**data)
            row.update(quality_passed=True, solve_s=elapsed, max_residual=meta["residual_norm_max"],
                       reused_by_assembly=meta["assembled_system_reuses"],
                       stage_calls=meta["runtime_profile"]["stage_calls"],
                       panels=meta["panel_count"], max_dofs=meta["dense_largest_system"],
                       rss_gib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
    row["scan_counts"] = {pol:{kind:scans.count((pol,kind)) for kind in ("residual","restore")} for pol in ("TE","TM")}
    (out/f"{label}_{mode}.json").write_text(json.dumps(row,indent=2,default=str)+"\n")
    print(label,mode,[(p["pol"],p["width"],p["credit_bytes_in_forecast"]) for p in pairs],
          row.get("reused_by_assembly"),row.get("memory_error","")[:90])


def compare(out, alternative):
    summary = {}
    for mode in MODES:
        rows = {k:json.loads((out/f"{k}_{mode}.json").read_text()) for k in ("main",alternative)}
        brief = {}
        for label,row in rows.items():
            plan = row["plans"][-1]
            brief[label] = {"TM":plan,"scans":row["scan_counts"]}
            if "memory_error" in row:
                brief[label]["error"] = row["memory_error"]
                continue
            assert row["quality_passed"] and row["reused_by_assembly"]==1
            brief[label].update(max_residual=row["max_residual"], linear_calls=row["stage_calls"]["linear_solve"],
                                inverse_calls=row["stage_calls"]["rhs_solve"])
        if mode!="too_small":
            with np.load(out/f"main_{mode}.npz") as a, np.load(out/f"{alternative}_{mode}.npz") as b:
                assert np.array_equal(a["angles"],b["angles"])
                brief["max_field_difference_over_main_peak"] = {p:float(np.max(abs(a[p]-b[p]))/np.max(abs(a[p]))) for p in ("TE","TM")}
                brief["peak_errors_against_reference"] = {k:{p:float(np.max(abs(z[p]-z["ref_"+p]))/np.max(abs(z["ref_"+p]))) for p in ("TE","TM")} for k,z in (("main",a),(alternative,b))}
        summary[mode] = brief
    return summary


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=[*MODES,"compare"])
    parser.add_argument("output",type=Path)
    parser.add_argument("--label",choices=["main","prototype","revised"])
    parser.add_argument("--alternative",choices=["prototype","revised"],default="prototype",help="tree to compare against main")
    opt=parser.parse_args()
    if opt.action=="compare": print(json.dumps(compare(opt.output,opt.alternative),indent=2))
    else:
        if not opt.label: parser.error("pass --label for numerical runs")
        run(opt.action,opt.label,opt.output)
