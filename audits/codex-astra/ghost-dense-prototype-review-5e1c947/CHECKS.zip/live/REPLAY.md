# Public solves with the actual prototype

The production solver is main at `ed90b65ff89826274adacae01bcfbafe143e9819`. The prototype tree is a second copy of the same revision with only `prototype/second-polarization-credit.patch` from `5e1c947ca6a94e9c62514ac14e98e8c3c04b94bc` applied to it. Use the audit harness and reference from that commit. The harness and reference are also identical in the earlier `8716f5f` audit.

Run each solve in its own Linux Python process with the shipped libraries, NumPy and SciPy. The original run used one core on an AMD EPYC 7763. CPU 2 is an example pin.

```sh
export PYTHONPATH=/path/to/ghost-backend-audit
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
mkdir -p fresh
export GRIM_ROOT=/path/to/ed90b65
for mode in ambient tight too_small; do taskset -c 2 python check_real_solver.py "$mode" fresh --label main; done
export GRIM_ROOT=/path/to/isolated-patched-export
for mode in ambient tight too_small; do taskset -c 2 python check_real_solver.py "$mode" fresh --label prototype; done
python check_real_solver.py compare fresh > fresh/comparison.json
```

Each job uses the public monostatic fixed-mesh solver on a PEC core of radius 0.10 m and a lossy coating of outer radius 0.12 m, relative permittivity 2.8 − 0.06i and relative permeability 1. Both linear polarizations are solved at 10 GHz and −16° through +15° on a 472-panel mesh (728 unknowns per system). The numerical path uses degree one, full residuals on disk, an explicit common assembly tile of 128, and a maximum batch of 32.

The diagnostic observes genuine matrix ownership, consumption, forecast widths, residual products and restore calls. In the two controlled runs, the TM planner and its final admission see the lower of actual available headroom and an injected uncredited headroom plus whatever owned-matrix hint the solver actually supplies. The test leaves the numerical algorithm and credit policy to the selected repository checkout. All live allocation guards outside this brief pricing/admission interval execute normally. The `ambient` run does not override headroom. The `tight` headroom is approximately one MiB below the minimum uncredited forecast for this fixture. The `too_small` headroom also misses the minimum after the verified credit, exercising refusal before TM factorization.

Each successful run archives the actual and analytic TE/TM fields, solver gates, plans, counts and timings. The four successful solves have one timing each. Timing on this small Linux example is qualitative. It does not estimate the cost of I/O pressure in the 24k timing pair. The capped cases inject availability and do not exert physical machine pressure. The assembly tile is fixed for this comparison; variable-tile identity requires a separate control.

The revised audit-only prototype is compared with the same original records by setting GRIM_ROOT to the revised export and repeating the three case commands with `--label revised`. Use `python check_real_solver.py compare fresh --alternative revised` for the corresponding results. Both converged field arrays and the angle and reference arrays were bit-identical to Claude's prototype on the two successful fixed-tile cases.
