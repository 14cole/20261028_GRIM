# Reproduce memory admission checks

Set PATCHED to a separate export of shipped ed90b65 with Claude's second-polarization-credit.patch applied. Set AUDIT to the ghost-backend-audit folder at 5e1c947. These controls use Python, NumPy, SciPy and the shipped Linux GHOST dependencies.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python check_limits.py "$PATCHED" > limits-replayed.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python pressure.py "$PATCHED" "$AUDIT" > pressure-replayed.json
```

The first command runs the patched Dense planner against the production memory ledger, with controlled operating-system RAM, commit and working-set readings. The 23,936-unknown matrix byte size is exact. The other phase sizes are illustrative. Two overlapping reservation scopes run in separate Python threads for the shared-process case. No large matrices or deliberately memory-starved processes are created. An explicitly offered matrix-size hint can be present in forecast telemetry even when the ledger's effective credit is zero. The trimmed case models physical RSS growth of 1 GiB and an independently specified allocated matrix size of 8.537 GiB. It shows what the ledger permits under those inputs. Actual residency of that historical matrix was not recorded at planning.

The second command exercises the public solver. In the full-shape tests it supplies scratch availability and stops at the numerical entry, before allocating the 23,936-unknown matrix. The returned OS physical-availability reading changes from 16 to 11 GiB either during the initial Dense forecast or immediately afterward. The late final-admission limit may vary slightly with the interpreter baseline credited by the active plan. The smaller numerical tests solve a 728-unknown, 32-direction coated cylinder with 16-angle batches. They change only the reported free RAM to 0.10 GiB just before the second polarization's spool check or just before its first RHS. The late RHS case continues to completion on otherwise adequately provisioned hardware; this establishes the check boundary rather than behavior under real memory exhaustion.

Exclusive ownership, declared reservation caps and an operating-system committable-memory ceiling address different constraints. The tested physical resident hint does not increase the independent commit allowance and is ignored in an overlapping ledger. On Linux the known nested-cgroup detector problem on main remains outside this patch.
