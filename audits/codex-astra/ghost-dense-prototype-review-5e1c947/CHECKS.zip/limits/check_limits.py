"""Controlled physical, commit, reservation and overlap probes of the proposed Dense plan.

Supply a checkout containing Claude's 5e1c947 prototype. The measurements are
production forecast + MemoryBudget decisions under controlled OS readings.
These probes use illustrative 24k phase byte inputs and allocate no large matrix.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import json
from pathlib import Path
import sys
import threading
from unittest.mock import patch

GIB = 2**30
N = 23936
MATRIX = N*N*16


def run(root):
    sys.path.insert(0,str(root/'tools/GHOST'))
    from ghost_backend.twod import solver
    from ghost_backend.execution import dense_memory as dm, memory, memory_budget as mb, options as opts

    def scenario(kind):
        rss, private = 0.125, 0.200
        probes = {'physical':20., 'commit':20. if kind=='windows_commit' else None,
                  'rss':rss, 'private':private}
        def commit_remaining():
            return None if probes['commit'] is None else round(probes['commit']*GIB)
        def forecast(state, amount, *, execution=True, submission=False):
            with dm.reused_matrix_credit(amount):
                row = dm.forecast(N,360,256,int(8.91*GIB),int(18.36*GIB),0,True,
                                  submission=submission,execution=execution)
            report = dict(physical_credit=state.last.get('credited_resident_gib'),commit_credit=state.last.get('credited_commit_gib'),
                          binding=state.last.get('binding_constraint'),constraints=state.last.get('limits_gib'))
            return dict(width=row['angle_batch_size'],capacity=None if row['capacity_bytes'] is None else row['capacity_bytes']/GIB,
                        peak=row['peak_bytes']/GIB, offered_bytes=row['reused_matrix_credit_bytes'],
                        ledger=report) if not submission else dict(width=row['angle_batch_size'],capacity=None,offered_bytes=row['reused_matrix_credit_bytes'])
        out={}
        with ExitStack() as stack:
            stack.enter_context(patch.object(solver,'_detect_available_gb',lambda: probes['physical']))
            stack.enter_context(patch.object(memory,'windows_available_commit_bytes',commit_remaining))
            stack.enter_context(patch.object(memory,'windows_system_commit',return_value=None))
            stack.enter_context(patch.object(mb,'process_memory',lambda:(round(probes['rss']*GIB),round(probes['private']*GIB))))
            stack.enter_context(patch.object(dm,'scratch_available',return_value=(True,None)))
            # Use public configuration for both request-specific and scheduler caps.
            active={'factorization':'dense','dense_residual_storage':'disk','angle_batch_size':256}
            if kind=='hard_cap':active['ram_budget_gib']=9.4
            if kind=='shared':active['ram_budget_gib']=13.0
            stack.enter_context(opts.execution_scope(active))
            if kind=='scheduler':stack.enter_context(opts.memory_allocation_scope(9.4))
            state=stack.enter_context(mb.scope())
            state.limit()
            probes.update(physical=7., rss=rss+(1. if kind=='trimmed' else MATRIX/GIB), private=private+MATRIX/GIB)
            if kind=='windows_commit':probes['commit']=11.4
            if kind=='shared':
                ready, release = threading.Event(), threading.Event()
                def peer():
                    with opts.execution_scope({'factorization':'dense','ram_budget_gib':0.5}):
                        with mb.scope(wanted_gib=.5) as other:
                            other.limit()
                            ready.set()
                            if not release.wait(10):raise TimeoutError('peer wait')
                            return {'shared':other.shared_process,'held':other.ceiling}
                with ThreadPoolExecutor(max_workers=1) as pool:
                    thread=pool.submit(peer)
                    try:
                        if not ready.wait(10):raise TimeoutError('peer failed to enrol')
                        out['during_overlap']=forecast(state,MATRIX)
                        out['no_hint_during_overlap']=forecast(state,0)
                    finally:release.set()
                    out['peer']=thread.result()
                out['post_overlap']=forecast(state,MATRIX)
                assert state.shared_process and out['during_overlap']['capacity']==out['no_hint_during_overlap']['capacity']
                return out
            out['credited']=forecast(state,MATRIX)
            out['without_credit']=forecast(state,0)
            if kind=='exclusive':
                out['wrong_size']=forecast(state,MATRIX-16)
                out['preview']=forecast(state,MATRIX,execution=False)
                out['submission']=forecast(state,MATRIX,execution=False,submission=True)
            out['initial_reservation_gib']=state.ceiling
            out['observed_rss_growth_gib']=probes['rss']-rss
            out['live_available_gib']=probes['physical']
            return out

    d={k:scenario(k) for k in ('exclusive','hard_cap','scheduler','windows_commit','shared','trimmed')}
    base=d['exclusive']
    assert base['without_credit']['width']==1 and base['credited']['width']==256
    assert all(base[k]['offered_bytes']==0 for k in ('wrong_size','preview','submission'))
    for k in ('hard_cap','scheduler','windows_commit'):
        row=d[k]['credited']
        assert abs(row['capacity']-9.4)<1e-6 and 1<row['width']<256 and row['peak']<=row['capacity'],(k,row)
    assert d['shared']['during_overlap']['width']==1 and d['shared']['peer']['shared']
    assert d['trimmed']['credited']['ledger']['physical_credit'] > d['trimmed']['observed_rss_growth_gib']+7
    return d


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('patched_source',type=Path)
    print(json.dumps(run(ap.parse_args().patched_source.resolve()),indent=2))
