"""Probe Dense at four pressure points by changing the *observed* OS headroom.

Full-size planning controls stop before allocating coefficients. Small numerical
controls run normally, with only the OS memory reading changed at a chosen point.
"""
import argparse
import json
import os
from pathlib import Path
import sys
from contextlib import ExitStack
from unittest.mock import patch
import numpy as np


def controls(source, audit):
    os.environ["GRIM_ROOT"]=str(source.resolve())
    sys.path.insert(0,str(audit.resolve()))
    from harness import cylinder_geo, solve_fixed
    from ghost_backend.twod import solver
    from ghost_backend.execution import dense_memory as dm
    from ghost_backend.linalg.dense import DenseFactor

    def trial(stage):
        class ReachedNumericalEntry(Exception):pass
        full = stage in ('during_forecast', 'after_forecast')
        s={'available':16., 'calls_after_decline':0, 'declined':False, 'plans':[], 'angles_solved_after_decline':0}
        o_forecast=dm.forecast
        o_solver=solver._solve_multi_region_indirect
        o_spool=dm.admit_spool
        o_dense_solve=DenseFactor.solve
        def physical():
            if s['declined']:s['calls_after_decline']+=1
            return s['available']
        def decline(available):
            s['declined']=True
            s['available']=available
        def forecast(*args,**kwargs):
            if full and kwargs.get('execution') and stage=='during_forecast':decline(11.)
            plan=o_forecast(*args,**kwargs)
            if kwargs.get('execution'):
                s['plans'].append(dict(width=plan['angle_batch_size'],forecast_gib=plan['peak_bytes']/2**30,
                                       chosen_capacity_gib=plan['capacity_bytes']/2**30,storage=plan['residual_storage']))
                if stage=='after_forecast':decline(11.)
            return plan
        def solve_by_pol(mesh,infos,pol,*args,**kwargs):
            if full: raise ReachedNumericalEntry
            s['pol']=pol
            return o_solver(mesh,infos,pol,*args,**kwargs)
        def spool(matrix):
            if s.get('pol')=='TM' and stage=='spool_admission':decline(.10)
            return o_spool(matrix)
        def dense_solve(self,rhs):
            if s.get('pol')=='TM' and stage=='first_rhs':decline(.10)
            result=o_dense_solve(self,rhs)
            if s['declined']:s['angles_solved_after_decline']+=rhs.shape[1]
            return result
        geometry=cylinder_geo(sides=8448 if full else 256,a=.10,b=.12,mu=1.,eps=2.8-.06j,center=(.031,-.017))
        try:
            with ExitStack() as stack:
                for module,name,value in ((solver,'_detect_available_gb',physical),(solver,'_solve_multi_region_indirect',solve_by_pol),
                        (dm,'forecast',forecast),(dm,'admit_spool',spool),(DenseFactor,'solve',dense_solve)):
                    stack.enter_context(patch.object(module,name,value))
                if full:stack.enter_context(patch.object(dm,'scratch_available',return_value=(True,None)))
                data,_=solve_fixed(geometry,10.,np.arange(360 if full else 32),'dense',threads=4 if full else 1,
                                   dense_residual_storage='disk',batch=256 if full else 16,assembly_tile=128)
                meta=data['metadata']
                s.update(outcome='completed',quality=meta['quality_gate']['passed'],residual=meta['residual_norm_max'])
        except ReachedNumericalEntry:
            s['outcome']='admitted_before_allocation'
        except MemoryError as exc:
            s.update(outcome='MemoryError',message=str(exc))
        return s
    outcomes={kind:trial(kind) for kind in ('during_forecast','after_forecast','spool_admission','first_rhs')}
    early,late=outcomes['during_forecast'],outcomes['after_forecast']
    assert early['outcome']=='admitted_before_allocation' and 1<early['plans'][-1]['width']<256,early
    assert late['outcome']=='MemoryError' and late['plans'][-1]['width']==256,late
    assert outcomes['spool_admission']['outcome']=='MemoryError'
    assert 'disk residual workspace' in outcomes['spool_admission']['message']
    assert outcomes['first_rhs']['outcome']=='completed' and outcomes['first_rhs']['quality'] and outcomes['first_rhs']['angles_solved_after_decline']==32
    return outcomes


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('source',type=Path);ap.add_argument('audit',type=Path)
    args=ap.parse_args()
    print(json.dumps(controls(args.source,args.audit),indent=2))
