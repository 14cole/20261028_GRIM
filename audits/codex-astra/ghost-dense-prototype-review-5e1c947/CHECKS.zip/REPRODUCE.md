# Replay the review of the Dense prototype

Start from three separate clean exports of shipped solver commit `ed90b65ff89826274adacae01bcfbafe143e9819`. Keep one as the shipped reference. Apply Claude's patch from `audits/claude-2026-11-26/ghost-backend-audit/prototype/second-polarization-credit.patch` at `5e1c947ca6a94e9c62514ac14e98e8c3c04b94bc` to the second. Apply the separate `reprice-verified-tile.patch` accompanying this report to the third, directly on the shipped export. Both patch files are standalone changes against main. The GitHub commit containing this report adds only files under audits.

Set AUDIT to Claude’s pinned ghost-backend-audit folder, MAIN, CLAUDE and REVISION to the three solver exports, and PYTHONPATH to AUDIT. Use Python with GHOST’s Linux runtime dependencies and shipped shared libraries. Run the commands from the extracted CHECKS.zip directory. The per-case replay notes give additional controls and output formats. CPU pinning is optional when checking numerical results.

```sh
export PYTHONPATH="$AUDIT"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
sha256sum -c SHA256SUMS
mkdir -p fresh
python raw/verify_proto.py "$AUDIT" > fresh/raw.json
python small/run_check.py --verify small
python small/run_check.py --verify small-revised
python small/run_check.py "$MAIN" "$CLAUDE" "$AUDIT" fresh/small-claude
python small/run_check.py "$MAIN" "$REVISION" "$AUDIT" fresh/small-revised
GRIM_ROOT="$MAIN" python identity/check_identity.py auto tighten > fresh/main-tight.json
GRIM_ROOT="$CLAUDE" python identity/check_identity.py auto tighten > fresh/claude-tight.json
GRIM_ROOT="$REVISION" python identity/check_identity.py auto tighten > fresh/revision-tight.json
GRIM_ROOT="$REVISION" python identity/check_identity.py auto relax > fresh/revision-relax.json
GRIM_ROOT="$REVISION" python identity/check_identity.py 128 tighten > fresh/revision-fixed.json
python limits/check_limits.py "$CLAUDE" > fresh/limits.json
python limits/pressure.py "$CLAUDE" "$AUDIT" > fresh/pressure.json
python residency/check_residency.py "$CLAUDE" > fresh/residency-claude.json
python residency/check_residency.py "$REVISION" > fresh/residency-revision.json
```

- **raw** rebuilds the 24k metrics from worker records, independent analytical fields, process I/O counters and sampled process/cgroup RAM. The run pair and 20-second samples are stored on Claude’s commit.
- **small** and **small-revised** are the independent 2,992-unknown checks of the two prototype files. run_check.py uses four threads in separate workers for a full 360-angle sweep. small-revised uses the same driver from small/.
- **live** includes nine fresh 728-unknown end-to-end runs, including deliberate admission refusals. The retained matrix and both numerical solvers are real. Controls supply the TM planning headroom and pin the effective tile to isolate a genuine reuse. See live/REPLAY.md to run these in fresh processes.
- **identity** varies the assembly-tile decision by controlling available headroom. The scripts observe both the forecast lookup and the matrix that assembly actually consumes. The positive control pins the tile to 128.
- **limits** tests reservation scope, memory caps and staged availability changes. Its Windows commit data are injected measurements on Linux. The full-size planning probe stops before allocating the matrix. The lower-size cases exercise the numerical solve.
- **residency** uses Linux mincore to measure page residency and MADV_DONTNEED on aligned interior pages of a zero-filled test array. The test verifies that contents remain zero. RAM headroom is controlled numerically. It captures both the ledger’s raw full-byte hint and the revised helper’s offered hint. Total process RSS is measured. Modest differences in RSS-related byte counts across processes are expected.
- **provenance.json** records the pinned source and patch identity checks.

Timing in the fresh small controls is supporting context. Their purpose is to test admission and field accuracy without exhausting physical memory.
