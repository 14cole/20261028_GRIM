"""Run four serial fresh-process controls on shipped and patched GHOST.

python run_check.py /path/to/shipped-ed90b65 /path/to/patched-export /path/to/ghost-backend-audit OUTPUT_DIR
Wrap the driver in taskset if desired. E.g. this review used taskset -c 1-4.
For artifact verification without rerunning, use: python run_check.py --verify OUTPUT_DIR.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np


def verify(out):
    rows = {}
    fields = {}
    for revision in ("current","candidate"):
        for backend in ("dense","compressed"):
            stem = f"{revision}_{backend}"
            row = json.loads((out/f"{stem}.json").read_text())
            with np.load(out/f"{stem}.npz",allow_pickle=False) as z:
                assert np.array_equal(z["angles_deg"], np.arange(360.))
                fields[stem] = {p:z[f"ghost_{p}"] for p in ("TE","TM")}
                analytic = {p:z[f"analytic_{p}"] for p in ("TE","TM")}
            assert row["requested"] == backend and row["quality_passed"] and row["unknowns_per_system"] == 2992
            assert row["angles"] == 360 and row["threads"] == 4 and row["ghz"] == 10
            assert all(f.shape == (360,) and np.isfinite(f).all() for f in fields[stem].values())
            per_pol = {p:float(np.max(np.abs(f-analytic[p]))/np.max(np.abs(analytic[p]))) for p,f in fields[stem].items()}
            rows[stem] = dict(linear_backend=row["linear_backend"], panels=row["panels"], largest_dofs=row["unknowns_per_system"],
                              gate=row["quality_passed"], residual_max=row["residual_max"],
                              batch_info=row["rhs_batches"],stage_calls=row["stage_calls"], error=per_pol)
    comparisons = {}
    for b in ("dense","compressed"):
        old, new = f"current_{b}", f"candidate_{b}"
        assert rows[old]["batch_info"] == rows[new]["batch_info"]
        assert rows[old]["stage_calls"] == rows[new]["stage_calls"]
        assert rows[old]["linear_backend"] == rows[new]["linear_backend"]
        comparisons[b] = {p:dict(bit_identical=fields[old][p].tobytes()==fields[new][p].tobytes(),
                                delta_over_peak=float(np.max(abs(fields[new][p]-fields[old][p]))/np.max(abs(fields[old][p]))))
                          for p in ("TE","TM")}
    return dict(runs=rows, before_after=comparisons)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify",type=Path)
    parser.add_argument("paths",nargs="*",type=Path)
    args=parser.parse_args()
    if args.verify is not None:
        if args.paths: parser.error("--verify takes only one directory")
        print(json.dumps(verify(args.verify),indent=2))
        return
    if len(args.paths)!=4:
        parser.error("expected CURRENT CANDIDATE AUDIT OUTPUT_DIR")
    baseline, candidate, audit, output = (p.resolve() for p in args.paths)
    output.mkdir(parents=True,exist_ok=True)
    for tag, root, mode in (("current",baseline,"dense"),("candidate",candidate,"dense"),
                            ("candidate",candidate,"compressed"),("current",baseline,"compressed")):
        name=f"{tag}_{mode}"
        options=dict(os.environ, GRIM_ROOT=str(root), PYTHONPATH=str(audit),GHOST_AUDIT_OPTIONS="{}")
        dest=output/f"{name}.npz"
        with (output/f"{name}.json").open("w") as log:
            subprocess.run([sys.executable,str(audit/"timed_job.py"),"1056",mode,"360","4",str(dest)],
                           check=True,env=options,stdout=log)
        print(f"{name} complete",flush=True)
    (output/"results.json").write_text(json.dumps(verify(output),indent=2)+"\n")

if __name__=="__main__":
    main()
