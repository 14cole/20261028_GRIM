# 2,992-unknown small-case controls

This is an independent rerun. The prior reply describes a 2,992-unknown check without attaching its candidate and control fields or specifying the angle and thread settings for those small jobs. Here the audit uses the public 10 GHz coated-cylinder driver, 1,056 outer sides, a 0.10 m PEC core radius, a 0.12 m coating radius, relative permittivity 2.8 − 0.06i, both polarizations, four assembly and BLAS threads, and 360 monostatic incident directions at integer degrees. Each job used a fresh Linux process, explicit backend selection, a single fixed mesh and full residual checks. Release and candidate use identical installed dependencies. This comparison tests fields, actual backend, quality and batch counts, with single timings for context.

Use the audit directory from Claude commit 5e1c947, a source export of shipped ed90b65 and a second export with only prototype/second-polarization-credit.patch applied. Linux CPU IDs 1–4 were available for the four serial jobs in this session. Run the driver from the folder containing the script. Comparing the archived results only needs NumPy.

```sh
python run_check.py --verify .
taskset -c 1-4 python run_check.py /path/to/ed90b65 /path/to/patched-export /path/to/ghost-backend-audit fresh-results
```
