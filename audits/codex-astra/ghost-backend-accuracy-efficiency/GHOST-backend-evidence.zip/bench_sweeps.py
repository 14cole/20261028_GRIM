"""Measure full public 2-D fixed-mesh solves in separate Linux processes, one CPU thread.

Run with tools/GHOST on PYTHONPATH and OPENBLAS_NUM_THREADS=OMP_NUM_THREADS=1.
Each result includes a fresh-process RSS high-water mark and separate complex fields.
"""
import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

import numpy as np
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.geometry.io import build_geometry_snapshot, parse_geometry
from ghost_backend.twod.solver import solve_monostatic_rcs_2d

def ellipse(panels):
    phi = -2 * np.pi * np.arange(panels) / panels
    xy = np.column_stack((0.10*np.cos(phi), 0.06*np.sin(phi)))
    lines = ["Title: homogeneous lossy dielectric ellipse (m)", "Segment: body 3",
             "properties: 3 1 0 1 0"]
    for start, end in zip(xy, np.roll(xy, -1, axis=0)):
        lines.append(" ".join(f"{x:.17g}" for x in (*start,*end)))
    lines.extend(["IBCS_Resistances:", "", "Dielectrics:", "1 2.5 -0.04 1.0 0.0"])
    return build_geometry_snapshot(*parse_geometry("\n".join(lines) + "\n"))

def solve(method, n, count, out):
    angles = list(range(-90,90)) if count == 180 else list(range(360))
    snapshot = ellipse(n)
    settings = dict(factorization=method, basis_order=1, mesh_strategy="global",
                    assembly_threads=1, blas_threads=1, rhs_compression="off",
                    angle_batch_size=60, ram_budget_gib=4)
    started = time.perf_counter()
    with cpu_allocation_scope(1):
        value = solve_monostatic_rcs_2d(snapshot, [8.0], angles, geometry_units='meters',
                                         strict_quality_gate=True, compute_condition_number=True,
                                         execution_options=settings)
    elapsed = time.perf_counter() - started
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    meta = value['metadata']
    assert meta['panel_count_max'] == n and meta['quality_gate']['passed']
    assert bool(meta.get('compressed_factors', [])) == (method == 'compressed')
    fields = {}
    for pol, rows in value['co_solved_samples'].items():
        assert [x['theta_inc_deg'] for x in rows] == angles
        samples = np.array([complex(x['rcs_amp_real'], x['rcs_amp_imag']) for x in rows])
        assert np.isfinite(samples).all()
        fields[pol] = samples
    assert set(fields) == {'HH','VV'}
    record = dict(method=method, panels=n, angles=count, largest_system=meta['dense_largest_system'],
                  wall_s=elapsed, peak_MiB=peak, backend=meta['linear_backend'], gate=bool(meta['quality_gate']['passed']),
                  mesh_certified=bool(meta.get('mesh_convergence_certified',False)),
                  condition_estimate=meta.get('condition_est_max'), affinity=sorted(os.sched_getaffinity(0)))
    for key in ('factorizations','factorization_records','compressed_factors','execution_options','quality_gate'):
        if key in meta:
            (out.parent/(out.name+'_'+key+'.json')).write_text(json.dumps(meta[key],indent=2,default=str)+'\n')
    np.savez_compressed(out.with_suffix('.npz'),angles=np.array(angles),**fields)
    out.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--one',choices=('dense','compressed'))
    parser.add_argument('--panels',type=int,default=768)
    parser.add_argument('--angles',type=int,choices=(180,360),default=180)
    args=parser.parse_args()
    if args.one:
        solve(args.one,args.panels,args.angles,args.out)
        return
    args.out.mkdir(parents=True,exist_ok=True)
    order=[('dense',180),('compressed',360),('compressed',180),('dense',360)]
    trials=[(method, angles, args.panels) for method,angles in order+list(reversed(order))]
    trials.append(('dense',360,2*args.panels))
    for i,(method,angles,n) in enumerate(trials):
        dest=args.out/f'{i:02}_{method}_{angles}_{n}'
        subprocess.run([sys.executable,__file__,'--one',method,'--panels',str(n),'--angles',str(angles),'--out',str(dest)],check=True)
if __name__=='__main__':main()
