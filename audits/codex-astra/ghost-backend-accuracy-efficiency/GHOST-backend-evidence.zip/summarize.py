"""Aggregate trials and compare full complex arrays on each measured angle."""
from pathlib import Path
from collections import defaultdict
from statistics import median
import argparse
import json
import re
import numpy as np

def difference(left, right):
    return {'peak_relative_complex':float(np.max(abs(left-right))/np.max(abs(right))),
            'relative_l2':float(np.linalg.norm(left-right)/np.linalg.norm(right))}

def summarize(folder):
    paths=sorted(p for p in folder.glob('*.json') if re.fullmatch(r'\d+_(dense|compressed)_\d+_\d+',p.stem))
    records=[(p,json.loads(p.read_text())) for p in paths]
    mesh=min(row['panels'] for _,row in records)
    groups=defaultdict(list)
    for path,row in records:
        if row['panels']==mesh:groups[row['method'],row['angles']].append((path,row))
    summary={}
    field_data={}
    for (method,count),rows in groups.items():
        assert len(rows)==2
        times=[row['wall_s'] for _,row in rows]
        ram=[row['peak_MiB'] for _,row in rows]
        key=f'{method}-{count}'
        summary[key]={'wall_s':times,'median_s':median(times),'peak_MiB':ram,'median_peak_MiB':median(ram),
                      'backend':rows[0][1]['backend'],'largest_system':rows[0][1]['largest_system']}
        with np.load(rows[0][0].with_suffix('.npz')) as z:
            field_data[key]={k:z[k] for k in z}
        with np.load(rows[1][0].with_suffix('.npz')) as repeat:
            summary[key]['repeat_peak_relative']=max(difference(repeat[pol],field_data[key][pol])['peak_relative_complex'] for pol in ('VV','HH'))
    errors={}
    for count in (180,360):
        left=field_data[f'compressed-{count}'];right=field_data[f'dense-{count}']
        assert np.array_equal(left['angles'],right['angles'])
        errors[f'compressed_vs_dense-{count}']={p:difference(left[p],right[p]) for p in ('VV','HH')}
    for method in ('dense','compressed'):
        a,b=field_data[f'{method}-180'],field_data[f'{method}-360']
        indices=[int(np.flatnonzero(b['angles']==x%360)[0]) for x in a['angles']]
        errors[f'overlap-{method}']={p:difference(a[p],b[p][indices]) for p in ('VV','HH')}
    fine=[(p,r) for p,r in records if r['panels']==mesh*2]
    assert len(fine)==1 and fine[0][1]['angles']==360
    with np.load(fine[0][0].with_suffix('.npz')) as z:
        errors['dense_coarse_vs_refined-360']={p:difference(field_data['dense-360'][p],z[p]) for p in ('VV','HH')}
    return {'timing':summary,'mesh_refinement_control':fine[0][1],'errors':errors}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path)
    p.add_argument('--out',type=Path,default=Path('sweep-summary.json'))
    args=p.parse_args(); summary=summarize(args.directory)
    args.out.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
