"""External-reference 2-D GHOST accuracy checks for reproducible translated cylinders.

Use GRIM main ed90b65's tools/GHOST on PYTHONPATH, one BLAS and assembly
thread. All angles are monostatic incidence plus observation. Files contain
the individual complex angular samples and the independent analytical answers.
"""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
from scipy import special
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.execution.options import cpu_allocation_scope
from ghost_backend.twod.solver import solve_monostatic_rcs_2d

RADIUS = 0.08
CENTER = np.array([0.035, -0.021])
EPS = 2.5 - 0.04j
MU = 1.3 - 0.02j
C = 299792458.0


def make_shape(material, panels):
    az = -2*np.pi*np.arange(panels)/panels
    nodes = CENTER + RADIUS*np.column_stack((np.cos(az),np.sin(az)))
    typ = 2 if material == 'pec' else 3
    lines=['Title: translated circular cylinder',f'Segment: circle {typ}', f'properties: {typ} 1 0 {int(typ==3)} 0']
    lines += [' '.join(f'{v:.17g}' for v in (*a,*b)) for a,b in zip(nodes,np.roll(nodes,-1,axis=0))]
    lines += ['IBCS_Resistances:', '', 'Dielectrics:']
    if typ==3:
        lines.append(f'1 {EPS.real} {EPS.imag} {MU.real} {MU.imag}')
    return build_geometry_snapshot(*parse_geometry('\n'.join(lines)+'\n'))


def circle_reference(freq, mat, pol, angles, stop):
    k = 2*np.pi*freq*1e9/C
    z = k*RADIUS
    refr = np.sqrt(EPS*MU)
    n=np.arange(stop+1)
    j=special.jv(n,z)
    h=special.hankel2(n,z)
    jp=special.jvp(n,z)
    hp=special.h2vp(n,z)
    if mat=='pec':
        coeff = -jp/hp if pol=='VV' else -j/h
    else:
        interior=special.jv(n,refr*z)
        derivative = refr*special.jvp(n,refr*z)/(EPS if pol=='VV' else MU)
        coeff = (j*derivative - jp*interior)/(hp*interior-h*derivative)
    weight = np.where(n==0,1.,2.)*(-1.)**n
    amplitude = -4j*np.sum(weight*coeff)
    phi = np.deg2rad(angles)
    phase = np.exp(2j*k*(CENTER[0]*np.cos(phi)+CENTER[1]*np.sin(phi)))
    return amplitude*phase


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=Path('.'))
    cli=p.parse_args()
    out=cli.output;out.mkdir(parents=True,exist_ok=True)
    all_fields={}
    report=dict(radius_m=RADIUS,center_m=CENTER.tolist(),epsilon=[EPS.real,EPS.imag],
                mu=[MU.real,MU.imag],angle_ranges={'2.0':'-90..89 inclusive','15.0':'0..359 inclusive'},
                main_commit='ed90b65ff89826274adacae01bcfbafe143e9819',cases=[],agreement=[])
    for freq, angles, meshes in [(2.,np.arange(-90,90),[96,384]),(15.,np.arange(360),[384,768])]:
        k=2*np.pi*freq*1e9/C
        all_fields[f'angles_f{int(freq)}']=angles
        for material in ['pec','dielectric']:
            references={}
            for pol in ['VV','HH']:
                order=int(np.ceil(k*RADIUS*abs(np.sqrt(EPS*MU))+25))
                ref=circle_reference(freq,material,pol,angles,order)
                longer=circle_reference(freq,material,pol,angles,order+10)
                ref_convergence=float(np.max(abs(longer-ref))/np.max(abs(ref)))
                assert ref_convergence < 1e-12
                references[pol]=ref
                all_fields[f'f{int(freq)}_{material}_{pol}_reference']=ref
            for panels in meshes:
                solved={}
                for method in ['dense','compressed']:
                    opts=dict(factorization=method,basis_order=1,mesh_strategy='global',assembly_threads=1,
                              blas_threads=1,rhs_compression='off',angle_batch_size=64,ram_budget_gib=3)
                    with cpu_allocation_scope(1):
                        raw=solve_monostatic_rcs_2d(make_shape(material,panels),[freq],angles.tolist(),
                            geometry_units='meters',strict_quality_gate=True,compute_condition_number=True,
                            execution_options=opts)
                    meta=raw['metadata']
                    assert meta['quality_gate']['passed'] and meta['panel_count_max']==panels
                    assert bool(meta.get('compressed_factors',[])) == (method=='compressed')
                    case=dict(frequency_ghz=freq,angles=len(angles),material=material,panels=panels,
                              method=method,max_unknowns=meta['dense_largest_system'],
                              reported_backend=meta['linear_backend'],quality_gate=meta['quality_gate']['passed'],
                              mesh_certified=meta.get('mesh_convergence_certified',False),
                              operator_tiles=[{k:f['compressed'][k] for k in ('operator','tiles','compressed_tiles','retained_bytes','near_bytes','far_bytes') if k in f['compressed']}
                                              for f in meta.get('compressed_factors',[])],
                              condition_estimate=meta['condition_est_max'], channels={})
                    for pol,ref in references.items():
                        rows=raw['co_solved_samples'][pol]
                        assert list(angles)==[r['theta_inc_deg'] for r in rows]
                        v=np.array([complex(r['rcs_amp_real'],r['rcs_amp_imag']) for r in rows])
                        err=float(np.max(abs(v-ref))/np.max(abs(ref)))
                        assert np.isfinite(err)
                        key=f'f{int(freq)}_{material}_{panels}_{method}_{pol}'
                        all_fields[key] = v
                        solved[(method,pol)]=v
                        case['channels'][pol]=dict(peak_relative_complex_error=err,
                            max_abs_rcs_error_db=float(np.max(abs(20*np.log10(abs(v)/abs(ref))))))
                        if method=='compressed':
                            d=solved[('dense',pol)]
                            report['agreement'].append(dict(frequency_ghz=freq,material=material,panels=panels,
                                polarization=pol,relative_l2=float(np.linalg.norm(v-d)/np.linalg.norm(d))))
                    report['cases'].append(case)
                    print(json.dumps(case),flush=True)
                    (out/'accuracy.json').write_text(json.dumps(report,indent=2)+'\n')
                    np.savez_compressed(out/'complex_fields.npz',**all_fields)

if __name__=='__main__':
    main()
