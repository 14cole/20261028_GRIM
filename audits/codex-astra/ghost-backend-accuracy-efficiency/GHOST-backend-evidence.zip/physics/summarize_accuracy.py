"""Read both saved numerical archives, independently recompute errors and identify the worst case."""
import json
from pathlib import Path
import numpy as np

def summarize(root):
    groups={}
    aggregate=[]
    for coated, name in [(False,'accuracy'),(True,'coating')]:
        report=json.loads((root/(name+'.json')).read_text())
        records=report['cases']
        assert len(records)==(8 if coated else 16)
        fieldfile='coating_fields.npz' if coated else 'complex_fields.npz'
        with np.load(root/fieldfile,allow_pickle=False) as arrays:
            for item in records:
                mat='coated_pec' if coated else item['material']
                freq=item['freq_ghz'] if coated else item['frequency_ghz']
                mesh=(item['outer_panels'],item['inner_panels']) if coated else (item['panels'],)
                prefix=f'f{int(freq)}_'+('' if coated else mat+'_')
                prefix+=('_'.join(map(str,mesh)) if coated else str(mesh[0]))+'_'
                angles=arrays[f'f{int(freq)}_angles' if coated else f'angles_f{int(freq)}']
                assert len(angles)==item['angles']
                case=dict(material=mat,freq_ghz=freq,mesh=list(mesh),angles=len(angles),unknowns=item['max_unknowns'])
                row=groups.setdefault((mat,freq,mesh),dict(**case,worst_complex_error=0.0,worst_width_error_db=0.0,max_method_difference_l2=0.0))
                for pol in ('VV','HH'):
                    val=arrays[f"{prefix}{item['method']}_{pol}"]
                    ref=arrays[f'f{int(freq)}_reference_{pol}' if coated else f'f{int(freq)}_{mat}_{pol}_reference']
                    error=float(np.max(abs(val-ref))/np.max(abs(ref)))
                    db=float(np.max(abs(20*np.log10(abs(val)/abs(ref)))))
                    assert abs(item['channels'][pol]['peak_relative_complex_error']-error) <1e-12
                    assert abs(item['channels'][pol]['max_abs_rcs_error_db']-db)<1e-10
                    row['worst_complex_error']=max(row['worst_complex_error'],error)
                    row['worst_width_error_db']=max(row['worst_width_error_db'],db)
                    other=arrays[f'{prefix}dense_{pol}']
                    rel=float(np.linalg.norm(val-other)/np.linalg.norm(other))
                    row['max_method_difference_l2']=max(row['max_method_difference_l2'],rel)
                aggregate.append(item['method'])
    rows=sorted(groups.values(),key=lambda x:(x['freq_ghz'],x['material'],x['mesh']))
    for freq in [2.,15.]:
        for mat in ['pec','dielectric','coated_pec']:
            a,b=[r for r in rows if r['material']==mat and r['freq_ghz']==freq]
            assert b['worst_complex_error']<a['worst_complex_error']
    return dict(fresh_solves=len(aggregate),cases=rows)

if __name__=='__main__':
    p=Path('.')
    blob=summarize(p)
    (p/'reference_summary.json').write_text(json.dumps(blob,indent=2)+'\n')
    for r in blob['cases']:
        print(r['freq_ghz'],r['material'],r['mesh'],f"error={r['worst_complex_error']:.5g}, dB={r['worst_width_error_db']:.5g}")
