"""Independent modal benchmark for a translated loss/magnetic-coated PEC cylinder.

Run beside validate_cylinders.py in the same environment. The analytic
reference satisfies the inner PEC condition and matches fields and
material-scaled derivatives at the exterior of the annulus.
"""
import json
from pathlib import Path
import numpy as np
from scipy import special
from validate_cylinders import (C, EPS, MU, CENTER, RADIUS, cpu_allocation_scope,
    solve_monostatic_rcs_2d, build_geometry_snapshot, parse_geometry)

CORE = 0.05

def geometry(outer,inner):
    text=['Title: coated circular PEC cylinder']
    for label,typ,rad,count in [('shell',3,RADIUS,outer),('metal',4,CORE,inner)]:
        text += [f'Segment: {label} {typ}',f'properties: {typ} 1 0 1 0']
        phi=-2*np.pi*np.arange(count)/count
        pts=CENTER+rad*np.column_stack((np.cos(phi),np.sin(phi)))
        text += [' '.join(f'{v:.17g}' for v in (*a,*b)) for a,b in zip(pts,np.roll(pts,-1,axis=0))]
    text += ['IBCS_Resistances:', '', 'Dielectrics:', f'1 {EPS.real} {EPS.imag} {MU.real} {MU.imag}']
    return build_geometry_snapshot(*parse_geometry('\n'.join(text)+'\n'))

def coated_ref(freq,pol,angles,cutoff):
    k=2*np.pi*freq*1e9/C
    z=k*RADIUS
    m=np.sqrt(EPS*MU)
    zi=m*k*CORE
    zo=m*z
    n=np.arange(cutoff+1)
    if pol=='VV':
        alpha=-special.jvp(n,zi)/special.yvp(n,zi)
    else:
        alpha=-special.jv(n,zi)/special.yv(n,zi)
    outer=special.jv(n,zo)+alpha*special.yv(n,zo)
    derivative=(special.jvp(n,zo)+alpha*special.yvp(n,zo))*m/(EPS if pol=='VV' else MU)
    b=(special.jv(n,z)*derivative-special.jvp(n,z)*outer)/(special.h2vp(n,z)*outer-special.hankel2(n,z)*derivative)
    monostatic=-4j*np.sum(np.where(n==0,1.,2.)*(-1.)**n*b)
    phi=np.deg2rad(angles)
    return monostatic*np.exp(2j*k*(CENTER[0]*np.cos(phi)+CENTER[1]*np.sin(phi)))

def main():
    out=Path('.')
    records=[]; agreement=[]; fields={}
    for freq,angles,meshes in [(2.,np.arange(-90,90),[(96,60),(384,240)]),
                               (15.,np.arange(360),[(384,240),(768,480)])]:
        refs={}
        for pol in ('VV','HH'):
            n=int(np.ceil(2*np.pi*freq*1e9/C*RADIUS*abs(np.sqrt(EPS*MU))+25))
            refs[pol]=coated_ref(freq,pol,angles,n)
            extra=coated_ref(freq,pol,angles,n+10)
            assert np.max(abs(extra-refs[pol]))/np.max(abs(refs[pol])) < 1e-12
            fields[f'f{int(freq)}_reference_{pol}']=refs[pol]
        fields[f'f{int(freq)}_angles']=angles
        for outer,inner in meshes:
            for method in ('dense','compressed'):
                opts=dict(factorization=method,basis_order=1,mesh_strategy='global',assembly_threads=1,
                          blas_threads=1,rhs_compression='off',angle_batch_size=64,ram_budget_gib=3)
                with cpu_allocation_scope(1):
                    result=solve_monostatic_rcs_2d(geometry(outer,inner),[freq],angles.tolist(),geometry_units='meters',
                          strict_quality_gate=True,compute_condition_number=True,execution_options=opts)
                m=result['metadata']
                assert m['quality_gate']['passed'] and m['panel_count_max']==outer+inner
                info=dict(freq_ghz=freq,angles=len(angles),outer_panels=outer,inner_panels=inner,
                          max_unknowns=m['dense_largest_system'],method=method,linear_backend=m['linear_backend'],
                          factor_metadata=m.get('compressed_factors',[]),discrete_gate=True,mesh_certified=m.get('mesh_convergence_certified',False),channels={})
                for pol,ref in refs.items():
                    rows=result['co_solved_samples'][pol]
                    assert [r['theta_inc_deg'] for r in rows]==list(angles)
                    value=np.array([complex(r['rcs_amp_real'],r['rcs_amp_imag']) for r in rows])
                    key=f'f{int(freq)}_{outer}_{inner}_{method}_{pol}'
                    fields[key]=value
                    info['channels'][pol]=dict(peak_relative_complex_error=float(np.max(abs(value-ref))/np.max(abs(ref))),
                                                max_abs_rcs_error_db=float(np.max(abs(20*np.log10(abs(value)/abs(ref))))))
                    if method=='compressed':
                        d=fields[key.replace('compressed','dense')]
                        agreement.append(dict(key=key,relative_l2=float(np.linalg.norm(value-d)/np.linalg.norm(d))))
                records.append(info)
                report = dict(core_radius_m=CORE,outer_radius_m=RADIUS,center_m=CENTER.tolist(),
                             epsilon=[EPS.real,EPS.imag],mu=[MU.real,MU.imag],cases=records,agreement=agreement)
                (out/'coating.json').write_text(json.dumps(report,indent=2)+'\n')
                np.savez_compressed(out/'coating_fields.npz',**fields)
                print(freq,outer,inner,method,info['channels'],flush=True)
if __name__=='__main__':
    main()
