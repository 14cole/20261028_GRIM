"""Use the desktop's Automatic policy and its fresh certified single-frequency backend.
Place validate_cylinders.py and the released tools/GHOST directory on PYTHONPATH.
"""
import argparse
import json
from pathlib import Path
import resource
import time
import numpy as np
from validate_cylinders import make_shape, circle_reference
from ghost_backend.execution.options import automatic_run, cpu_allocation_scope, execution_scope
from ghost_backend.execution.fresh_sweep import run_fresh
from ghost_backend.runs.quality import accuracy_target_policy
from ghost_backend.twod.solver import solve_monostatic_rcs_2d_certified

def run(work, vertices):
    controls=automatic_run('monostatic')
    opts=controls['execution_options']
    opts.update(assembly_threads=1,blas_threads=1)
    angles=np.arange(-90,90)
    policy=accuracy_target_policy('standard')
    report={'frequency_ghz':2.,'base_geometry_vertices':vertices,'material':'dielectric',
            'radius_m':0.08, 'center_m':[0.035,-0.021], 'relative_permittivity':[2.5,-0.04],
            'relative_permeability':[1.3,-0.02], 'execution_options':opts, 'mesh_policy':policy,
            'geometry_units':'meters','incident_angles':180,'solver_method':controls['solver_method'],
            'lu_precision':controls['lu_precision']}
    call=dict(geometry_snapshot=make_shape('dielectric',vertices), frequencies_ghz=[2.], elevations_deg=angles.tolist(),
              geometry_units='meters',mesh_convergence_policy=policy,solver_method=controls['solver_method'])
    start=time.perf_counter()
    with cpu_allocation_scope(1), execution_scope(opts,limit_blas=True):
        try:
            value=run_fresh(solve_monostatic_rcs_2d_certified,call,opts,controls['lu_precision'],True)
        except Exception as exc:
            report.update(outcome='refused', reason=str(exc), exception=type(exc).__name__)
            return report
    report.update(outcome='solved',wall_seconds=time.perf_counter()-start,
                  peak_process_RSS_GiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
    m=value['metadata']
    keys=['linear_backend','solver_method','panel_count_max','dense_largest_system','certified_entry_point',
          'mesh_convergence_certified','published_mesh','quality_gate','mesh_convergence','mesh_strategy','basis_order']
    report['metadata']={k:m[k] for k in keys if k in m}
    report['channel_mesh']={c:{k:v for k,v in cm.items() if k in keys or k.startswith(('adaptive_','galerkin_'))}
                            for c,cm in m['channel_metadata'].items()}
    fields={'angles_deg':angles}
    report['physics']={}
    for c in ['VV','HH']:
        rows=value['co_solved_samples'][c]
        assert [a['theta_inc_deg'] for a in rows]==angles.tolist()
        got=np.asarray([complex(a['rcs_amp_real'],a['rcs_amp_imag']) for a in rows])
        ref=circle_reference(2.,'dielectric',c,angles,40)
        extended=circle_reference(2.,'dielectric',c,angles,50)
        fields[c]=got
        fields[c+'_reference']=ref
        report['physics'][c]={'max_rel_complex_error':float(np.max(abs(got-ref))/np.max(abs(ref))),
                              'reference_tail':float(np.max(abs(extended-ref))/np.max(abs(ref))),
                              'max_abs_rcs_error_db':float(np.max(abs(20*np.log10(abs(got/ref)))))}
    np.savez_compressed(work/'certified_fields.npz',**fields)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=Path('.'));p.add_argument('--vertices',type=int,default=96);args=p.parse_args()
    args.output.mkdir(exist_ok=True,parents=True)
    summary=run(args.output,args.vertices)
    def convert(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        raise TypeError(type(x).__name__)
    (args.output/'certified.json').write_text(json.dumps(summary,indent=2,default=convert)+'\n')
    print(summary['outcome'], summary.get('physics',summary.get('reason')))
