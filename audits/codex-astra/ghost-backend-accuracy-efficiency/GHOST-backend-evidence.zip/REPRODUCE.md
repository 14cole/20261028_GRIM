# Reproduce the backend checks

Use a Linux Python environment with the dependencies of GHOST at `ed90b65ff89826274adacae01bcfbafe143e9819` in 14cole/20261028_GRIM. All test and reference scripts are included in the archive. Run from its root in a new working directory. Replace CPU 3 with an allowed CPU on your host. Wall times and peak RSS depend on hardware, libraries and thread counts.

```bash
export GRIM_ROOT=/path/to/20261028_GRIM
export PYTHONPATH="$GRIM_ROOT/tools/GHOST:$PWD/physics"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
sha256sum -c SHA256SUMS
mkdir -p replay/physics replay/sweeps
python physics/validate_cylinders.py --output replay/physics
(cd replay/physics && python ../../physics/validate_coating.py && python ../../physics/summarize_accuracy.py)
python physics/certified_control.py --output replay/certified
python physics/certified_control.py --vertices 192 --output replay/certified-finer
taskset -c 3 python bench_sweeps.py --out replay/sweeps
python summarize.py replay/sweeps --out replay/sweep-summary.json
```

The fixed-mesh reference and performance scripts force a backend and capture both polarizations. The certified control uses the default Automatic and standard convergence settings with a one-thread CPU limit. Its --vertices option changes the input polygon resolution. The individual .npz files contain the complex samples. The per-trial execution, quality-gate and compressed-factor metadata identify what actually ran. For the angular overlap check, −90° through −1° match 270° through 359°. Compare each channel separately.

`results/` contains eight ordered timing trials and the independent refined-ellipse control. `physics/` contains external reference data and the homogeneous and coated cylinder comparisons. `certified/` holds the two default-policy controls. The archive includes numerical arrays and output metadata from small test geometries. It contains no production edits or native binaries.
