"""Recompute the Round 4 raw fields, timings, memory and identity controls from the pinned archive.

Usage: python verify_round4.py /path/to/ghost-backend-audit
Requires NumPy and SciPy. No GHOST solve is executed.
"""
import argparse
import datetime
import itertools
import json
import re
from pathlib import Path

import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp


GIB = 1024**3


def solve_analytic(polarization, angles):
    k = 2*np.pi*10e9 / 299792458.0
    eps = 2.8 - 0.06j
    refractive_index = np.sqrt(eps)
    q = refractive_index / (1. if polarization == "TM" else eps)
    a, b = k*refractive_index*.100, k*refractive_index*.120
    x = k*.120
    solution = []
    for n in range(91):
        # Three unknowns: outgoing field and the two annular Bessel amplitudes.
        # Continuity of field and scaled radial flux, then PEC core condition.
        aj, ay = (jv(n, a), yv(n, a)) if polarization == "TM" else (jvp(n, a), yvp(n, a))
        mat = np.array([[hankel2(n,x), -jv(n,b), -yv(n,b)],
                        [h2vp(n,x), -q*jvp(n,b), -q*yvp(n,b)], [0., aj, ay]])
        scale = np.max(np.abs(mat), axis=0)
        s = np.linalg.solve(mat/scale, [-jv(n,x), -jvp(n,x), 0.])[0]/scale[0]
        solution.append(s*(-1)**n * (1 if n == 0 else 2))
    phi = np.deg2rad(angles)
    shift = np.exp(2j * k * (.031*np.cos(phi) -.017*np.sin(phi)))
    return -4j * sum(solution) * shift


def metric(test, ref):
    assert test.shape == ref.shape and np.isfinite(test).all() and np.isfinite(ref).all()
    d = abs(test - ref)
    return dict(bit_identical=test.tobytes()==ref.tobytes(), max_over_peak=float(d.max()/max(abs(ref))),
                rel_l2=float(np.linalg.norm(d)/np.linalg.norm(ref)), angle_of_max_deg=int(d.argmax()))


def fields(path, keys):
    with np.load(path, allow_pickle=False) as z:
        assert np.array_equal(z['angles_deg'], np.arange(360.))
        return {k:z[k] for k in keys}


def compare(a, b):
    return {p:metric(a['ghost_'+p], b['ghost_'+p]) for p in ('TM', 'TE')}


def samples(path):
    lines = path.read_text().splitlines()
    columns = lines[0].split()
    frames = []
    for line in lines[1:]:
        values = line.split()
        assert len(columns) == len(values)
        frames.append({k: (float(v.split('=')[1]) if k == 'psi_some_avg10' else int(v))
                       for k, v in zip(columns, values)})
    assert all(a['t_s'] < b['t_s'] for a, b in zip(frames, frames[1:]))
    assert all(a['read_bytes'] <= b['read_bytes'] for a,b in zip(frames,frames[1:]))
    return frames


def report(audit):
    folder = audit/'results'/'c_cand24k'
    first = fields(audit/'results'/'c_proto24k'/'candidate'/'s8448_a360_t4_dense.npz', ('ghost_TE', 'ghost_TM'))
    old = fields(audit/'results'/'c_trace24k'/'s8448_a360_t4_dense.npz', ('ghost_TE','ghost_TM'))
    exact = {p: solve_analytic(p, np.arange(360.)) for p in ('TE','TM')}
    arrays, results = {}, {}
    for tag in ('current','candidate'):
        run = folder/tag
        assert (run/'status.txt').read_text().split()[0] == 'rc=0'
        assert not (run/'dense.err').read_text().strip()
        d = json.loads((run/'dense.out').read_text())
        assert (d['quality_passed'] and d['requested']=='dense' and d['rhs_compression']=='off'
                and d['threads']==4 and d['angles']==360 and d['unknowns_per_system']==23936
                and d['ghz']==10. and d['panels']==15488 and not d['warnings'])
        arrays[tag] = fields(run/'s8448_a360_t4_dense.npz', ('ghost_TE','ghost_TM','analytic_TE','analytic_TM'))
        plans = [e for e in d['memory_estimates'] if e.get('model')=='dense_phase_v1']
        assert len(plans)==2 and all(p['residual_storage']=='disk' for p in plans)
        batch = [p['angle_batch_size'] for p in plans]
        b = d['rhs_batches']
        s = d['stage_calls']
        assert sum((360+w-1)//w for w in batch)==b['dense_rhs_batch_count']==s['linear_solve']
        assert b['dense_rhs_column_count']==720 and b['assembled_system_reuses']==1 and b['dense_factorization_count']==2
        assert len({p['matrix_bytes'] for p in plans})==1
        filesize = plans[0]['matrix_bytes']
        assert filesize == 16*d['unknowns_per_system']**2
        samples_ = samples(run/'samples.txt')
        high = lambda key: max(r[key] for r in samples_)
        sample_peaks = {k:high(k)/GIB for k in ('cg_usage','cg_rss','cg_cache','cg_inactive_file','cg_active_file')}
        io = d['process_io']
        plans_out = [dict(planned_capacity_gib=p['capacity_bytes']/GIB,
                          peak_forecast_gib=p['peak_bytes']/GIB, batch=p['angle_batch_size'],
                          recovery=p['memory_recovery'],tile=p['assembly_tile'],
                          matrix_credit_gib=p.get('reused_matrix_credit_bytes',0)/GIB)
                     for p in plans]
        checks = {}
        for p in ('TE','TM'):
            f = arrays[tag]['ghost_'+p]
            a = arrays[tag]['analytic_'+p]
            errors = metric(f,exact[p])
            refcheck = metric(a, exact[p])
            assert refcheck['max_over_peak'] < 2e-14
            assert abs(errors['max_over_peak']-d['error_'+p]) < 2e-14
            checks[p] = dict(analytic_vs_independent=refcheck, solver_vs_independent=errors,
                             vs_earlier_current_trace=metric(f,old['ghost_'+p]),
                             vs_first_prototype=metric(f,first['ghost_'+p]))
        gate, = [event for event in d['memory_estimates'] if event.get('method') == 'reused_dense_matrix_admission']
        logged_wall_s = int(re.search(r'wall=(\d+)s', (run/'status.txt').read_text()).group(1))
        assert samples_[-1]['t_s'] <= logged_wall_s
        assert samples_[-1]['read_bytes'] <= io['read_bytes']
        sampled_hwm_gib = high('hwm_kb')/1024**2
        assert sampled_hwm_gib <= d['peak_rss_gib'] + .0005
        results[tag] = dict(subprocess_wall_s=d['process_wall_s'], wrapper_wall_s=logged_wall_s,
                            sampled_process_hwm_gib=sampled_hwm_gib,
                            sampled_global_major_fault_delta=samples_[-1]['pgmajfault'] - samples_[0]['pgmajfault'],
                            planning_offer_bytes=plans[-1].get('reused_matrix_offered_bytes'),
                            planning_credit_bytes=plans[-1].get('reused_matrix_credit_bytes'),
                            admission=gate, solve_wall_s=d['solve_wall_s'], peak_rss_gib=d['peak_rss_gib'],
                            residual_max=d['residual_max'],factor_count=b['dense_factorization_count'],
                            batch_column_count=b['dense_rhs_column_count'], matrix_reuse_count=b['assembled_system_reuses'],
                            plans=plans_out, measured_stages=d['stage_seconds'],stage_calls=s,
                            additional_inverse_applications=s['rhs_solve']-s['linear_solve'],
                            matrix_bytes=filesize, logical_read_equivalents=io['rchar']/filesize,
                            physical_read_equivalents=io['read_bytes']/filesize,
                            process_read_bytes=io['read_bytes'], process_write_bytes=io['write_bytes'],
                            sampled_peak_gib=sample_peaks, sampled_system_psi_max=high('psi_some_avg10'),
                            sampled_system_psi_nonzero_points=[(r["t_s"],r["psi_some_avg10"]) for r in samples_ if r["psi_some_avg10"] > 0.],
                            sampled_count=len(samples_), sampled_last_seconds=samples_[-1]['t_s'],
                            errors=checks)
    a,b = results['current'],results['candidate']
    dt=a['solve_wall_s']-b['solve_wall_s']
    diff = dict(speedup=a['solve_wall_s']/b['solve_wall_s'],elapsed_reduction_s=dt,
                elapsed_reduction_pct=dt/a['solve_wall_s']*100,
                inclusive_linear_reduction_s=a['measured_stages']['linear_solve']-b['measured_stages']['linear_solve'],
                physical_reads_reduction_pct=100*(1-b['process_read_bytes']/a['process_read_bytes']),
                peak_rss_delta_gib=b['peak_rss_gib']-a['peak_rss_gib'],
                peak_rss_delta_pct=(b['peak_rss_gib']/a['peak_rss_gib']-1)*100,
                sampled_anon_delta_gib=b['sampled_peak_gib']['cg_rss']-a['sampled_peak_gib']['cg_rss'])
    boot = boot_window(folder)
    assert boot['elapsed_s'] == sum(run['wrapper_wall_s'] for run in results.values())
    earlier_compressed = json.loads((audit/'results'/'c_large'/'compressed.out').read_text())
    return dict(runs=results, change=diff, session=boot, earlier_session_compressed={
        k:earlier_compressed[k] for k in ('solve_wall_s','peak_rss_gib','unknowns_per_system','angles','threads')
    }, field_change=compare(arrays['candidate'],arrays['current']),
                small=small_controls(audit), identity=identity_controls(audit))


def boot_window(folder):
    def time_and_uptime(marker):
        lines = (folder/f'host_{marker}.txt').read_text().splitlines()
        now = datetime.datetime.strptime(lines[-1], '%a %b %d %H:%M:%S UTC %Y').replace(tzinfo=datetime.timezone.utc)
        value = re.search(r' up\s+(\d+(?::\d+)?)( min)?,', lines[-2]).group(1)
        if ':' in value:
            hour, minute = (int(x) for x in value.split(':'))
            minutes = hour*60+minute
        else:
            minutes = int(value)
        return now, minutes
    start, a = time_and_uptime('start')
    end, b = time_and_uptime('end')
    short = datetime.timedelta(minutes=1)
    inferred_starts = [start-a*short, end-b*short]
    return dict(start=start.isoformat(), end=end.isoformat(), elapsed_s=(end-start).total_seconds(),
                uptime_start_min=a, uptime_end_min=b,
                rounded_uptime_consistent_with_one_boot=max(inferred_starts)-short <= min(inferred_starts),
                boot_id_provided=False)


def small_controls(audit):
    folder = audit/'results'/'d_small'
    result = {}
    for backend in ('dense','compressed'):
        meta, output = {}, {}
        for tag in ('main','cand'):
            name = f'{tag}_{backend}'
            assert not (folder/f'{name}.err').read_text().strip()
            d = json.loads((folder/f'{name}.json').read_text())
            assert d['quality_passed'] and not d['warnings'] and d['requested'] == backend
            assert (d['angles'],d['unknowns_per_system'],d['threads']) == (360, 2992, 1)
            meta[tag] = d
            output[tag] = fields(folder/f'{name}.npz',('ghost_TM','ghost_TE'))
        same = meta['main']['rhs_batches'] == meta['cand']['rhs_batches']
        result[backend] = dict(fields=compare(output['cand'],output['main']),
                               candidate_batch_events=meta['cand']['rhs_batches'],
                               identical_batch_events=same,
                               independent_reference_errors={p:metric(output['cand']['ghost_'+p], solve_analytic(p, np.arange(360.)))
                                                             for p in ('TE','TM')},
                               reported_walls_s={k:v['solve_wall_s'] for k,v in meta.items()})
    return result


def identity_controls(audit):
    folder = audit/'results'/'d_identity'
    labels = ('shipped','prototype','codex_revision','candidate')
    groups = {label:json.loads((folder/f'{label}.json').read_text()) for label in labels}
    decisions = {}
    fields_by_tree = {}
    result = {}
    for tree, group in groups.items():
        rows = group['rows']
        assert len(rows) == 37
        counts = {key:0 for key in ('solved','refused','hit_with_credit','miss_without_credit',
                                    'miss_with_credit','hit_without_credit','hit_at_batch_1')}
        bad = []
        decisions[tree] = []
        fields_by_tree[tree] = {}
        for i,r in enumerate(rows):
            solved = r['outcome'] == 'solved'
            counts[r['outcome']] += 1
            lookup = r['lookup'] or {}
            hit = lookup.get('hit')
            gate_credit = (r['final_gate'] or {}).get('credit_bytes', 0)
            tm = r['tm_plans']
            width = tm[-1]['batch'] if tm else None
            te_headroom = None if r['te_available_gib'] is None else round(r['te_available_gib']-group['reserve_gib'], 2)
            tm_headroom = None if r['tm_available_gib'] is None else round(r['tm_available_gib']-group['reserve_gib'], 2)
            decisions[tree].append([r['case'], te_headroom, tm_headroom, r['outcome'], hit,
                                    bool(gate_credit), width, lookup.get('retained_tile'), lookup.get('requested_tile')])
            assert r['credited_without_reuse'] == bool(solved and gate_credit and not hit)
            if not solved:
                continue
            assert hit is not None
            counts[('hit' if hit else 'miss') + ('_with_credit' if gate_credit else '_without_credit')] += 1
            counts['hit_at_batch_1'] += int(hit and width == 1)
            if not hit and gate_credit:
                bad.append(dict(index=i, row=r['case'], te_headroom_gib=te_headroom,
                                tm_headroom_gib=tm_headroom, retained_tile=lookup['retained_tile'],
                                lookup_tile=lookup['requested_tile'], gate_credit_bytes=gate_credit))
            arr = {}
            for p in ('te','tm'):
                v = np.asarray(r[p])
                assert v.shape == (2, 180) and np.isfinite(v).all()
                arr[p] = v[0] + 1j*v[1]
            fields_by_tree[tree][i] = arr
        result[tree] = dict(counts=counts, false_credit=bad)
    agrees = decisions['candidate'] == decisions['codex_revision']
    changed = [i for i,(a,b) in enumerate(zip(decisions['shipped'], decisions['prototype'])) if a[3]!=b[3]]
    assert all(row[0:3] == ref[0:3] for tree in labels for row,ref in zip(decisions[tree],decisions['shipped']))
    # Compare all solved pairs in both normalization directions using the smaller peak as denominator.
    all_fields = [(label,i,fields) for label, rows in fields_by_tree.items() for i,fields in rows.items()]
    max_delta = {p:0.0 for p in ('te','tm')}
    for (_,_,f),(_,_,g) in itertools.combinations(all_fields,2):
        for p in ('te','tm'):
            max_delta[p] = max(max_delta[p], float(np.max(abs(f[p]-g[p])) / min(np.max(abs(v[p])) for v in (f,g))))
    matched_raw = all(np.array_equal(fields_by_tree['candidate'][i][p].view('u8'),v[p].view('u8'))
                      for i,v in fields_by_tree['codex_revision'].items() for p in ('te','tm'))
    return dict(trees=result, all_solved_rows=len(all_fields), all_pairs_max_over_peak=max_delta,
                revision_candidate_decision_match=agrees, revision_candidate_matching_rows_fields_bitwise_equal=matched_raw,
                changed_shipped_vs_prototype_rows=changed)


if __name__=='__main__':
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('audit',type=Path)
    print(json.dumps(report(arg.parse_args().audit), indent=2))
