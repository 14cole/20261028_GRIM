# Reproduce the fourth-round review

Unzip `CHECKS.zip` in an empty working directory. The archive holds the raw controls and scripts. Claude’s large original arrays and logs remain at the pinned GitHub commit. Use Python with NumPy and SciPy and a Linux environment with the repository’s GHOST dependencies. The local runs used x86-64 Linux 6.18.57, AMD EPYC 7763, a 16 GiB cgroup, a four-CPU quota, Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0. Whole-page counts, exact timing, peak memory and baseline ledger credits can vary with allocator alignment and host load.

## Prepare disposable checkouts

Run these commands in the evidence directory, setting `repo_dir` to a clone containing the shipped commit and Claude’s exact commit. All three trees created here are disposable exports. The additional patch is included both in the archive and beside the review on the audit branch. Its SHA-256 is `8e651825b8e735e55a968b921aff335d3263090caa74a5ccf08b8287200d18f8`.

```sh
set -eu
export EVIDENCE="$PWD"
sha256sum -c SHA256SUMS
repo_dir=/path/to/20261028_GRIM
work_dir=$(mktemp -d)
shipped=ed90b65ff89826274adacae01bcfbafe143e9819
review=d0b732fc025d47118ae999970be0f392bff9e89f
audit_dir=audits/claude-2026-11-26/ghost-backend-audit
mkdir -p "$work_dir/shipped" "$work_dir/candidate" "$work_dir/revised" "$work_dir/audit"
git -C "$repo_dir" archive "$shipped" | tar -x -C "$work_dir/shipped"
git -C "$repo_dir" archive "$review:$audit_dir" | tar -x -C "$work_dir/audit"
export SHIPPED_ROOT="$work_dir/shipped"
export CANDIDATE_ROOT="$work_dir/candidate"
export REVISED_ROOT="$work_dir/revised"
export CLAUDE_AUDIT="$work_dir/audit"
cp -a "$SHIPPED_ROOT/." "$CANDIDATE_ROOT/"
git -C "$CANDIDATE_ROOT" apply --check "$CLAUDE_AUDIT/prototype/candidate-vs-ed90b65.patch"
git -C "$CANDIDATE_ROOT" apply "$CLAUDE_AUDIT/prototype/candidate-vs-ed90b65.patch"
cp -a "$CANDIDATE_ROOT/." "$REVISED_ROOT/"
git -C "$REVISED_ROOT" apply --check "$EVIDENCE/private-matrix-reuse.patch"
git -C "$REVISED_ROOT" apply "$EVIDENCE/private-matrix-reuse.patch"
export PYTHONPATH="$CLAUDE_AUDIT" GRIM_ROOT="$CANDIDATE_ROOT"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
```

## Recompute stored comparisons

```sh
python data/verify_round4.py "$CLAUDE_AUDIT"
python small/run_check.py --verify small
python small/run_check.py --verify small-revised
python midscale/pair.py "$SHIPPED_ROOT" "$REVISED_ROOT" "$CLAUDE_AUDIT" midscale --verify
python midscale/compare_orders.py midscale
python live/ledger/check_ledger.py compare live/ledger
python live/check_public.py compare live
python live/tiles/compare_tiles.py live/tiles
python revised-checks/compare_two_shells.py revised-checks linux
python multiangle/replay.py --analyze
python alternative/summarize_private.py "$EVIDENCE"
```

## Fresh computations

Use separate output directories to preserve the archived reference data. For per-case command lines, follow `linux/REPLAY.md`, `multiangle/REPLAY.md`, `live/REPLAY.md`, `revised-checks/REPLAY.md`, `windows/REPLAY.md`, `integration/NOTES.md` and `alternative/REPLAY.md`. The last describes a separate experimental branch from the Claude candidate. The combined patch already contains the dielectric change.

```sh
python small/run_check.py "$SHIPPED_ROOT" "$CANDIDATE_ROOT" "$CLAUDE_AUDIT" "$work_dir/new-small"
python small/run_check.py "$SHIPPED_ROOT" "$REVISED_ROOT" "$CLAUDE_AUDIT" "$work_dir/new-small-revised"
python midscale/pair.py "$SHIPPED_ROOT" "$REVISED_ROOT" "$CLAUDE_AUDIT" "$work_dir/new-midscale"
python midscale/pair.py "$SHIPPED_ROOT" "$REVISED_ROOT" "$CLAUDE_AUDIT" "$work_dir/new-midscale/reversed" --shipped-first
python midscale/compare_orders.py "$work_dir/new-midscale"
python pageflags/study.py "$CANDIDATE_ROOT"
python cow/write_cost.py "$CANDIDATE_ROOT"
NUMPY_MADVISE_HUGEPAGE=0 python pageflags/solve.py "$CANDIDATE_ROOT" "$CLAUDE_AUDIT" "$work_dir/pageflags"
python integrated/verify_probe.py "$REVISED_ROOT"
python integrated/huge_fork.py "$REVISED_ROOT"
```

For the allocation-only 24k control run `python pageflags/study.py "$CANDIDATE_ROOT" --full` or `python integrated/verify_probe.py "$REVISED_ROOT" --large` on a Linux cgroup-v2 host with a numeric memory limit and at least 8.54 GiB plus 4 GiB free. Each creates a fully written array and releases it at process exit. The real 11,968-unknown disk pair needs room for a 2.14 GiB matrix in scratch. The separate 23,936-unknown solver run requires at least 8.54 GiB in scratch and enough RAM for the public solver. Claude’s `timed_job.py` and `trace_24k.sh` are in the pinned audit directory. The historical trace script collects cgroup-v1 counters, so use the corresponding v2 counters when replaying on cgroup v2.

## Directory guide

| Directory | Evidence |
|---|---|
| `data` | Recount of all 148 archival controls, large before/after fields, independent cylinder solution, timings and host counters |
| `small`, `small-revised` | Fresh 2,992-unknown Dense and Compressed public runs against shipped, original patch and integrated addition |
| `midscale` | Fresh, order-balanced 11,968-unknown public disk pairs with natural headroom and 360 complex outputs per polarization and run |
| `live`, `windows` | Original patch with real, absent, lost and partial observations, live ledger, tile transitions, dispatch and native Windows test script |
| `multiangle` | Two coated bodies at 180 signed monostatic angles with both versions of the candidate |
| `linux`, `cow` | Real two-body page transitions plus separate anonymous zero-page and fork controls |
| `pageflags`, `integrated` | Independent per-page feasibility checks and integrated code interface, failure and allocation controls |
| `integration` | Checks on actual destination identity for an ordinary and an extreme dielectric |
| `revised-checks` | 13 fresh public solver trials of the combined patch with gate decisions and fields |
| `alternative` | Independent `smaps` comparator and its raw results, including repeated huge-page controls |

The files named `candidate` in `small-revised` and `revised-checks` are runs of the combined patch. Files named `candidate` in `small` and `live` are runs of Claude’s original candidate. Geometry, frequency, number of angles and public entry points are recorded in the individual scripts. Numerical quality here refers to the tested fixed mesh.
