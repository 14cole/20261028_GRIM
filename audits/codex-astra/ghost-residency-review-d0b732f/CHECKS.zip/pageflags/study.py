"""Linux proof of concept. Reads only flag words about the calling process's own NumPy array."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import sys
import time
import numpy as np

def private_candidate(a):
    """Research gate on Linux. None means ownership, layout or page state is unmeasurable."""
    if sys.platform != "linux" or not isinstance(a, np.ndarray) or not a.flags.owndata or not a.flags.writeable:
        return None
    if not (a.flags.c_contiguous or a.flags.f_contiguous):
        return None
    page = os.sysconf("SC_PAGE_SIZE")
    low = a.ctypes.data
    first = (low + page - 1) // page
    end = (low + a.nbytes) // page
    matches = 0
    # Bits 63, 62, 61 and 56 are present, swapped, file/shared-anon and exclusively mapped.
    mask = np.uint64(0xe100000000000000)
    wanted = np.uint64(0x8100000000000000)
    try:
        with open("/proc/self/pagemap", "rb", buffering=0) as handle:
            for start in range(first, end, 65536):
                count = min(65536, end - start)
                raw = os.pread(handle.fileno(), 8 * count, 8 * start)
                if len(raw) != 8 * count:
                    return None
                flags = np.frombuffer(raw, dtype=np.uint64)
                matches += int(np.count_nonzero((flags & mask) == wanted))
    except OSError:
        return None
    return page * matches

def compare(candidate, size, full):
    sys.path.insert(0, str(candidate.resolve() / "tools/GHOST"))
    from ghost_backend.execution.residency import resident_bytes
    if full:
        if size > 24000:
            raise ValueError("Outside this benchmark's sizes")
        # This experiment only needs anonymous memory. Leave room for concurrent work.
        cg = Path("/sys/fs/cgroup")
        maximum, current = [int((cg / key).read_text()) for key in ("memory.max", "memory.current")]
        available = int(next(x.split()[1] for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))) * 1024
        if min(available, maximum-current) < 16*size*size + 4*1024**3:
            raise RuntimeError("Insufficient available memory for this scale control")
    rows = {}
    def obs(key):
        times = []
        for meth in (resident_bytes, private_candidate):
            then = time.perf_counter()
            value = meth(a)
            times.append([value, time.perf_counter()-then])
        rows[key] = dict(zip(("candidate_mincore_bytes_and_seconds", "pageflags_bytes_and_seconds"), times))
        return [x[0] for x in times]
    a = np.empty((size, size), dtype=np.complex128, order="F")
    a.fill(1)
    paid = obs("written")
    assert paid[0] == paid[1] and paid[0] >= a.nbytes - 2 * os.sysconf("SC_PAGE_SIZE")
    assert private_candidate(a[:, :1]) is None
    if not full:
        readfd, writefd = os.pipe()
        child = os.fork()
        if child == 0:
            os.close(writefd)
            os.read(readfd, 1)
            os._exit(0)
        os.close(readfd)
        try:
            share = obs("shared_at_fork")
            assert share[0] == paid[0] and share[1] == 0
        finally:
            os.close(writefd)
            os.waitpid(child, 0)
        p = os.sysconf("SC_PAGE_SIZE")
        addr = (a.ctypes.data + p - 1) // p * p
        nbytes = (a.ctypes.data + a.nbytes - addr) // p * p
        advise = ctypes.CDLL(None, use_errno=True).madvise
        advise.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
        for flag in (15,4):
            if advise(addr, nbytes, flag):
                raise OSError(ctypes.get_errno(), "madvise")
        assert obs("released") == [0,0]
        view = np.ctypeslib.as_array((ctypes.c_ubyte*nbytes).from_address(addr))
        assert not view[::p].sum()
        assert obs("read_zero") == [nbytes,0]
        view[::2*p] = 2
        assert obs("half_write") == [nbytes,((nbytes//p+1)//2)*p]
    return {"platform": platform.platform(),"matrix_order":"F","size":size,"nbytes":a.nbytes,"measures":rows}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("candidate", type=Path)
    ap.add_argument("--full",action="store_true",help="24k allocation control only, requires a headroom-checked host")
    args = ap.parse_args()
    print(json.dumps(compare(args.candidate, 23936 if args.full else 2048, args.full), indent=2))
