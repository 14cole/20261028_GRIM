"""Linux page-flag feasibility on two real solver fixtures. Run from the unpacked evidence directory."""
import argparse
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch
from study import private_candidate

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("candidate",type=Path)
    ap.add_argument("audit",type=Path)
    ap.add_argument("output",type=Path)
    args = ap.parse_args()
    root = Path(__file__).resolve().parents[1]
    os.environ["GRIM_ROOT"] = str(args.candidate.resolve())
    sys.path[:0] = [str(args.audit.resolve()), str(args.candidate.resolve()/"tools/GHOST"), str(root/"linux"),str(root/"windows")]
    from check_no_credit import evaluate
    from solver_pages import run
    from ghost_backend.execution import residency
    args.output.mkdir(parents=True, exist_ok=True)
    with patch.object(residency,"_posix",private_candidate):
        disk = evaluate("measured",args.candidate.resolve(),args.audit.resolve(),args.output)
        ordinary = run("memory",512,.7,"two_shells")
    assert disk["admitted"] and disk["gates"][-1]["width"] == 32 and ordinary["quality_passed"]
    assert all(row["granted"] == row["present_exclusive_pages"] * os.sysconf("SC_PAGE_SIZE") for row in ordinary["credit_samples"])
    print(json.dumps({"single_disk":disk,"two_memory":ordinary},indent=2))
if __name__ == "__main__":
    main()
