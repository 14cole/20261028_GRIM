"""Run with python write_cost.py /path/to/candidate on Linux with procfs."""
import json
import os
from pathlib import Path
import resource
import sys

import numpy as np

sys.path.insert(0, str(Path(sys.argv[1]).resolve() / "tools" / "GHOST"))
from ghost_backend.execution.residency import resident_bytes

def smaps(pid):
    wanted = {"Private_Dirty", "Private_Clean", "Pss", "Rss"}
    fields = {}
    with open(f"/proc/{pid}/smaps_rollup") as handle:
        for line in handle:
            key, sep, value = line.partition(":")
            if key in wanted:
                fields[key] = int(value.split()[0])
    return fields

def memory_snapshot(child_pid):
    return {"credit": int(resident_bytes(a)), "parent_kib": smaps("self"),
            "child_kib": smaps(child_pid), "parent_minor_faults": resource.getrusage(resource.RUSAGE_SELF).ru_minflt}

a = np.ones((2048,2048), dtype=np.complex128, order="F")
resident_bytes(a)
command_r, command_w = os.pipe()
reply_r, reply_w = os.pipe()
pid = os.fork()
if pid == 0:
    os.close(command_w)
    os.close(reply_r)
    os.write(reply_w, b"R")
    os.read(command_r, 1)
    os.write(reply_w, b"Y" if np.all(a == 1) else b"N")
    os._exit(0)

os.close(command_r)
os.close(reply_w)
try:
    assert os.read(reply_r, 1) == b"R"
    before = memory_snapshot(pid)
    a.fill(2)
    after = memory_snapshot(pid)
    os.write(command_w, b"G")
    child_had_original = os.read(reply_r, 1) == b"Y"
finally:
    os.close(command_w)
    os.close(reply_r)
    os.waitpid(pid, 0)
pss_growth = sum(after[k]["Pss"] - before[k]["Pss"] for k in ("parent_kib", "child_kib"))
assert before["credit"] == after["credit"] > a.nbytes * 0.99
assert child_had_original and np.all(a == 2)
print(json.dumps({"matrix_bytes":a.nbytes, "before":before,"after":after,"child_verified_original_after_parent_writes":child_had_original,
                  "combined_pss_growth_kib":pss_growth, "parent_minor_fault_delta":after["parent_minor_faults"]-before["parent_minor_faults"]},indent=2))
