"""Determine the candidate's platform policy; stand-ins return sentinel byte counts."""
import argparse
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np


def check(checkout):
    sys.path.insert(0, str(checkout / 'tools/GHOST'))
    from ghost_backend.execution import residency

    matrix = np.empty((512, 512), dtype=np.complex128, order='F')
    out = {}
    for platform in ('linux', 'win32', 'darwin', 'freebsd14', 'unknown'):
        used = []
        def win(_):
            used.append('windows')
            return 4096
        def unix(_):
            used.append('posix')
            return 8192
        with patch.object(residency, 'sys', SimpleNamespace(platform=platform)), \
             patch.object(residency, '_windows', win), patch.object(residency,'_posix',unix):
            credit = residency.physical_credit(matrix)
        out[platform] = dict(dispatched=used, credit=credit)
    with patch.object(residency, 'sys', SimpleNamespace(platform='win32')), \
         patch.object(residency, '_windows', side_effect=OSError('injected failure')):
        out['raising_windows_probe'] = residency.physical_credit(matrix)
    out['runner'] = sys.platform
    return out


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('checkout',type=Path)
    print(json.dumps(check(p.parse_args().checkout.resolve()),indent=2))
