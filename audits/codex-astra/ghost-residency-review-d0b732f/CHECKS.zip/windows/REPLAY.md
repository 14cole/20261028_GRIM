# Windows release policy and zero-credit admission

The round-four patch routes win32 to QueryWorkingSetEx and every other platform to mincore. Sentinel functions demonstrate the platform decision without executing a Windows API. Query failure returns zero. Claude's proposed release policy would require an explicit Linux allowlist. The unchanged candidate would attempt to grant credit on Windows, Darwin, FreeBSD and other platforms.

## Admission control

Three fresh Linux processes ran the public Dense solver, two polarizations, 728 unknowns, 32 signed monostatic angles, disk-backed residuals and tile 128. This is a controlled admission check. Only the TM headroom is deliberately constrained, to 0.428667195 GiB before credit. The candidate's third run additionally simulates a residency reading returning unknown. Both actual matrices and the final gate are real.

| Tree and residency | TM batch width | TM limit, GiB | TM peak estimate, GiB | Outcome |
|---|---:|---:|---:|---|
| ed90b65 shipped | 1 | 0.436564572 | 0.429643758 | Passed, reused once |
| Candidate, native Linux read | 32 | 0.436559804 | 0.429643758 | Passed, reused once |
| Candidate, unavailable | 1 | 0.428667195 | 0.429643758 | Refused before TM |

The native buffer had 8,479,744 allocated bytes and 8,474,624 observed interior bytes. The successful solves had identical TE fields, TM relative L2 difference 1.6812e-14, and maximum reported residual 2.67242e-13. Peak timings are outside the scope of this admission test. The shipped tree gives an actual identity-matching retained allocation credit at the final gate, even when the planner selects batch one. The candidate removes that credit when residency cannot be measured. Releasing with conservative withholding can therefore change whether a job finishes. This applies wherever the reading fails, including Linux. The synthetic headroom does not establish the incidence on desktop hardware.

## Reproduction on Linux

Each invocation starts a fresh process. Set SHIPPED and CANDIDATE to clean ed90b65 and the same tree plus candidate-vs-ed90b65.patch. AUDIT denotes the ghost-backend-audit directory at Claude's d0b732f. The baseline used the previous checkout of harness.py, SHA256 0685b05df31ce9b482af36c520ac0674879c2fe129b95d13ae83711ee77b1d63, identical to the current harness.

```sh
python check_platform.py "$CANDIDATE" > dispatch.json
OPENBLAS_NUM_THREADS=1 python check_no_credit.py shipped "$SHIPPED" "$AUDIT" . > shipped.json
OPENBLAS_NUM_THREADS=1 python check_no_credit.py measured "$CANDIDATE" "$AUDIT" . > measured.json
OPENBLAS_NUM_THREADS=1 python check_no_credit.py unavailable "$CANDIDATE" "$AUDIT" . > unavailable.json
```

## Windows validation

No native Windows test ran in this audit. The included script was syntax checked on Linux. Run it in a dedicated native 64-bit Windows process, with a Python environment containing NumPy and the GHOST dependencies.

```powershell
python native_windows_probe.py C:\path\to\candidate --mib 256 > windows-residency.json
```

The synthetic probe compares the candidate's per-address QueryWorkingSetEx reading with two separate QueryWorkingSet enumerations of the process's own working set, filtered to the matrix's whole interior pages. It collects process RSS, private bytes, system and available commit, plus the candidate query time. Its working-set trim affects only the probe process. Check that forced trimming caused an observable decline for this matrix, an unrelated allocation did not restore credit, and rewriting half the matrix restored matching pages. If trimming is ineffective or the snapshots move significantly between queries, repeat and report the ambiguity. These are time-separated observations. A successful synthetic test should be followed by native end-to-end mixed-material solves and page-file/commit checks on the intended 32 GB desktop before enabling Windows credit.
