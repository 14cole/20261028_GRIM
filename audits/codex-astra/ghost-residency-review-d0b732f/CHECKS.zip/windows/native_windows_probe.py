"""Native Windows synthetic comparison of the candidate with the process working-set list.

Run in its own process on 64-bit Windows. EmptyWorkingSet affects this process only.
This probe checks an ordinary NumPy allocation, independent of a full GHOST solve.
"""
import argparse
import ctypes
import json
import mmap
from pathlib import Path
import platform
import sys
import time


def measure(checkout, mib):
    if sys.platform != 'win32' or ctypes.sizeof(ctypes.c_void_p) != 8 or mmap.PAGESIZE != 4096:
        raise SystemExit('This probe requires native 64-bit Windows with ordinary 4 KiB pages.')
    import numpy as np
    from ctypes import wintypes

    sys.path.insert(0, str(checkout / 'tools/GHOST'))
    from ghost_backend.execution import memory, residency

    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    kernel.GetCurrentProcess.argtypes = []
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    process = kernel.GetCurrentProcess()
    psapi.QueryWorkingSet.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    psapi.QueryWorkingSet.restype = wintypes.BOOL
    psapi.EmptyWorkingSet.argtypes = [wintypes.HANDLE]
    psapi.EmptyWorkingSet.restype = wintypes.BOOL

    page = mmap.PAGESIZE
    matrix = np.empty((1024, mib * 64), dtype=np.complex128, order='F')
    start = matrix.ctypes.data
    first_vpn = (start + page - 1) // page
    end_vpn = (start + matrix.nbytes) // page
    # Allocate the sampling buffer once for the normal and the unrelated
    # allocations; do not allocate a second matrix-sized reference object.
    native = memory.windows_process_memory()
    capacity = max(65536, ((native.rss if native else 128 << 20) + 3 * matrix.nbytes) // page)

    def occupied():
        nonlocal capacity, buffer
        while True:
            if psapi.QueryWorkingSet(process, buffer, ctypes.sizeof(buffer)):
                break
            error = ctypes.get_last_error()
            if error not in (24, 122) or capacity >= 1 << 23:
                raise ctypes.WinError(error)
            capacity *= 2
            buffer = (ctypes.c_size_t * (capacity + 1))()
        count = int(buffer[0])
        if count > capacity:
            raise RuntimeError('Working-set count exceeds supplied capacity')
        # PSAPI_WORKING_SET_BLOCK.VirtualPage is the ULONG_PTR above bit 11.
        return page * sum(first_vpn <= (buffer[index] >> 12) < end_vpn
                          for index in range(1, count + 1))

    buffer = (ctypes.c_size_t * (capacity + 1))()
    observed = []
    def snapshot(phase):
        before = occupied()
        start_time = time.perf_counter()
        measured = residency.resident_bytes(matrix)
        seconds = time.perf_counter() - start_time
        after = occupied()
        native = memory.windows_process_memory()
        observed.append(dict(phase=phase, matrix_resident_candidate=measured,
                             ws_list_before=before, ws_list_after=after,
                             candidate_seconds=seconds,
                             process=vars(native) if native else None,
                             system_commit=memory.windows_system_commit(),
                             available_commit=memory.windows_available_commit_bytes()))

    snapshot('allocated')
    matrix.fill(1 + 1j)
    snapshot('all_written')
    if not psapi.EmptyWorkingSet(process):
        raise ctypes.WinError(ctypes.get_last_error())
    snapshot('after_self_trim')
    unrelated = np.empty_like(matrix)
    unrelated.fill(2 + 2j)
    snapshot('after_unrelated_write')
    matrix[:, :matrix.shape[1] // 2].fill(3 + 3j)
    snapshot('half_rewritten')
    assert unrelated[0, 0] == 2 + 2j
    return dict(os=platform.platform(), python=sys.version, numpy=np.__version__,
                matrix_bytes=matrix.nbytes, interior_bytes=(end_vpn - first_vpn) * page,
                snapshots=observed)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkout', type=Path)
    parser.add_argument('--mib', type=int, default=128, choices=(64, 128, 256, 512))
    args = parser.parse_args()
    print(json.dumps(measure(args.checkout.resolve(), args.mib), indent=2))
