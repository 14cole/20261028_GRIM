"""Compare shipped and candidate admission at the same TM headroom with no residency observation.

Run each mode in a fresh Linux Python process. The candidate's missing measurement
is simulated. All matrices, geometry, ownership, solves and numerical gates are real.
"""
import argparse
import json
import os
from pathlib import Path
import sys
from contextlib import ExitStack
from unittest.mock import patch

import numpy as np


def evaluate(mode, checkout, audit, output):
    os.environ['GRIM_ROOT']=str(checkout)
    sys.path.insert(0,str(audit))
    from harness import cylinder_geo, fields_of, solve_fixed
    from ghost_backend.twod import solver
    from ghost_backend.twod.assembly import session
    from ghost_backend.execution import dense_memory

    cap=.42866719514131546
    state=dict(pol=None, tm_query=False)
    gates=[]
    calls=[]
    original_resources=solver._dense_formulation_resources
    original_estimate=solver._estimate_memory_gb
    original_limit=solver._solve_memory_limit_gb
    original_pair=session.plan_paired_assembly

    def resources(mesh, infos, pol, *args, **kw):
        state['pol']=pol
        return original_resources(mesh,infos,pol,*args,**kw)

    def estimate(*args,**kw):
        if kw.get('activate_memory_plan') and state['pol']=='TM':
            state['tm_query']=True
        return original_estimate(*args,**kw)

    def limit(resident_gb=0.):
        real=original_limit(resident_gb)
        return min(real,cap+resident_gb) if state['tm_query'] else real

    def pair(pol,form,dofs,peak,allowed):
        answer=original_pair(pol,form,dofs,peak,allowed)
        plan=dense_memory.current(dofs)
        gates.append(dict(pol=pol,dofs=dofs,width=plan['angle_batch_size'],
                          offered=plan.get('reused_matrix_offered_bytes',0),
                          credit_at_forecast=plan.get('reused_matrix_credit_bytes',0),
                          peak_gib=peak,gate_limit_gib=allowed))
        state['tm_query']=False
        return answer

    def unavailable(array):
        calls.append(array.nbytes)
        return None

    geometry=cylinder_geo(sides=256,a=.1,b=.12,eps=2.8-.06j,mu=1.,center=(.031,-.017))
    kw=dict(threads=1,batch=32,dense_residual_storage='disk',assembly_tile=128)
    data=dict(mode=mode,uncredited_tm_headroom_gib=cap,runner=sys.platform,
              gates=gates,missing_measurement_nbytes=calls)
    with ExitStack() as stack:
        for target,key,fn in ((solver,'_dense_formulation_resources',resources),
                               (solver,'_estimate_memory_gb',estimate),
                               (solver,'_solve_memory_limit_gb',limit),
                               (session,'plan_paired_assembly',pair)):
            stack.enter_context(patch.object(target,key,fn))
        if mode=='unavailable':
            from ghost_backend.execution import residency
            stack.enter_context(patch.object(residency,'resident_bytes',unavailable))
        try:
            result,t=solve_fixed(geometry,10.,np.arange(-16.,16.),'dense',**kw)
        except MemoryError as exc:
            data.update(admitted=False,reason=str(exc))
        else:
            meta=result['metadata']
            fields=fields_of(result)
            np.savez_compressed(output / (mode+'.npz'),angles_deg=np.arange(-16.,16.),**fields)
            data.update(admitted=True,reused_by_assembly=meta['assembled_system_reuses'],
                        passed=meta['quality_gate']['passed'],max_residual=meta['residual_norm_max'])
    return data


if __name__=='__main__':
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('mode',choices=('shipped','measured','unavailable'))
    arg.add_argument('checkout',type=Path)
    arg.add_argument('audit',type=Path)
    arg.add_argument('output',type=Path)
    a=arg.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    print(json.dumps(evaluate(a.mode,a.checkout.resolve(),a.audit.resolve(),a.output.resolve()),indent=2))
