"""Run one genuine dual-polarization solve or compare saved runs.

GRIM_ROOT selects the shipped or isolated patched export; add the pinned Claude
audit directory to PYTHONPATH. The ordinary candidate observations call Linux
mincore. Other labels deliberately supply missing or fractional observations.
The headroom input is controlled only at the second polarization's plan/gate.
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
from unittest.mock import patch
import numpy as np

GIB = 1024**3
MODES = ("ambient", "native", "half", "unavailable", "disappears", "unavailable_ample")


def exercise(mode, label, output):
    from harness import cylinder_geo, fields_of, solve_fixed
    from reference import stored_amplitude
    from ghost_backend.twod import solver
    from ghost_backend.execution import dense_memory
    from ghost_backend.twod.assembly import session

    source_resources = solver._dense_formulation_resources
    source_estimate = solver._estimate_memory_gb
    source_limit = solver._solve_memory_limit_gb
    source_pair = session.plan_paired_assembly
    source_take = session.AssemblySession.take
    cap = None if mode in ("ambient","unavailable_ample") else .42866719514131546
    rows = {"label":label, "mode":mode, "uncredited_tm_gib":cap,
            "os_probes":[], "budget_samples":[], "plans":[], "reuses":[]}
    phase = {"pol":None, "gate":False}

    def resources(mesh, infos, pol, *args, **kwargs):
        result = source_resources(mesh, infos, pol, *args, **kwargs)
        phase["pol"] = pol
        return result

    def estimate(*args, **kwargs):
        if phase["pol"] == "TM" and kwargs.get("activate_memory_plan"):
            phase["gate"] = True
        return source_estimate(*args, **kwargs)

    def limit(resident_gb=0.):
        genuine = source_limit(resident_gb)
        if phase["gate"]:
            effective = genuine if cap is None else min(genuine, cap+resident_gb)
            rows["budget_samples"].append({"offered_bytes":round(resident_gb*GIB),
                                           "available_gib":effective})
            return effective
        return genuine

    def pair(pol, formulation, dofs, peak, available):
        answer = source_pair(pol,formulation,dofs,peak,available)
        plan = dense_memory.current(dofs)
        rows["plans"].append(dict(pol=pol,unknowns=dofs,requested_width=plan["requested_angle_batch_size"],
                                  width=plan["angle_batch_size"],storage=plan["residual_storage"],
                                  credit_bytes=plan.get("reused_matrix_credit_bytes",0),
                                  gate_gib=available,peak_gib=peak))
        phase["gate"] = False
        return answer

    def take(assembly, key, pol):
        held = assembly.pending
        result = source_take(assembly,key,pol)
        if pol=="TM":
            rows["reuses"].append({"offered_tile":held[0][-1] if held else None,
                                   "executing_tile":key[-1],"matched":result is not None})
        return result

    fixture = dict(a=.100,b=.120,eps=2.8-.06j,mu=1.,center=(.031,-.017))
    angles = np.arange(-16., 16.)
    text = cylinder_geo(sides=256, **fixture)
    output.mkdir(exist_ok=True,parents=True)
    with ExitStack() as ctx:
        if label != "shipped":
            from ghost_backend.execution import residency
            platform_query = residency._posix
            def observe(matrix):
                observed = platform_query(matrix)
                record = {"array_bytes":matrix.nbytes,"actual_native_bytes":observed}
                rows["os_probes"].append(record)
                missing = mode in ("unavailable","unavailable_ample") or (
                    mode=="disappears" and len(rows["os_probes"])>1)
                if missing:
                    record["reported"] = "injected OS error"
                    raise OSError("Controlled OS residency query failure")
                if mode=="half":
                    record["reported"] = observed//8192*4096
                else:
                    record["reported"] = observed
                return record["reported"]
            ctx.enter_context(patch.object(residency,"_posix",observe))
        for obj, name, hook in ((solver,"_dense_formulation_resources",resources),
                (solver,"_estimate_memory_gb",estimate),(solver,"_solve_memory_limit_gb",limit),
                (session,"plan_paired_assembly",pair),(session.AssemblySession,"take",take)):
            ctx.enter_context(patch.object(obj,name,hook))
        try:
            result, elapsed = solve_fixed(text,10.,angles,"dense",threads=1,batch=32,
                                         dense_residual_storage="disk",assembly_tile=128)
        except MemoryError as exc:
            rows.update(solved=False,error=str(exc))
        else:
            md=result["metadata"]
            assert md["quality_gate"]["passed"] and md["dense_largest_system"]==728
            dots=fields_of(result)
            save={"angles":angles}
            for p,v in dots.items():
                save[p]=v
                save["ref_"+p]=stored_amplitude(p,10.,angles,**fixture)
            np.savez_compressed(output/f"{label}_{mode}.npz",**save)
            rows.update(solved=True, quality=md["quality_gate"]["passed"], panels=md["panel_count"],
                        residual=md["residual_norm_max"], batches=md["runtime_profile"]["stage_calls"]["linear_solve"],
                        inverse_calls=md["runtime_profile"]["stage_calls"]["rhs_solve"],
                        matrix_reused=md["assembled_system_reuses"])
    (output/f"{label}_{mode}.json").write_text(json.dumps(rows,indent=2)+"\n")
    return rows


def compare(output):
    saved={}
    for path in sorted(output.glob("*_*.json")):
        row=json.loads(path.read_text())
        if "label" in row:
            saved[(row["label"],row["mode"])]=row
    assert ("shipped","native") in saved and ("candidate","unavailable") in saved
    source={"shipped":{}, "candidate":{}}
    with np.load(output/"shipped_native.npz") as reference:
        for (label,mode),r in saved.items():
            tm=r["plans"][-1]
            out=dict(solved=r["solved"], TM_width=tm["width"], gate_gib=tm["gate_gib"],peak_gib=tm["peak_gib"],
                     credit_bytes=tm["credit_bytes"], last_limit=r["budget_samples"][-1])
            if r["solved"]:
                with np.load(output/f"{label}_{mode}.npz") as fields:
                    assert np.array_equal(fields["angles"], reference["angles"])
                    difference = {
                        pol: float(np.max(np.abs(fields[pol] - reference[pol])) /
                                   np.max(np.abs(reference[pol])))
                        for pol in ("TE", "TM")
                    }
                    error = {
                        pol: float(np.max(np.abs(fields[pol] - fields["ref_" + pol])) /
                                   np.max(np.abs(fields["ref_" + pol])))
                        for pol in ("TE", "TM")
                    }
                    assert all(value < 1e-11 for value in difference.values())
                    assert all(value < 0.01 for value in error.values())
                    assert r["quality"] and r["matrix_reused"] == 1
                    assert r["reuses"] == [
                        {"offered_tile": 128, "executing_tile": 128, "matched": True}
                    ]
                    out.update(
                        batches=r["batches"], inverse_calls=r["inverse_calls"],
                        quality=r["quality"], residual=r["residual"],
                        matrix_reused=r["matrix_reused"], diff_over_shipped_peak=difference,
                        error_over_analytic_peak=error,
                    )
            source[label][mode] = out
    shipped = source["shipped"]["native"]
    candidate = source["candidate"]
    assert shipped["solved"] and shipped["TM_width"] == 1 and shipped["inverse_calls"] == 33
    assert shipped["credit_bytes"] == 0
    assert shipped["last_limit"]["offered_bytes"] == 16 * 728 ** 2
    assert candidate["native"]["solved"] and candidate["native"]["TM_width"] == 32
    assert candidate["native"]["inverse_calls"] == 2
    assert candidate["native"]["last_limit"]["offered_bytes"] > candidate["half"]["last_limit"]["offered_bytes"] > 0
    for mode in ("unavailable", "disappears"):
        assert not candidate[mode]["solved"]
        assert candidate[mode]["last_limit"]["offered_bytes"] == 0
        assert candidate[mode]["gate_gib"] < candidate[mode]["peak_gib"]
    assert candidate["unavailable"]["credit_bytes"] == 0
    assert candidate["disappears"]["credit_bytes"] > 0
    assert candidate["half"]["solved"] and candidate["unavailable_ample"]["solved"]
    assert candidate["unavailable_ample"]["last_limit"]["offered_bytes"] == 0
    return source


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("action",choices=(*MODES,"compare"))
    p.add_argument("output",type=Path);p.add_argument("--label",choices=("candidate","shipped")); a=p.parse_args()
    if a.action=="compare": print(json.dumps(compare(a.output),indent=2))
    else:
        if not a.label: p.error("--label is required")
        r=exercise(a.action,a.label,a.output);print(a.label,a.action,r["solved"],r["plans"][-1])
