"""Check automatic tile transitions, withheld credit, matrix reuse and field equivalence."""
import json
from pathlib import Path
import sys

import numpy as np

folder = Path(sys.argv[1])
reports = {name: json.loads((folder/f"{name}.json").read_text())
           for name in ("auto_tighten", "auto_relax", "pinned")}
for name, record in reports.items():
    tm = record["forecasts"][-1]
    assert tm["pol"] == "TM"
    assert tm["matched_tile"] == (0 if name == "auto_relax" else 128)
    assert record["lookup"][-1]["current_tile"] == tm["matched_tile"]
    if name == "pinned":
        assert tm["credited_bytes"] > 0 and record["take"][0]["reuse"]
        assert record["solved"] and record["gate"]
    else:
        assert tm["credited_bytes"] == 0 and record["lookup"][-1]["bytes"] == 0
        assert record["solved"] == (name == "auto_relax")
        if record["solved"]:
            assert not record["take"][0]["reuse"] and record["gate"]
        else:
            assert not record["take"] and tm["gate_estimate_gib"] > tm["gate_capacity_gib"]

with np.load(folder/"pinned.npz") as pinned, np.load(folder/"auto_relax.npz") as relaxed:
    assert np.array_equal(pinned["angles"], relaxed["angles"])
    differences = {pol: float(np.max(np.abs(pinned[pol]-relaxed[pol]))/np.max(np.abs(relaxed[pol])))
                   for pol in ("TE", "TM")}
    assert max(differences.values()) < 1e-11
    print(json.dumps({"pinned_minus_relaxed_over_relaxed_peak": differences}, indent=2))
