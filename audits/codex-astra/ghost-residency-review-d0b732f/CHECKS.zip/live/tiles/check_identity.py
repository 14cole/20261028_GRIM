"""Exercise TM's ownership check before and after a real change in the planned assembly tile.

Run once per fresh interpreter. GRIM_ROOT points to the shipping or patched tree.
PYTHONPATH includes Claude's audit harness. Only live capacity during pricing and
admission is simulated. A real TE matrix is assembled, retained and matched.
"""
import argparse
from contextlib import ExitStack
import json
from pathlib import Path
from unittest.mock import patch

import numpy as np
from harness import cylinder_geo, solve_fixed, fields_of
from ghost_backend.execution import dense_memory
from ghost_backend.twod import solver
from ghost_backend.twod.assembly import session

GIB = 1024**3


def run(tile, direction, opts_output):
    log = {"explicit_tile": tile, "direction": direction, "forecasts": [], "lookup": [], "take": []}
    state = {"pol": None, "cap": None}
    orig_resources = solver._dense_formulation_resources
    orig_forecast = dense_memory.forecast
    orig_limit = solver._solve_memory_limit_gb
    lookup_name = "reusable_dense" if hasattr(session, "reusable_dense") else "reusable_dense_bytes"
    orig_lookup = getattr(session, lookup_name)
    orig_take = session.AssemblySession.take
    orig_pair = session.plan_paired_assembly

    def resources(mesh, infos, pol, *args, **kwargs):
        state["pol"] = pol
        state["cap"] = None
        return orig_resources(mesh, infos, pol, *args, **kwargs)

    def lookup(mesh, infos, pol, formulation, dofs):
        value = orig_lookup(mesh, infos, pol, formulation, dofs)
        if pol == "TM":
            retained = session.current_session().pending
            key = session.system_key(mesh, infos, 'multi_region', 8, 8)
            log["lookup"].append(dict(pol=pol, bytes=0 if value is None else int(value.nbytes if hasattr(value, "nbytes") else value), current_tile=key[-1],
                                      retained_tile=None if retained is None else retained[0][-1]))
        return value

    def limit(resident_gb=0.):
        current = orig_limit(resident_gb)
        if state["cap"] is None: return current
        return min(current, state["cap"] + resident_gb)

    def forecast(d, count, batch, assembly, solve, extra, eligible, **kw):
        args = (d, count, batch, assembly, solve, extra, eligible)
        if not kw.get("execution"): return orig_forecast(*args, **kw)
        state["cap"] = None
        unconstrained = orig_forecast(*args, **kw)
        disk_peak = unconstrained["peak_bytes"]
        memory_peak = max(assembly, solve) + extra + 128*1024**2
        if disk_peak >= memory_peak: raise ValueError((disk_peak, memory_peak, d))
        enforce = state["pol"] == ("TM" if direction == "tighten" else "TE")
        if enforce:
            # Give the TE run a lower budget in the reverse case. In the
            # forward case prices including the verified TM matrix are just
            # below the threshold for switching from the normal tile.
            total_gib = (disk_peak + min((memory_peak-disk_peak)//2,
                                         unconstrained["matrix_bytes"]//2)) / GIB
            state["cap"] = total_gib - (unconstrained["matrix_bytes"]/GIB if state["pol"] == "TM" else 0)
        candidate = orig_forecast(*args, **kw)
        log["forecasts"].append(dict(pol=state["pol"], without_credit_gib=state["cap"],
                                     capacity_gib=candidate["capacity_bytes"]/GIB,
                                     peak_gib=candidate["peak_bytes"]/GIB, disk_peak_gib=disk_peak/GIB,
                                     full_memory_gib=memory_peak/GIB, recovery_tile=candidate["assembly_tile"],
                                     credited_bytes=candidate.get("reused_matrix_credit_bytes",0),
                                     batch=candidate["angle_batch_size"]))
        return candidate

    def pair(pol, kind, d, estimate, cap):
        value = orig_pair(pol, kind, d, estimate, cap)
        log["forecasts"][-1].update(gate_estimate_gib=estimate, gate_capacity_gib=cap,
                                     matched_tile=dense_memory.assembly_tile_setting(0))
        state["cap"] = None
        return value

    def take(assembly, key, pol):
        old = assembly.pending
        value = orig_take(assembly, key, pol)
        if pol=="TM":
            log["take"].append(dict(pol=pol, old_tile=old[0][-1] if old else None,
                               actual_key_tile=key[-1], same_other_key_parts=old is not None and old[0][:-1]==key[:-1],
                               reuse=value is not None, orders=list(key[-3:-1])))
        return value

    options = {} if tile == "auto" else {"assembly_tile":int(tile)}
    try:
        with ExitStack() as st:
            for obj,key,f in [(solver,"_dense_formulation_resources",resources),
                    (dense_memory,"forecast",forecast),(solver,"_solve_memory_limit_gb",limit),
                    (session,lookup_name,lookup),(session,"plan_paired_assembly",pair),
                    (session.AssemblySession,"take",take)]:
                st.enter_context(patch.object(obj,key,f))
            result,_ = solve_fixed(cylinder_geo(sides=1056,a=.10,b=.12,eps=2.8-.06j,mu=1.,center=(.031,-.017)),
                                  10.,np.arange(-90.,90.),"dense",threads=1,
                                  dense_residual_storage="disk",**options)
            md = result["metadata"]
            fields = fields_of(result)
            np.savez_compressed(opts_output, angles=np.arange(-90.,90.), TE=fields["TE"], TM=fields["TM"])
            log.update(solved=True,gate=md["quality_gate"]["passed"],reuses=md["assembled_system_reuses"],
                        residual=md["residual_norm_max"],dofs=md["dense_largest_system"])
    except MemoryError as exc:
        log.update(solved=False, error=str(exc))
    return log


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("tile",choices=["auto","128"])
    p.add_argument("direction",choices=["tighten","relax"])
    p.add_argument("fields",type=Path,help="NPZ for fields if admitted")
    args=p.parse_args()
    print(json.dumps(run(args.tile,args.direction,args.fields),indent=2))
