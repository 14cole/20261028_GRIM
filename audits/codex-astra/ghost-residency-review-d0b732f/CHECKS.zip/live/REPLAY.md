# Public GHOST checks on the proposed dense matrix residency allowance

All cases call the public fixed-mesh monostatic solver with the normal strict numerical quality gate. These are independent runs on one Linux host with a 16 GiB cgroup limit. The fixture is a translated concentric coated PEC cylinder at 10 GHz, core radius 100 mm, outer radius 120 mm, relative permittivity 2.8 − 0.06i, relative permeability 1. Every successful run retains every complex field for both polarizations in NPZ format. Variation among these runs tests a change in memory accounting and discrete solution equivalence. A fixed-mesh quality pass does not certify mesh convergence.

## Does zero allowance reproduce shipped admission?

The strongest test is in `ledger/`. Only the OS availability reading and, in the failure case, the success of the OS residency query are controlled. GHOST runs all of its own memory-ledger, batch, identity and admission calculations. Availability is 4.000 GiB on entry and 0.910 GiB for the second polarization in every run. The entry reservation holds back 0.400 GiB. The spendable headroom is 0.510 GiB before applying ledger credits. There are 1,936 panels, 2,992 unknowns per polarization and 180 angles from −90° to +89°. Disk residuals, tile 128, one BLAS/assembly thread.

| Source and second-polarization query | Forecast width | Final limit (GiB) | Required (GiB) | Outcome |
|---|---:|---:|---:|---|
| Shipped | 1 | 0.643396 | 0.596232 | Reused and solved |
| Candidate, injected query failure | 1 | 0.565569 | 0.596232 | Declined before matrix consumption |
| Candidate, native Linux | 180 | 0.643392 | 0.596232 | Reused and solved |

The native candidate and shipped run produce identical TE fields. Their maximum normalized TM difference is 7.76e−13. The largest relative solve residual is 1.82e−12 in both. Shipped grants the full 143,233,024-byte matrix at admission. The candidate withholds the entire matrix hint on an OS query failure. Its other ledger credits still count, including 0.055569 GiB of interpreter baseline in the recorded failure. The old and new admission decisions therefore differ even though both forecasts chose one angle per batch in the unavailable case. This is an intentional consequence if the product adopts fail-closed admission. It merits a user-facing note for machines without a working residency measurement. Physical RAM remained plentiful during these controlled experiments. The numbers do not demonstrate that the shipped solve would run out of memory under actual pressure.

## What happens if pressure or the probe result changes?

The smaller control in this directory uses 472 panels, 728 unknowns per polarization and 32 signed angles from −16° to +15°. It clamps only the reported TM planning/admission budget, with an uncredited 0.428667195 GiB and a required 0.429643758 GiB. The ambient case has no clamp. This isolates how independently sampled planning and admission hints drive the result. Native measurements retrieve the buffer’s resident pages through the kernel; the half and failure cases intentionally change what the query reports.

| Run | Resident hint at forecast / gate (bytes) | TM width | Combined RHS calls | Outcome |
|---|---:|---:|---:|---|
| Shipped | 0 / 8,479,744 | 1 | 33 | Reused and solved |
| Candidate, native Linux | 8,474,624 / 8,474,624 | 32 | 2 | Reused and solved |
| Candidate, half reported | 4,235,264 / 4,235,264 | 32 | 2 | Reused and solved |
| Candidate, both queries fail | 0 / 0 | 1 | — | Declined |
| Candidate, final query fails | 8,474,624 / 0 | 32 | — | Declined |
| Candidate, both fail with ample free RAM | 0 / 0 | 32 | 2 | Reused and solved |

The four successful candidate runs all preserve the shipped TE fields bit for bit. The maximum TM discrepancy divided by the shipped peak magnitude is 3.24e−14. Errors relative to the analytical coated cylinder at this mesh are 0.313% TE and 0.319% TM. The raw files contain both the script-supplied native query result and the value deliberately reported to the solver, and the complete budget inputs. The `plans` entry reports forecast credit. The `budget_samples` entries show the real value offered to the last gate. A stale forecast credit never rescued the failed gate in the changing-query case.

## Tile transition controls

The three real 2,992-unknown runs in `tiles/` start from Codex's previous independent effective-tile control, updated for the candidate's new array-valued lookup. The script moves the automatic assembly tile by controlling per-polarization planning headroom. With a tightening budget, 0 → 128 invalidates the retained operator, withdraws all credit and declines before TM. With a relaxing budget, 128 → 0 invalidates it and rebuilds TM with zero credit. For an explicit tile, 128 → 128 matches, the native query credits 143,228,928 of 143,233,024 B, and the retained operator is consumed. The two completions pass the quality gate. The complex TE arrays are identical, and their maximum normalized TM difference is 1.44e−14.

## Reproduction

Use Python with the repository's scientific dependencies and the pinned audit fixture/harness. Set `SHIPPED_ROOT` to the export at ed90b65 and `CANDIDATE_ROOT` to an isolated copy of that export with only the candidate-vs-ed90b65.patch from Claude d0b732f applied. Point `PYTHONPATH` at Claude's audits/claude-2026-11-26/ghost-backend-audit directory. The native branch of these checks requires a working Linux mincore.

```sh
export PYTHONPATH=/path/to/ghost-backend-audit
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export GRIM_ROOT="$SHIPPED_ROOT"
python ledger/check_ledger.py shipped ledger
python check_public.py native . --label shipped
export GRIM_ROOT="$CANDIDATE_ROOT"
python ledger/check_ledger.py candidate_failure ledger
python ledger/check_ledger.py candidate_native ledger
python ledger/check_ledger.py compare ledger
for mode in ambient native half unavailable disappears unavailable_ample; do
    python check_public.py "$mode" . --label candidate
done
python check_public.py compare .
python tiles/check_identity.py auto tighten tiles/auto_tighten.npz > tiles/auto_tighten.json
python tiles/check_identity.py auto relax tiles/auto_relax.npz > tiles/auto_relax.json
python tiles/check_identity.py 128 tighten tiles/pinned.npz > tiles/pinned.json
python tiles/compare_tiles.py tiles
```

The recorded runs used one CPU through taskset. Native whole-page bytes can vary slightly with allocation alignment. The real budget ledger's baseline memory credit can vary with process startup footprint. Comparisons check behavior and numerical error rather than requiring this host's exact byte counts for residency.
