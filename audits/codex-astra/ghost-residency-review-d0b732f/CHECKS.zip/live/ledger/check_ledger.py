"""Exercise the production request ledger by supplying only OS-level readings."""
import argparse
import json
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

import numpy as np
from harness import cylinder_geo, fields_of, solve_fixed
from ghost_backend.execution import dense_memory, memory_budget
from ghost_backend.twod import solver
from ghost_backend.twod.assembly import session


def run(label, output):
    available_on_entry = 4.0
    # Ordinary 10% reserve on entry leaves 0.510 GiB of spendable TM headroom.
    tm_available = 0.910
    rows = dict(label=label, entry_available_gib=available_on_entry,
                tm_available_gib=tm_available, credit_offers=[], plans=[], takes=[])
    phase = {"pol": None}
    original_resources = solver._dense_formulation_resources
    original_limit = solver._solve_memory_limit_gb
    original_pair = session.plan_paired_assembly
    original_take = session.AssemblySession.take

    def resources(mesh, infos, pol, *args, **kwargs):
        phase["pol"] = pol
        return original_resources(mesh, infos, pol, *args, **kwargs)

    def available():
        return tm_available if phase["pol"] == "TM" else available_on_entry

    def limit(resident_gb=0.):
        value = original_limit(resident_gb)
        if phase["pol"] == "TM":
            last = memory_budget.current().last
            rows["credit_offers"].append(
                dict(offered_bytes=round(resident_gb*1024**3), limit_gib=value,
                     ledger_physical_credit_gib=last["credited_resident_gib"],
                     binding=last["binding_constraint"], raw_limits=last["limits_gib"]))
        return value

    def pair(pol, formulation, dofs, estimate, cap):
        value = original_pair(pol, formulation, dofs, estimate, cap)
        plan = dense_memory.current(dofs)
        rows["plans"].append(dict(pol=pol, dofs=dofs, cap_gib=cap, estimate_gib=estimate,
                                  batch=plan["angle_batch_size"],
                                  plan_credit=plan.get("reused_matrix_credit_bytes", 0)))
        return value

    def take(assembly, key, pol):
        old = assembly.pending
        value = original_take(assembly, key, pol)
        if pol == "TM":
            rows["takes"].append(dict(prior_tile=old[0][-1] if old else None, tm_tile=key[-1],
                                      reused=value is not None))
        return value

    def os_failure(value):
        raise OSError("Injected unsupported Linux page-residency query")

    with ExitStack() as ctx:
        for obj, name, hook in (
            (solver, "_dense_formulation_resources", resources),
            (solver, "_detect_available_gb", available),
            (solver, "_solve_memory_limit_gb", limit),
            (session, "plan_paired_assembly", pair),
            (session.AssemblySession, "take", take),
        ):
            ctx.enter_context(patch.object(obj, name, hook))
        if label == "candidate_failure":
            from ghost_backend.execution import residency
            ctx.enter_context(patch.object(residency, "_posix", os_failure))
        elevations = np.arange(-90., 90.)
        try:
            result, _ = solve_fixed(
                cylinder_geo(sides=1056, a=.100, b=.120, eps=2.8-.06j, mu=1.,
                             center=(.031,-.017)), 10., elevations, "dense", threads=1,
                dense_residual_storage="disk", assembly_tile=128)
        except MemoryError as exc:
            rows.update(solved=False, error=str(exc))
        else:
            pols=fields_of(result)
            np.savez_compressed(output/f"{label}.npz", angles=elevations, **pols)
            meta=result["metadata"]
            rows.update(solved=True, panels=meta["panel_count"], gate=meta["quality_gate"]["passed"],
                        residual=meta["residual_norm_max"], matrix_reuse=meta["assembled_system_reuses"],
                        inverse_calls=meta["runtime_profile"]["stage_calls"]["rhs_solve"])
    (output/f"{label}.json").write_text(json.dumps(rows, indent=2)+"\n")
    return rows


def compare(output):
    names=("shipped", "candidate_native", "candidate_failure")
    rows={name:json.loads((output/f"{name}.json").read_text()) for name in names}
    for name, r in rows.items():
        assert r["plans"][-1]["dofs"] == 2992
        assert r["credit_offers"][-1]["binding"] == "live_physical_ram"
        assert r["solved"] == (name != "candidate_failure")
    assert rows["candidate_failure"]["credit_offers"][-1]["offered_bytes"] == 0
    assert rows["candidate_failure"]["plans"][-1]["cap_gib"] < rows["candidate_failure"]["plans"][-1]["estimate_gib"]
    for name in ("shipped", "candidate_native"):
        assert rows[name]["solved"] and rows[name]["gate"] and rows[name]["matrix_reuse"] == 1
    with np.load(output/"shipped.npz") as shipped, np.load(output/"candidate_native.npz") as native:
        assert np.array_equal(shipped["angles"], native["angles"])
        differences={p:float(np.max(np.abs(native[p]-shipped[p]))/np.max(np.abs(shipped[p])))
                     for p in ("TE","TM")}
        assert max(differences.values()) < 1e-11
    return dict(difference_over_shipped_peak=differences)


if __name__ == "__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("case", choices=("shipped","candidate_native","candidate_failure","compare"))
    cli.add_argument("output", type=Path)
    args=cli.parse_args()
    if args.case == "compare":
        print(json.dumps(compare(args.output),indent=2))
    else:
        r=run(args.case, args.output)
        print(args.case, r["solved"], r["plans"][-1])
