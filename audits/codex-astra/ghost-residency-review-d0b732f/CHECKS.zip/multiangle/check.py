"""Run the two-cylinder Linux allocation control with 180 requested monostatic angles."""
import argparse
from pathlib import Path
import json
import sys
from unittest.mock import patch
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "linux"))
import solver_pages

def run(name, headroom, budget, batch):
    angles = np.arange(-90., 90.)
    solve_fixed = solver_pages.solve_fixed
    observed = {}

    def sweep(text, frequency, previous_angles, backend, **options):
        options["batch"] = batch
        result, elapsed = solve_fixed(text, frequency, angles, backend, **options)
        meta = result["metadata"]
        assert meta["quality_gate"]["passed"]
        observed["panels"] = meta["panel_count"]
        observed["rhs_batches"] = {key: meta.get(key) for key in
                                   ("dense_rhs_batch_count", "dense_max_rhs_columns", "dense_rhs_column_count", "dense_factorization_count")}
        observed["plans_from_metadata"] = [p for p in (meta.get("experimental_cpu") or {}).get("memory_estimates", [])
                                          if p.get("model") == "dense_phase_v1" or p.get("method") == "reused_dense_matrix_admission"]
        return result, elapsed

    planning = []
    pair = solver_pages.dense_memory.pair
    def observe_pair(dofs, allowed):
        result = pair(dofs, allowed)
        plan = solver_pages.dense_memory.current(dofs)
        planning.append(dict(paired=result, peak_gib=plan["peak_bytes"]/2**30, batch=plan["angle_batch_size"]))
        return result
    with patch.object(solver_pages, "solve_fixed", sweep), patch.object(solver_pages.dense_memory, "pair", observe_pair):
        try:
            row = solver_pages.run("memory", 512, budget, "two_shells", physical_headroom=headroom)
        except MemoryError as exc:
            row = dict(memory_error=str(exc), budget_gib=budget)
    row["completed_planning"] = planning
    row.update(observed, signed_start_deg=-90, signed_last_deg=89, step_deg=1, requested_batch=batch)
    if "raw_fields" in row:
        values = {k:np.array([complex(*pair) for pair in pairs]) for k,pairs in row.pop("raw_fields").items()}
        assert all(v.shape==(180,) and np.isfinite(v).all() for v in values.values())
        np.savez_compressed(HERE/f"{name}.npz", angles=angles, **values)
    (HERE/f"{name}.json").write_text(json.dumps(row, indent=2)+"\n")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("name")
    p.add_argument("--headroom", type=float)
    p.add_argument("--budget", type=float, default=.7)
    p.add_argument("--batch", type=int, default=180)
    args = p.parse_args()
    run(args.name, args.headroom, args.budget, args.batch)
