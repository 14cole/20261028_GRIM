# Two coated cylinders and 180 signed monostatic incidence angles

Run `python multiangle/replay.py "$CANDIDATE_ROOT" "$REVISED_ROOT" "$CLAUDE_AUDIT"` from the extracted evidence bundle, with the solver’s Python dependencies installed. Use `--analyze` alone to analyze the stored raw outputs without solving. The scripts reuse the two-cylinder geometry and observational hooks from `linux/solver_pages.py`. All solves request 180 equally spaced signed monostatic angles from −90° through +89°, both polarizations, memory residual storage, 10 GHz, a fixed linear 2,880-unknown mesh, assembly tile 128 and one thread. The Linux base-page condition uses NumPy’s environment switch to disable huge-page advice. Machine timings are incidental and some controls ran concurrently.

| Configured budget | Requested RHS columns | Physical telemetry | Claude candidate | Revised Linux probe |
|---|---:|---|---|---|
| 0.7 GiB | 180 | Measured | TE LU-copy guard refused | Same |
| 0.7525 GiB | 180 | Measured | TM LU-copy guard refused after TE | Same |
| 2 GiB | 180 | Measured | Passed, 2 total RHS batches | Passed, identical fields |
| 0.7 GiB | 32 | Measured | Passed, 12 total RHS batches | Passed, identical fields |
| 0.7 GiB | 32 | Modeled at 0.48 GiB spendable live RAM | Passed, 12 total RHS batches | TM live physical gate refused |

With the 2 GiB cap the optional partner matrix was assembled during TE. At planning and gate, both trees counted 95,694,848 privately charged bytes. At 0.7 GiB and width 32, GHOST reused the unpaired TE matrix, and the candidate credited all 132,706,304 resident bytes. Excluding 9,036 nonexclusive zero pages yielded 95,694,848 bytes of revised credit. The fields were bit-identical across patches at each successful width. Across the 32- and 180-column runs, maximum normalized complex differences were 1.32e−13 TE and 5.54e−13 TM over all 180 angles. Every completed run passed strict quality, with maximum residual ≤7.55e−13.

Only the pressure row changes the two live-headroom measurements. At the same 0.48 GiB modeled headroom as the five-angle run, the real 0.587361820 GiB TM forecast fit the candidate’s 0.603592377 GiB live physical limit but exceeded the revised 0.569122772 GiB limit. That controlled decision demonstrates sensitivity; it is not an actual host OOM. The 0.7 and 0.7525 GiB, width-180 failures are separate local LU-copy checks. An additional 0.765 GiB candidate-only control enabled paired assembly and failed the TE LU-copy guard as well.

Each successful run stores two arrays of 180 complex fields and an angle vector in NPZ. Each JSON records the outcome and completed phase plans. The summary includes direct per-width candidate/revised bit comparisons, cross-width deltas, and comparison against the five signed angles overlapping the prior run.
