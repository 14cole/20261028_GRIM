"""Run public sweep controls in fresh processes, or reanalyze their saved results."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
SCENARIOS = [
    ("0p7_b180", .7, 180, None),
    ("0p7525_b180", .7525, 180, None),
    ("2_b180", 2., 180, None),
    ("0p7_b32", .7, 32, None),
    ("pressure_b32", .7, 32, .48),
]

def run(label, tree, audit, budget, batch, headroom):
    env = dict(os.environ, GRIM_ROOT=str(tree.resolve()), PYTHONPATH=str(audit.resolve()),
               NUMPY_MADVISE_HUGEPAGE="0", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
    args = [sys.executable, str(HERE / "check.py"), label, "--budget",str(budget),"--batch",str(batch)]
    if headroom is not None:
        args += ["--headroom", str(headroom)]
    subprocess.run(args, env=env, check=True)


def analyze():
    summary = {}
    prev = json.loads((HERE.parent/"linux/real_two_memory_basepages.json").read_text())["raw_fields"]
    with np.load(HERE/"candidate_2_b180.npz") as reference:
        for label in ["candidate","integrated"]:
            for suffix,*_ in SCENARIOS:
                name = f"{label}_{suffix}"
                row = json.loads((HERE/(name+".json")).read_text())
                obs = summary[name] = {"quality_passed":row.get("quality_passed"), "error":row.get("memory_error"),
                                       "planning_calls":len(row["completed_planning"]), "rhs_batches":row.get("rhs_batches"),
                                       "granted_bytes":[s["granted"] for s in row.get("credit_samples",[])],
                                       "nonexclusive_pages":[s["present_nonexclusive_pages"] for s in row.get("credit_samples",[])],
                                       "residual":row.get("max_residual")}
                if not row.get("quality_passed"): continue
                with np.load(HERE/(name+".npz")) as got:
                    np.testing.assert_array_equal(reference["angles"], got["angles"])
                    overlap = np.isin(got["angles"], np.arange(-2,3))
                    obs["max_relative_field_delta_vs_candidate_180"] = {
                        p:float(max(abs(reference[p]-got[p]))/max(abs(reference[p]))) for p in ("TE","TM")}
                    subset = {p:np.array([complex(*t) for t in prev[p]]) for p in ("TE","TM")}
                    obs["max_relative_field_delta_vs_five_angle_subset"] = {
                        p:float(max(abs(subset[p]-got[p][overlap]))/max(abs(subset[p]))) for p in subset}
    for suffix in ("2_b180","0p7_b32"):
        with np.load(HERE/f"candidate_{suffix}.npz") as a, np.load(HERE/f"integrated_{suffix}.npz") as b:
            summary[f"integrated_{suffix}"]["bit_identical_to_same_width_candidate"] = {
                p:bool(np.array_equal(a[p].view("u8"), b[p].view("u8"))) for p in ("TE","TM")}
    (HERE/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analyze",action="store_true")
    for name in ("candidate", "integrated", "audit"):
        parser.add_argument(name, type=Path, nargs="?")
    args=parser.parse_args()
    if not args.analyze:
        if not all((args.candidate,args.integrated,args.audit)):
            parser.error("Pass the candidate and revised checkout paths and the pinned Claude audit directory.")
        for label,tree in (("candidate",args.candidate),("integrated",args.integrated)):
            for suffix,budget,batch,headroom in SCENARIOS:
                run(f"{label}_{suffix}",tree,args.audit,budget,batch,headroom)
        run("candidate_0p765_b180",args.candidate,args.audit,.765,180,None)
    analyze()
