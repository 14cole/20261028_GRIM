"""Observe Linux THP and per-page credits while sharing a written array with a waiting child."""
import json
import os
from pathlib import Path
import re
import sys

import numpy as np

sys.path.insert(0,str(Path(sys.argv[1]).resolve()/"tools/GHOST"))
from ghost_backend.execution.residency import physical_credit

page=os.sysconf("SC_PAGE_SIZE")
a=np.ones((3072,3072),dtype=np.complex128,order="F")
begin=a.ctypes.data
end=begin+a.nbytes

def regions():
    selected=False
    sums=dict(AnonHugePages=0,Private_Dirty=0,Shared_Dirty=0,Rss=0,Pss=0)
    total_vma_size=0
    for line in Path("/proc/self/smaps").read_text().splitlines():
        m=re.match(r"^([a-f0-9]+)-([a-f0-9]+) ",line)
        if m:
            lo,hi=(int(v,16) for v in m.groups())
            selected=bool(lo<end and begin<hi)
            if selected:
                total_vma_size+=hi-lo
        elif selected:
            k,sep,v=line.partition(":")
            if k in sums:
                sums[k]+=int(v.split()[0])
    return {"matrix_credit":physical_credit(a),"covering_vma_bytes":total_vma_size,"covering_vma_kib":sums}

stages={"initial":regions()}
r,w=os.pipe()
pid=os.fork()
if pid==0:
    os.close(w)
    os.read(r,1)
    os._exit(0)
os.close(r)
try:
    stages["held_by_child"]=regions()
    # Touch one base page in every 2 MiB. Whether the kernel copies a whole folio is observed.
    a.ravel(order="K")[::(2*1024**2//a.itemsize)]=2
    stages["one_write_per_2mib"]=regions()
    a.fill(3)
    stages["all_written_again"]=regions()
finally:
    os.close(w)
    os.waitpid(pid,0)
assert stages["held_by_child"]["matrix_credit"]==0
assert 0<stages["one_write_per_2mib"]["matrix_credit"]<=stages["initial"]["matrix_credit"]
assert stages["all_written_again"]["matrix_credit"]==stages["initial"]["matrix_credit"]
print(json.dumps({"matrix_bytes":a.nbytes,"scope":"smaps values cover all VMAs overlapping the matrix, including edge slack","stages":stages},indent=2))
