"""Usage: python verify_probe.py REVISED_ROOT [--large]. Linux OS calls require no extra privileges."""
import argparse
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch
import numpy as np

if __name__ == "__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("root",type=Path)
    ap.add_argument("--large",action="store_true")
    args=ap.parse_args()
    sys.path.insert(0,str(args.root.resolve()/"tools/GHOST"))
    from ghost_backend.execution import residency as m
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"pageflags"))
    import study
    # Compare the implemented gate with the separately written page-flag probe on every stage.
    rows = study.compare(args.root,23936 if args.large else 2048,args.large) if args.large else {}
    if not args.large:
        from types import SimpleNamespace
        a=np.ones((2048,2048),np.complex128,order="F")
        checks={}
        checks["writable_F"]=m.physical_credit(a)
        checks["writable_C"]=m.physical_credit(np.ones((512,512),np.complex128))
        checks["view"]=m.physical_credit(a[:, :1])
        a.flags.writeable=False
        checks["readonly"]=m.physical_credit(a)
        a.flags.writeable=True
        checks["empty"]=m.physical_credit(np.empty((0,)))
        for name in ("win32","darwin","freebsd14","unknown"):
            with patch.object(sys,"platform",name),patch.object(m,"_posix",side_effect=AssertionError("called")):
                checks[name]=m.physical_credit(a)
        with patch("builtins.open",side_effect=PermissionError("controlled denial")):
            checks["no_proc"]=m.physical_credit(a)
        with patch.object(os,"pread",return_value=b''):
            checks["short_read"]=m.physical_credit(a)
        for name in ("4.1.21","unknown"):
            with patch.object(os,"uname",return_value=SimpleNamespace(release=name)):
                checks["kernel_"+name]=m.physical_credit(a)
        assert checks["writable_F"] > 0 and checks["writable_C"] > 0
        assert all(v == 0 for k,v in checks.items() if not k.startswith("writable"))
        page=os.sysconf("SC_PAGE_SIZE")
        addr,pages=m._interior(a,page)
        import ctypes
        adv=ctypes.CDLL(None, use_errno=True).madvise
        adv.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int]
        for flag in (15,4):
            assert adv(addr,pages*page,flag)==0
        v=np.ctypeslib.as_array((ctypes.c_ubyte*(pages*page)).from_address(addr))
        states={}
        def record(stage):
            got=m.physical_credit(a)
            expected=study.private_candidate(a)
            assert got==expected
            states[stage]=got
        record("released")
        assert not v[::page].sum()
        record("read_zero")
        v[::2*page]=1
        record("half_written")
        v[::page]=2
        record("all_written")
        r,w=os.pipe()
        pid=os.fork()
        if pid==0:
            os.close(w)
            os.read(r,1)
            os._exit(0)
        os.close(r)
        try:
            record("shared_at_fork")
            v[::page]=3
            record("after_writing_shared")
        finally:
            os.close(w)
            os.waitpid(pid,0)
        assert states==dict(released=0,read_zero=0,half_written=((pages+1)//2)*page,all_written=pages*page,shared_at_fork=0,after_writing_shared=pages*page)
        rows={"interface":checks,"page_states":states}
    else:
        written=rows["measures"]["written"]
        written["integrated_bytes_and_seconds"]=written.pop("candidate_mincore_bytes_and_seconds")
    print(json.dumps(rows,indent=2))
