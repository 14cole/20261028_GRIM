"""Observe public GHOST solves. Optional flags control TM headroom or credit to test gate sensitivity."""
import argparse
from contextlib import ExitStack
import json
from check_linux_pages import inventory
from unittest.mock import patch
import numpy as np
from harness import cylinder_geo, fields_of, solve_fixed
from ghost_backend.execution import dense_memory
from ghost_backend.twod.assembly import scatter
from ghost_backend.twod import solver
from ghost_backend.execution.memory_budget import current
from check_linux_pages import PAGE

def run(storage, sides, budget, geometry, physical_headroom=None, exclusive_only=False):
    text = cylinder_geo(sides=sides, a=.10, b=.12, eps=2.8-.06j, mu=1., center=(.031,-.017))
    if geometry == "two_shells":
        second = cylinder_geo(sides=sides, a=.073, b=.092, eps=3.1-.085j, mu=1., center=(.35,-.017))
        segments = second.split("Segment:", 1)[1].split("IBCS_Resistances:")[0]
        segments = segments.replace("coat_outer", "outer_right").replace("coat_inner", "inner_right").replace(" 0 1 0\n"," 0 2 0\n")
        text = text.replace("IBCS_Resistances:", "Segment:" + segments + "IBCS_Resistances:")
        text += "2 " + second.rsplit("Dielectrics:\n1 ", 1)[1]
    original = dense_memory.bounded_reuse_hint
    checks = []
    def read_matrix(a):
        credit = original(a)
        if a is not None:
            sample = inventory(a)
            if exclusive_only:
                credit = min(credit, sample["present_exclusive_pages"] * PAGE)
            checks.append(dict(shape=a.shape, granted=credit, **sample))
        return credit
    plans = []
    p = dense_memory.pair
    def pairing(dofs, allowed):
        result = p(dofs, allowed)
        plan = dense_memory.current(dofs)
        plans.append(dict(paired=result, residual_storage=plan['residual_storage'],
                          peak_gib=plan['peak_bytes']/2**30 if 'peak_bytes' in plan else None))
        return result
    preparations = []
    old_prepare = scatter._prepare_system
    def observe_prepare(mesh, infos, pol, destination=None, *args, **kwargs):
        if destination is None:
            return old_prepare(mesh, infos, pol, destination, *args, **kwargs)
        before = inventory(destination)
        answer = old_prepare(mesh, infos, pol, destination, *args, **kwargs)
        preparations.append(dict(pol=pol, before=before, after=inventory(destination)))
        return answer
    pressure_limits = []
    old_limit = solver._solve_memory_limit_gb
    def limit(resident_gb=0.):
        if physical_headroom is None or not checks or not resident_gb or resident_gb * 2**30 != checks[-1]["granted"]:
            return old_limit(resident_gb)
        owner = current()
        reserve = max(owner.cohort["physical_reserve"], .1 * (owner.initial_available or 0.))
        with patch.object(solver, "_detect_available_gb", return_value=reserve+physical_headroom):
            value = old_limit(resident_gb)
        pressure_limits.append(dict(estimated_spendable_gib=physical_headroom, offered_gib=resident_gb,
                                    actual_ledger_limit_gib=value, binding=owner.last["binding_constraint"]))
        return value
    base = dict(storage=storage, sides=sides, budget_gib=budget, geometry=geometry, plans=plans,
                physical_headroom_gib=physical_headroom, exclusive_control=exclusive_only, pressure_limits=pressure_limits,
                credit_samples=checks, preparations=preparations)
    with ExitStack() as stack:
        stack.enter_context(patch.object(solver, "_solve_memory_limit_gb", limit))
        stack.enter_context(patch.object(dense_memory, "bounded_reuse_hint", read_matrix))
        stack.enter_context(patch.object(dense_memory, "pair", pairing))
        stack.enter_context(patch.object(scatter, "_prepare_system", observe_prepare))
        try:
            result, elapsed = solve_fixed(text, 10., np.arange(-2.,3.), "dense", threads=1, batch=5,
                        dense_residual_storage=storage, assembly_tile=128, ram_gib=budget)
        except MemoryError as exc:
            if physical_headroom is None:
                raise
            return dict(base, memory_error=str(exc))
    meta = result["metadata"]
    return dict(base,
                quality_passed=meta["quality_gate"]["passed"], max_residual=meta["residual_norm_max"],
                max_dofs=meta["dense_largest_system"], reuses=meta["assembled_system_reuses"],
                raw_fields={pol:[[z.real,z.imag] for z in values] for pol,values in fields_of(result).items()},
                solve_s=elapsed)


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    p.add_argument("storage", choices=["memory","disk"])
    p.add_argument("sides", type=int)
    p.add_argument("geometry", choices=["shell","two_shells"])
    p.add_argument("--budget", type=float)
    p.add_argument("--physical-headroom", type=float, help="Controlled TM spendable physical telemetry (GiB)")
    p.add_argument("--exclusive-only", action="store_true", help="Control: withhold pages lacking Linux's exclusivity flag")
    args=p.parse_args()
    print(json.dumps(run(args.storage,args.sides,args.budget,args.geometry,args.physical_headroom,args.exclusive_only), indent=2))
