# Linux owned-matrix credit on shared zero pages

This test applies to the four-file candidate at Claude’s d0b732f, based on ed90b65. The decisive case exercises GHOST’s public solver entry point with two disjoint, lossy dielectric-coated PEC cylinders, both polarizations, five monostatic angles (−2° through 2°), 10 GHz and a fixed linear mesh. The cores/outer radii are 100/120 mm and 73/92 mm. Relative permittivities are 2.8−0.06i and 3.1−0.085i. The solve has 2,880 unknowns. It uses one thread, assembly tile 128, a 0.7 GiB user budget, and explicit memory residual storage. The TE and TM preparations are unpaired. No geometry modifications, page-release calls, fork, or artificial RAM pressure are required to exhibit the error on this public path.

In the base-page run, the candidate’s two TM credit measurements each returned 132,706,304 bytes for 32,399 entirely resident 4 KiB pages. 9,036 pages were nonexclusive in Linux’s own per-address pagemap flags. We read all 4,096 bytes of each already-present nonexclusive page and found all zero. The production TM preparation called `matrix.fill(0)` on that same destination, after which every page was exclusive and process-wide Private_Dirty rose by precisely 35.296875 MiB. The fixed-mesh solve passed the strict quality gate. With NumPy’s default huge-page preference on this host, 48 pages (192 KiB) instead underwent this transition. These two figures demonstrate sensitivity to allocation/layout; neither is a forecast of how large an error will occur on another machine or at 24k.

On the same base-page geometry and 0.7 GiB budget, switching to disk residual storage produced a retained matrix with all 32,399 pages already private. The disk and memory runs, the default-THP memory run, and the candidate controlled-gate run produced bit-identical stored field pairs at all five angles in both polarizations. This separate disk control is consistent with the scratch restore overwriting the original buffer before the TM gate.

A second pair of public solves exercises the **real admission decision** with controlled telemetry. The only simulated resource is physical RAM availability during the two credit-bearing TM plan/gate calls. Spendable RAM was set to 0.48 GiB after GHOST’s existing reserve, and the configured 0.7 GiB cap and production ledger were retained. The 0.586694248 GiB TM forecast passed at 0.603592377 GiB with the candidate and failed at 0.569122772 GiB with the same 9,036 shared pages excluded. The host had ample real RAM. No OOM event was attempted or observed.

`check_linux_pages.py` supplies a deliberately synthetic sanity check on a separate owned NumPy buffer. Merely reading through an anonymous zero range or retaining an existing writable matrix in a sleeping forked child lets Linux report an address as resident although a later parent write needs a physical page. It compares mincore with present/exclusive bits and process smaps; no pagemap PFNs or privileged kernel-page flags are read. The synthetic setup disables THP on the specific allocation. The actual solver tests do not issue madvise; the base-page runs set NumPy’s documented environment switch to disable large-page advice (the host kernel policy is `always [madvise] never`). The uncontrolled solve samples flags/content and process-level smaps without altering the matrix or resource decisions.

## Replay

Use Linux with accessible `/proc/self/{pagemap,smaps_rollup}` and the repository’s GHOST dependencies. Set `GRIM_ROOT` to a checkout with the original Claude candidate applied and `PYTHONPATH` to the pinned Claude audit directory that contains `harness.py`. Use a fresh process for each invocation. `PY` is the interpreter with NumPy/SciPy.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
"$PY" check_linux_pages.py > synthetic.json
"$PY" solver_pages.py memory 256 shell > real_shell_memory.json
"$PY" solver_pages.py memory 256 two_shells > real_two_memory.json
"$PY" solver_pages.py memory 256 two_shells --budget 0.52 > real_two_memory_budget.json
"$PY" solver_pages.py memory 512 two_shells --budget 0.7 > real_two_memory_budget_large_v2.json

export NUMPY_MADVISE_HUGEPAGE=0
"$PY" solver_pages.py memory 512 two_shells --budget 0.7 > real_two_memory_basepages.json
"$PY" solver_pages.py disk 512 two_shells --budget 0.7 > real_two_disk_basepages.json
"$PY" solver_pages.py memory 512 two_shells --budget 0.7 --physical-headroom 0.48 > gate_candidate.json
"$PY" solver_pages.py memory 512 two_shells --budget 0.7 --physical-headroom 0.48 --exclusive-only > gate_exclusive.json
```

Each successful solver JSON contains raw complex fields for all ten outputs. The exclusive-only switch is an audit control, not a proposed portable production implementation. It flags known nonexclusive pages in this experiment and leaves the rest of the candidate and ledger intact. Timings in the records are incidental and some runs overlapped. Synthetic and controlled headroom results measure different things; the ambient real solve is the evidence of naturally occurring overcredit.
