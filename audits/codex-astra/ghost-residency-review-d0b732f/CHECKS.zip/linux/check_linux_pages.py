"""Linux R4 checks. GRIM_ROOT names the checkout with the standalone candidate applied."""
import ctypes
import json
import os
import platform
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(os.environ["GRIM_ROOT"]) / "tools/GHOST"))
from ghost_backend.execution import residency
PAGE = os.sysconf("SC_PAGESIZE")


def inventory(a):
    addr, count = residency._interior(a, PAGE)
    fd = os.open("/proc/self/pagemap", os.O_RDONLY)
    try:
        raw = os.pread(fd, count * 8, (addr // PAGE) * 8)
    finally:
        os.close(fd)
    flags = np.frombuffer(raw, dtype=np.uint64)
    assert len(flags) == count
    present = (flags >> 63).astype(bool)
    exclusive = ((flags >> 56) & 1).astype(bool)
    shared_nonzero = 0
    # Inspect only already-present nonexclusive pages; no absent PTE is touched.
    for offset in np.flatnonzero(present & ~exclusive):
        if any(ctypes.string_at(addr + int(offset) * PAGE, PAGE)):
            shared_nonzero += 1
    return {"nonexclusive_pages_with_nonzero_content": shared_nonzero, "whole_pages": count, "candidate_credit_bytes": residency.physical_credit(a),
            "present_pages": int(present.sum()), "present_exclusive_pages": int((present & exclusive).sum()),
            "present_nonexclusive_pages": int((present & ~exclusive).sum()),
            "smaps_rollup_kib": {line.split(":")[0]: int(line.split()[1])
                for line in Path("/proc/self/smaps_rollup").read_text().splitlines()
                if line.split(":")[0] in {"Rss", "Pss", "Private_Dirty", "Shared_Dirty", "Private_Clean"}}}


def synthetic():
    a = np.zeros((2048, 2048), dtype=np.complex128, order="F")
    addr, count = residency._interior(a, PAGE)
    advise = ctypes.CDLL(None, use_errno=True).madvise
    advise.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
    for flag in (15, 4):  # MADV_NOHUGEPAGE, MADV_DONTNEED on a known-zero anonymous range
        if advise(addr, count * PAGE, flag):
            raise OSError(ctypes.get_errno(), "madvise")
    cells = np.ctypeslib.as_array((ctypes.c_ubyte * (count * PAGE)).from_address(addr))
    stages = {"untouched": inventory(a)}
    assert cells[::PAGE].sum() == 0
    stages["read_zeros"] = inventory(a)
    cells[::2*PAGE] = 1
    stages["half_written"] = inventory(a)
    cells[::PAGE] = 2
    stages["all_written"] = inventory(a)
    for stage in ("read_zeros", "half_written", "all_written"):
        assert stages[stage]["candidate_credit_bytes"] == count * PAGE
    # The child only holds mappings and blocks; no Python workers or BLAS are started.
    r, w = os.pipe()
    pid = os.fork()
    if pid == 0:
        os.close(w)
        os.read(r, 1)
        os._exit(0)
    os.close(r)
    try:
        stages["fork_shared"] = inventory(a)
        cells[::PAGE] = 3
        stages["after_parent_cow"] = inventory(a)
    finally:
        os.close(w)
        os.waitpid(pid, 0)
    return {"kernel": platform.release(), "page_bytes": PAGE, "stages": stages}


if __name__ == "__main__":
    print(json.dumps(synthetic(), indent=2))
