"""Summarize alternative results against fields recorded by the two companion controls."""
import argparse
import json
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('evidence_root',type=Path)
args=p.parse_args()
base=args.evidence_root
out=base/'alternative'
def read(path):
    return json.loads(path.read_text())

rows=[]
with np.load(base/'live/shipped_native.npz') as shipped, np.load(base/'live/candidate_native.npz') as candidate:
    dirs=[*sorted((out/'final_repeats').glob('run*')), out/'pressure_no_thp']
    for d in dirs:
        x=read(d/'candidate_native.json')
        tm=x['plans'][-1]
        row=dict(id=str(d.relative_to(out)),credit_bytes=tm['credit_bytes'],tm_width=tm['width'],solved=x['solved'])
        if x['solved']:
            with np.load(d/'candidate_native.npz') as z:
                assert np.array_equal(shipped['angles'],z['angles'])
                row['relative_peak_vs_shipped']={pol:float(np.max(abs(z[pol]-shipped[pol]))/np.max(abs(shipped[pol]))) for pol in ('TE','TM')}
                row['equal_fields_to_candidate']=all(np.array_equal(z[pol],candidate[pol]) for pol in ('TE','TM'))
                assert row['equal_fields_to_candidate']
        rows.append(row)
x=read(out/'two_no_thp.json')
y=read(base/'linux/real_two_memory_basepages.json')
gate=read(out/'two_gate.json')
x_held=x['credit_samples'][0]
report=dict(pressure=rows,
    two_cylinders=dict(passed=x['quality_passed'],
        fields_equal_to_candidate=(x['raw_fields']==y['raw_fields']),
        private_bytes=x_held['present_exclusive_pages']*4096,
        alternative_bytes=x_held['granted'], candidate_bytes=y['credit_samples'][0]['granted'],
        preparation_private_dirty_kib=x['preparations'][0]['after']['smaps_rollup_kib']['Private_Dirty']-x['preparations'][0]['before']['smaps_rollup_kib']['Private_Dirty'],
        tight_gate_rejected='memory_error' in gate, gated_gib=gate['pressure_limits'][-1]['actual_ledger_limit_gib']))
assert report['two_cylinders']['fields_equal_to_candidate'] and report['two_cylinders']['tight_gate_rejected']
print(json.dumps(report,indent=2))
