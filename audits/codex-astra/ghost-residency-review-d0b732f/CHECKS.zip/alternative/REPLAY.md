# Experimental Linux private-memory bound

Keep this as an independent accounting control. A stricter bound resolved the proven over-credit in a real solve. Its coverage on ordinarily allocated arrays was too variable to recommend adoption. A lower bound on current private memory cannot reserve it through the next write.

## Method and scope

The single-file patch applies on top of Claude's fourth candidate. It reads Linux `/proc/self/smaps` for the whole-page interior of the retained matrix. It accepts ordinary owning, writable, square Fortran-contiguous complex128 NumPy arrays, as used by the Dense solver. It includes only anonymous private writable mappings or the process heap, requires the expected base page size and ignores explicit hugetlb mappings. For each eligible mapping, start with kernel `Private_Dirty`, then subtract **all** bytes elsewhere in that mapping and all reported `AnonHugePages`, `KSM` and `LazyFree` bytes. Clamp the result to the interval from zero to the matrix's overlap with the mapping. Debiting every outside byte lets a partially populated mapping give a useful lower bound without attributing a neighbor's memory to GHOST. The exclusions can overlap and under-credit.

Missing or inaccessible Linux telemetry, unsupported layouts, file-backed arrays, or other platforms receive zero credit. The file-mapping control independently tested the mapping filter as well as array ownership. The study used Linux 6.18.57 with 4 KiB pages, conventional anonymous NumPy allocations, and either the host's ordinary 2 MiB THP configuration or the NumPy opt-out in a test subprocess. This is evidence for those conditions. Other kernel versions, multi-size THP accounting, unusual allocators or aliasing, real swap, and the query cost of walking an application's VMAs at 24k remain unvalidated. The probe only observes process-local backing and cannot determine which memory cgroup paid the charge after migration. Procfs accounting and headroom can change after either sample.

## Results

- An untouched 64 MiB matrix and the same matrix after a read from every page both received zero. Claude's candidate gave 67,104,768 bytes after the reads. Writing alternate pages earned 33,554,432 bytes. Writing every page earned 67,104,768 bytes. After a fork the credit dropped to zero while the child held the shared pages. After the parent wrote every page the full credit returned.
- One 144 MiB fully written matrix under normal THP had 150,990,848 eligible interior bytes, all reported present and exclusive. The conservative alternative gave 2,093,056 bytes, only 1.39%. The measured sub-millisecond timings in the synthetic control apply to this small, mostly idle process.
- At 728 DOFs and the specified modelled TM headroom, six of seven fresh processes admitted the TM solve at width 32 with 2,183,168 bytes of credit. The seventh obtained only 86,016 bytes, planned width 1, and refused at the live gate. With NumPy's huge-page advice disabled, the same fixture admitted width 32 with 8,388,608 bytes of credit. Each successful run returned both complex field arrays bit-identical to Claude's candidate. TE was identical to shipped and TM differed by at most 3.24e-14 of shipped peak amplitude. The count of six successes is descriptive.
- At 2,880 DOFs, two distinct coated cylinders, memory residuals, 0.7 GiB explicit cap, and NumPy THP advice off, the ordinary solve granted 91.203125 MiB. The pagemap control found 91.261719 MiB present and exclusive. The mincore candidate granted 126.558594 MiB including 35.296875 MiB of shared zero pages. The TM preparation raised sampled private dirty memory by 36,144 KiB. The alternative matched both candidate field arrays exactly. With the TM physical headroom controlled to 0.48 GiB, the alternative refused at an available 0.56850 GiB against its 0.58669 GiB forecast, before TM preparation.

## Reproduction

Use fresh source exports for the two trees. The original is main at `ed90b65ff89826274adacae01bcfbafe143e9819` plus Claude's `candidate-vs-ed90b65.patch` from `d0b732fc025d47118ae999970be0f392bff9e89f`. Its patch SHA-256 is `6112790451c020797727bdab8d9b49670c67d97d831015b91439283869e51a72`. Make a fresh copy of that candidate. The commands below apply `alternative/private-dirty-linux.patch` to the copy. The supplemental patch SHA-256 is `ff2ff138701422e5dd215cb6e90c62b255e31d0cfefa71ab846723c2a90e98d7`.

In the commands below, `EVIDENCE` is the directory containing this audit's `alternative`, `live`, and `linux` folders. `CLAUDE_AUDIT` is the pinned Claude ghost-backend-audit directory with the public harness and analytic reference. Set `CANDIDATE_ROOT` to the unmodified Claude candidate, `GRIM_ROOT` to the fresh copy, and `PYTHON` to the interpreter equipped for the solver. The public pressure driver's `--label candidate` identifies its instrumented interface. `GRIM_ROOT` selects the actual source.

```sh
export CANDIDATE_ROOT GRIM_ROOT PYTHON
export PYTHONPATH="$CLAUDE_AUDIT"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
git -C "$GRIM_ROOT" apply --check "$EVIDENCE/alternative/private-dirty-linux.patch"
git -C "$GRIM_ROOT" apply "$EVIDENCE/alternative/private-dirty-linux.patch"
"$PYTHON" "$EVIDENCE/alternative/check_private.py"
"$PYTHON" "$EVIDENCE/live/check_public.py" native /tmp/smaps-native --label candidate
NUMPY_MADVISE_HUGEPAGE=0 "$PYTHON" "$EVIDENCE/live/check_public.py" native /tmp/smaps-base --label candidate
NUMPY_MADVISE_HUGEPAGE=0 "$PYTHON" "$EVIDENCE/linux/solver_pages.py" memory 512 two_shells --budget .7
NUMPY_MADVISE_HUGEPAGE=0 "$PYTHON" "$EVIDENCE/linux/solver_pages.py" memory 512 two_shells --budget .7 --physical-headroom .48
"$PYTHON" "$EVIDENCE/alternative/summarize_private.py" "$EVIDENCE"
```

The summary command checks the archived fresh runs and every completed field against the independent shipped and Claude candidate runs. Raw complex arrays for the 728 runs are under `final_repeats` and `pressure_no_thp`. The two-cylinder field data are in `two_no_thp.json`.
