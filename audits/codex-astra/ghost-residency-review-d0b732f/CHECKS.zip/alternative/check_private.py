"""Base-page, ordinary THP, and fail-closed controls for the audit alternative."""
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import sys
from time import perf_counter
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(os.environ['GRIM_ROOT'])/'tools/GHOST'))
from ghost_backend.execution import residency as alternative

candidate_path = Path(os.environ['CANDIDATE_ROOT'])/'tools/GHOST/ghost_backend/execution/residency.py'
spec=importlib.util.spec_from_file_location('claude_candidate', candidate_path)
original=importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)

page = os.sysconf('SC_PAGESIZE')
advice = ctypes.CDLL(None,use_errno=True).madvise
advice.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_int]
def sample(matrix):
    address,n = alternative._interior(matrix,page)
    fd=os.open('/proc/self/pagemap',os.O_RDONLY)
    try:
        flags = np.frombuffer(os.pread(fd,n*8,address//page*8),dtype=np.uint64)
    finally:
        os.close(fd)
    assert len(flags)==n
    private = ((flags>>63==1) & ((flags>>56)&1==1) & ((flags>>61)&1==0))
    t=perf_counter()
    credit=alternative.physical_credit(matrix)
    secs=perf_counter()-t
    return dict(bytes=n*page, private=page*int(private.sum()), candidate=original.physical_credit(matrix), alternative=credit, seconds=secs)

a=np.zeros((2048,2048), order='F', dtype=np.complex128)
start,n=alternative._interior(a,page)
for flag in (15,4):
    if advice(start,n*page,flag):
        raise OSError(ctypes.get_errno(),'madvise')
cells=np.ctypeslib.as_array((ctypes.c_ubyte*(n*page)).from_address(start))
rows={'untouched':sample(a)}
assert cells[::page].sum()==0
rows['read_zeros']=sample(a)
cells[::2*page]=1
rows['half_written']=sample(a)
cells[::page]=2
rows['all_written']=sample(a)
r,w=os.pipe()
pid=os.fork()
if pid==0:
    os.close(w)
    os.read(r,1)
    os._exit(0)
os.close(r)
try:
    rows['fork_shared']=sample(a)
    cells[::page]=3
    rows['after_parent_cow']=sample(a)
finally:
    os.close(w)
    os.waitpid(pid,0)
b=np.zeros((3072,3072),order='F',dtype=np.complex128)
b.fill(1)
rows['fully_written_default_thp']=sample(b)
with patch('builtins.open',side_effect=PermissionError):
    failed=alternative.physical_credit(a)
with patch.object(sys,'platform','darwin'):
    darwin=alternative.physical_credit(a)
with patch.object(sys,'platform','win32'):
    windows=alternative.physical_credit(a)
import tempfile
with tempfile.TemporaryFile() as f:
    f.truncate(a.nbytes)
    mapped=np.memmap(f,mode='r+',shape=a.shape,dtype=a.dtype,order='F')
    mapped.fill(1)
    assert alternative.physical_credit(mapped)==0
    assert alternative._posix(mapped)==0  # VMA filter independently excludes the file.
guards=dict(permission_failure=failed, darwin=darwin, win32=windows,
            view=alternative.physical_credit(a.T), file_mapping=alternative.physical_credit(mapped))
assert set(guards.values())=={0}
for label in ('untouched','read_zeros','fork_shared'):
    assert rows[label]['alternative']==0
for row in rows.values():
    assert 0<=row['alternative']<=row['private']<=row['bytes']
for label in ('half_written','all_written','after_parent_cow'):
    row=rows[label]
    assert row['alternative'] >= .97*row['private']
assert rows['read_zeros']['candidate']==rows['read_zeros']['bytes']
print(json.dumps(dict(kernel=os.uname().release, page=page, rows=rows, guards=guards),indent=2))
