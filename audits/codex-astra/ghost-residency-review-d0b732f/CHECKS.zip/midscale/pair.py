"""Run two serial public 360-angle solves with real disk storage and ambient memory telemetry."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import numpy as np

def compare(output):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"data"))
    from verify_round4 import solve_analytic, metric
    independent = {p:solve_analytic(p,np.arange(360.)) for p in ("TE","TM")}
    names = ("integrated", "shipped")
    rows = {}
    fields = {}
    for name in names:
        row=json.loads((output / (name+".json")).read_text())
        assert row["unknowns_per_system"] == 11968 and row["angles"] == 360 and row["quality_passed"]
        assert row["rhs_batches"]["assembled_system_reuses"] == 1
        with np.load(output / (name+".npz"),allow_pickle=False) as f:
            assert np.array_equal(f["angles_deg"],np.arange(360.))
            fields[name]={k:f["ghost_"+k] for k in ("TE","TM")}
            analytic={k:float(np.max(abs(f["ghost_"+k]-f["analytic_"+k]))/max(abs(f["analytic_"+k]))) for k in ("TE","TM")}
        admission=[r for r in row["memory_estimates"] if r.get("method")=="reused_dense_matrix_admission"]
        assert len(admission)==1 and row["residual_storage_requested"] == "disk"
        independent_errors={k:metric(fields[name][k],independent[k])["max_over_peak"] for k in ("TE","TM")}
        assert all(v<2e-5 for v in independent_errors.values())
        rows[name]=dict(independent_analytic_max_over_peak=independent_errors,panels=row["panels"],system_dofs=row["unknowns_per_system"],seconds=row["solve_wall_s"],peak_rss_gib=row["peak_rss_gib"],residual=row["residual_max"],rhs_batches=row["rhs_batches"],admission=admission[0],analytic_peak_relative=analytic)
    delta={k:float(max(abs(fields[names[0]][k]-fields[names[1]][k]))/max(abs(fields[names[1]][k]))) for k in ("TE","TM")}
    assert all(v<1e-10 for v in delta.values())
    return {"runs":rows,"relative_peak_difference":delta}

if __name__ == "__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("shipped",type=Path)
    ap.add_argument("integrated",type=Path)
    ap.add_argument("audit",type=Path)
    ap.add_argument("out",type=Path)
    ap.add_argument("--verify",action="store_true")
    ap.add_argument("--shipped-first",action="store_true",help="Reverse the pair order")
    args=ap.parse_args()
    out=args.out.resolve()
    out.mkdir(exist_ok=True,parents=True)
    if not args.verify:
        order = [("integrated",args.integrated),("shipped",args.shipped)]
        if args.shipped_first:
            order.reverse()
        for name,root in order:
            env=dict(os.environ,GRIM_ROOT=str(root.resolve()),GHOST_AUDIT_OPTIONS=json.dumps(dict(dense_residual_storage="disk",assembly_tile=128)))
            with (out / (name+".json")).open("w") as log:
                subprocess.run([sys.executable,str(args.audit.resolve()/"timed_job.py"),"4224","dense","360","4",str(out/(name+".npz"))],env=env,stdout=log,check=True)
            print(name+" completed",flush=True)
    (out/"comparison.json").write_text(json.dumps(compare(out),indent=2)+"\n")
