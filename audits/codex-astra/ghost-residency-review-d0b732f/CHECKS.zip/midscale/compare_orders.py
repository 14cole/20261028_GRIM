"""Summarize two fresh order-balanced pairs, all full fields, and independent reference errors."""
import json
from pathlib import Path
import sys
import numpy as np
from pair import compare

root=Path(sys.argv[1]).resolve()
results={}
hold={}
for label,folder,order in (("integrated_first",root,("integrated","shipped")),
                           ("shipped_first",root/"reversed",("shipped","integrated"))):
    result=compare(folder)
    result["order"]=list(order)
    result["integrated_over_shipped_time"]=result["runs"]["integrated"]["seconds"]/result["runs"]["shipped"]["seconds"]
    for role in order:
        data=json.loads((folder/(role+".json")).read_text())
        result["runs"][role]["stage_seconds"]=data["stage_seconds"]
        result["runs"][role]["process_io"]=data["process_io"]
        with np.load(folder/(role+".npz"),allow_pickle=False) as ar:
            for pol in ("TE","TM"):
                key=(label,role,pol)
                hold[key]=ar["ghost_"+pol]
    results[label]=result
reference=("integrated_first","shipped")
equal=all(v.tobytes()==hold[(*reference,k[2])].tobytes() for k,v in hold.items())
results["all_four_fields_bit_identical_by_pol"]=equal
assert all(ret["rhs_batches"]["dense_rhs_batch_count"]==4 for data in list(results.values())[:2] for ret in data["runs"].values())
print(json.dumps(results,indent=2))
