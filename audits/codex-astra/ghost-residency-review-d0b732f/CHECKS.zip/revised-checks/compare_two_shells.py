"""Compare the combined patch's admission and fields with the original candidate."""
import json
from pathlib import Path
import sys


def load(directory, name):
    return json.loads((directory/name).read_text())


revised, original = map(Path, sys.argv[1:3])
gate = load(revised, "two_shells_gate.json")
ample = load(revised, "two_shells_ample.json")
old_gate = load(original, "gate_candidate.json")
old_ample = load(original, "real_two_memory_basepages.json")
assert old_gate["quality_passed"] and "memory_error" in gate
assert all(record["binding"] == "live_physical_ram" for record in gate["pressure_limits"])
assert gate["pressure_limits"][-1]["actual_ledger_limit_gib"] < gate["plans"][-1]["peak_gib"]
for report in (gate, ample):
    for sample in report["credit_samples"]:
        page = old_gate["credit_samples"][0]["granted"] // old_gate["credit_samples"][0]["present_pages"]
        assert sample["present_nonexclusive_pages"] > 0
        assert sample["granted"] == sample["present_exclusive_pages"]*page
assert ample["quality_passed"] and ample["max_dofs"] == 2880
assert ample["raw_fields"] == old_ample["raw_fields"]
print(json.dumps(dict(
    unmodified_candidate_limit_gib=old_gate["pressure_limits"][-1]["actual_ledger_limit_gib"],
    revised_limit_gib=gate["pressure_limits"][-1]["actual_ledger_limit_gib"],
    estimated_peak_gib=gate["plans"][-1]["peak_gib"],
    granted_bytes=gate["credit_samples"][-1]["granted"],
    nonexclusive_pages=gate["credit_samples"][-1]["present_nonexclusive_pages"],
    revised_ample_fields_exactly_equal=True,
), indent=2))
