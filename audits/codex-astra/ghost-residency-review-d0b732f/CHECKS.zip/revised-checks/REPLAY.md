# Combined audit patch through the public fixed-mesh solver

Changes under test, applied in order to a clean export of main ed90b65, are Claude's candidate-vs-ed90b65.patch from d0b732f and Codex's private-matrix-reuse.patch alongside this evidence. Their SHA-256 digests are 6112790451c020797727bdab8d9b49670c67d97d831015b91439283869e51a72 and 8e651825b8e735e55a968b921aff335d3263090caa74a5ccf08b8287200d18f8 respectively. Every combined-tree solve runs in a fresh Linux process with one BLAS/assembly thread. The shipped reference JSON and fields in ledger/ and public/ are byte-for-byte copies of the separately executed, same-session shipped references in live/. Files named candidate in these subdirectories refer to the combined research patch.

With base pages, the two-shell test exposes shared zero pages in the actual retained GHOST matrix before a subsequent in-place TM write. The revised native code offers 95,694,848 bytes for 23,363 eligible pages and excludes 9,036 shared pages. The original candidate counted all 132,706,304 bytes. A controlled 0.48 GiB of spendable TM physical headroom yields 0.569122772 GiB under the revised native rule and 0.603592377 GiB under Claude's original rule. The required peak is 0.586694248 GiB. The revised code declines while the original admits. With ample live RAM and the same 0.7 GiB explicit cap the revised patch completes and exactly reproduces all ten complex field samples. No test-side credit override or page release was used in these two combined-tree cases.

The one-shell ledger pair tests an injected OS page-query failure and a normal native measurement under identical controlled available-memory inputs. At 2,992 unknowns native Linux reused 143,228,928 bytes at a 0.643392 GiB gate and passed all 180 angles. Shipped planned a width of 1, and the combined patch planned a width of 180. TE was bit-identical to shipped, and the maximum normalized TM field difference was 7.76e−13. An unavailable probe yielded a 0.565553 GiB final limit and declined below the 0.596232 GiB estimate. The smaller public controls also cover partial measured credit, a query failure after a successful forecast, and a missing query with ample RAM. The automatic-tile controls exercise withdrawal of the credit when either 0 → 128 or 128 → 0 invalidates the retained operator. Their complete gate values, complex arrays, comparisons and regression assertions appear in the three subdirectories. The fixture definitions and measurement details are in ../live/REPLAY.md and ../linux/REPLAY.md.

## Replay

From the evidence root containing live/, linux/ and revised-checks/, set GRIM_ROOT to the clean, patched tree and PYTHONPATH to the pinned Claude ghost-backend-audit directory. Use scientific Python with the project's dependencies and Linux with readable /proc/self/pagemap and /proc/self/smaps_rollup. The two-shell case uses NumPy's base-page control on a worker whose kernel huge-page setting is madvise. Record the page configuration when reproducing on other hosts.

```sh
export GRIM_ROOT=/path/to/combined-tree
export PYTHONPATH=/path/to/claude/ghost-backend-audit
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export NUMPY_MADVISE_HUGEPAGE=0
python linux/solver_pages.py memory 512 two_shells --budget 0.7 --physical-headroom 0.48 > revised-checks/two_shells_gate.json
python linux/solver_pages.py memory 512 two_shells --budget 0.7 > revised-checks/two_shells_ample.json
python revised-checks/compare_two_shells.py revised-checks linux
unset NUMPY_MADVISE_HUGEPAGE

for case in candidate_failure candidate_native; do
    python live/ledger/check_ledger.py "$case" revised-checks/ledger
done
python live/ledger/check_ledger.py compare revised-checks/ledger

for case in ambient native half unavailable disappears unavailable_ample; do
    python live/check_public.py "$case" revised-checks/public --label candidate
done
python live/check_public.py compare revised-checks/public

python live/tiles/check_identity.py auto tighten revised-checks/tiles/auto_tighten.npz > revised-checks/tiles/auto_tighten.json
python live/tiles/check_identity.py auto relax revised-checks/tiles/auto_relax.npz > revised-checks/tiles/auto_relax.json
python live/tiles/check_identity.py 128 tighten revised-checks/tiles/pinned.npz > revised-checks/tiles/pinned.json
python live/tiles/compare_tiles.py revised-checks/tiles
```

The original candidate's ambient two-shell field reference and controlled admission must exist in linux/ for the two-shell comparison. The three other checkers use the shipped references already present in the evidence. To regenerate those references, follow the commands in ../live/REPLAY.md. Controlled memory readings model admission decisions, and timing under these controls is incidental. None establishes performance at 24k unknowns, a true low-memory outcome or Windows compatibility.
