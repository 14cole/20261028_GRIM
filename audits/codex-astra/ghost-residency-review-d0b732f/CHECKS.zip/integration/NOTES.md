# Retained Dense matrix and final admission

## Archived 24k run

The second candidate `dense_phase_v1` entry in Claude's `results/c_cand24k/candidate/dense.out` offered 9,166,913,536 bytes and credited 9,166,909,440 at planning. A separate `reused_dense_matrix_admission` record immediately before admission shows the same measured credit, effective tile 128, a 9.969146728515625 GiB forecast, and 13.420233154296875 GiB limit. The shipped execution used a 9.110851295292377 GiB forecast and a 13.426147079467773 GiB limit after narrowing the batch. The candidate prices the second polarization using a live measure at both points. The stored credit is an input to the ledger. Physical headroom, stable reservation, explicit and scheduler limits, and any available commit headroom can limit the effective result.

The lookups use the material/geometry/frequency/quadrature/tile session key. The session retains the array. Planning holds only a weak reference between lookups. If the candidate tile cannot consume the priced buffer, planning reprices uncredited. Execution looks up the current tile again. An overlapping run owner suppresses the extra physical hint, and the ordinary commit calculation receives no extra hint. The archive records one successful assembly-session lookup. For this multi-region case assembly either reuses the matrix directly or sends it to fresh assembly as the destination. The 24k run used disk residual storage and no paired second matrix. On successful TE completion the restoration loop writes every row into the retained buffer before TM. The source and run evidence give no indication the benchmark benefited from reading unallocated zero pages. Other admission paths require their own checks.

A missing residency probe gives zero additional credit at the candidate's final gate. Shipped still passes the verified array's nominal allocation size there. At a RAM boundary this can change whether a solve is accepted. Disabling Windows residency alone would therefore change some shipped Windows admission decisions. Bistatic uses its independent uncredited gate in `twod/solver.py`, outside the monostatic experiment.

## Actual reuse versus a session lookup

The study-D wrapper logs `AssemblySession.take` success. The session increments its reuse counter before the formulation inspects the retrieved coefficients. `twod/formulations/dielectric.py` lines 41–54 conditionally discards the fetched object if the saved scaling factor has magnitude at most 1e-12. We exercised that separate path using public CPU Dense monostatic solves with one passive homogeneous dielectric cylinder, 1 GHz, three angles, one thread, explicit disk storage and tile 128.

The control has relative permittivity 4 and permeability 1. The deliberately extreme case uses 2e12 and 2e-12, respectively. Both have refractive index 2; both pass the material validator. With 48 sides (96 unknowns), the latter has a saved TE factor of 5e-13. Both planner and gate credited 143,360 bytes of a 147,456-byte ndarray. TM reported a cache hit, discarded the ndarray, and assembled a different one. The independent weak reference had already expired immediately before the replacement allocation. At 384 sides (768 unknowns) the case credited 9,433,088 bytes of 9,437,184. At both sizes the replacement reused the same virtual address, the original weak reference had expired, and RSS at the pre-allocation snapshot equalled RSS at the final gate. There is no demonstrated simultaneous ownership, peak memory increase, or exhausted-RAM failure. Behavior on another allocator or under actual RAM pressure was not measured. A matched lookup alone cannot substantiate destination identity.

The audit-only `retain-dielectric-destination.patch` clears the matched destination and uses it for the full reassembly when the fast rescaling is singular. The ordinary rescaling continues unchanged. The public control and extreme cases returned the same array after this repair and produced exactly the same TE/TM complex fields before and after. Local stage RSS samples are diagnostic snapshots, not a peak-RAM or execution-time benchmark. The correction is independent of the 24k coated-cylinder speed result. A further four solves used the full integrated revision with the ordinary module loaded from that tree. Each returned the priced object, passed the quality check, and matched the original candidate's complex fields bit for bit. See `dielectric_integrated.json` and `dielectric_384_integrated.json`.

## Reproduction

Start with a clean candidate export and Claude's pinned audit harness. Set the paths appropriately. To leave the export intact, apply the small patch only to a temporary copy of the formulation module.

```sh
export GRIM_ROOT=/path/to/candidate
export PYTHONPATH=/path/to/claude/ghost-backend-audit
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
audit=/path/to/integration
scratch=$(mktemp -d)
module=tools/GHOST/ghost_backend/twod/formulations/dielectric.py
mkdir -p "$scratch/$(dirname "$module")"
cp "$GRIM_ROOT/$module" "$scratch/$module"
(cd "$scratch" && patch -p1 < "$audit/retain-dielectric-destination.patch")
python "$audit/check_destination.py" --sides 48
python "$audit/check_destination.py" --sides 48 --alternative "$scratch/$module"
python "$audit/check_destination.py" --sides 384
python "$audit/check_destination.py" --sides 384 --alternative "$scratch/$module"
```

The observer holds only a weak reference and the original data pointer as an integer; it never modifies a coefficient or a memory limit. The optional alternative runs the patched assembly function against the rest of the same candidate export. The JSON outputs include the full complex fields. To repeat the integrated cases, point `GRIM_ROOT` at the integrated tree and run the two sizes without `--alternative`.
