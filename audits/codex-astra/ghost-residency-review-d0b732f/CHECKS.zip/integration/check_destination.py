"""Observe a real public single-dielectric Dense solve. No gate or coefficients are changed.

GRIM_ROOT points at the tree under test; add Claude's harness directory to PYTHONPATH.
"""
import argparse
import json
import sys
from pathlib import Path
import importlib.util
import weakref
from unittest.mock import patch

import numpy as np
from harness import cylinder_geo, fields_of, solve_fixed
from ghost_backend.execution import dense_memory
from ghost_backend.twod.assembly import session
from ghost_backend.twod.formulations import dielectric

def run(epsilon, permeability, sides, alt_path=None):
    text = cylinder_geo(.010, sides, a=.008, eps=epsilon, mu=permeability)
    text = text.split("Segment: coat_inner")[0] + "IBCS_Resistances:" + text.split("IBCS_Resistances:", 1)[1]
    observations = []
    tracked = {}
    def rss_bytes():
        # The stage observations are local snapshots. They do not measure peak RSS.
        status = Path("/proc/self/status").read_text().splitlines()
        return int(next(line.split()[1] for line in status if line.startswith("VmRSS:"))) * 1024
    measure = dense_memory.bounded_reuse_hint
    def measured(array):
        hint = measure(array)
        if array is not None:
            tracked["array"] = weakref.ref(array)
            tracked["address"] = array.ctypes.data
            observations.append(dict(event="measured", rss_bytes=rss_bytes(), allocated=array.nbytes, granted=hint))
        return hint
    assemble = dielectric.assemble_system
    if alt_path is not None:
        spec = importlib.util.spec_from_file_location("revised_dielectric", alt_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        assemble = module.assemble_system
    zeros = np.zeros
    def allocations(*args, **kwargs):
        caller = sys._getframe(1)
        if caller.f_code is assemble.__code__ and caller.f_locals.get("pol") == "TM":
            old = tracked.get("array")
            observations.append(dict(event="before_zeros", rss_bytes=rss_bytes(), shape=list(args[0]),
                        old_alive=(old is not None and old() is not None)))
        return zeros(*args, **kwargs)
    def actual(*args, **kwargs):
        pol = args[2]
        matrix = assemble(*args, **kwargs)
        if pol == "TM" and "array" in tracked:
            same = tracked["array"]() is matrix
            observations.append(dict(event="returned", same_object=same, same_address=(matrix.ctypes.data == tracked["address"]), rss_bytes=rss_bytes(), allocated=matrix.nbytes))
        return matrix
    take = session.AssemblySession.take
    def lookup(owner, key, pol):
        item = take(owner, key, pol)
        if pol == "TM":
            observations.append(dict(event="lookup", hit=item is not None,
                     old_factor=(abs(item[1]) if item is not None else None)))
        return item
    record = dict(eps=epsilon, mu=permeability, sides=sides, observations=observations)
    with patch.object(np, "zeros", allocations), patch.object(dense_memory, "bounded_reuse_hint", measured), patch.object(dielectric, "assemble_system", actual), patch.object(session.AssemblySession, "take", lookup):
        try:
            result, wall = solve_fixed(text, 1.0, [-20., 0., 20.], "dense", threads=1,
                                dense_residual_storage="disk", assembly_tile=128)
            m = result["metadata"]
            record.update(solved=True, quality=m["quality_gate"]["passed"], elapsed_s=wall,
                          declared_reuse=m.get("assembled_system_reuses"), gates=[x for x in m["experimental_cpu"]["memory_estimates"] if x.get("method") == "reused_dense_matrix_admission"],
                          fields={k:[[z.real,z.imag] for z in v] for k,v in fields_of(result).items()})
        except Exception as exc:
            record.update(solved=False, error=str(exc))
    return record
if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--sides",type=int,default=48)
    p.add_argument("--alternative", type=Path)
    a=p.parse_args()
    print(json.dumps([run(4.,1.,a.sides,a.alternative), run(2.e12, 2.e-12,a.sides,a.alternative)],indent=2))
