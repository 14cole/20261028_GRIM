"""Exercise Line Expansion trial cases omitted from Claude's proposed suite.

Run with GRIM_ROOT set to a release checkout (or a copy with trial-fix.patch applied)
and PYTHONPATH including Claude's audit directory, which supplies common.py.
Writes one JSON to stdout. Inputs and outputs are real GRIM files in a temporary folder.
"""
import json
import tempfile
from pathlib import Path
import numpy as np
from common import expand, write_section, reopen, rel, scalar
from ghost_backend.io.grim import _save_grim_npz
from ghost_backend.assembly.fields import load_body_requested_radar_grid
from ghost_backend.ui.line_expansion import parse_samples


def main(directory):
    out = {}
    section = write_section(directory)
    grid = dict(frequencies_ghz=[1.0], azimuths_deg=[10.,55.,85.], elevations_deg=[20.])
    attitude = dict(axis_az_deg=32., axis_el_deg=8., roll_deg=9.)
    def run(name, base=None, **options):
        result = expand([section], output_grim=str(directory/(name+'.grim')),
                        **(grid if base is None else dict(body_grim=str(base))), **options)
        payload,field = reopen(result['output'])
        return payload,field,result['warnings']
    base,ref,_ = run('ref')
    _,att_ref,_ = run('att',**attitude)
    def write(name, field, **metadata):
        payload = dict(base, **metadata)
        payload.update(rcs_amp_real=field.real.copy(),rcs_amp_imag=field.imag.copy(),
                       rcs_power=4*np.pi*abs(field)**2,rcs_phase=np.angle(field))
        return _save_grim_npz(payload, str(directory/(name+'.grim')))
    def compare(name, source, expected, **kwargs):
        try:
            payload,field,warnings = run(name, source, **kwargs)
        except Exception as error:
            out[name] = dict(accepted=False, error=str(error))
            return
        out[name] = dict(accepted=True,error=rel(field,expected),warnings=warnings)
    compare('degree_control',write('degree',ref),2*ref)
    units=json.loads(scalar(base,'units'))
    units['elevation_coordinate_convention']='sentri_theta_top_zero'
    compare('polar_theta',write('polar-base',ref,elevations=90-np.asarray(grid['elevations_deg']),
                                units=json.dumps(units)),2*ref)
    phase_ref=scalar(base,'phase_reference').replace('exp(+jwt)','exp(-jwt)')
    compare('opposite_phase',write('negative-phase-base',ref.conj(),
                    time_convention='exp(-jwt)',phase_reference=phase_ref),2*ref.conj())
    # An incoming zero field has no angle-dependent value to transform; the first
    # output at explicit B should equal the independent section at B exactly.
    old_attitude=dict(axis_az_deg=0., axis_el_deg=0., roll_deg=0.)
    old_grid=dict(schema='ghost.workflow.requested-radar-grid.v1',**grid, **old_attitude)
    source=write('zero-declared',0*ref,requested_radar_grid_json=json.dumps(old_grid))
    first,first_field,first_w=run('explicit-override',source,**attitude)
    out['explicit_override']=dict(error=rel(first_field,att_ref),warnings=first_w,
        stored_request_attitude={k:load_body_requested_radar_grid(str(directory/'explicit-override.grim'))[k] for k in attitude},
        stored_line_attitude=json.loads(scalar(first,'line_expansion_provenance_json') or '{}').get('body_attitude_deg'))
    compare('override_chained_implicit',directory/'explicit-override.grim',2*att_ref)
    compare('override_chained_explicit',directory/'explicit-override.grim',2*att_ref,**attitude)
    # BoR body-profile keys trigger a default-zero fallback in the shared
    # radar grid loader when the request itself is missing or unreadable.
    rho=np.array([0.,0.01,0.]); z=np.array([-0.01,0.,0.01])
    zero=write('zero-bor-no-request',0*ref,body_profile_rho_m=rho,body_profile_z_m=z,body_model_aspects_deg=np.array([0.,180.]))
    out['bor_preexisting_loader_default']=load_body_requested_radar_grid(zero) is not None
    run('bor-override',zero,**attitude)
    compare('bor_override_chained',directory/'bor-override.grim',2*att_ref)
    compare('bor_override_chained_explicit',directory/'bor-override.grim',2*att_ref,**attitude)
    # Count both axes separately, never allocate their product.
    naz=len(parse_samples('0:359:0.01','Azimuth'))
    nel=len(parse_samples('-90:90:0.01','Elevation'))
    out['accepted_grid_size'] = dict(azimuths=naz,elevations=nel,looks=naz*nel,
                                     scatter_gib=naz*nel*4*16/2**30)
    return out


if __name__=='__main__':
    with tempfile.TemporaryDirectory() as directory:
        print(json.dumps(main(Path(directory)),indent=2))
