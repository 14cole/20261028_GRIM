"""Independent, unprivileged fixtures for the proposed Claude cgroup discovery change.

PYTHONPATH=/path/to/checkout/tools/GHOST python independent_layouts.py
Mock procfs, sysfs and loads only. Data fixtures below specify actual sibling use.
"""
import io
import json
import os
from pathlib import Path
from unittest.mock import patch

from ghost_backend.execution.memory_budget import MemoryBudget
from ghost_backend.hpc import scheduler
from ghost_backend.twod import solver

G=2**30
CG='/sys/fs/cgroup'
PROC='/proc/self/cgroup'
MI='/proc/self/mountinfo'
def v2(i, mount_root, path):
    return f'{i} 8 0:31 {mount_root} {path} ro - cgroup2 cgroup2 ro\n'

def trial(mounts, counters, member='/team/mine/worker', *, corrupt=False):
    data={PROC: '0::'+member+'\n', MI: mounts, '/proc/meminfo': 'MemTotal:       33554432 kB\nMemAvailable:   25165824 kB\n'}
    for path,(limit,used) in counters.items():
        data[path+'/memory.max']=str(limit)
        if used is not None:
            data[path+'/memory.current']=str(used)
    def fake_open(path,*args,**kw):
        s=data.get(os.fspath(path))
        if s is None:raise FileNotFoundError(path)
        if corrupt and path==MI:
            # Linux escapes space, tab, newline and backslash in mountinfo; a mount
            # point may still contain arbitrary non-UTF8 bytes on a UTF-8 Python.
            raw=io.BytesIO(s.encode()+b'55 8 0:51 / /mnt/\xff ro - tmpfs tmpfs ro\n')
            if 'b' in kw.get('mode',args[0] if args else 'r'):
                return raw
            return io.TextIOWrapper(raw,encoding=kw.get('encoding') or 'utf-8',errors=kw.get('errors'))
        return io.StringIO(s)
    def fake_read(path,*args,**kw):
        return fake_open(os.fspath(path)).read()
    result={}
    with patch.dict(os.environ,{},clear=True), patch.object(solver,'open',fake_open,create=True), patch.object(solver,'_psutil_available_bytes',return_value=24*G), patch.object(solver,'_slurm_available_bytes',return_value=None), patch.object(solver,'_process_rss_bytes',return_value=G//4), patch.object(Path,'read_text',fake_read):
        try:
            result['solver_detected_GiB']=solver._detect_available_gb()
            result['ledger_budget_GiB']=MemoryBudget().limit()
        except Exception as exc:
            result['error']=type(exc).__name__
        result['hpc_capacity_GiB']=scheduler.detect_memory_gb()
    return result

def main():
    native=v2(9,'/',CG)
    sibling=v2(10,'/team/sibling','/mnt/other')
    own={CG:('max',8*G),CG+'/team':('max',6*G),CG+'/team/mine':(6*G,2*G),CG+'/team/mine/worker':('max',G//4)}
    sib={'/mnt/other':(G,7*G//8)}
    result={
        'own_control':trial(native,own),
        'same_with_irrelevant_sibling_bind':trial(native+sibling,dict(own,**sib)),
        'sibling_bind_at_conventional_path':trial(v2(9,'/','/mnt/real')+v2(10,'/team/sibling',CG),dict({k.replace(CG,'/mnt/real'):v for k,v in own.items()},**{CG:sib['/mnt/other']})),
        'unreadable_usage_with_siblings':trial(native,{**own, CG+'/team/mine':(6*G,None)}),
        'non_utf8_unrelated_mount':trial(native,own,corrupt=True),
        'root_512MiB_limit':trial(native,{CG:(G//2,G//4)},member='/'),
    }
    # Every /team/mine case has 4 GiB remaining. The parent limit is 6 GiB,
    # 2 GiB are used, and the process accounts for only 0.25 GiB of that usage.
    # The unreadable-usage fixture hides that 2 GiB counter from the probe.
    for case, data in result.items():
        remaining = 0.25 if case == 'root_512MiB_limit' else 4.
        capacity = 0.5 if case == 'root_512MiB_limit' else 6.
        data.update(expected_detected_GiB=remaining, expected_budget_GiB=0.9*remaining,
                    expected_cgroup_capacity_GiB=capacity)
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
