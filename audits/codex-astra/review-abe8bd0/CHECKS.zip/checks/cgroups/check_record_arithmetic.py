"""Recalculate over-admission from all ten real cgroup records in Claude's handoff."""
import argparse
import json
from pathlib import Path

GIB=2**30
def main():
    p=argparse.ArgumentParser()
    p.add_argument('records',type=Path)
    args=p.parse_args()
    result=[]
    for path in sorted(args.records.glob('*.json')):
        row=json.loads(path.read_text())
        truth=row['true_remaining_bytes']/GIB
        budget=row['ledger_budget_gib']
        delta=budget-.9*truth
        levels=[l for h in row['hierarchies'] for l in h['levels'] if l['remaining_bytes'] is not None]
        assert all(int(l['limit'])-int(l['usage'])==l['remaining_bytes'] for l in levels)
        raw=min([row['mem_available_bytes']]+[l['remaining_bytes'] for l in levels])/GIB
        assert abs(delta-row['over_admitted_gib'])<1e-8
        result.append(dict(record=path.stem,available_gib=truth,reported_budget_gib=budget,
                           correct_budget_gib=.9*truth,excess_gib=delta,
                           before_walk_minus_final_truth_mib=(raw-truth)*1024))
    assert len(result)==10
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
