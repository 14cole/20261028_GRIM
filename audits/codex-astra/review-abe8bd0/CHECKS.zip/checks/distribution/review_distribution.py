"""Check notices, wheel checksum provenance and missing-kernel reports on current main.

Run with the GUI's Linux Python environment, a C compiler, setuptools and wheel:
python review_distribution.py /path/to/GRIM /tmp/empty-result-directory /path/to/Claude/response/distribution
All modifications occur in a temporary GHOST tree. Only healthy or missing libs are tested.
"""
import argparse
import base64
import csv
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory
import zipfile
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repo', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('claude_scripts', type=Path)
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=False)
claude = args.claude_scripts.resolve()
notices = ['ghost_backend/execution/DATACLASSES_LICENSE.txt','ghost_backend/execution/thread_control/LICENSE-3.6.0.txt']
source = args.repo.resolve()/'tools/GHOST'
targets = json.loads((source/'NATIVE_LIBRARIES_LINUX.json').read_text())['libraries']
def digest(b): return hashlib.sha256(b).hexdigest()
def build(src, folder, *extra):
    with (out / (folder+'.log')).open('w') as log:
        subprocess.run([sys.executable, str(src/'scripts/build_distribution.py'), '--output',str(out/folder),*extra], stdout=log, stderr=subprocess.STDOUT, check=True)
def archive(path):
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path) as t:
            return {n.name:t.extractfile(n).read() for n in t.getmembers() if n.isfile()}
    with zipfile.ZipFile(path) as f:
        return {n:f.read(n) for n in f.namelist() if not n.endswith('/')}
def inventory(folder):
    results = {}
    for path in sorted((out/folder).iterdir()):
        if path.suffix not in ('.gz','.whl','.zip'): continue
        members=archive(path)
        results[path.name] = {
            'count':len(members),
            'notices': {k: any(n.endswith(k) and b==(source/k).read_bytes() for n,b in members.items()) for k in notices},
            'vendored_py':any(k.endswith('/_threadpoolctl.py') for k in members),
            'diagnostic':any(k.endswith('scripts/check_speed_paths.py') for k in members),
            'manifest_paths':[k for k in members if 'NATIVE_LIBRARIES' in k],
            'natives':[k for k in members if k.endswith(('.dll','.so'))]}
    return results
report = {}
with TemporaryDirectory() as tmp:
    stage = Path(tmp)/'GHOST'
    shutil.copytree(source, stage, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.egg-info'))
    build(stage,'baseline','--native','--no-openmp')
    report['baseline']=inventory('baseline')
    w = next((out/'baseline').glob('*.whl'))
    members=archive(w)
    record=next(k for k in members if k.endswith('.dist-info/RECORD'))
    hashes={row[0]:row[1] for row in csv.reader(io.StringIO(members[record].decode()))}
    release=json.loads(next((out/'baseline').glob('*-manifest.json')).read_text())['native']['libraries']
    def validate(rec):
        name=rec['path'];data=members[name];actual=digest(data)
        byte_hash='sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
        return dict(name=name,shipped_checkout_match=actual==rec['sha256'],wheel_record_match=byte_hash==hashes[name],
                    generated_manifest_match=actual==release[name]['sha256'],sha256=actual)
    report['fresh_no_openmp']=list(map(validate,targets))
    assert all(x['wheel_record_match'] and x['generated_manifest_match'] for x in report['fresh_no_openmp'])
    assert not report['fresh_no_openmp'][-1]['shipped_checkout_match']
    installed=Path(tmp)/'installed'; installed.mkdir()
    with zipfile.ZipFile(w) as f:f.extractall(installed)
    for rec in targets:
        lib=ctypes.CDLL(str(installed/rec['path']))
        assert all(hasattr(lib,k) for k in rec['required_exports'])
    report['fresh_no_openmp_exports_pass']=True
    p=stage/'pyproject.toml'
    p.write_text(p.read_text().replace('[tool.setuptools.package-data]', '[tool.setuptools.package-data]\n"ghost_backend.execution.thread_control" = ["LICENSE-3.6.0.txt"]\n"ghost_backend.execution" = ["DATACLASSES_LICENSE.txt"]'))
    build(stage,'fixed')
    report['two_notice_trial']=inventory('fixed')
    assert all(all(d['notices'].values()) for d in report['two_notice_trial'].values())
    env={k:v for k,v in os.environ.items() if not k.startswith(('OPENBLAS','OMP_','MKL','GHOST','PYTHONPATH'))}
    env['PYTHONPATH']=str(stage)
    baseline={}
    report['solve_diagnostic']={}
    for state in ('normal','missing_near'):
        if state=='missing_near':
            (stage/'ghost_backend/twod/assembly/native/libghost_near.so').unlink()
        diagnostic=subprocess.run([sys.executable,str(stage/'scripts/check_speed_paths.py')],cwd=tmp,env=env,capture_output=True,text=True)
        arr=Path(tmp)/(state+'.npz')
        solved=subprocess.run([sys.executable,str(claude/'solve_probe.py'),str(arr)],cwd=tmp,env=env,capture_output=True,text=True,check=True)
        d=json.loads(solved.stdout)
        with np.load(arr) as f: fields={k:f[k].copy() for k in f.files}
        if state=='normal':baseline=fields
        report['solve_diagnostic'][state]=dict(diagnostic_exit=diagnostic.returncode,check_rows=diagnostic.stdout.splitlines()[1:],
            loaders=d['loaders'],warnings=d['python_warnings'],metadata=[{'backend':r['linear_backend'],'warnings':r['metadata_warnings'],'gate':r['quality_passed']} for r in d['runs']],
            max_field_relative_l2=max(np.linalg.norm(v-baseline[k])/np.linalg.norm(baseline[k]) for k,v in fields.items()))
    assert report['solve_diagnostic']['normal']['loaders']['near_available']
    assert not report['solve_diagnostic']['missing_near']['loaders']['near_available']
(out/'review_distribution.json').write_text(json.dumps(report,indent=2)+'\n')
