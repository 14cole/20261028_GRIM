"""Exercise a placed point after a lossless azimuth relabel on a profile-bearing base.

Set GRIM_ROOT and put its root, tools/GHOST, Claude's audit helper path and
Codex's check_placed_feature.py directory on PYTHONPATH.
"""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
import check_placed_feature as case
from common import expand, write_section, reopen, rel
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.assembly import fields
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly

def run(work):
    case.GRID.update(azimuths_deg=[0.,45.,120.,210.])
    section = write_section(work)
    csv = work/'point.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    pattern = case.create_point_pattern(work)
    surface = work/'patch.stl'
    surface.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    true = case.point_reference(case.ATT)
    zero = case.point_reference(case.ZERO)
    rows = {}
    for kind, bor in (('sections',None), ('bor',case.sphere(work))):
        out = work/(kind+'-original.grim')
        expand([section],output_grim=str(out),**(dict(body_grim=str(bor)) if bor else case.GRID),**case.ATT)
        _, original = reopen(out)
        edited = work/(kind+'-axis-edit.grim')
        RcsGrid.load(str(out)).edit_axis_value('azimuth',0,360.).save(str(edited))
        for label, selected, perm in (('intact',out,[0,1,2,3]),('axis_edit',edited,[1,2,3,0])):
            prior, data = reopen(selected)
            opts = dict(coordinate_units='meters',point_locations_csv=csv,
                        point_datasets={'pattern':pattern},point_response_settings={'pattern':{'one_sided':False}})
            if not bor: opts.update(surface_mesh=surface,surface_units='meters')
            request = FeatureAssemblyRequest(base_grim=selected,output_grim=work/(kind+'-'+label+'-out.grim'),**opts)
            recordfn = getattr(fields,'recorded_line_expansion_attitude',lambda p: None)
            rec = recordfn(prior)
            row = dict(input_field_error=rel(data,original[perm]), request_present='requested_radar_grid_json' in prior,
                       profile_present='body_profile_rho_m' in prior,recognized_record=rec)
            try:
                plan = prepare_feature_assembly(request)
                dest = execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
                after,total = reopen(dest)
                row.update(plan_angles={k:plan.radar_grid[k] for k in case.ATT},samples=data.size,
                           added_error=rel(total-data,true[perm]), total_error=rel(total,data+true[perm]),
                           added_error_vs_zero=rel(total-data,zero[perm]),
                           output_recognized_record=recordfn(after), warnings=list(plan.validation_warnings))
                if kind=='sections' and label=='intact':
                    for variant, att in [('matching',case.ATT),('conflicting',case.ZERO)]:
                        sub = work/('direct-'+variant+'.grim')
                        try:
                            fields.add_features_to_monostatic_grim(str(selected),str(sub),radar_grid={**plan.radar_grid,**att},
                                points=plan.point_placements,declared_coherent_base=True)
                            dp,df = reopen(sub)
                            row['direct_'+variant]=dict(added_error=rel(df-data,true),total_error=rel(df,data+true), output_recognized_record=recordfn(dp))
                        except Exception as exc:
                            row['direct_'+variant]=dict(refused=type(exc).__name__+': '+str(exc))
            except Exception as exc:
                row['refused']=type(exc).__name__+': '+str(exc)
            rows[kind+'_'+label]=row
    return rows

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:print(json.dumps(run(Path(temp)),indent=2))
