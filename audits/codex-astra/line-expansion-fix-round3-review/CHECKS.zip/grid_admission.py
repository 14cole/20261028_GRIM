"""Trace read order and reopened field sizes for regular native v1 and v2 files.
Set GRIM_ROOT to the checkout, and put its tools/GHOST and Claude's line-expansion audit
directory (with common.py) on PYTHONPATH.
"""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import numpy as np
from common import expand, reopen, write_section
from ghost_backend.assembly import expand_wing_sections as wing
from ghost_backend.io.grim import _save_grim_npz
from ghost_backend.ui.line_expansion import parse_samples

def exercise(directory):
    section=write_section(directory)
    axes=dict(azimuths_deg=[10.,20.,30.],elevations_deg=[0.,45.],frequencies_ghz=[1.])
    ref=directory/'six.grim'
    expand([section],output_grim=str(ref),**axes)
    ref_body,ref_field=reopen(ref)
    results={}
    axis_names=['azimuths','elevations','frequencies','polarizations']
    field_names=('rcs_complex','rcs_amp_real','rcs_amp_imag','rcs_power','rcs_phase')

    def test(name,path,limits,*,accepted):
        destination=directory/(name+'-output.grim')
        sentinel=b'original'
        destination.write_bytes(sentinel)
        with np.load(ref,allow_pickle=False) as f:
            cls=type(f)
        reads=[]
        gates=[]
        real_read=cls.__getitem__
        def observe_read(handle,key):
            value=real_read(handle,key)
            reads.append(key)
            return value
        real_check=wing._check_grid_size
        def observe_gate(*args,**kwargs):
            gates.append(list(reads))
            return real_check(*args,**kwargs)
        req=axes if path is None else {'body_grim':str(path)}
        with ExitStack() as ctx:
            ctx.enter_context(patch.object(cls,'__getitem__',observe_read))
            ctx.enter_context(patch.object(wing,'_check_grid_size',observe_gate))
            for key,value in limits.items():
                ctx.enter_context(patch.object(wing,key,value))
            try:
                expand([section],output_grim=str(destination),**req)
            except ValueError as exc:
                error=str(exc)
            else:
                error=None
        assert (error is None)==accepted, (name,error)
        simple=dict(accepted=error is None,error=error,first_gate_saw=gates[0])
        assert gates[0]==(axis_names if path else []),(name,gates[0])
        if accepted:
            _,out=reopen(destination)
            simple.update(output_shape=out.shape,output_samples=out.size)
            if name in ('entered_at_boundaries','v1_at_boundaries','v2_at_boundaries'):
                expected=ref_field if path is None else 2*ref_field
                simple['max_relative_field_difference']=float(np.max(abs(out-expected))/np.max(abs(expected)))
                assert simple['max_relative_field_difference']<2e-14
        else:
            assert not any(n in field_names for n in reads)
            simple['old_output_kept']=destination.read_bytes()==sentinel
            assert simple['old_output_kept']
        results[name]=simple

    look_cap={'MAX_LOOKS':5}
    at_cap={'MAX_LOOKS':6,'MAX_OUTPUT_SAMPLES':18,'MAX_AXIS_SAMPLES':3}
    test('entered_too_many_looks',None,look_cap,accepted=False)
    test('entered_at_boundaries',None,at_cap,accepted=True)
    for ver in (1,2):
        file=directory/f'v{ver}.grim'
        _save_grim_npz(ref_body,str(file),format_version=ver)
        test(f'v{ver}_too_many_looks',file,look_cap,accepted=False)
        test(f'v{ver}_too_many_samples',file,{'MAX_OUTPUT_SAMPLES':17},accepted=False)
        test(f'v{ver}_too_many_azimuths',file,{'MAX_AXIS_SAMPLES':2},accepted=False)
        test(f'v{ver}_at_boundaries',file,at_cap,accepted=True)
    payload=dict(ref_body)
    labels=['VV','HH','VH','HV','TOTAL']
    for key in ('rcs_power','rcs_phase','rcs_amp_real','rcs_amp_imag'):
        original=np.asarray(payload[key])
        payload[key]=original[..., [0,1,2,2,0]]
    payload['polarizations']=np.asarray(labels)
    payload['polarization_aliases_json']=np.asarray(json.dumps(labels))
    output=directory/'five.grim'
    _save_grim_npz(payload,str(output),format_version=2)
    test('five_channels_24_sample_limit',output,{'MAX_OUTPUT_SAMPLES':24},accepted=False)
    test('five_channels_30_sample_limit',output,{'MAX_OUTPUT_SAMPLES':30},accepted=True)
    one=100_000
    parser={}
    for value in ('0:99999:1','0:100000:1','0:99999.9999999995:1'):
        try:
            parser[value]=len(parse_samples(value,'Azimuth'))
        except ValueError as exc:
            parser[value]=str(exc)
    assert parser['0:99999:1']==one
    assert all(isinstance(parser[k],str) for k in ('0:100000:1','0:99999.9999999995:1'))
    try:
        expand([section],output_grim=str(directory/'many-freq.grim'),azimuths_deg=[10.],elevations_deg=[0.],frequencies_ghz=range(1,one+2))
    except ValueError as exc:
        api_limit=str(exc)
    else:
        raise AssertionError('100001 frequencies passed preflight')
    assert '100,001' in api_limit and 'frequencies' in api_limit
    return dict(archive_cases=results,gui_sweep_counts=parser,direct_api_100001_frequencies=api_limit)
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        print(json.dumps(exercise(Path(tmp)),indent=2))
