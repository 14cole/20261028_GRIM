"""Test a valid version-1 linear power-and-phase field omitting its optional log unit."""
import json
import tempfile
from pathlib import Path
import numpy as np
from common import expand, reopen, rel, scalar, write_section
from ghost_backend.io.grim import _save_grim_npz
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly

def run(root):
    section = write_section(root)
    source = root/'source.grim'
    expand([section],output_grim=str(source), frequencies_ghz=[1.], azimuths_deg=[0.,50.], elevations_deg=[0.])
    base, field = reopen(source)
    units = json.loads(scalar(base,'units'))
    old = units.pop('rcs_log_unit',None)
    result = {}
    for name, us in (('known',{**units,'rcs_log_unit':old}), ('missing',units)):
        pp = {k:v for k,v in base.items() if k not in ('rcs_amp_real','rcs_amp_imag','complex_field_domain','phase_reference','amplitude_convention','time_convention','polarization_basis','raw_complex_amplitude_preserved')}
        pp.update(units=np.asarray(json.dumps(us)),rcs_power=4*np.pi*abs(field)**2,rcs_phase=np.angle(field))
        path = root/(name+'-v1.grim')
        _save_grim_npz(pp,str(path),format_version=1)
        after = root/(name+'-addition.grim')
        ex = expand([section],output_grim=str(after),body_grim=str(path))
        payload, rf = reopen(after)
        info=dict(field_error=rel(rf,2*field), saved_log_unit=json.loads(scalar(payload,'units')).get('rcs_log_unit'), warnings=ex['warnings'])
        try:
            plan = prepare_feature_assembly(FeatureAssemblyRequest(base_grim=after,output_grim=root/(name+'-assembly.grim'),allow_legacy_base_metadata=False))
            path = execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
            info['strict_assembly'] = dict(field_error=rel(reopen(path)[1],rf))
        except ValueError as exc:
            info['strict_assembly'] = dict(refused=str(exc))
        result[name]=info
    return result

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as d:
        print(json.dumps(run(Path(d)),indent=2))
