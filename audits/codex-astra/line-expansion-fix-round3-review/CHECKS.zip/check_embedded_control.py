"""Confirm the rotated, axis-edited BoR case with its matching STL and correct-attitude control."""
import json
import struct
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
from ghost_backend.assembly import fields, workflow
from ghost_backend.geometry.frames import CAD2AXIS
import check_edited_assembly as probe

def make_mesh(base, out):
    profile=fields.load_body_profile_grim(str(base))
    tris,_=workflow.bor_shadow_triangles(profile,max_sag_m=0.00001,normal_tolerance_deg=2.)
    tri=np.asarray(tris)@CAD2AXIS
    with out.open('wb') as f:
        f.write(bytes(80)); f.write(struct.pack('<I',len(tri)))
        for row in tri:
            cross=np.cross(row[1]-row[0],row[2]-row[0])
            normal=cross/np.linalg.norm(cross)
            f.write(struct.pack('<12fH',*normal,*row.flat,0))
    return out

def run(work,correct_plan):
    genuine_request=probe.FeatureAssemblyRequest
    genuine_grid=workflow.load_body_requested_radar_grid
    def with_mesh(**kwargs):
        base=Path(kwargs['base_grim'])
        if base.name=='bor-axis-edit.grim':
            kwargs.update(surface_mesh=make_mesh(base,work/'sphere.stl'), surface_units='meters')
        return genuine_request(**kwargs)
    def grid(path):
        result=genuine_grid(path)
        if result is None or Path(path).name!='bor-axis-edit.grim' or not correct_plan:
            return result
        with np.load(path,allow_pickle=False) as payload:
            rec=fields.recorded_line_expansion_attitude(payload)
        return {**result,**rec[0]}
    with patch.object(probe,'FeatureAssemblyRequest',with_mesh),patch.object(workflow,'load_body_requested_radar_grid',grid):
        row=probe.run(work)['bor_axis_edit']
    return {k:v for k,v in row.items() if k!='warnings'}

if __name__=='__main__':
    result={}
    for name,correct in [('matching_stl',False),('matching_stl_trusted_plan_trial',True)]:
        with tempfile.TemporaryDirectory() as temp:result[name]=run(Path(temp),correct)
    print(json.dumps(result,indent=2))
