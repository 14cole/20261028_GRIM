"""Counterfactual controls for three known frame-preserving operations in fixed fixtures.

Only the metadata on the disposable, transformed files is changed. The input
samples, Assembly entry points and numerical routines are the candidate's.
This is a causal audit control for these fixtures, not a GRIM converter.
"""
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import numpy as np
from GRIM_Backend.datasets.grid import RcsGrid
import check_cropped_assembly as cropped
import check_edited_assembly as edited
import check_resampled_assembly as sampled
import check_placed_feature as case

LINE = "line_expansion_provenance_json"
REQUEST = "requested_radar_grid_json"
crop = cropped.crop_dataset
interp = RcsGrid.interpolate_axis
edit = RcsGrid.edit_axis_value

def carry(sample, result):
    data = json.loads(str(np.asarray(sample.extra[LINE]).item()))
    assert data['body_attitude_deg'] == case.ATT
    data['radar_grid_deg'] = dict(azimuths=list(map(float,result.azimuths)),
                                  elevations=list(map(float,result.elevations)))
    result.extra[LINE] = json.dumps(data)
    return result

def keep_crop(sample,*args,**kwargs):
    return carry(sample,crop(sample,*args,**kwargs))

def keep_resampled(sample,*args,**kwargs):
    return carry(sample,interp(sample,*args,**kwargs))

def keep_bor_request(sample,*args,**kwargs):
    result = edit(sample,*args,**kwargs)
    assert args == ('azimuth',0,360.) and sample.azimuths[0] == 0.
    if REQUEST in sample.extra:
        data=json.loads(str(np.asarray(sample.extra[REQUEST]).item()))
        data['azimuths_deg']=list(map(float,result.azimuths))
        result.extra[REQUEST]=json.dumps(data)
    return result

def run():
    report = {}
    with tempfile.TemporaryDirectory() as temp, patch.object(cropped,'crop_dataset', keep_crop):
        row=cropped.run(Path(temp))['crop']
        report['crop']={'feature_error':row['added_error'],'sum_error':row['total_error']}
    with tempfile.TemporaryDirectory() as temp, patch.object(RcsGrid,'edit_axis_value', keep_bor_request):
        row=edited.run(Path(temp))['bor_axis_edit']
        report['edited_bor']={'feature_error':row['added_error'],'sum_error':row['total_error']}
    with tempfile.TemporaryDirectory() as temp, patch.object(RcsGrid,'interpolate_axis',keep_resampled):
        for key,row in sampled.run(Path(temp)).items():
            report[key]={'feature_error':row['added_field_error']}
    assert all(row['feature_error'] < 3e-14 for row in report.values()), report
    return report

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
