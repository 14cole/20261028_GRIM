"""Run actual Line Expansion exports; observe callback cancellation and failed rename cleanup."""
import inspect
import json
import os
from pathlib import Path
import stat
import tempfile
import threading
from unittest.mock import patch

import numpy as np
from ghost_backend.assembly import expand_wing_sections as wing
from ghost_backend.io import grim


SQUARE = ('Title: square\nSegment: shape 2\nproperties: 2 -24 0 0 0\n'
          '-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')
BEFORE = b'previous complete file'


class StopController(threading.Event):
    """Explicit event for shutdown, with a second independent user-cancel source."""
    def __init__(self):
        super().__init__()
        self.user_cancel = threading.Event()
        self.user_cancel.set()
        self.callback_polls = 0

    def is_user_canceled(self):
        self.callback_polls += 1
        return self.user_cancel.is_set()


def run(case):
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        section = root/'section.geo'
        section.write_text(SQUARE)
        target = root/'result.grim'
        target.write_bytes(BEFORE)
        target.chmod(0o664)
        req = dict(sections=[dict(geometry=str(section),root=(0,0,0),tip=(.25,0,0),normal=(0,0,1))],
                   output_grim=str(target),coordinate_units='meters',geometry_units='meters',
                   frequencies_ghz=[1.],azimuths_deg=[30.],elevations_deg=[0.],
                   section_angle_step_deg=5.,shadow=False)
        stop = StopController()
        gate_type = getattr(wing,'PublicationGate',None)
        gate = gate_type() if gate_type is not None else None
        signals = []
        request_polls = []
        if case in ('bound_sibling_callback', 'wrapped_sibling_callback'):
            req['section_solver_kwargs'] = {'abort_event':stop}
            req['cancel_check'] = stop.is_user_canceled if case.startswith('bound') else lambda: stop.is_user_canceled()
        if case in ('consume_once_with_gate','consume_once_without_gate','latched_with_gate'):
            def poll():
                answer = bool(signals)
                if answer:
                    request_polls.append(True)
                    if not case.startswith('latched'):
                        signals.pop()
                return answer
            req['cancel_check'] = poll
        if case.endswith('with_gate') and gate is not None:
            req['publication_gate'] = gate
        base_save = grim._save_grim_npz
        base_replace = os.replace
        def save(payload,*args,**kwargs):
            result = base_save(payload,*args,**kwargs)
            if 'line_expansion_provenance_json' in payload:
                signals.append(True)
            return result
        def replace(src,dst,*args,**kwargs):
            if Path(dst)==target and case=='rename_failure':
                raise OSError('simulated destination failure')
            return base_replace(src,dst,*args,**kwargs)
        with patch.object(grim,'_save_grim_npz',save),patch.object(os,'replace',replace):
            try:
                wing.expand_wing_sections(**req)
            except Exception as exc:
                outcome = type(exc).__name__
            else:
                outcome = 'saved'
        prior = target.read_bytes() == BEFORE
        result = dict(outcome=outcome,prior_preserved=prior,
                      stage_files_after=sorted(p.name for p in root.iterdir() if p.name.startswith('.')),
                      callback_polls=stop.callback_polls,post_stage_positive_polls=len(request_polls),
                      file_mode=oct(stat.S_IMODE(target.stat().st_mode)))
        if gate is not None and 'publication_gate' in req:
            result['publication_closed'] = gate.closed
        if not prior:
            with np.load(target, allow_pickle=False) as ds: result['published_azimuths']=ds['azimuths'].tolist()
        return result


if __name__=='__main__':
    print(json.dumps({k:run(k) for k in ('bound_sibling_callback','wrapped_sibling_callback',
        'consume_once_with_gate','consume_once_without_gate','latched_with_gate','rename_failure','normal')},indent=2))
