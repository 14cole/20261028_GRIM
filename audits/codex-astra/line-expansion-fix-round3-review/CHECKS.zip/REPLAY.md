# Replaying the round-three audit

Extract this archive into a scratch directory and run the commands there. Use a Linux GHOST/GRIM numerical environment with PySide6 and pytest. The review used Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and PySide6 6.12.0 on x86-64. Our comparisons read the results back from disk. They cover small analytical cases, with one BLAS thread, and do not measure production-scale performance or Windows behavior.

Set CANDIDATE to a complete checkout of d1b96fd. Keep the pinned Claude fixture directory at its normal depth inside the checkout. In a comparison against older code, only GRIM_ROOT and its runtime search paths should change.

```bash
sha256sum -c SHA256SUMS
export CANDIDATE=/path/to/d1b96fd
export TESTS="$CANDIDATE/audits/claude-2026-11-26/astra-audit-response/line-expansion"
select_runtime() {
    export GRIM_ROOT="$1"
    export PYTHONPATH="$GRIM_ROOT:$GRIM_ROOT/tools/GHOST:$TESTS"
}
select_runtime "$CANDIDATE"
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
mkdir -p replay
python -m pytest -q "$TESTS/test_line_expansion_regressions.py"
python "$TESTS/independent_checks.py" replay/independent.json
python "$TESTS/gui_checks.py" replay/gui.json
python "$TESTS/grim_app_check.py" replay/grim.json
python "$TESTS/bor_base_check.py" replay/bor.json

python check_assembly_panel.py > replay/panel.json
python check_placed_feature.py > replay/placed.json
python check_placed_feature.py --one-sided > replay/placed-one.json
python check_grid_operations.py > replay/grid-operations.json
python check_cropped_assembly.py > replay/cropped-assembly.json
python check_resampled_assembly.py > replay/resampled.json
python check_edited_assembly.py > replay/edited.json
python check_invalidated_subset.py > replay/invalidated-subset.json
python check_study_subset.py > replay/study-subset.json
python check_transfer_controls.py > replay/transfer.json
python check_embedded_control.py > replay/embedded-control.json
python trial_transform_metadata.py > replay/trial-transform.json

python check_attitude_roundtrip.py > replay/metadata.json
python check_cancel_edges.py > replay/edge.json
python cancel_sources.py > replay/sources.json
python cancel_publication.py --output replay/stages.json
python publication_overlap.py --require-isolation > replay/overlap.json
python grid_admission.py > replay/grid.json
python check_optional_log_unit.py > replay/optional-log-unit.json
```

For the cross-version check, supply the checkout path for each version. The write steps run the actual older producers, and the read steps open their files with the candidate. The final two steps use a genuine round-two file with an assumed attitude.

```bash
select_runtime /path/to/ed90b65
python check_older_outputs.py write replay/cross released
select_runtime /path/to/d0a9b01
python check_older_outputs.py write replay/cross round1
select_runtime /path/to/9635f7c
python check_older_outputs.py write replay/cross round2
python check_assumed_upgrade.py replay/cross/released/section.grim replay/cross/round2/assumed.grim
select_runtime "$CANDIDATE"
python check_older_outputs.py read replay/cross released > replay/released.json
python check_older_outputs.py read replay/cross round1 > replay/round1.json
python check_older_outputs.py read replay/cross round2 > replay/round2.json
python check_assumed_upgrade.py replay/cross/round2/assumed.grim replay/cross/round2/next.grim
```

Use independent angles first, then compare with the saved observations. For the placed-feature checks, subtract the exact loaded base before comparing the added field with the independent reference. Crop and regrid controls isolate errors in feature placement from interpolation or earlier approximations. The transfer, embedded and transform controls alter known metadata or a resolved attitude only in disposable fixtures/processes. They are diagnostic experiments and are not shipped fixes. Temporary paths, process IDs and timings can differ. Some probes catch an exception to preserve successful controls in the same JSON file, so inspect values as well as the exit status.
