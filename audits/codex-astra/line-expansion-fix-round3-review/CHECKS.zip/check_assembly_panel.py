"""Generate real inputs and inspect the user-facing Assembly panel's normal readiness decision."""
import json
import os
from pathlib import Path
import tempfile
from PySide6.QtWidgets import QApplication
from GRIM_Backend.assembly.model import preflight_base_grim
from GRIM_Backend.assembly.panel import FeatureAssemblyPanel
from ghost_backend.assembly import workflow
from check_placed_feature import ATT, GRID, sphere
from common import expand, write_section

def run(work):
    os.environ['GRIM_ASSEMBLY_DRAFT_DIR']=str(work/'drafts')
    app=QApplication.instance() or QApplication([])
    section=write_section(work)
    bor=sphere(work)
    mesh=work/'patch.stl'
    mesh.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    results={}
    for label, body, provide_stl in [('sections_only',None,False),('sections_with_stl',None,True),('with_bor',bor,False)]:
        saved=work/(label+'.grim')
        expand([section],output_grim=str(saved),**(dict(body_grim=str(body)) if body else GRID),**ATT)
        pre=preflight_base_grim(saved)
        panel=FeatureAssemblyPanel(service=workflow)
        panel.set_base_grim(str(saved))
        if provide_stl:
            panel.set_surface_mesh(str(mesh))
            panel.surface_units.setCurrentIndex(panel.surface_units.findData('meters'))
        panel.output_picker.set_path(str(work/(label+'-result.grim')))
        panel._update_workflow_readiness()
        app.processEvents()
        results[label]=dict(classified_valid=bool(pre.valid),geometry_summary=pre.summary,
            panel_body_help=panel.body_preview_help.text(),validate_enabled=panel.preview_button.isEnabled(),
            calculate_enabled=panel.build_button.isEnabled())
        panel.close()
        panel.deleteLater()
        app.processEvents()
    return results
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp: print(json.dumps(run(Path(tmp)),indent=2))
