"""Use identical code on round two and round three with a genuine output in between."""
import argparse
from pathlib import Path
import json
from common import expand, reopen, scalar, write_section

def append(base, dst):
    output=expand([write_section(dst.parent)], body_grim=str(base), output_grim=str(dst))
    payload,_=reopen(dst)
    record=json.loads(scalar(payload,"line_expansion_provenance_json"))
    return {"warnings":output['warnings'],"source":record.get("body_attitude_source"),"orientation":record['body_attitude_deg'],"keys":sorted(record),"contains_grid_request":"requested_radar_grid_json" in payload}

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument('source',type=Path)
    parser.add_argument('destination',type=Path)
    cmd=parser.parse_args()
    print(json.dumps(append(cmd.source.resolve(),cmd.destination.resolve()),indent=2))
