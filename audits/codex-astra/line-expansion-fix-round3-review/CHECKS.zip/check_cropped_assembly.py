"""Check that GRIM Crop and subsequent Assembly agree on the same physical samples.
Place the previous review's check_placed_feature.py on PYTHONPATH.
"""
import json
from pathlib import Path
import tempfile
from common import expand, reopen, write_section, rel
from GRIM_Backend.datasets.grid import RcsGrid
from GRIM_Backend.datasets.transforms import crop_dataset
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly
from check_placed_feature import GRID, ATT, create_point_pattern, point_reference

def run(work):
    section = write_section(work)
    src = work / 'expanded.grim'
    expand([section], output_grim=str(src), **GRID, **ATT)
    crop = work / 'cropped.grim'
    crop_dataset(RcsGrid.load(str(src)), azimuth_range=(40.,125.)).save(str(crop))
    pattern = create_point_pattern(work)
    mesh = work / 'patch.stl'
    mesh.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    csv = work / 'placements.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    expected=point_reference(ATT,True)
    report = {}
    fields = []
    for label,base,ref in [('intact',src,expected),('crop',crop,expected[1:3])]:
        bp, original = reopen(base)
        req = FeatureAssemblyRequest(base_grim=base,output_grim=work/(label+'-done.grim'),surface_mesh=mesh,
                                    surface_units='meters',coordinate_units='meters',
                                    point_locations_csv=csv,point_datasets={'pattern':pattern})
        plan = prepare_feature_assembly(req)
        out = execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
        _, result = reopen(out)
        fields.append(result-original)
        report[label]={'planned_angles':{k:float(plan.radar_grid[k]) for k in ATT},
                       'provenance_in_base':'line_expansion_provenance_json' in bp,
                       'added_error':rel(result-original,ref),'total_error':rel(result,original+ref),
                       'azimuths':list(map(float,bp['azimuths']))}
    report['common_added_samples_error'] = rel(fields[1],fields[0][1:3])
    return report
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
