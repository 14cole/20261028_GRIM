"""Process-local demonstration. Test whether transform-owned metadata decisions fix the measured cases."""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import numpy as np
from GRIM_Backend.datasets.grid import RcsGrid
from check_grid_operations import KEY, run as check_grid
from check_cropped_assembly import run as check_assembly

crop, wrap, edit = RcsGrid.axis_crop, RcsGrid.wrap_azimuth, RcsGrid.edit_axis_value

def keep_record(operation):
    def perform(grid, *args, **kwargs):
        result=operation(grid,*args,**kwargs)
        target = result[0] if isinstance(result,tuple) else result
        if KEY in grid.extra:
            target.extra[KEY]=grid.extra[KEY]
        return result
    return perform

def edited(grid,name,idx,value):
    result=edit(grid,name,idx,value)
    if result is grid or KEY not in grid.extra or name != 'azimuth':
        return result
    # This probe uses degrees and exactly represented labels. A shipped change
    # must use the file's units for comparisons and handle every supported axis.
    old=float(grid.azimuths[idx])
    if abs((float(value)-old+180.)%360.-180.)>1e-9:
        record=json.loads(str(np.asarray(grid.extra[KEY]).item()))
        record.pop('radar_grid_deg',None)
        result.extra[KEY]=json.dumps(record)
    return result

with ExitStack() as stack:
    stack.enter_context(patch.object(RcsGrid,'axis_crop',keep_record(crop)))
    stack.enter_context(patch.object(RcsGrid,'wrap_azimuth',keep_record(wrap)))
    stack.enter_context(patch.object(RcsGrid,'edit_axis_value',edited))
    with tempfile.TemporaryDirectory() as folder:
        grid=check_grid(Path(folder))
    with tempfile.TemporaryDirectory() as folder:
        assembly=check_assembly(Path(folder))
print(json.dumps(dict(grid=grid,assembly=assembly),indent=2))
