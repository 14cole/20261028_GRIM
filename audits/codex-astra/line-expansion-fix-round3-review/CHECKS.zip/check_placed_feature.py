"""Exercise Line Expansion -> Assembly with a known point response on real saved bases.

Set GRIM_ROOT to the repository and add Claude's line-expansion audit directory to PYTHONPATH.
The constant local Jones matrix is the identity times an amplitude P. Its translation
phase at each look is analytic. No Assembly orientation or field function is used for that reference.
"""
import argparse
import json
import tempfile
from pathlib import Path
import numpy as np
from common import expand, write_section, reopen, rel
from ghost_backend.assembly.fields import export_radar_grim, point_pattern_convention_metadata, radar_grid_aspects
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly, prepare_feature_input_preview
from ghost_backend.bor import dispatch
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.io.solver_export import export_solver_result
from ghost_backend.io.grim import _save_grim_npz

RADIUS = .15
P = .7 + .2j
ATT = dict(axis_az_deg=20., axis_el_deg=-10., roll_deg=15.)
ZERO = dict(axis_az_deg=0., axis_el_deg=0., roll_deg=0.)
GRID = dict(frequencies_ghz=[1.], azimuths_deg=[5.,45.,120.,210.], elevations_deg=[15.,35.])

def point_reference(att, one_sided=False):
    # Site is CAD +z: local meridian upper side before a positive roll about the long axis.
    yaw, pitch, roll = np.radians([att[k] for k in ('axis_az_deg','axis_el_deg','roll_deg')])
    up = np.array([-np.sin(pitch)*np.cos(yaw), -np.sin(pitch)*np.sin(yaw), np.cos(pitch)])
    cross = np.array([np.sin(yaw), -np.cos(yaw), 0.])
    site_earth = RADIUS*(up*np.cos(roll)+cross*np.sin(roll))
    az, el = np.meshgrid(np.radians(GRID['azimuths_deg']),np.radians(GRID['elevations_deg']),indexing='ij')
    look = np.stack([np.cos(el)*np.cos(az),np.cos(el)*np.sin(az),np.sin(el)],axis=-1)
    phase = np.exp(4j*np.pi*1e9*(look@site_earth)/299792458.)
    if one_sided:
        phase *= (look @ site_earth) > 0.0
    return (P*phase)[:,:,None,None] * np.array([1.,1.,0.])

def sphere(folder):
    t=np.linspace(0,np.pi,49)
    coords=np.stack([RADIUS*np.sin(t),RADIUS*np.cos(t)],axis=-1)
    coords[0,0]=coords[-1,0]=0.
    lines=['Title: sphere','Segment: sphere 2','properties: 2 1 0 0 0']
    lines += [' '.join(map(str,(*a,*b))) for a,b in zip(coords,coords[1:])]
    lines += ['IBCS_Resistances:','Dielectrics:']
    geom=parse_geometry('\n'.join(lines)+'\n')
    snap=build_geometry_snapshot(*geom) if isinstance(geom,tuple) else build_geometry_snapshot(geom)
    aspects=sorted(set(radar_grid_aspects(GRID['azimuths_deg'],GRID['elevations_deg'],ATT['axis_az_deg'],ATT['axis_el_deg']).ravel()))
    result=dispatch.solve_monostatic_rcs_bor(snap,[1.],aspects,geometry_units='meters',workers=1)
    return Path(export_solver_result(result,str(folder/'sphere.grim'),context=dict(solver_kind='bor',snapshot=snap,units='meters',radar_grid={**GRID,**ATT}))[0])

def create_point_pattern(folder):
    path=folder/'point.grim'
    export_radar_grim(str(path),bor_result=None,placements=[],azimuths_deg=[0.,90.,180.,270.],elevations_deg=[-90.,0.,90.],frequencies_ghz=[1.])
    payload, zeros = reopen(path)
    arr=np.broadcast_to(np.array([P,P,0.]),zeros.shape)
    payload.update(rcs_amp_real=arr.real,rcs_amp_imag=arr.imag,rcs_power=4*np.pi*np.abs(arr)**2,rcs_phase=np.angle(arr),**point_pattern_convention_metadata())
    for k in ('storage_kind','storage_domain','rcs_complex','grim_format_version','polarization_basis'):
        payload.pop(k,None)
    _save_grim_npz(payload,str(path))
    return path

def run(folder, one_sided=False):
    section=write_section(folder)
    csv=folder/'placements.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    mesh=folder/'patch.stl'
    mesh.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    pattern=create_point_pattern(folder)
    bor=sphere(folder)
    results={}
    for name, att, body in [('sections_zero',ZERO,None),('sections_rotated',ATT,None),('bor_rotated',ATT,bor)]:
        base=folder/(name+'-base.grim')
        expand([section],output_grim=str(base),**(dict(body_grim=str(body)) if body else GRID),**att)
        before, original=reopen(base)
        opts=dict(coordinate_units='meters',point_locations_csv=csv)
        if not body: opts.update(surface_mesh=mesh,surface_units='meters')
        try:
            preview=prepare_feature_input_preview(base_grim=base,**opts)
            out=folder/(name+'-result.grim')
            request=FeatureAssemblyRequest(base_grim=base,output_grim=out,point_datasets={'pattern':pattern},
                 point_response_settings={} if one_sided else {'pattern':{'one_sided':False}}, **opts)
            plan=prepare_feature_assembly(request)
            path=execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
            after,summed=reopen(path)
            actual=summed-original
            expected=point_reference(att,one_sided)
            results[name]=dict(source=preview.body_source,expected_attitude=att,plan_attitude={k:float(plan.radar_grid[k]) for k in ATT},
                samples=actual.size,raw_feature_peak=float(np.max(abs(actual))),relative_feature_error=rel(actual,expected),
                relative_sum_error=rel(summed,original+expected),relative_feature_error_vs_zero=rel(actual,point_reference(ZERO,one_sided)),
                result_requested_grid=json.loads(str(after['requested_radar_grid_json'])) if 'requested_radar_grid_json' in after else None)
        except Exception as exc:
            results[name]=dict(error=f'{type(exc).__name__}: {exc}')
    return results

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--one-sided',action='store_true',help='Use default Assembly point sidedness and the corresponding analytic reference.')
    args=parser.parse_args()
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp),args.one_sided),indent=2))
