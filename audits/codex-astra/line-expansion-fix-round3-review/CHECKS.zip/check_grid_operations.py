"""Check ordinary GRIM grid transforms across file boundaries and a subsequent expansion.
Use the round-three checkout and its line-expansion/common.py on PYTHONPATH.
"""
import json
from pathlib import Path
import tempfile
import numpy as np
from common import expand, reopen, write_section, rel
from GRIM_Backend.datasets.grid import RcsGrid
from GRIM_Backend.datasets.transforms import crop_dataset
from ghost_backend.assembly.fields import recorded_line_expansion_attitude
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly

ATT = dict(axis_az_deg=20., axis_el_deg=-10., roll_deg=15.)
AZ = [0., 60., 120., 180., 240., 300.]
EL = [10., 30.]
KEY = "line_expansion_provenance_json"

def by_axis_edit_shift(grid):
    # Descending order avoids duplicates. This is a 60-degree rotation of the labels.
    for idx in reversed(range(len(AZ))):
        grid = grid.edit_axis_value("azimuth", idx, AZ[idx] + 60.)
    return grid

def run(root):
    section = write_section(root)
    source = root / 'section.grim'
    expand([section], output_grim=str(source), frequencies_ghz=[1.0], azimuths_deg=AZ, elevations_deg=EL, **ATT)
    p, initial = reopen(source)
    out = {}
    load = lambda: RcsGrid.load(str(source))
    cropped = lambda: crop_dataset(load(), azimuth_range=(60.,180.))
    renamed = lambda: load().edit_axis_value('azimuth',0,360.)
    cases = [
        ('intact',load,ATT),
        ('single_seam_relabel',renamed,ATT),
        ('angular_crop',cropped,ATT),
        ('wrap_after_seam_relabel',lambda: renamed().wrap_azimuth('0_360'),ATT),
        ('axis_shift',lambda: load().shift_azimuth(60.),{**ATT,'axis_az_deg':ATT['axis_az_deg']+60}),
        ('axis_shift_via_axis_edit',lambda: by_axis_edit_shift(load()),{**ATT,'axis_az_deg':ATT['axis_az_deg']+60}),
        ('new_look_via_axis_edit',lambda: load().edit_axis_value("azimuth", 1, 65.),None)
    ]
    for name,make,known in cases:
        grid = make()
        filename = root / (name+'.grim')
        grid.save(str(filename))
        bp, base = reopen(filename)
        az = list(map(float,bp['azimuths']))
        el = list(map(float,bp['elevations']))
        declared = recorded_line_expansion_attitude(bp)
        item = {'axes':[az,el],'record_present':KEY in bp,'recorded':None if not declared else declared[0]}
        try:
            plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=filename,output_grim=root/('planned-'+name+'.grim')))
            item['assembly_plans']={k:float(plan.radar_grid[k]) for k in ATT}
        except Exception as exc: item['assembly_exception']=str(exc)
        if known is not None:
            ref_file=root/('reference-'+name+'.grim')
            expand([section],output_grim=str(ref_file),frequencies_ghz=[1.0],azimuths_deg=az,elevations_deg=el,**known)
            reference=reopen(ref_file)[1]
            item['base_error_vs_independent_section']=rel(base,reference)
        for mode, angles in [('implicit',{}),('explicit',known)]:
            if angles is None:continue
            dest=root/(mode+name+'.grim')
            try:
                result=expand([section],output_grim=str(dest),body_grim=str(filename),**angles)
                fp, field=reopen(dest)
                entry={'warnings':result['warnings'],'saved':json.loads(str(fp[KEY].item()))['body_attitude_deg']}
                if known is not None:
                    entry['sum_error']=rel(field,base+reference)
            except Exception as exc:
                entry={'error':str(exc)}
            item[mode] = entry
        out[name]=item
    return out
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
