"""Use the original rotated file with Assembly's public study-azimuth setting."""
import json
from pathlib import Path
import tempfile
from common import expand, write_section, reopen, rel
import check_placed_feature as case
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly

def run(directory):
    source = directory / 'source.grim'
    expand([write_section(directory)],output_grim=str(source),**case.GRID,**case.ATT)
    point = case.create_point_pattern(directory)
    csv = directory/'point.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    mesh = directory/'patch.stl'
    mesh.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    _, baseline = reopen(source)
    reference = case.point_reference(case.ATT, True)[1:3]
    request = FeatureAssemblyRequest(base_grim=source, output_grim=directory/'subset.grim',
        study_azimuths_deg=[45.,120.], surface_mesh=mesh,surface_units='meters',coordinate_units='meters',
        point_locations_csv=csv,point_datasets={'pattern':point})
    plan = prepare_feature_assembly(request)
    out = execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
    payload, result = reopen(out)
    return {'azimuths':payload['azimuths'].tolist(),'plan_attitude':{k:plan.radar_grid[k] for k in case.ATT},
            'added_field_error':rel(result-baseline[1:3],reference),'total_error':rel(result,baseline[1:3]+reference)}

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
