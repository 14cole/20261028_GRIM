"""Exercise rotated, already expanded GRIM outputs through Axis Edit and expansion again.
Use a GHOST/GRIM environment with GRIM_ROOT set, its root and tools/GHOST on PYTHONPATH and Claude's line-expansion fixture directory on PYTHONPATH.
"""
import json
import tempfile
from pathlib import Path

import numpy as np
from common import expand, reopen, rel, scalar, write_section
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.io.grim import _save_grim_npz

ATT = dict(axis_az_deg=20., axis_el_deg=-10., roll_deg=15.)
GRID = dict(azimuths_deg=[0.,45.,120.,210.], elevations_deg=[15.,35.],frequencies_ghz=[1.])
KEY = "line_expansion_provenance_json"

def run(root):
    section = write_section(root)
    def add(name, base=None, **att):
        output = root / (name+".grim")
        info = expand([section], output_grim=str(output), **(GRID if base is None else {"body_grim":str(base)}), **att)
        return output, *reopen(output), info["warnings"]
    source,p,field,_ = add("rotated", **ATT)
    edited = root/"edited.grim"
    RcsGrid.load(str(source)).edit_axis_value("azimuth",0,360.).save(str(edited))
    ep,ef = reopen(edited)
    eprov = json.loads(scalar(ep,KEY) or "{}")
    ref = (2*field)[[1,2,3,0]]
    out=dict(edited_field_error=rel(ef,field[[1,2,3,0]]), retains_request="requested_radar_grid_json" in ep,
             retained_provenance_attitude=eprov.get("body_attitude_deg"),retained_provenance_sources=eprov.get("body_attitude_source"))
    for name,base,att,expected in [("intact",source,{},2*field),("edit_then_implicit",edited,{},ref),
                                   ("edit_then_explicit",edited,ATT,ref),("edit_then_wrong",edited,dict(axis_az_deg=100.,axis_el_deg=20.,roll_deg=-30.),ref)]:
        try:
            _,payload,f,w=add(name,base,**att)
            pr=json.loads(scalar(payload,KEY) or "{}")
            out[name] = dict(error=rel(f,expected), warnings=w, saved=pr.get("body_attitude_deg"), sources=pr.get("body_attitude_source"))
        except ValueError as exc:
            out[name]=dict(refused=str(exc))
    # A GRIM v1 legacy power/phase writer represents absent phase and amplitude tags as empty strings.
    legacy={k:v for k,v in p.items() if k not in ("complex_field_domain","rcs_amp_real","rcs_amp_imag","raw_complex_amplitude_preserved",
                                                    "phase_reference","amplitude_convention","time_convention","polarization_basis")}
    legacy.update(rcs_power=4*np.pi*abs(field)**2,rcs_phase=np.angle(field),
                  metadata_advisories_json=np.asarray(json.dumps(["prior calibration advisory"])))
    orig=root/'legacy.grim'
    _save_grim_npz(legacy,str(orig),format_version=1)
    _,restored,rf,wr=add("legacy_once",orig)
    _,again,af,wr2=add("legacy_twice",root/'legacy_once.grim')
    out["legacy_blank_fields"]=dict(error=rel(rf,2*field),next_error=rel(af,3*field), phase_reference=scalar(restored,"phase_reference"),
                                   amplitude_convention=scalar(restored,"amplitude_convention"),domain=scalar(restored,"complex_field_domain"),
                                   advisories=scalar(restored,"metadata_advisories_json"),next_advisories=scalar(again,"metadata_advisories_json"))
    from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly
    for tag,base in [("strict_assembly_known",source),("strict_assembly_restored",root/"legacy_once.grim")]:
        try:
            plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=base, output_grim=root/(tag+".grim"), allow_legacy_base_metadata=False))
            published=execute_feature_assembly(plan, acknowledged_plan_sha256=plan.prepared_plan_sha256)
            out[tag]=dict(success=True,error=rel(reopen(published)[1],reopen(base)[1]))
        except (TypeError,ValueError,RuntimeError) as err:
            out[tag]=dict(success=False,detail=str(err))
    return out

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as directory:
        print(json.dumps(run(Path(directory)),indent=2))
