"""Assemble one known point on a section after a GRIM angular regrid in the same frame.

Use the current GHOST/GRIM checkout, its pinned common.py and the round-two
check_placed_feature.py helper. Reopen and subtract the actual resampled base
so interpolation error in the base does not enter the feature comparison.
"""
import json
from pathlib import Path
import tempfile
import numpy as np

from common import expand, write_section, reopen, rel
import check_placed_feature as case
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.assembly import fields, workflow

def run(work):
    csv = work/'point.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    mesh = work/'plane.stl'
    mesh.write_text('solid plane\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid plane\n')
    pattern = case.create_point_pattern(work)
    source = work/'source.grim'
    az = [20., 21., 22., 23.]
    el = [16., 26.]
    case.GRID.update(azimuths_deg=az,elevations_deg=el)
    expand([write_section(work)],output_grim=str(source),**case.GRID,**case.ATT)
    results = {}
    for label, grid in [('native',az), ('exact_subset',[21.,22.]), ('interpolated',[20.5,21.5,22.5])]:
        base = source
        if label != 'native':
            base = work/(label+'.grim')
            RcsGrid.load(str(source)).interpolate_axis('azimuth',grid).save(str(base))
        payload, input_field = reopen(base)
        request = workflow.FeatureAssemblyRequest(base_grim=base, output_grim=work/(label+'-out.grim'),
            coordinate_units='meters',point_locations_csv=csv,point_datasets={'pattern':pattern},
            surface_mesh=mesh,surface_units='meters',point_response_settings={'pattern':{'one_sided':False}})
        case.GRID['azimuths_deg'] = grid
        row = {"stored_provenance":"line_expansion_provenance_json" in payload,
               "trusted_attitude": fields.recorded_line_expansion_attitude(payload)}
        try:
            plan = workflow.prepare_feature_assembly(request)
            dest = workflow.execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
            result, total = reopen(dest)
            actual = total-input_field
            row.update(planned={k:float(plan.radar_grid[k]) for k in case.ATT},
                       warnings=list(plan.validation_warnings),samples=int(actual.size),
                       added_field_error=rel(actual, case.point_reference(case.ATT)),
                       error_vs_zero=rel(actual, case.point_reference(case.ZERO)))
        except Exception as exc:
            row['refusal']=str(exc)
        results[label]=row
    return results

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
