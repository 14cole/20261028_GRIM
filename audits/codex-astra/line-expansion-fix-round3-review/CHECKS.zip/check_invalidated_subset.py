"""Test Assembly after a changed look is discarded from the requested study subset."""
import json
import tempfile
from pathlib import Path
import numpy as np

import check_placed_feature as case
from common import write_section, expand, reopen, rel
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.assembly import fields
from ghost_backend.assembly.workflow import FeatureAssemblyRequest,prepare_feature_assembly,execute_feature_assembly

def run(work):
    case.GRID.update(azimuths_deg=[0.,45.,120.,210.])
    section=write_section(work)
    base=work/'sections.grim'
    expand([section],output_grim=str(base),**case.GRID,**case.ATT)
    edited=work/'edit.grim'
    RcsGrid.load(str(base)).edit_axis_value('azimuth',1,50.).save(str(edited))
    pattern=case.create_point_pattern(work)
    csv=work/'point.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n')
    mesh=work/'patch.stl'
    mesh.write_text('solid patch\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid patch\n')
    indices=[0,2,3]
    kwargs=dict(study_azimuths_deg=(0.,120.,210.),coordinate_units='meters',surface_mesh=mesh,surface_units='meters',
                point_locations_csv=csv,point_datasets={'pattern':pattern},point_response_settings={'pattern':{'one_sided':False}})
    expected=case.point_reference(case.ATT)[indices]
    zero=case.point_reference(case.ZERO)[indices]
    _,original=reopen(base)
    out={}
    for label,src in [('intact',base),('edited_unused_look',edited)]:
        p,b=reopen(src)
        result=work/(label+'.grim')
        plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=src,output_grim=result,**kwargs))
        dest=execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
        after,total=reopen(dest)
        out[label]=dict(plan_angles={k:plan.radar_grid[k] for k in case.ATT},output_axes=after['azimuths'].tolist(),input_unchanged_error=rel(b[indices],original[indices]),
                        added_error=rel(total-b[indices],expected),total_error=rel(total,b[indices]+expected),
                        added_error_vs_zero=rel(total-b[indices],zero), output_recognized_record=fields.recorded_line_expansion_attitude(after),
                        warnings=list(plan.validation_warnings))
    return out

if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:print(json.dumps(run(Path(tmp)),indent=2))
