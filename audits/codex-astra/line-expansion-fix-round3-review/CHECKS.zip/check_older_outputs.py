"""Make unchanged exports on each old revision; consume them later on the proposed revision.

With GRIM_ROOT + its tools/GHOST + candidate's committed audit fixture directory
+ the prior audit archive (containing check_placed_feature.py) on PYTHONPATH:
python check_older_outputs.py write <scratch directory> <producer label>
python check_older_outputs.py read <same scratch directory> <producer label>
Use a different scratch root for unrelated runs.
"""
import argparse
import json
from pathlib import Path

from common import expand, write_section, reopen, rel, scalar
from GRIM_Backend.assembly.model import preflight_base_grim
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.assembly.workflow import (
    FeatureAssemblyRequest, execute_feature_assembly, prepare_feature_assembly,
)
import check_placed_feature as geometry

ATT = dict(axis_az_deg=20., axis_el_deg=-10., roll_deg=15.)
GRID = dict(frequencies_ghz=[1.], azimuths_deg=[0.,45.,120.,210.], elevations_deg=[15.,35.])

def describe(path):
    payload,_=reopen(path)
    prov=json.loads(scalar(payload,'line_expansion_provenance_json') or '{}')
    return dict(grid_request='requested_radar_grid_json' in payload,
                line_record_keys=sorted(prov),recorded=prov.get('body_attitude_deg'),
                preflight_valid=preflight_base_grim(path).valid)

def write(root,tag):
    folder=root/tag
    folder.mkdir(parents=True,exist_ok=True)
    s=write_section(folder)
    geometry.GRID=GRID
    b=geometry.sphere(folder)
    for name,source in [('section',None),('with-body',b)]:
        dest=folder/(name+'.grim')
        request=GRID if source is None else dict(body_grim=str(source))
        expand([s],output_grim=str(dest),**request,**ATT)
        edited=RcsGrid.load(str(dest)).edit_axis_value('azimuth',0,360.)
        edited.save(str(folder/(name+'-edit.grim')))

def read(root,tag):
    folder=root/tag
    dst=root/('read-'+tag)
    dst.mkdir(exist_ok=True)
    s=write_section(dst)
    single=reopen(folder/'section.grim')[1]
    out={}
    for name in ('section','with-body','section-edit','with-body-edit'):
        src=folder/(name+'.grim');orig=reopen(src)[1]
        ref=single[[1,2,3,0]] if name.endswith('-edit') else single
        item=out[name]=describe(src)
        try:
            plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=src,output_grim=dst/(name+'-assembly.grim')))
            f=execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
            item['assembly']=dict(plan={k:float(plan.radar_grid[k]) for k in ATT},error=rel(reopen(f)[1],orig))
        except (ValueError,RuntimeError,KeyError) as exc:
            item['assembly']=dict(refused=str(exc))
        for mode,angles in [('implicit',{}),('stated',ATT),('wrong',dict(axis_az_deg=0.,axis_el_deg=0.,roll_deg=0.))]:
            target=dst/(name+'-'+mode+'.grim')
            try:
                a=expand([s],output_grim=str(target),body_grim=str(src),**angles)
                item[mode]=dict(error=rel(reopen(target)[1],orig+ref),warnings=a['warnings'],
                                output=describe(target) if mode=='stated' else None)
            except (ValueError,RuntimeError,KeyError) as exc:
                item[mode]=dict(refused=str(exc))
    return out

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=['write','read'])
    parser.add_argument('directory',type=Path)
    parser.add_argument('producer')
    cli=parser.parse_args()
    if cli.operation=='write':
        write(cli.directory.resolve(),cli.producer)
    else:
        print(json.dumps(read(cli.directory.resolve(),cli.producer),indent=2))
