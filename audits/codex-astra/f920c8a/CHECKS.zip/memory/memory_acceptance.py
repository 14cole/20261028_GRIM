"""Check scheduler capacity and solver headroom against synthetic cgroup v2 layouts.

PYTHONPATH=/path/to/checkout/tools/GHOST python memory_acceptance.py
No cgroups or large allocations are created. The program prints measurements.
"""
import io
import json
import os
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from ghost_backend.hpc import scheduler
from ghost_backend.execution.memory_budget import MemoryBudget
from ghost_backend.twod import solver

G = 2**30
M = 2**20
CG = "/sys/fs/cgroup"


def observe(counters, mounts=(("/", CG),), member="/", host_total=32, host_free=24):
    files = {"/proc/self/cgroup": f"0::{member}\n", "/proc/meminfo": f"MemTotal: {host_total * 2**20} kB\n",
             "/proc/self/mountinfo": "".join(
                 f"{10+i} 8 0:33 {root} {mount} ro - cgroup2 cgroup2 ro\n" for i, (root,mount) in enumerate(mounts))}
    for path, (limit,usage) in counters.items():
        files[path + "/memory.max"] = str(limit)
        if usage is not None:
            files[path + "/memory.current"] = str(usage)
    def read(path, *args, **kwargs):
        try:
            return files[os.fspath(path)]
        except KeyError as err:
            raise FileNotFoundError(path) from err
    def source_open(path, *args, **kwargs):
        return io.StringIO(read(path))
    with ExitStack() as stack:
        stack.enter_context(patch.dict(os.environ, {}, clear=True))
        stack.enter_context(patch.object(Path, "read_text", read))
        stack.enter_context(patch.object(solver, "open", source_open, create=True))
        stack.enter_context(patch.object(solver, "_psutil_available_bytes", return_value=host_free * G))
        stack.enter_context(patch.object(solver, "_slurm_available_bytes", return_value=None))
        stack.enter_context(patch.object(solver, "_process_rss_bytes", return_value=G//4))
        return dict(scheduler_capacity_GiB=scheduler.detect_memory_gb(), solver_available_GiB=solver._detect_available_gb(),
                    ledger_budget_GiB=MemoryBudget().limit())


def main():
    rows = []
    for limit in (511,512,513,768):
        rows.append(dict(fixture=f"root cap {limit} MiB; 256 MiB used",
                         true_total_GiB=limit/1024, true_available_GiB=(limit-256)/1024,
                         **observe({CG: (limit*M,256*M)})))
    roots=(("/", "/mnt/own"),("/team/other", CG))
    own="/mnt/own/team/mine"
    counters={"/mnt/own": ("max",6*G),own:(6*G,2*G),CG:(G,7*G//8)}
    rows.append(dict(fixture="unrelated bind at conventional path",true_total_GiB=6, true_available_GiB=4,
                     **observe(counters,roots,"/team/mine")))
    counters={CG:("max",8*G),CG+"/team/mine":(6*G,None)}
    for used in (1,3):
        rows.append(dict(fixture=f"same observable files; hypothetical group usage {used} GiB, unreadable",
                         true_total_GiB=6,true_available_GiB=6-used,
                         **observe(counters,member="/team/mine")))
    print(json.dumps(rows,indent=2))

if __name__=="__main__":
    main()
