"""Check Claude's two-validator proposal with real disk round trips and real section solves.

GRIM_ROOT=<ed90b65> PYTHONPATH=<abe8bd0_line-expansion-audit-directory> python validate_boundary.py
"""
import json
import tempfile
from pathlib import Path

import numpy as np
from common import expand, write_section, reopen, rel
from ghost_backend.assembly import expand_wing_sections as wing
from ghost_backend.assembly import fields
from ghost_backend.io.grim import _save_grim_npz

axes = dict(frequencies_ghz=[1.0], azimuths_deg=[5., 45.], elevations_deg=[20.])
attitude = dict(axis_az_deg=35., axis_el_deg=7., roll_deg=-11.)


def inspect(directory):
    root = Path(directory)
    section = write_section(root)
    raw = root / 'reference.grim'
    expand([section], output_grim=str(raw), **axes, **attitude)
    original, ref = reopen(raw)
    outcomes = {}
    for case in ('valid_attitude', 'tag_and_primary_phase', 'primary_phase_only', 'different_amplitude_only'):
        payload = original.copy()
        expected = 2 * ref
        if case in ('primary_phase_only', 'tag_and_primary_phase'):
            expr = str(original['phase_reference']).replace('exp(+jwt)', 'exp(-jwt)')
            assert 'exp(-jwt)' in expr
            payload['phase_reference'] = np.array(expr)
            payload.pop('time_convention', None)
            if case == 'tag_and_primary_phase':
                payload['time_convention'] = np.array('exp(-jwt)')
            amp = ref.conj()
            payload.update(rcs_amp_real=amp.real, rcs_amp_imag=amp.imag,
                           rcs_phase=np.angle(amp), rcs_power=4*np.pi*abs(amp)**2)
            expected = 2 * amp
        elif case == 'different_amplitude_only':
            payload['amplitude_convention'] = np.array('sqrt(sigma_3d)')
        path = root / (case+'.grim')
        _save_grim_npz(payload, str(path))
        disk, decoded, _ = wing._load_base(str(path))
        def run(fn):
            try: fn()
            except ValueError as exc: return str(exc)
            return 'accepted'
        grid = dict(**axes, **attitude)
        statuses = dict(grid=run(lambda: fields.validate_assembly_base_grid_metadata(disk,grid,case)),
                        optional_field_tags=run(lambda: fields._validate_optional_field_tags(disk,case)),
                        declared_coherent_base=run(lambda: fields._validate_declared_coherent_base(dict(disk,_amp=decoded),case)))
        if case != 'different_amplitude_only' and all(statuses[k]=='accepted' for k in ('grid','optional_field_tags')):
            res = expand([section], output_grim=str(root/(case+'-added.grim')), body_grim=str(path), **attitude)
            _, out = reopen(res['output'])
            statuses.update(error_relative_to_expected_peak=rel(out, expected), output_warnings=res['warnings'])
        statuses.update(stored_phase=str(disk.get('phase_reference')), stored_optional_time_tag=str(disk.get('time_convention')))
        outcomes[case] = statuses
    return outcomes


if __name__ == '__main__':
    with tempfile.TemporaryDirectory() as directory:
        print(json.dumps(inspect(directory), indent=2))
