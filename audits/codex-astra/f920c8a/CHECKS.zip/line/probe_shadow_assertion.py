"""Check whether Claude's shadowing integration test distinguishes shadowing off.

Requires the exact f920c8a Line Expansion tests on PYTHONPATH and a GRIM_ROOT.
Temporarily ignores the one public shadow request in the test harness only.
"""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import test_line_expansion_regressions as tests


class TemporaryPaths:
    def __init__(self, directory):
        self.directory = Path(directory)

    def mktemp(self, name):
        result = self.directory / name
        result.mkdir()
        return result


with tempfile.TemporaryDirectory() as directory:
    fixture = tests.ctx.__wrapped__(TemporaryPaths(directory))
    real_expand = tests.expand
    def ignore_shadow(sections, **kwargs):
        assert kwargs.get("shadow") is True
        return real_expand(sections, **dict(kwargs, shadow=False))
    with patch.object(tests, "expand", ignore_shadow):
        tests.test_expansion_completes_with_default_shadowing_on_a_bor_profile_base(fixture)
    disabled = tests.reopen(fixture["work"] / "shadowed.grim")[1]
    tests.test_expansion_completes_with_default_shadowing_on_a_bor_profile_base(fixture)
    enabled = tests.reopen(fixture["work"] / "shadowed.grim")[1]
    print(json.dumps({
        "unchanged_test_passed_with_shadow_request_ignored": True,
        "unchanged_test_passed_with_real_trial_shadowing": True,
        "max_difference_on_actual_fixture_normalized_to_reference": tests.rel(enabled, disabled),
    }, indent=2))
