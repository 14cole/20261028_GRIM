"""Check the large-grid preflight without building the angular product (Linux).
Run with a GHOST checkout on PYTHONPATH. --require-refusal is an acceptance test.
"""
import argparse
import json
import resource
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
from ghost_backend.assembly.expand_wing_sections import expand_wing_sections
from ghost_backend.ui.line_expansion import parse_samples


class WouldAllocateProduct(RuntimeError):
    pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-refusal', action='store_true')
    args = parser.parse_args()
    reached = []
    def stop(*axes, **kwargs):
        reached.append([len(axis) for axis in axes])
        raise WouldAllocateProduct()

    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        source = directory / 'square.geo'
        source.write_text('Title: square\nSegment: shape 2\nproperties: 2 -24 0 0 0\n'
                          '-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')
        request = dict(sections=[dict(geometry=str(source), root=(0,0,0), tip=(.25,0,0),
                                      normal=(0,0,1))], coordinate_units='meters', geometry_units='meters',
                       frequencies_ghz=[1.0], section_angle_step_deg=10., shadow=False)
        small = directory/'control.grim'
        expand_wing_sections(**request, output_grim=str(small), azimuths_deg=[30,60], elevations_deg=[0])
        assert small.is_file()
        # Bound this fresh process in case a future implementation allocates before meshgrid.
        vm_kib = int(next(s for s in Path('/proc/self/status').read_text().splitlines()
                          if s.startswith('VmSize:')).split()[1])
        soft, hard = resource.getrlimit(resource.RLIMIT_AS)
        limits = [vm_kib * 1024 + 256 * 2**20]
        limits.extend(x for x in (soft, hard) if x != resource.RLIM_INFINITY)
        resource.setrlimit(resource.RLIMIT_AS, (min(limits), hard))
        large = directory/'large.grim'
        az = parse_samples('0:359:0.01','Azimuth')
        el = parse_samples('-90:90:0.01','Elevation')
        with patch.object(np, 'meshgrid', stop):
            try:
                expand_wing_sections(**request, output_grim=str(large), azimuths_deg=az, elevations_deg=el)
            except WouldAllocateProduct:
                status = 'reached_meshgrid'
                detail = 'stopped by the audit before array construction'
            except (ValueError, MemoryError, OverflowError) as exc:
                status = 'refused'
                detail = str(exc)
            else:
                status = 'completed'
                detail = ''
        result = dict(control_produced_output=small.is_file(), axes=[len(az),len(el)],
                      looks=len(az)*len(el), status=status, detail=detail, meshgrid_calls=reached,
                      large_output_exists=large.exists())
        print(json.dumps(result,indent=2))
        if args.require_refusal:
            # A raw allocator failure must not be mistaken for deliberate preflight.
            assert status == 'refused' and not reached and not large.exists()
            assert any(word in detail.lower() for word in ('grid','look','sample')), detail


if __name__ == '__main__':
    main()
