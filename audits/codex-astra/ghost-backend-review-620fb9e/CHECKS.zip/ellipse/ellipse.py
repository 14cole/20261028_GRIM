"""Validate or run the Study C fixture stretched in its plane, on a signed half-circle.

Set GRIM_ROOT to production ed90b65 and PYTHONPATH to the Claude audit containing
harness.py. Use one fresh process per backend. Output files go in --out.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import resource

for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = os.environ.get("ELLIPSE_THREADS", "2")

import numpy as np
from harness import cylinder_geo, fields_of, solve_fixed
from threadpoolctl import threadpool_info

CENTER = np.array([0.031, -0.017])
SCALE = np.array([1.25, 0.8])
FREQUENCY_GHZ = 10.0
ANGLES = np.arange(-90, 90, dtype=float)


def geometry():
    circle = cylinder_geo(sides=2112, center=CENTER, a=0.10, b=0.12, eps=2.8-0.06j, mu=1)
    lines = []
    loops = {}
    current = None
    for line in circle.splitlines():
        if line.startswith("Segment: "):
            current = line.split()[1]
            loops[current] = []
        elif line == "IBCS_Resistances:":
            current = None
        if current and not line.startswith(("Segment:", "properties:")):
            ends = np.array(line.split(), dtype=float).reshape(2, 2)
            points = CENTER + (ends - CENTER) * SCALE
            loops[current].append((ends, points))
            line = " ".join(format(v, ".17g") for v in points.ravel())
        lines.append(line)
    counts = {}
    for (loop, segments), radius in zip(loops.items(), (0.12, 0.10), strict=True):
        arr = np.array(segments)
        before, after = arr[:, 0], arr[:, 1]
        assert np.array_equal(np.roll(after[:, 0], -1, axis=0), after[:, 1])
        for edges in (before, after):
            poly = edges[:, 0]
            area = 0.5 * abs(np.sum(poly[:, 0] * edges[:, 1, 1] - poly[:, 1] * edges[:, 1, 0]))
            expected = len(poly) * radius**2 * np.sin(2*np.pi / len(poly)) / 2
            np.testing.assert_allclose(area, expected, rtol=1e-12)
        np.testing.assert_allclose(np.ptp(after[:, 0], axis=0), 2 * radius * SCALE, rtol=1e-13)
        counts[loop] = len(segments)
    assert counts == {"coat_outer": 2112, "coat_inner": 1760}
    return "\n".join(lines) + "\n", counts


def run(which, out):
    text, counts = geometry()
    record = dict(geometry_sha256=hashlib.sha256(text.encode()).hexdigest(), geometry_panels=counts,
                  center_m=CENTER.tolist(), axis_scale=SCALE.tolist(), thread_request=2,
                  frequency_ghz=FREQUENCY_GHZ, permit_affinity=sorted(os.sched_getaffinity(0)),
                  python=platform.python_version(), kernel=platform.release(),
                  production="ed90b65", claude_harness="620fb9e", angle_min_deg=-90,
                  angle_max_deg=89, angle_step_deg=1, angle_count=len(ANGLES))
    if which == "check":
        print(json.dumps(record, indent=2))
        return
    assert all(os.environ[v] == "2" for v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"))
    result, elapsed = solve_fixed(text, FREQUENCY_GHZ, ANGLES, which, threads=2)
    peak_bytes = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    fields = fields_of(result)
    out.mkdir(exist_ok=True, parents=True)
    for label, pol in (("VV","TE"), ("HH","TM")):
        rows = result["co_solved_samples"][label]
        for name in ("theta_inc_deg", "theta_scat_deg"):
            np.testing.assert_array_equal([r[name] for r in rows], ANGLES)
        assert np.all(np.isfinite(fields[pol]))
    np.savez_compressed(out / f"{which}.npz", angles_deg=ANGLES, **fields)
    meta = result["metadata"]
    record.update(requested=which, linear_backend=meta["linear_backend"], panels=meta["panel_count"],
                  unknowns_per_system=meta.get("dense_largest_system") or meta["linear_node_count"],
                  nodes=meta["linear_node_count"], solver_method=meta["solver_method"],
                  polynomial_degree=meta["polynomial_degree"], quality_passed=meta["quality_gate"]["passed"],
                  max_residual=meta["residual_norm_max"], warnings=meta.get("warnings"),
                  solve_wall_s=elapsed, peak_rss_bytes=peak_bytes, peak_rss_gib=peak_bytes/2**30,
                  rhs_compression=meta["cpu_rhs_compression_requested"], angle_batch_size_request=256,
                  frequency_count=1, solve_type="one fixed mesh", threadpools=threadpool_info(),
                  cpu_model=next((line.split(":",1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")), None),
                  thread_environment={k: os.environ[k] for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS")})
    (out / f"{which}.json").write_text(json.dumps(record, indent=2, default=str)+"\n")
    print(json.dumps(record, default=str), flush=True)
    assert record["linear_backend"] == {"dense": "cpu", "compressed": "cpu_hmatrix"}[which]
    assert record["unknowns_per_system"] == 5984 and record["panels"] == 3872 and record["quality_passed"]


def compare(out):
    records = {}
    for which in ("dense", "compressed"):
        records[which] = json.loads((out / f"{which}.json").read_text())
    assert records["dense"]["geometry_sha256"] == records["compressed"]["geometry_sha256"]
    comparison = {}
    with np.load(out/"dense.npz") as dense, np.load(out/"compressed.npz") as comp:
        for backend in (dense, comp):
            np.testing.assert_array_equal(ANGLES, backend["angles_deg"])
        phi = np.deg2rad(ANGLES)
        k = 2 * np.pi * FREQUENCY_GHZ * 1e9 / 299792458.0
        undo_translation = np.exp(-2j * k * (CENTER[0] * np.cos(phi) + CENTER[1] * np.sin(phi)))
        for pol in ("TE", "TM"):
            amp = np.abs(dense[pol])
            delta = np.abs(comp[pol]-dense[pol])
            comparison[pol] = dict(max_abs=float(np.max(delta)), max_over_dense_peak=float(np.max(delta)/max(amp)),
                                   relative_l2=float(np.linalg.norm(delta)/np.linalg.norm(dense[pol])),
                                   worst_angle_deg=float(ANGLES[np.argmax(delta)]),
                                   min_dense_magnitude=float(min(amp)), max_dense_magnitude=float(max(amp)),
                                   min_angle_deg=float(ANGLES[np.argmin(amp)]), max_angle_deg=float(ANGLES[np.argmax(amp)]),
                                   amplitude_span_db=float(20*np.log10(max(amp)/min(amp))))
            for backend_name, backend in (("dense", dense), ("compressed", comp)):
                centered = backend[pol] * undo_translation
                negative = centered[(ANGLES < 0) & (ANGLES > -90)][::-1]
                positive = centered[ANGLES > 0]
                assert len(positive) == len(negative) == 89
                difference = np.abs(positive - negative)
                comparison[pol][f"{backend_name}_mirror_max_over_peak"] = float(max(difference)/max(abs(centered)))
                comparison[pol][f"{backend_name}_mirror_relative_l2"] = float(np.linalg.norm(difference)/np.linalg.norm(positive))
    path = out / "comparison.json"
    path.write_text(json.dumps(comparison, indent=2)+"\n")
    print(path.read_text())


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["check", "dense", "compressed", "compare"])
    parser.add_argument("--out", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    if args.action == "compare":
        compare(args.out)
    else:
        run(args.action, args.out)
