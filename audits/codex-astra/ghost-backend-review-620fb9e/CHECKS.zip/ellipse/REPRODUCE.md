# Coated ellipse at 10 GHz

Use GHOST production commit `ed90b65` and `harness.py` from Claude's audit at `620fb9e`. Set `GRIM_ROOT` to the production checkout and add the audit directory to `PYTHONPATH`. The environment needs GHOST's solver dependencies, NumPy and threadpoolctl. Run from this directory.

```bash
python ellipse.py check
taskset -c 1-4 python ellipse.py dense
taskset -c 1-4 python ellipse.py compressed
python ellipse.py compare
```

The two timed commands run serially in fresh Linux processes. Each requests two solver, assembly and BLAS threads. `solve_wall_s` includes geometry parsing and the full fixed-mesh solve for both polarizations. `peak_rss_gib` is the process high-water resident set on Linux in units of 2³⁰ bytes. Each backend has one timing sample.

Starting from Claude's 2,112-sided coated cylinder, scale every line endpoint by 1.25 along x and 0.8 along y about the original centre of (0.031, −0.017) m. The outer diameters are 0.300 × 0.192 m and the PEC core diameters are 0.250 × 0.160 m. The coating has relative permittivity 2.8 − 0.06j and relative permeability 1. There are 1,760 inner and 2,112 outer panels and 5,984 unknowns per polarization. The code checks preserved areas, connected loops, correct extents and unchanged panel counts.

Each NPZ stores 180 complex TE and TM amplitudes at one-degree intervals from −90° through +89°. The solver's incident and scattered angle outputs are checked against that grid. The JSON comparison uses Dense amplitude as the denominator for peak-normalized and relative L2 differences. The mirror check removes the centre translation factor exp(2jk c·u) and compares complex fields at each signed angle pair from 1° to 89°. The magnitude range and its dB span refer to the Dense field. This fixture has no independently computed analytic field reference.
