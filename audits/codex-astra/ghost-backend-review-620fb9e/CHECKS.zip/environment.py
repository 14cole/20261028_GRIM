"""Record local hardware, BLAS and cgroup details for the comparison."""
import contextlib
import io
import json
import os
import platform
from pathlib import Path

import numpy
import scipy
import scipy.linalg


def read(path):
    return Path(path).read_text().strip()


def build(module):
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        module.show_config()
    return output.getvalue()


print(json.dumps({
    "platform": platform.platform(), "python": platform.python_version(),
    "numpy": numpy.__version__, "scipy": scipy.__version__,
    "numpy_config": build(numpy), "scipy_config": build(scipy),
    "cpu": next(x.split(":")[-1].strip() for x in read("/proc/cpuinfo").splitlines() if x.startswith("model name")),
    "affinity": sorted(os.sched_getaffinity(0)), "cgroup_cpu_max": read("/sys/fs/cgroup/cpu.max"),
    "cgroup_memory_max_bytes": read("/sys/fs/cgroup/memory.max"),
    "swap": read("/proc/swaps"), "thread_env": {k:os.environ.get(k) for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS")},
    "timed_job_thread_override": "Per case from 1, 2 or 4 for assembly, BLAS and OMP."
}, indent=2))
