"""Audit Claude's saved timing experiments. Use Python, NumPy, SciPy and an archived results/ tree."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import statistics

import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp


def reference(angles, pol, count):
    """Annular radial solution that meets the PEC boundary by construction."""
    k = 2*np.pi*10e9/299792458.
    eps = 2.8 - 0.06j
    mu = 1.
    n = np.arange(count+1)
    m = np.sqrt(eps*mu)
    inside, outside = k*m*0.100, k*m*0.120
    jcore, ycore = (jv(n,inside), yv(n,inside)) if pol=='TM' else (jvp(n,inside), yvp(n,inside))
    shell = ycore*jv(n,outside) - jcore*yv(n,outside)
    deriv = (ycore*jvp(n,outside) - jcore*yvp(n,outside))*m/(eps if pol=='TE' else mu)
    x = k*0.120
    r = (jv(n,x)*deriv - jvp(n,x)*shell) / (h2vp(n,x)*shell-hankel2(n,x)*deriv)
    amp = -4j*np.sum(r*(-1)**n*np.where(n==0,1,2))
    theta = np.deg2rad(angles)
    return amp*np.exp(2j*k*(.031*np.cos(theta)-.017*np.sin(theta)))


def compare(left, right):
    return dict(peak_normalized=float(np.max(abs(left-right))/np.max(abs(right))),
                relative_l2=float(np.linalg.norm(left-right)/np.linalg.norm(right)))


def group_stats(data):
    return dict(median=statistics.median(data),minimum=min(data),maximum=max(data))


def run(root):
    records=[]
    repeated_tags=defaultdict(list)
    for batch in sorted(root.glob('c*/runs.jsonl')):
        for line in batch.read_text().splitlines():
            row=json.loads(line)
            assert row['returncode']==0
            filename=batch.parent/(row['tag']+'.npz')
            repeated_tags[row['tag']].append(str(filename.relative_to(root)))
            records.append((row,filename))
    for name in ('dense','compressed'):
        row=json.loads((root/'c_large'/f'{name}.out').read_text())
        filename=root/'c_large'/f"s{row['outer_sides']}_a{row['angles']}_t{row['threads']}_{name}.npz"
        records.append((row,filename))
    input_files={x for _,x in records}
    assert len(input_files)==len(records) and input_files==set(root.glob('c*/*.npz'))
    groups=defaultdict(list)
    for row,path in records:
        assert row['quality_passed'] and np.isfinite(row['residual_max'])
        with np.load(path,allow_pickle=False) as z:
            arrays={k:z[k] for k in z.files}
        theta=arrays['angles_deg']
        assert np.array_equal(theta,np.arange(row['angles'])*(360/row['angles']))
        for pol in ('TM','TE'):
            assert arrays['ghost_'+pol].shape==theta.shape and np.isfinite(arrays['ghost_'+pol]).all()
        key=(row['unknowns_per_system'],row['threads'],row['angles'],row['requested'])
        groups[key].append((row,arrays,path))
    out=dict(total_record_count=len(records),quality_pass_count=sum(bool(r['quality_passed']) for r,p in records),
             duplicate_tag_groups={t:files for t,files in repeated_tags.items() if len(files)>1},
             groups=[],backend_pairs=[],grid_overlap=[],threads=[],max_ref_archive_delta=0.,max_ref_tail=0.,max_logged_error_delta=0.)
    for (n,t,a,m),trials in sorted(groups.items()):
        first=trials[0][1]
        repmax=0.
        local=0.
        for r,arrays,p in trials:
            for pol in ('TM','TE'):
                numeric=arrays['ghost_'+pol]
                archived=arrays['analytic_'+pol]
                exact=reference(arrays['angles_deg'],pol,80)
                longer=reference(arrays['angles_deg'],pol,90)
                repmax=max(repmax,compare(numeric,first['ghost_'+pol])['peak_normalized'])
                out['max_ref_archive_delta']=max(out['max_ref_archive_delta'], compare(exact,archived)['peak_normalized'])
                out['max_ref_tail']=max(out['max_ref_tail'],compare(exact,longer)['peak_normalized'])
                err=compare(numeric,exact)['peak_normalized']
                out['max_logged_error_delta']=max(out['max_logged_error_delta'],abs(err-r['error_'+pol]))
                local=max(local,err)
        out['groups'].append(dict(unknowns=n,threads=t,angles=a,method=m,repeats=len(trials),panels=trials[0][0]['panels'],
                                  solver_seconds=group_stats([r['solve_wall_s'] for r,z,p in trials]),
                                  peak_RSS_GiB=group_stats([r['peak_rss_gib'] for r,z,p in trials]),
                                  max_between_repeats=repmax, peak_field_error=local))
        if m=='dense':
            other=groups[n,t,a,'compressed'][0][1]
            out['backend_pairs'].append(dict(unknowns=n,threads=t,angles=a,channels={p:compare(other['ghost_'+p],first['ghost_'+p]) for p in ('TM','TE')}))
        if a==180 and (n,t,360,m) in groups:
            other=groups[n,t,360,m][0][1]
            assert np.array_equal(first['angles_deg'],other['angles_deg'][::2])
            out['grid_overlap'].append(dict(unknowns=n,threads=t,method=m,channels={p:compare(first['ghost_'+p],other['ghost_'+p][::2]) for p in ('TM','TE')}))
        if t==1 and (n,4,a,m) in groups:
            other=groups[n,4,a,m][0][1]
            out['threads'].append(dict(unknowns=n,angles=a,method=m,channels={p:compare(first['ghost_'+p],other['ghost_'+p]) for p in ('TM','TE')}))
    out['max_repeat_field_spread']=max(x['max_between_repeats'] for x in out['groups'])
    return out


if __name__=='__main__':
    parser=argparse.ArgumentParser(__doc__);parser.add_argument('results',type=Path)
    print(json.dumps(run(parser.parse_args().results),indent=2))
