"""Compare fresh 5,984-unknown runs with each other and the pinned Intel archive."""
import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np


def error(field, reference):
    return float(np.max(abs(field-reference)) / np.max(abs(reference)))


def summarize(local, archived):
    records = [json.loads(line) for line in (local / "runs.jsonl").read_text().splitlines()]
    assert len(records) == 8 and len({r["tag"] for r in records}) == 8
    groups = defaultdict(list)
    fields = {}
    comparisons = []
    for row in records:
        assert (row["panels"], row["unknowns_per_system"], row["angles"]) == (3872, 5984, 360)
        assert row["quality_passed"] and row["returncode"] == 0
        key = (row["threads"], row["requested"])
        groups[key].append(row)
        fields[row["tag"]] = {}
        ref_threads = key[0] if key[0] != 2 else 1
        path = archived / "c_part2" / f"s2112_a360_t{ref_threads}_f10_{key[1]}_r0.npz"
        with np.load(local / (row["tag"] + ".npz"), allow_pickle=False) as z, np.load(path, allow_pickle=False) as other:
            assert np.array_equal(z["angles_deg"], np.arange(360.))
            assert np.array_equal(z["angles_deg"], other["angles_deg"])
            for pol in ("TE", "TM"):
                field = z[f"ghost_{pol}"]
                assert field.shape == (360,) and np.isfinite(field).all()
                fields[row["tag"]][pol] = field
                against_exact = error(field, z[f"analytic_{pol}"])
                assert abs(against_exact-row[f"error_{pol}"]) < 1e-14
                comparisons.append(dict(tag=row["tag"], pol=pol, analytic=against_exact,
                    intel_reference_threads=ref_threads, versus_intel_peak=error(field, other[f"ghost_{pol}"])))
    table = []
    for key, runs in sorted(groups.items()):
        threads, method = key
        count = 2 if threads == 2 else 1
        assert len(runs) == count and len(groups[threads, "dense"]) == count
        seconds = [r["solve_wall_s"] for r in runs]
        rss = [r["peak_rss_gib"] for r in runs]
        backend_errors, repeat_errors = [], []
        for i in range(count):
            for pol in ("TE", "TM"):
                field = fields[runs[i]["tag"]][pol]
                dense = fields[groups[threads,"dense"][i]["tag"]][pol]
                backend_errors.append(error(field, dense))
                repeat_errors.append(error(field, fields[runs[0]["tag"]][pol]))
        table.append(dict(threads=threads, backend=method, count=count, seconds=seconds, peak_rss_gib=rss,
                          median_seconds=statistics.median(seconds), median_rss=statistics.median(rss),
                          max_versus_dense=max(backend_errors), max_between_repeats=max(repeat_errors)))
    return dict(runs=table, comparisons=comparisons,
                max_versus_intel=max(x["versus_intel_peak"] for x in comparisons),
                max_versus_analytic=max(x["analytic"] for x in comparisons))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("local", type=Path)
    p.add_argument("archived_results", type=Path)
    a = p.parse_args()
    print(json.dumps(summarize(a.local, a.archived_results), indent=2))
