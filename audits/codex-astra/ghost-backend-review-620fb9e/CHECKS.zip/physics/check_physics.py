"""Check the archived cylinder fields or run the released mesh certificate again.

Set PYTHONPATH to the released tools/GHOST and the Claude audit directory, which
contains harness.py. Select --archive /path/to/claude-audit/results or --fresh
/path/to/new/output. Use one BLAS and assembly thread for the fresh solves.
"""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy import special

# Inner and outer radii in metres, then relative permittivity and permeability.
FIXTURES = {
    "pec": (None, .05, 1., 1.),
    "coat": (.04, .05, 2.8 - .06j, 1.),
    "coat-magnetic": (.04, .05, 4. - .5j, 1.5 - .3j),
    "coat-thick": (.03, .06, 2.8 - .06j, 1.),
}
CENTER = (.031, -.017)
POLARIZATIONS = ("TE", "TM")


def exact(name, ghz, polarization, angles, extra=0):
    inner, outer, eps, mu = FIXTURES[name]
    k = 2 * np.pi * ghz * 1e9 / 299792458.
    index = np.sqrt(eps * mu)
    nmax = int(np.ceil(abs(index * k * outer))) + 29 + extra
    coefficients = []
    x = k * outer
    for n in range(nmax + 1):
        j, jp = special.jv(n, x), special.jvp(n, x)
        h, hp = special.hankel2(n, x), special.h2vp(n, x)
        if inner is None:
            coefficients.append(-jp / hp if polarization == "TE" else -j / h)
            continue

        z, zi = index * x, index * k * inner
        if polarization == "TE":
            factor = index / eps
            pec_j, pec_y = special.jvp(n, zi), special.yvp(n, zi)
        else:
            factor = index / mu
            pec_j, pec_y = special.jv(n, zi), special.yv(n, zi)
        # Two exterior-interface conditions and one condition at the PEC core.
        matrix = np.array([
            [h, -special.jv(n, z), -special.yv(n, z)],
            [hp, -factor * special.jvp(n, z), -factor * special.yvp(n, z)],
            [0., pec_j, pec_y],
        ], dtype=complex)
        # Equilibrate the three basis functions before the direct interface solve.
        scale = np.max(np.abs(matrix), axis=0)
        incident = np.array([-j, -jp, 0.], dtype=complex)
        waves = np.linalg.solve(matrix / scale, incident) / scale
        coefficients.append(waves[0])

    orders = np.arange(len(coefficients))
    direction = np.deg2rad(angles)
    displacement = CENTER[0] * np.cos(direction) + CENTER[1] * np.sin(direction)
    phase = np.exp(2j * k * displacement)
    degeneracy = np.where(orders == 0, 1, 2)
    return -4j * np.sum(degeneracy * (-1.) ** orders * coefficients) * phase


def relative(field, reference):
    return float(np.max(abs(field - reference)) / np.max(abs(reference)))


def check(archive):
    summary = {"a": {}, "b": {}, "reference_errors": [], "series_tail": [],
               "pair_peak": [], "pair_l2": []}
    for study in ("a", "b"):
        pairs = {}
        for path in sorted((archive / study).glob("*.npz")):
            with np.load(path) as arrays:
                parts = path.stem.split("_")
                name = parts[0]
                ghz = float(parts[1].removesuffix("GHz")) if study == "a" else 6.
                angles = arrays["angles_deg"]
                assert np.array_equal(angles, np.arange(360))
                errors = {}
                for pol in POLARIZATIONS:
                    analytical = exact(name, ghz, pol, angles)
                    tail = exact(name, ghz, pol, angles, extra=9)
                    summary["reference_errors"].append(relative(analytical, arrays["analytic_" + pol]))
                    summary["series_tail"].append(relative(analytical, tail))
                    field = arrays["ghost_" + pol]
                    errors[pol] = relative(field, analytical)
                    if study == "a":
                        key = ("_".join(parts[:-1]), pol)
                        pairs.setdefault(key, {})[parts[-1]] = field
                summary[study][path.stem] = errors
        for pair in pairs.values():
            dense, compressed = pair["dense"], pair["compressed"]
            summary["pair_peak"].append(relative(compressed, dense))
            summary["pair_l2"].append(float(np.linalg.norm(compressed - dense) / np.linalg.norm(dense)))
    for key in ("reference_errors", "series_tail", "pair_peak", "pair_l2"):
        values = summary[key]
        summary[key] = {"max": max(values), "n": len(values)}

    assert len(summary["a"]) == 48 and len(summary["b"]) == 12
    assert summary["reference_errors"]["max"] < 1e-12
    accuracy_rows = json.loads((archive / "a" / "summary.json").read_text())
    assert len(accuracy_rows) == 48
    for row in accuracy_rows:
        key = f"{row['fixture']}_{row['ghz']:g}GHz_{row['outer_sides']}_{row['requested']}"
        for pol in POLARIZATIONS:
            assert abs(row["error_" + pol] - summary["a"][key][pol]) < 1e-12
        assert row["quality_passed"]

    metadata_files = sorted((archive / "b").glob("*_metadata.json"))
    assert len(metadata_files) == 12
    summary["certificates"] = {}
    for path in metadata_files:
        metadata = json.loads(path.read_text())
        assert metadata["mesh_convergence_certified"] and metadata["quality_gate"]["passed"]
        assert metadata["published_mesh"] == "fine"
        for channel in metadata["channel_metadata"].values():
            assert channel["mesh_convergence"]["geometry_approximation_certified"] is False
        convergence = metadata["mesh_convergence"]
        summary["certificates"][path.stem.removesuffix("_metadata")] = {
            "base_to_fine_complex_max_normalized": convergence["complex_max_normalized"],
            "estimated_published_complex_max_normalized": convergence["estimated_published_complex_max_normalized"],
        }
    return summary


def fresh(out):
    from harness import cylinder_geo, snapshot, fields_of, solve_monostatic_rcs_2d_certified
    from ghost_backend.execution.options import efficient_defaults, cpu_allocation_scope
    from ghost_backend.runs.quality import accuracy_target_policy

    out.mkdir(exist_ok=True, parents=True)
    angles = np.arange(360.)
    rows = {}
    for sides, inner_sides in ((16, 12), (360, 288)):
        geometry = cylinder_geo(b=.05, sides=sides, a=.04, eps=2.8 - .06j, mu=1.,
                                center=CENTER, n=0, inner_sides=inner_sides)
        options = efficient_defaults()
        options.update(assembly_threads=1, blas_threads=1)
        with cpu_allocation_scope(1):
            value = solve_monostatic_rcs_2d_certified(
                geometry_snapshot=snapshot(geometry), frequencies_ghz=[6.],
                elevations_deg=angles.tolist(), geometry_units="meters",
                mesh_convergence_policy=accuracy_target_policy("standard"),
                execution_options=options,
            )
        metadata = value["metadata"]
        assert metadata["mesh_convergence_certified"] and metadata["quality_gate"]["passed"]
        assert metadata["published_mesh"] == "fine"
        row = {
            "published_mesh": metadata["published_mesh"], "backend": metadata["linear_backend"],
            "panels": metadata["panel_count_max"], "quality_passed": metadata["quality_gate"]["passed"],
            "mesh_certified": metadata["mesh_convergence_certified"], "channels": {},
            "base_to_fine_complex_max_normalized": metadata["mesh_convergence"]["complex_max_normalized"],
            "channel_max_abs_db": {},
        }
        arrays = {"angles_deg": angles}
        for pol, field in fields_of(value).items():
            assert len(field) == len(angles)
            analytical = exact("coat", 6., pol, angles)
            arrays["ghost_" + pol] = field
            arrays["analytic_" + pol] = analytical
            row["channels"][pol] = relative(field, analytical)
            row["channel_max_abs_db"][pol] = float(np.max(abs(20 * np.log10(abs(field) / abs(analytical)))))
        np.savez_compressed(out / f"fresh_coat_{sides}.npz", **arrays)
        rows[f"coat_{sides}"] = row
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    operation = parser.add_mutually_exclusive_group(required=True)
    operation.add_argument("--archive", type=Path)
    operation.add_argument("--fresh", type=Path)
    args = parser.parse_args()
    result = check(args.archive) if args.archive else fresh(args.fresh)
    print(json.dumps(result, indent=2, sort_keys=True))
