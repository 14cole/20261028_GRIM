"""Replay Claude's explicit Dense fixture, retaining the backend plan and factor events.
Set GRIM_ROOT to ed90b65; pass the audit folder and the mode (plan, automatic or controls).
In plan mode stop on the first activated phase plan, before dense assembly or LAPACK.
"""
import json
import os
import sys
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, sys.argv[1])
import numpy as np
from harness import cylinder_geo, solve_fixed, fields_of
from ghost_backend.twod import solver
from ghost_backend.linalg.hierarchical import automatic_twod_hierarchical

parameters = dict(a=.10, b=.12, eps=2.8-.06j, mu=1.0, center=(.031,-.017))
audit = Path(sys.argv[1])
mode = sys.argv[2]
if mode == 'plan':
    sides, n_angles, threads = 8448, 360, 4
    with (audit/'results/c_large/dense.out').open() as f:
        historical = json.load(f)
    capacity = historical['memory_accounting']['cohort_capacity_gib']
    original_forecast = solver._estimate_memory_gb
    plans = []

    class PlanCaptured(Exception):
        pass

    def capture(*args, **kwargs):
        gb = original_forecast(*args, **kwargs)
        if kwargs.get('activate_memory_plan'):
            resources = kwargs['dense_resources']
            d = resources['system_dofs']
            plans.append(dict(nodes=resources['nodes'], dofs=d,
                              formulation=resources['formulation'], estimated_peak_gib=gb,
                              legacy_hierarchical_default=automatic_twod_hierarchical(d),
                              **resources['memory_estimate']))
            raise PlanCaptured()
        return gb

    for scratch in (True, False):
        try:
            with patch.object(solver, '_solve_memory_limit_gb', return_value=capacity), \
                 patch('ghost_backend.execution.dense_memory.scratch_available', return_value=(
                        scratch, None if scratch else 'counterfactual insufficient disk')), \
                 patch.object(solver, '_estimate_memory_gb', side_effect=capture):
                solve_fixed(cylinder_geo(sides=sides, **parameters), 10., np.arange(n_angles),
                            'dense', threads=threads)
        except PlanCaptured:
            pass
    print(json.dumps(plans, indent=2))
elif mode == 'automatic':
    from ghost_backend.execution import selection
    with (audit/'results/c_large/dense.out').open() as f:
        capacity = json.load(f)['memory_accounting']['cohort_capacity_gib']
    original_select = selection.select_backend
    records = []

    class SelectionCaptured(Exception):
        pass

    def capture_selection(*args, **kwargs):
        answer = original_select(*args, **kwargs)
        row = answer['meshes'][0]
        records.append(dict(sides=sides, selected=answer['selected'], reason=answer['reason'],
                            candidates=answer['candidates'], budget=capacity,
                            unknowns=row['unknowns'], dense_storage=row['backend_memory_plans']['dense'].get('residual_storage')))
        raise SelectionCaptured()

    for sides in (1056, 2112, 4224, 8448):
        try:
            with patch.object(solver, '_solve_memory_limit_gb', return_value=capacity), \
                 patch('ghost_backend.execution.dense_memory.scratch_available', return_value=(True, None)), \
                 patch.object(selection, 'select_backend', side_effect=capture_selection):
                solve_fixed(cylinder_geo(sides=sides, **parameters), 10., np.arange(360.), 'automatic', threads=4)
        except SelectionCaptured:
            pass
    print(json.dumps(records, indent=2))
elif mode == 'controls':
    histories, fields = {}, {}
    for storage in ('memory', 'disk'):
        result, elapsed = solve_fixed(cylinder_geo(sides=256, **parameters), 10.,
                                      np.arange(0.,360.,10.), 'dense', threads=1,
                                      dense_residual_storage=storage)
        meta = result['metadata']
        fields[storage] = fields_of(result)
        histories[storage] = dict(
            linear_backend=meta['linear_backend'], solver_method=meta['solver_method'],
            quality_passed=meta['quality_gate']['passed'],
            elapsed_s=elapsed,
            experimental_cpu=meta['experimental_cpu'],
            runtime_profile=meta.get('runtime_profile',{}),
            selection=meta.get('backend_selection',{}))
    histories['disk_vs_memory'] = {pol: float(np.max(np.abs(v-fields['memory'][pol])) /
                                               np.max(np.abs(fields['memory'][pol])))
                                   for pol,v in fields['disk'].items()}
    print(json.dumps(histories, default=str, indent=2))
else:
    raise ValueError('Expected plan, automatic or controls')
