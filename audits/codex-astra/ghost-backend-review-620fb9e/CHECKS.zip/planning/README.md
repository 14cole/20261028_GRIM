# Dense storage and Automatic selection

The solver is from production commit `ed90b65ff89826274adacae01bcfbafe143e9819`. The probe imports `harness.py` and the recorded large-case budget from Claude's `620fb9e` audit. The 13 source files used to trace selection, Dense factorization, memory admission and metadata matched their GitHub blob IDs.

Run with `GRIM_ROOT` pointing to the production checkout. Substitute the path to Claude's `ghost-backend-audit` folder for `$AUDIT`.

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python route_probe.py "$AUDIT" plan > plan.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python route_probe.py "$AUDIT" automatic > automatic.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python route_probe.py "$AUDIT" controls > controls.json
```

- `plan` uses the original 8,448-sided coated cylinder, 360 angles, four requested threads and the recorded 13.601781 GiB cohort budget. It evaluates both scratch-available and scratch-unavailable scenarios and stops at the first actual phase plan, before matrix allocation. With disk scratch the released default plans a 9.969 GiB peak, an 8.537 GiB residual file, a 128-entry assembly tile, a 256-angle batch and sequential polarizations. With no disk scratch the initial forecast is 18.461 GiB. Even two bare dense matrices total 17.075 GiB before other work.
- `automatic` runs the public selector on the original four mesh sizes, with the same budget and disk scratch. It stops as soon as the planner returns. It chooses Dense at 2,992 and 5,984 unknowns per polarization and Compressed at 11,968 and 23,936.
- `controls` runs the public Dense solver twice on a 728-unknown version of the coating for 36 angles. Both in-memory and disk residual storage give the identical 72 complex fields and pass the solve gate. The high-level method string is identical. The factor events in `experimental_cpu.systems` distinguish the two, and `runtime_profile.stage_seconds` records the numerical stages. Times in these small controls serve only to identify instrumentation.
- Claude's large run did complete. Its 9.259-GiB peak and the released defaults support in-memory complex128 LU with original coefficients spooled to disk for residuals. The archived top-level method tag alone cannot establish the exact historical execution path. The per-factor events, environment overrides and stage timings were omitted. Assembly tiles, loss of paired assembly, repeated residual reads and dense factorization can all affect wall time. CPU and storage measurements on the original host would be needed to apportion it.
- The Dense ledger reports 15.113 GiB initially available and a 13.602-GiB cohort capacity despite the environment report's 13.35-GiB cgroup limit. The precise cgroup membership and usage counters from this particular run were not saved. The numbers are consistent with the previously identified nested cgroup detection issue.
