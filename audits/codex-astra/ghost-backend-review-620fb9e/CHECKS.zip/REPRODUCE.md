# Reproduce the GHOST audit checks

Use a checkout or archive of shipped revision `ed90b65ff89826274adacae01bcfbafe143e9819` for the solver and the directory `audits/claude-2026-11-26/ghost-backend-audit` from Claude's `620fb9ebc1c5b2248687ecbf4841ca633904b700` for the fixtures and the archived results. Extract CHECKS.zip to a separate directory and run the following there. Use Python with NumPy, SciPy, threadpoolctl and the GHOST dependencies and shipped native kernels. Our host settings are in environment.json. taskset and the peak RSS measurements used here are Linux-specific. Choose CPU IDs available to your worker.

```sh
export GRIM_ROOT=/path/to/ed90b65
export CLAUDE_AUDIT=/path/to/ghost-backend-audit
export PYTHONPATH="$CLAUDE_AUDIT"
sha256sum -c SHA256SUMS
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python physics/check_physics.py --archive "$CLAUDE_AUDIT/results"
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python physics/check_physics.py --fresh replay/certified
OPENBLAS_NUM_THREADS=1 python timing/check_timing.py "$CLAUDE_AUDIT/results"
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python planning/route_probe.py "$CLAUDE_AUDIT" plan
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python planning/route_probe.py "$CLAUDE_AUDIT" automatic
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python planning/route_probe.py "$CLAUDE_AUDIT" controls
taskset -c 1-4 python "$CLAUDE_AUDIT/study_c_timing.py" replay/cylinder 2112:360:2:2 2112:360:1:1 2112:360:4:1
python timing/check_reruns.py replay/cylinder "$CLAUDE_AUDIT/results"
```

Use a new output directory for each repeat of the full driver. It appends to runs.jsonl. The archived cylinder workers used the unmodified timing driver, 256-angle batches, both polarizations, degree one, residual checks, no condition estimate and RHS compression off. The local elapsed times include parsing the geometry text, assembly, factorization, all right-hand sides and quality checks. The timer ends before the analytical reference and field export. Peak RSS is the fresh process high-water mark. Each request pins its assembly, OpenMP and BLAS thread counts. The four worker CPU IDs share a four-CPU quota with the container. Small archive and planner checks used CPU 0 during portions of the first group of two-thread timings. No other benchmark-scale solves ran concurrently.

In planning/plan.json, each row is a counterfactual run of the production planner at the archived 24k memory budget, stopped before allocating the large matrix. planning/automatic.json records selection before assembly. planning/controls.json contains factor events and stage timings for two small, actual Dense solves. The field difference of zero is computed from all 36 samples of both polarizations.

For the separate 180-direction coated ellipse, see ellipse/REPRODUCE.md. Geometry and angle checks, script, individual logs, raw complex fields and paired comparisons are included. The numerical comparison is between the two public backends on a fixed mesh.

physics/earlier-codex-fields.json is the output of Claude's cross_check_codex.py applied to the earlier Codex archive from c5b9a39. timing/earlier-ellipse.json is the original summarize.py applied to that archive's results directory. Both scripts are available in the respective pinned audit folders or evidence archive.
