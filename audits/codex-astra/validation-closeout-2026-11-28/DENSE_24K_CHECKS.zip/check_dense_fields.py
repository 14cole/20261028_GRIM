"""Compare saved monostatic fields to independently evaluated coated-cylinder boundary conditions.

Usage: python check_dense_fields.py /path/to/fresh_pair /path/to/ghost-backend-audit
Accepts either fields.npz in each directory of a freshly measured pair or extracted audit evidence.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp

def reference(pol, angles):
    k = 2*np.pi*10e9 / 299792458.0
    epsilon = 2.8 - 0.06j
    q = np.sqrt(epsilon)
    admittance = q/epsilon if pol=="TE" else q
    core = k*q*.10
    shell = k*q*.12
    outside = k*.12
    coeffs = []
    for harmonic in range(91):
        n=harmonic
        jb, yb = (jv(n,core), yv(n,core)) if pol=="TM" else (jvp(n,core), yvp(n,core))
        rows = np.array([[hankel2(n,outside),-jv(n,shell),-yv(n,shell)],
                         [h2vp(n,outside),-admittance*jvp(n,shell),-admittance*yvp(n,shell)],
                         [0.,jb,yb]])
        scale = np.max(abs(rows),axis=0)
        c = np.linalg.solve(rows/scale,[-jv(n,outside),-jvp(n,outside),0.])[0]/scale[0]
        coeffs.append(c * (-1)**n * (1 if n==0 else 2))
    angle=np.deg2rad(angles)
    shift=np.exp(2j*k*(.031*np.cos(angle)-.017*np.sin(angle)))
    return -4j*sum(coeffs)*shift

def read(path):
    with np.load(path,allow_pickle=False) as data:
        assert np.array_equal(data["angles_deg"],np.arange(360.))
        return {p:data["ghost_"+p] for p in ("TE","TM")}

def compare(value, ref):
    assert value.shape == ref.shape == (360,) and np.isfinite(value).all() and np.isfinite(ref).all()
    err=abs(value-ref)
    return {"bit_identical":value.tobytes()==ref.tobytes(),
            "max_error_over_peak":float(max(err)/max(abs(ref))),
            "relative_l2":float(np.linalg.norm(value-ref)/np.linalg.norm(ref)),
            "max_error_angle_deg":int(err.argmax())}

if __name__ == "__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("fresh",type=Path)
    ap.add_argument("claude",type=Path)
    args=ap.parse_args()
    archives=args.claude/"results/c_cand24k"
    fields={name:read(args.fresh/name/"fields.npz") for name in ("shipped","corrected") if (args.fresh/name/"fields.npz").exists()}
    if not fields: raise ValueError("No full-size fields in the supplied pair")
    src={name:read(archives/name/"s8448_a360_t4_dense.npz") for name in ("current","candidate")}
    truth={pol:reference(pol,np.arange(360.)) for pol in ("TE","TM")}
    out={}
    for name, record in fields.items():
        out[name]={}
        for p,val in record.items():
            out[name][p]={target:compare(val,ref[p]) for target,ref in
                          [("analytic",truth),("archived_shipped",src["current"]),("archived_candidate",src["candidate"])]}
            assert out[name][p]["analytic"]["max_error_over_peak"] < 4e-6
    if len(fields)==2:
        out["before_after"]={p:compare(fields["corrected"][p],fields["shipped"][p]) for p in ("TE","TM")}
        assert all(r["max_error_over_peak"] < 1e-10 for r in out["before_after"].values())
    print(json.dumps(out,indent=2))
