"""Read completed solver CPU ticks alongside the cgroup total for other-work context."""
import json
import os
from pathlib import Path
import sys
import time

root=Path(sys.argv[1])
ticks=os.sysconf('SC_CLK_TCK')
for label in ('corrected','shipped'):
    dest=root/label
    while not (dest/'pid').exists():time.sleep(2)
    pid=int((dest/'pid').read_text())
    proc=Path('/proc')/str(pid)/'stat'
    sample_file=dest/'samples.jsonl'
    while not (sample_file.exists() and sample_file.stat().st_size):time.sleep(1)
    first=json.loads(sample_file.open().readline())
    zero=first['cpu']['usage_usec']
    with (dest/'cpu-context.jsonl').open('x') as log:
        while proc.exists() and not (dest/'status.json').exists():
            try:stat=proc.read_text().rpartition(') ')[2].split()
            except (ProcessLookupError,FileNotFoundError):break
            if not stat or stat[0]=='Z':break
            snapshot=Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines()
            cpu_us=int(next(s.split()[1] for s in snapshot if s.startswith('usage_usec ')))
            proc_s=(int(stat[11])+int(stat[12]))/ticks
            all_s=(cpu_us-zero)/1e6
            log.write(json.dumps({'observed_epoch_s':time.time(),'process_cpu_s':proc_s,'all_cgroup_cpu_s_since_job_start':all_s,'other_cgroup_cpu_s':all_s-proc_s})+'\n')
            log.flush()
            time.sleep(10)
