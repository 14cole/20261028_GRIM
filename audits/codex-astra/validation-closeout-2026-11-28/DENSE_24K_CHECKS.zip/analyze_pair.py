"""Recalculate numerical and resource comparisons from independent jobs and both archival controls."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np

def metric(a,b):
    assert a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all()
    return {'bit_identical':a.tobytes()==b.tobytes(),'rel_peak':float(np.max(np.abs(a-b))/np.max(np.abs(b))),
            'rel_l2':float(np.linalg.norm(a-b)/np.linalg.norm(b))}

def compare_fields(a,b):
    return {pol:metric(a['ghost_'+pol],b['ghost_'+pol]) for pol in ('TE','TM')}

def read_npz(path):
    with np.load(path,allow_pickle=False) as ar:
        assert np.array_equal(ar['angles_deg'],np.arange(360))
        return {k:ar[k].copy() for k in ar}

def summary(files,original_dir,independent_script):
    import importlib.util
    spec=importlib.util.spec_from_file_location('previous_independent',independent_script)
    analytic=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analytic)
    exact={p:analytic.solve_analytic(p,np.arange(360)) for p in ('TE','TM')}
    archived={k:read_npz(original_dir/k/'s8448_a360_t4_dense.npz') for k in ('candidate','current')}
    data={}
    fields={}
    for label in ('corrected','shipped'):
        dest=files/label
        if not (dest/'status.json').exists():continue
        status=json.loads((dest/'status.json').read_text())
        assert status['exit']==0
        r=json.loads((dest/'dense.json').read_text())
        assert r['quality_passed'] and r['panels']==15488 and r['unknowns_per_system']==23936
        f=read_npz(dest/'fields.npz')
        fields[label]=f
        samples=[json.loads(line) for line in (dest/'samples.jsonl').read_text().splitlines()]
        for k in ('TE','TM'):
            assert all(np.isfinite(f['ghost_'+k]))
        plans=[m for m in r['memory_estimates'] if 'residual_storage' in m]
        gates=[m for m in r['memory_estimates'] if m.get('method')=='reused_dense_matrix_admission']
        assert len(plans)==2 and len(gates)==1
        result={k:r[k] for k in ('panels','unknowns_per_system','angles','threads','ghz','polling_wall_s','residual_max','rhs_batches','stage_calls','stage_seconds','solve_wall_s','peak_rss_gib','process_io','quality_passed') if k in r}
        result['gate']=gates[0]
        result['plans']=[{k:p.get(k) for k in ('residual_storage','angle_batch_size','reused_matrix_credit_bytes','capacity_bytes','peak_bytes','memory_recovery','assembly_tile')} for p in plans]
        result.update({
          'max_sampled_anon_gib':max(i['cgroup_memstat']['anon'] for i in samples)/2**30,
          'max_sampled_file_gib':max(i['cgroup_memstat']['file'] for i in samples)/2**30,
          'minimum_scratch_free_gib':min(i['file_disk_free'] for i in samples)/2**30,
          'samples':len(samples),
          'vs_archived_candidate':compare_fields(f,archived['candidate']),
          'vs_archived_shipped':compare_fields(f,archived['current']),
          'vs_independent_reference':{p:metric(f['ghost_'+p],exact[p]) for p in ('TE','TM')},
          'reference_check':{p:metric(f['analytic_'+p],exact[p]) for p in ('TE','TM')},
          'end_event_counts':status['cgroup_events']})
        cpu_path = dest/'cpu-context.jsonl'
        if cpu_path.exists() and cpu_path.stat().st_size:
            cpu = json.loads(cpu_path.read_text().splitlines()[-1])
            result['last_passive_cpu_sample'] = cpu
            result['other_cgroup_cpu_fraction_at_last_sample'] = cpu['other_cgroup_cpu_s']/cpu['all_cgroup_cpu_s_since_job_start']
        result['start_events'] = json.loads((dest/'host-start.json').read_text())['cgroup']['memory.events']
        data[label]=result
    ret={'runs':data}
    if set(fields)=={'corrected','shipped'}:
        a,b=data['corrected'],data['shipped']
        ret.update({'fresh_fields':compare_fields(fields['corrected'],fields['shipped']),
                    'speed_factor':b['solve_wall_s']/a['solve_wall_s'],
                    'seconds_saved':b['solve_wall_s']-a['solve_wall_s'],
                    'peak_rss_gib_delta':a['peak_rss_gib']-b['peak_rss_gib'],
                    'physical_read_bytes_fraction':a['process_io']['read_bytes']/b['process_io']['read_bytes'] if b['process_io']['read_bytes'] else None})
    return ret

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('fresh',type=Path)
    parser.add_argument('original_dir',type=Path,help='results/c_cand24k in the pinned Claude audit')
    parser.add_argument('independent_script',type=Path,help='data/verify_round4.py from the earlier audit archive')
    ap=parser.parse_args()
    print(json.dumps(summary(ap.fresh,ap.original_dir,ap.independent_script),indent=2))
