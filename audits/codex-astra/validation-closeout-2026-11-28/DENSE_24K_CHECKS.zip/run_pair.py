"""Run pinned original 23,936-unknown public solver from two isolated source trees, sequentially."""
import argparse
import datetime
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def kv(path, separator=None):
    result={}
    try:
        rows=path.read_text().splitlines()
    except (FileNotFoundError,ProcessLookupError): return {}
    for line in rows:
        if separator:
            k,_,v=line.partition(separator)
        else:
            k,_,v=line.partition(' ')
        try: result[k]=int(v.strip().split()[0])
        except (ValueError,IndexError): continue
    return result

def fs(p):
    u=shutil.disk_usage(p)
    return {'total':u.total,'used':u.used,'free':u.free}

def read_optional(path):
    try:return path.read_text().strip()
    except OSError:return None

def run(label,source,audit,out,scratch,cpus,interval):
    dest=out/label;dest.mkdir(exist_ok=False)
    cgroup=Path('/sys/fs/cgroup')
    env=dict(os.environ,GRIM_ROOT=str(source),GHOST_AUDIT_OPTIONS='{}',TMPDIR=str(scratch),PYTHONPATH=str(audit),PYTHONDONTWRITEBYTECODE='1')
    before={'time':utc(),'platform':platform.platform(),'host_cpu':next(line.split(':')[-1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),
            'scratch':fs(scratch),'cpu_affinity':cpus,'process_cgroup':read_optional(Path('/proc/self/cgroup')),
            'cgroup':{key:read_optional(cgroup/key) for key in ['cpu.max','memory.max','memory.current','memory.swap.max','memory.events']},
            'host_mem_kib':kv(Path('/proc/meminfo'),':'),'boot_id':read_optional(Path('/proc/sys/kernel/random/boot_id')),
            'harness':'timed_job.py 8448 dense 360 4 fields.npz','job_options':{},'temporary_storage':'disk-backed overlay',
            'label':label}
    assert before['scratch']['free']>=16*23936**2+64*1024**2
    (dest/'host-start.json').write_text(json.dumps(before,indent=2))
    index=0
    start=time.monotonic()
    with (dest/'dense.json').open('w') as log,(dest/'stderr.txt').open('w') as err,(dest/'samples.jsonl').open('w') as samples:
        process=subprocess.Popen(['taskset','-c',cpus,sys.executable,str(audit/'timed_job.py'),'8448','dense','360','4',str(dest/'fields.npz')],cwd=dest,stdout=log,stderr=err,env=env)
        (dest/'pid').write_text(str(process.pid))
        proc=Path('/proc')/str(process.pid)
        while process.poll() is None:
            status=kv(proc/'status',':')
            cc=kv(cgroup/'memory.stat')
            sample={'seconds':round(time.monotonic()-start,3),'utc':utc(),'rss_kib':status.get('VmRSS'),'hwm_kib':status.get('VmHWM'),
                    'io':kv(proc/'io',':'),'file_disk_free':fs(scratch)['free'],'memory_current':read_optional(cgroup/'memory.current'),
                    'cgroup_memstat':{k:cc.get(k) for k in ('anon','file','inactive_file','active_file','pgmajfault','pgscan','pgsteal','file_dirty')},
                    'cpu':kv(cgroup/'cpu.stat'),'pressure_memory':read_optional(cgroup/'memory.pressure')}
            samples.write(json.dumps(sample)+'\n');samples.flush()
            index+=1
            if index%24==1: print(label,sample['utc'],round(sample['seconds']),sample['rss_kib'],sample['io'].get('read_bytes'),flush=True)
            try:process.wait(timeout=interval)
            except subprocess.TimeoutExpired: pass
    code=process.returncode
    result={'exit':code,'elapsed_seconds':round(time.monotonic()-start,3),'end':utc(),'scratch_after':fs(scratch),'cgroup_events':kv(cgroup/'memory.events')}
    (dest/'status.json').write_text(json.dumps(result,indent=2))
    print(label,result,flush=True)
    if code:raise RuntimeError((dest/'stderr.txt').read_text()[-3000:])
    row=json.loads((dest/'dense.json').read_text())
    assert row['quality_passed'] and row['unknowns_per_system']==23936 and row['angles']==360
    assert row['panels']==15488 and row['extra_options']=={}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('shipped',type=Path)
    ap.add_argument('corrected',type=Path)
    ap.add_argument('claude_audit',type=Path)
    ap.add_argument('output',type=Path)
    ap.add_argument('scratch',type=Path)
    ap.add_argument('--cpus',default='1-4')
    ap.add_argument('--interval',type=int,default=10)
    ap.add_argument('--labels',nargs='+',default=['corrected','shipped'],choices=['corrected','shipped'])
    a=ap.parse_args()
    a.output.mkdir(parents=True,exist_ok=True);a.scratch.mkdir(parents=True,exist_ok=True)
    for label in a.labels:run(label,getattr(a,label).resolve(),a.claude_audit.resolve(),a.output.resolve(),a.scratch.resolve(),a.cpus,a.interval)
