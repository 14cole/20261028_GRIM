# End-to-end 23,936-unknown Dense comparison

Use the 528-file shipped checkout at `ed90b65ff89826274adacae01bcfbafe143e9819`. Make a separate copy, apply Claude's `prototype/candidate-vs-ed90b65.patch` from `d0b732fc025d47118ae999970be0f392bff9e89f` and then apply `private-matrix-reuse.patch` from `6a7bdc98f43c88c991758c2445f8c445741e84b8`. The source hashes are in `provenance.json`. The audit directory containing the unmodified `timed_job.py` and `harness.py` is `audits/claude-2026-11-26/ghost-backend-audit` at Claude's pinned commit.

Use the project's Linux Python environment with NumPy and SciPy. Provide a cleared real disk directory with at least 8.54 GiB plus 64 MiB of free space. The runner creates fresh output subdirectories and calls the public solver in a separate process for each version. Adjust the CPU IDs to match the machine's allocation. For example, on this machine four CPU IDs were 1–4.

```sh
python run_pair.py "$SHIPPED_ROOT" "$CORRECTED_ROOT" "$CLAUDE_AUDIT" "$OUTPUT" "$DISK_SCRATCH" --cpus 1-4
python analyze_pair.py "$OUTPUT" "$CLAUDE_AUDIT/results/c_cand24k" "$PREVIOUS_AUDIT/data/verify_round4.py" > comparison.json
```

The test requested Dense, 360 monostatic directions and both polarizations on the 10 GHz coated PEC cylinder. It used the actual available-RAM reading, four threads, the default automatic residual-storage plan and no explicit RAM cap or tile. The four-core Linux execution environment had a 16 GiB cgroup memory limit and no active swap device. The integrated revision ran first and shipped second on the same boot. Local preparation enlarged free disk space by temporarily packing old generated verification copies. Each original file was reconstructed and checked byte-for-byte before temporarily parking it. Its verification and publication sources remained in place. This unrelated preparation is unnecessary on hosts with sufficient scratch.

Memory and I/O samples use Linux cgroup v2 and process counters. The absolute high-water RSS and final process I/O totals come from the unmodified timed solver. The sampled container anonymous and file usage include all processes in this shared cgroup. Report storage I/O from `read_bytes` and `write_bytes` in the completed JSON. `rchar` measures logical reads, including page-cache hits. The two matrix-status files include return codes and cgroup memory events. Fields are complex amplitudes on the tested mesh and the field-comparison denominators are reference peaks.

The corrected public solve finished before a separate Line Expansion suite used a 53.6 second quiet interval. The orchestration parent paused after the public solver had produced its final fields. No solver child was paused. The corrected launcher's outer elapsed time includes this interval. Use `solve_wall_s` for elapsed-time comparisons. The low-cost optional CPU observer records accumulated solver CPU ticks versus total cgroup CPU time, including initial concurrent unrelated work. Other processes used about 11% over the corrected job's first 5m41s. The full series is archived. This is one corrected-first, shipped-second pair.

A separate analytical implementation and all same-host field checks can be replayed with `python check_dense_fields.py fresh "$CLAUDE_AUDIT"` after extracting this archive. See fresh-field-crosscheck.json for the outputs.
