"""Public save/reopen/crop/Assembly controls after GRIM transformations."""
import json, tempfile
from pathlib import Path
from common import expand, write_section, reopen, rel
import check_placed_feature as q
from GRIM_Backend.datasets.grid import RcsGrid
from GRIM_Backend.datasets.transforms import crop_dataset
from ghost_backend.assembly.fields import recorded_line_expansion_attitude
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly
import numpy as np

def run(d):
    out={}
    section=write_section(d)
    pattern=q.create_point_pattern(d)
    mesh=d/'patch.stl'
    mesh.write_text('solid p\nfacet normal 0 0 1\nouter loop\nvertex -1 -1 .15\nvertex 1 -1 .15\nvertex 0 1 .15\nendloop\nendfacet\nendsolid p\n')
    csv=d/'p.csv'
    csv.write_text('placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\ns,p,0,0,.15,0,0,1,1,0,0\n')
    original=d/'src.grim'
    # The 0 to 360 seam relabel exercises wrap and reorder before crop.
    q.GRID.update(azimuths_deg=[0.,45.,120.,230.],elevations_deg=[16.,26.])
    expand([section],output_grim=str(original),**q.GRID,**q.ATT)
    for name, op in [('signed_wrap',lambda s:s.wrap_azimuth('-180_180')),
                     ('rewrap_to_positive',lambda s:s.wrap_azimuth('-180_180').wrap_azimuth('0_360'))]:
        inter=d/(name+'-inter.grim')
        op(RcsGrid.load(str(original))).save(str(inter))
        final=d/(name+'.grim')
        crop_dataset(RcsGrid.load(str(inter)),azimuth_range=(-180.,360.)).save(str(final))
        bp,base=reopen(final)
        report={'record':recorded_line_expansion_attitude(bp),'axes':bp['azimuths'].tolist()}
        try:
            dest=d/(name+'-out.grim')
            plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=final,output_grim=dest,surface_mesh=mesh,surface_units='meters',coordinate_units='meters',point_locations_csv=csv,point_datasets={'p':pattern}))
            execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
            _,total=reopen(dest);q.GRID['azimuths_deg']=bp['azimuths'].tolist()
            report['field_relative_error']=rel(total-base,q.point_reference(q.ATT,True))
            report['plan']={k:plan.radar_grid[k] for k in q.ATT}
        except ValueError as e:
            report['refused']=str(e)
        out[name]=report
    return out
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        print(json.dumps(run(Path(tmp)),indent=2))
