"""Exercise persisted GRIM source and output records using a rotated Line Expansion file."""
import json
from pathlib import Path
import tempfile
import numpy as np
from GRIM_Backend.datasets.grid import RcsGrid
from common import expand, write_section
from ghost_backend.assembly.fields import recorded_line_expansion_attitude

angles = {'axis_az_deg': 20., 'axis_el_deg': -10., 'roll_deg': 15.}
key = 'line_expansion_provenance_json'
def record(grid):
    return json.loads(np.asarray(grid.extra[key]).reshape(()).item())
def read(path):
    with np.load(path,allow_pickle=False) as fp:
        return recorded_line_expansion_attitude(fp)
def run(work):
    source=work/'source.grim'
    expand([write_section(work)],output_grim=str(source),frequencies_ghz=[1.],azimuths_deg=[0.,90.,180.,270.],
           elevations_deg=[10.,20.],**angles)
    grid=RcsGrid.load(str(source))
    checked={}
    def check(name, result, expected, storage_degrees=True):
        path=work/(name+'.grim')
        result.save(str(path))
        value=read(path) if storage_degrees else None
        r=record(result)
        if expected is None:
            assert 'body_attitude_invalidated_by' in r and 'body_attitude_deg' not in r
            assert value is None
        else:
            assert r['body_attitude_deg']==angles
            if storage_degrees:
                assert value[0]==angles
            assert np.allclose(r['radar_grid_deg']['azimuths'],expected)
        checked[name]=dict(trusted=None if value is None else value[0], scope=r.get('radar_grid_deg'), invalidated=r.get('body_attitude_invalidated_by'))
    changed=grid.edit_axis_value('azimuth',1,95.)
    check('changed_then_excluded',changed.axis_crop(azimuths=[0.,180.]),None)
    check('changed_then_reverted',changed.edit_axis_value('azimuth',1,90.),None)
    check('changed_then_interpolated',changed.interpolate_axis('azimuth',[0.,90.,180.]),None)
    injected=RcsGrid.load(str(source))
    # Simulated externally edited source: a crop excludes the offending look.
    damaged=record(injected); damaged['radar_grid_deg']['azimuths'][1]=95.
    injected.extra[key]=json.dumps(damaged)
    check('stale_on_entry_crop',injected.axis_crop(azimuths=[0.,180.]),None)
    rad=grid.convert_axis_units(azimuth='rad',elevation='rad')
    cropped=rad.axis_crop(azimuths=[0.,np.pi]).edit_axis_value('azimuth',0,2*np.pi)
    check('radian_crop_wrap',cropped,[180.,360.],False)
    check('radian_round_trip',cropped.convert_axis_units(azimuth='deg',elevation='deg'),[180.,360.])
    check('full_turn_shift_string',grid.shift_azimuth('360'),[360.,450.,540.,630.])
    check('elevation_change',grid.edit_axis_value('elevation',0,11.),None)
    check('frequency_edit',grid.edit_axis_value('frequency',0,1.1),[0.,90.,180.,270.])
    check('zero_shift',grid.shift_elevation(0.),[0.,90.,180.,270.])
    check('mirror',grid.mirror_about_azimuth(0.),None)
    check('swap',grid.swap_elevation_azimuth(),None)
    check('unchanged_rounding',grid.round_axes(3),[0.,90.,180.,270.])
    # An aborted invalid crop must leave the supplier's original record intact.
    old_value=str(np.asarray(grid.extra[key]).item())
    try: grid.axis_crop(azimuths=[31.])
    except ValueError: pass
    else: raise AssertionError('empty crop unexpectedly completed')
    assert str(np.asarray(grid.extra[key]).item())==old_value and read(source)[0]==angles
    return checked
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as tmp:
        print(json.dumps(run(Path(tmp)),indent=2))
