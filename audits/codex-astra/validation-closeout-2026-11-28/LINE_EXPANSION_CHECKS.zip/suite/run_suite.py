"""Run Claude's pinned tests and the round-three public workflow controls in isolated processes.

Usage: run_suite.py SOURCE PINNED_FIXTURES UNPACKED_R3_CHECKS OUTPUT [--old MAIN ROUND1 ROUND2]
Use a new OUTPUT directory for each revision. Set PYTHONPATH to any environment-only deps.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from xml.etree import ElementTree

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for n in ("source", "fixtures", "controls", "output"):
        p.add_argument(n, type=Path)
    p.add_argument("--old", nargs=3, type=Path, metavar=("SHIPPED","ROUND1","ROUND2"))
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--only", nargs="+", help="Re-run the selected ordinary workflows")
    args = p.parse_args()
    source, fixtures, controls, output = [getattr(args,n).resolve() for n in ("source","fixtures","controls","output")]
    output.mkdir(parents=True, exist_ok=True)
    results = {}
    def launch(name, command, tree=source, file_output=None):
        result_file = output / (name + ".json")
        with tempfile.TemporaryDirectory(prefix="line-check-") as tmp:
            paths=[str(tree),str(tree/"tools/GHOST"),str(fixtures),str(controls),os.environ.get("PYTHONPATH","")]
            env=dict(os.environ, GRIM_ROOT=str(tree), PYTHONPATH=os.pathsep.join(paths), TMPDIR=tmp,
                XDG_CACHE_HOME=tmp+"/cache", GRIM_ASSEMBLY_DRAFT_DIR=tmp+"/drafts",
                OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
                QT_QPA_PLATFORM="offscreen", PYTHONDONTWRITEBYTECODE="1")
            process=subprocess.run([sys.executable,*map(str,command)],env=env,cwd=tmp,capture_output=True,text=True)
            if process.stderr:
                (output/(name+".stderr")).write_text(process.stderr)
            result={"exit_code":process.returncode}
            if process.stdout:
                if file_output is not None:
                    if file_output == "log":
                        (output/(name+".log")).write_text(process.stdout)
                else:
                    try:
                        value=json.loads(process.stdout)
                        result_file.write_text(json.dumps(value,indent=2)+"\n")
                    except ValueError:
                        (output/(name+".log")).write_text(process.stdout)
                        result["non_json_stdout"]=True
            results[name]=result
            print(name,process.returncode,flush=True)
    # Produce historical native files on each stated revision, then read them on SOURCE.
    if args.old:
        cross = output / "historical"
        labels = ["released","round1","round2"]
        for label, tree in zip(labels,args.old):
            launch("produce-"+label,[controls/"check_older_outputs.py","write",cross,label],tree.resolve(),"log")
        launch("assumed-old",[controls/"check_assumed_upgrade.py",cross/"released/section.grim",cross/"round2/assumed.grim"],args.old[-1].resolve())
        for label in labels:
            launch(label,[controls/"check_older_outputs.py","read",cross,label])
        launch("assumed-current",[controls/"check_assumed_upgrade.py",cross/"round2/assumed.grim",cross/"round2/new.grim"])
    jobs=[("pytest",["-m","pytest","-q","-p","no:cacheprovider","--tb=short","--junitxml",output/"pytest.xml",fixtures/"test_line_expansion_regressions.py"],"log")]
    for name,script in [("gui","gui_checks"),("independent","independent_checks"),("grim","grim_app_check"),("bor","bor_base_check")]:
        jobs.append((name,[fixtures/(script+".py"),output/(name+".json")],"file"))
    ordinary={
        "panel":"check_assembly_panel","placed":"check_placed_feature","grid-operations":"check_grid_operations",
        "cropped-assembly":"check_cropped_assembly","resampled":"check_resampled_assembly","edited":"check_edited_assembly",
        "study-subset":"check_study_subset","transfer":"check_transfer_controls","embedded-control":"check_embedded_control",
        "trial-transform":"trial_transform_metadata","metadata":"check_attitude_roundtrip","edge":"check_cancel_edges",
        "sources":"cancel_sources","grid":"grid_admission","optional-log-unit":"check_optional_log_unit"}
    jobs.extend((name,[controls/(script+".py")],None) for name,script in ordinary.items())
    jobs.extend([
        ("placed-one",[controls/"check_placed_feature.py","--one-sided"],None),
        ("invalidated-subset",[Path(__file__).with_name("discarded_look.py").resolve()],None),
        ("overlap",[controls/"publication_overlap.py","--require-isolation"],None),
        ("stages",[controls/"cancel_publication.py","--output",output/"stages.json"],"file")])
    if args.only:
        names = {j[0] for j in jobs}
        unknown = set(args.only) - names
        if unknown:
            p.error(f"Unknown workflow labels: {sorted(unknown)}")
        jobs = [job for job in jobs if job[0] in args.only]
    def execute(job):
        name,command,file_output=job
        launch(name,command,file_output=file_output)
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(execute,jobs))
    if "pytest" in results and (output/"pytest.xml").exists():
        suite=ElementTree.parse(output/"pytest.xml").getroot().find("testsuite")
        results["pytest"]["counts"]={k:int(suite.get(k)) for k in ("tests","failures","errors","skipped")}
    (output/"processes.json").write_text(json.dumps(results,indent=2)+"\n")
    if any(r["exit_code"] for r in results.values()):
        sys.exit(1)

if __name__=="__main__":
    main()
