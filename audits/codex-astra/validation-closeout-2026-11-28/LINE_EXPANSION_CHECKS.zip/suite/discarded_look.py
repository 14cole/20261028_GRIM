"""Exercise the pinned discarded-look workflow, allowing intentional preflight refusal."""
import json
from pathlib import Path
import tempfile
from check_invalidated_subset import run

if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmp:
        directory=Path(tmp)
        try:
            result=run(directory)
        except (ValueError,RuntimeError) as exc:
            if not (directory/"intact.grim").is_file() or (directory/"edited_unused_look.grim").exists():
                raise
            if not any(word in str(exc).casefold() for word in ("attitude","orientat")):
                raise
            result={"edited_unused_look":{"refusal":str(exc),"edited_output_published":False,"intact_control_published":True}}
    print(json.dumps(result,indent=2))
