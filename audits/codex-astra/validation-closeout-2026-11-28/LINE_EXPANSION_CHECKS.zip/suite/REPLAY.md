# Reproduce the Line Expansion integration checks

Use a Linux GHOST/GRIM Python environment with PySide6 and pytest. The checks use the packaged native CPU kernels and small fixture geometries. Select the complete production checkout to test. FIXTURES is the unpacked directory `audits/claude-2026-11-26/astra-audit-response/line-expansion` at Claude’s pinned commit `d0b732f`. CONTROLS is the unpacked `CHECKS.zip` from `audits/codex-astra/line-expansion-fix-round3-review` at Codex commit `8be7789`. The same fixtures drive both the previous revision and the correction.

```sh
python run_suite.py "$TREE" "$FIXTURES" "$CONTROLS" results \
    --old "$SHIPPED" "$ROUND1" "$ROUND2"
python check_results.py results --compare "$CONTROLS"
```

SHIPPED, ROUND1 and ROUND2 are clean production trees at `ed90b65`, `d0a9b01` and `9635f7c`. Their public producers create fresh historical files. The candidate opens them, expands them again and runs Assembly. Workspaces and drafts are isolated for each process. The runner also executes the four historical standalone programs, checks cancellation at publication, and reopens the saved datasets to compare the added and combined complex fields. Setting `--workers 1` runs all cases serially. The numerical thresholds refer to the small independent reference fixtures.

`processes.json` stores completion codes. The summary from `check_results.py` inspects actual numerical values and exceptions inside each program’s output. One copy of the earlier excluded-look probe is called through `discarded_look.py`, which accepts a deliberate attitude refusal only if the valid control was saved and the edited result was withheld. The comparison lists path-by-path standalone output changes, including warnings or metadata affected by the proposed correction.

The first integrated run overlapped a separate 23,936-unknown Dense benchmark in a shared 16 GiB cgroup. Some ordinary small jobs correctly refused to start and several diagnostic scripts captured those errors inside their JSON. Re-run this regression suite with normal available RAM. Its numbers are correctness checks under ordinary headroom. Memory-admission limits are left at their production settings.
