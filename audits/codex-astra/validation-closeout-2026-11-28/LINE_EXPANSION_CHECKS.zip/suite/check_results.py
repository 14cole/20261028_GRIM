"""Assert release-facing outcomes, including the numerical results saved inside successful scripts."""
import argparse
import json
import re
import math
from pathlib import Path

def run(folder, compare):
    def read(name):
        return json.loads((folder/(name+".json")).read_text())
    status={}
    def check(name, condition):
        status[name]=bool(condition)
    def accurately(rows, *keys):
        return all(0. <= row.get(k,float("inf")) < 3e-13 for row in rows for k in keys)
    p=read("processes")
    check("all_subprocesses", all(r["exit_code"]==0 and not r.get("non_json_stdout") for r in p.values()))
    check("all_62_pinned_tests",p["pytest"].get("counts")==dict(tests=62,failures=0,errors=0,skipped=0))
    p=read("panel")
    check("load_assembly_panel_sections_and_bodies",all(r["validate_enabled"] and r["calculate_enabled"] for r in p.values()))
    for name in ("placed","placed-one"):
        check(name+"_intact_fields",accurately(read(name).values(),"relative_feature_error","relative_sum_error"))
    check("study_subset_offsets",accurately([read("study-subset")],"added_field_error","total_error"))
    p=read("cropped-assembly")
    check("cropped_field_and_attitude",accurately(pv:=[p["intact"],p["crop"]],"added_error","total_error") and pv[0]["planned_angles"]==pv[1]["planned_angles"])
    resampled=read("resampled")
    check("both_regrids_and_control_match",accurately(resampled.values(),"added_field_error"))
    edited=read("edited")
    check("intact_and_equivalent_seam_fields_all_match", accurately(edited.values(),"total_error","added_error","input_field_error"))
    matched=edited["sections_intact"]["direct_matching"]
    conflicting=edited["sections_intact"]["direct_conflicting"]
    check("direct_consistent_and_conflicting",accurately([matched],"total_error","added_error") and "refused" in conflicting)
    excluded=read("invalidated-subset")["edited_unused_look"]
    check("excluded_edited_row_cannot_revive_false_orientation",
          ("refusal" in excluded and not excluded["edited_output_published"]) or accurately([excluded],"added_error","total_error"))
    g=read("grid-operations")
    frame_preserving=[g[n] for n in ("intact","angular_crop","single_seam_relabel","wrap_after_seam_relabel")]
    check("frame_preserving_edits", all(accurately([v["implicit"],v["explicit"]],"sum_error") and v["recorded"]==v["assembly_plans"] for v in frame_preserving))
    def unresolved(row):
        return bool(row.get("warnings") or row.get("error")) or accurately([row],"sum_error")
    check("shifted_angle_requires_correct_attitude_or_warns", all(unresolved(g[n]["implicit"]) and accurately([g[n]["explicit"]],"sum_error") for n in ("axis_shift_via_axis_edit","axis_shift")))
    p=read("edge")
    check("publication_rollback_on_cancel_or_rename_failure",
          all(r["prior_preserved"] and not r["stage_files_after"] for k,r in p.items() if k!="normal") and p["normal"]["published_azimuths"]==[30.0])
    p=read("stages")
    check("publication_rollback_stages",all(r["existing_file_preserved"]==(r["cancel_at"]!="none") and not r["residual_staged_files"] for r in p))
    check("independent_cancel_sources",all(r["existing_output_kept"] for r in read("sources").values()))
    p=read("overlap")
    check("overlapping_cancel_and_completed_publish",p["same_process_concurrent"]["actual_output_azimuths"]==[30.0] and not p["same_process_concurrent"]["staged_filename_collision"] and not p["gui_rename_boundary"]["existing_file_preserved"])
    p=read("optional-log-unit")
    check("legacy_optional_log_units",accurately(p.values(),"field_error") and accurately([p["known"]["strict_assembly"]],"field_error") and "refused" in p["missing"]["strict_assembly"])
    p=read("metadata")
    check("stage_native_field_and_strict_modes",all(p[n]["success"] and p[n]["error"]<3e-13 for n in ("strict_assembly_known","strict_assembly_restored")))
    for label in ("released","round1","round2"):
        p=read(label)
        check("ordinary_historical_inputs_"+label,
            accurately([p[name]["stated"] for name in ("section","with-body","section-edit","with-body-edit")],"error") and
            accurately([p["with-body"]["assembly"],p["with-body"]["implicit"]],"error") and "refused" in p["with-body"]["wrong"])
    # Compare historical baseline numerical records, allowing path, UI timing or intended output to differ.
    diff={}
    if compare is not None:
        def flatten(obj):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    for path,val in flatten(v):
                        yield (k,)+path,val
            elif isinstance(obj,list):
                for i,v in enumerate(obj):
                    for path,val in flatten(v):
                        yield (str(i),)+path,val
            else:
                yield (),obj
        def norm(x):
            if isinstance(x,str):
                x=re.sub(r'/[^\s"\n]+?/(?=(?:le-|gui\.grim|section\.grim|base\.grim))','<tmp>/',x)
                x=re.sub(r'le-([\w-]+)-[^/\s]+/',r'le-\1/',x)
            return x
        for n in ("independent","gui","bor","grim","grid"):
            one=dict(flatten(json.loads((compare/(n+".json")).read_text())))
            two=dict(flatten(read(n)))
            keys=sorted(one.keys()|two.keys())
            changes=[]
            for k in keys:
                s="/".join(k)
                if "seconds" in s or "cancel_clicked_at" in s:continue
                a,b=norm(one.get(k)),norm(two.get(k))
                if isinstance(a,float) and isinstance(b,(int,float)) and math.isclose(a,b,abs_tol=1e-14,rel_tol=1e-12): continue
                if a!=b:changes.append(dict(path=s,before=a,after=b))
            diff[n]=dict(paths=len(keys),changes=changes)
        check("native_v1_v2_admission_stable",not diff["grid"]["changes"])
    return dict(checks=status,pinned_script_comparison=diff)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("results",type=Path)
    p.add_argument("--compare",type=Path)
    a=p.parse_args()
    res=run(a.results,a.compare)
    print(json.dumps(res,indent=2))
    if not all(res["checks"].values()):
        raise SystemExit(1)
