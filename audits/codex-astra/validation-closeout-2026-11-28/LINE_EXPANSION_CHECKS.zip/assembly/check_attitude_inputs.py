"""Check the assembled body/feature orientation before and after saved look edits.

Uses common.py from Claude's pinned audit and check_placed_feature.py from the
round-three Codex evidence. Set GRIM_ROOT and PYTHONPATH to the code under test.
"""
import json
from pathlib import Path
import tempfile
import numpy as np
from common import expand, write_section, reopen, rel
import check_placed_feature as case
from ghost_backend.assembly import fields, workflow
from ghost_backend.io.grim import _save_grim_npz

def rejected(operation):
    try:
        operation()
    except ValueError as exc:
        assert "attitude" in str(exc)
        return str(exc)
    raise AssertionError("An ambiguous or incompatible field was accepted")

def run(work):
    case.GRID.update(azimuths_deg=[0.,45.,120.,210.])
    section = write_section(work)
    base = work / "expanded.grim"
    expand([section],output_grim=str(base),body_grim=str(case.sphere(work)),**case.ATT)
    original, base_field = reopen(base)
    csv = work/"point.csv"
    csv.write_text("placement_id,dataset_id,x,y,z,nx,ny,nz,roll_x,roll_y,roll_z\nsite,pattern,0,0,.15,0,0,1,1,0,0\n")
    kwargs = dict(coordinate_units="meters", point_locations_csv=csv,
        point_datasets={"pattern":case.create_point_pattern(work)},point_response_settings={"pattern":{"one_sided":False}})
    out= {}
    def req(path, label, **extra):
        return workflow.FeatureAssemblyRequest(base_grim=path,output_grim=work/(label+".grim"), **kwargs, **extra)
    def modified(label, change, drop_request=False):
        p=dict(original)
        r=json.loads(str(p["line_expansion_provenance_json"]))
        change(p,r)
        p["line_expansion_provenance_json"]=np.asarray(json.dumps(r))
        if drop_request:
            p.pop("requested_radar_grid_json",None)
        path=work/(label+".grim")
        _save_grim_npz(p,str(path))
        return path
    def bad_grid(p,r):
        p["azimuths"]=np.array([0.,50.,120.,210.])
    def mark_invalid(p,r):
        r["body_attitude_invalidated_by"]="Edit radar azimuth"
    def legacy(p,r):
        r.pop("radar_grid_deg")
        r.pop("body_attitude_source")
        r.pop("body_attitude_deg")
    def assumed(p,r):
        r["body_attitude_source"]["roll_deg"]="assumed"
    for label,fn in (("stale",bad_grid),("invalidated",mark_invalid)):
        path=modified(label,fn)
        selected=dict(**case.GRID, **case.ATT)
        selected["azimuths_deg"]=[0.,120.,210.]
        out[label]=dict(plan=rejected(lambda: workflow.prepare_feature_assembly(req(path,label+"-result",study_azimuths_deg=(0.,120.,210.)))),
                        direct=rejected(lambda: fields.add_features_to_monostatic_grim(str(path),str(work/(label+"-direct.grim")),radar_grid=selected,declared_coherent_base=True)),
                        request_survived="requested_radar_grid_json" in reopen(path)[0])
        assert not (work/(label+"-direct.grim")).exists()
        # A valid-looking stale BoR request must not beat a genuinely changed look.
        from ghost_backend.assembly.expand_wing_sections import _declared_attitude
        assert _declared_attitude(reopen(path)[0])==({},{},True)
    path=modified("assumed",assumed,drop_request=True)
    plan=workflow.prepare_feature_assembly(req(path,"assumed-output"))
    result=workflow.execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
    p,x=reopen(result)
    out["assumed"]=dict(warning=next(w for w in plan.validation_warnings if "assum" in w and "Line Expansion" in w),
                        source=fields.recorded_line_expansion_attitude(p)[1]["roll_deg"],error=rel(x-base_field,case.point_reference(case.ATT)))
    assert out["assumed"]["error"]<1e-12
    out["equivalent_direct_deg"]={}
    grid=dict(plan.radar_grid,roll_deg=case.ATT["roll_deg"]+360.,axis_az_deg=case.ATT["axis_az_deg"]-360.)
    for key in ("all","no_roll"):
        if key=="no_roll":
            del grid["roll_deg"]
        direct=fields.add_features_to_monostatic_grim(str(path), str(work/(key+".grim")),radar_grid=grid,points=plan.point_placements,declared_coherent_base=True)
        err=rel(reopen(direct)[1]-base_field,case.point_reference(case.ATT))
        assert err<1e-12
        out["equivalent_direct_deg"][key]=err
    path=modified("legacy",legacy)
    plan=workflow.prepare_feature_assembly(req(path,"legacy-output"))
    result=workflow.execute_feature_assembly(plan,acknowledged_plan_sha256=plan.prepared_plan_sha256)
    p,x=reopen(result)
    out["legacy"]=dict(planned={k:plan.radar_grid[k] for k in case.ATT},
            warning=next(w for w in plan.validation_warnings if "older Line Expansion file" in w),
            output_warning=any("older Line Expansion file" in w for w in json.loads(str(p["metadata_advisories_json"]))),
            feature_error=rel(x-base_field,case.point_reference(case.ATT)))
    assert out["legacy"]["feature_error"]<1e-12 and out["legacy"]["output_warning"]
    return out

if __name__=="__main__":
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
