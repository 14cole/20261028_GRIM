# Independent checks of f2f08b5

Use a clean checkout or export of shipped main `ed90b65ff89826274adacae01bcfbafe143e9819` for the solver. Get the audit directory `audits/claude-2026-11-26/ghost-backend-audit` at Claude's `f2f08b5fe0e087c5a56871bdda3f29f466112518`. The earlier comparison inputs are in `audits/codex-astra/ghost-backend-review-620fb9e/CHECKS.zip` at `98cbd3a700ac81d62a86fb14ce66556a1ae6d971`. Extract this archive to another directory and run the following there. The solver timings and memory counters below are Linux measurements. The archived metadata identifies CPU, software, cgroup limits and BLAS.

```sh
export GRIM_ROOT=/path/to/ed90b65
export AUDIT=/path/to/f2f08b5/ghost-backend-audit
export PYTHONPATH="$AUDIT"
sha256sum -c SHA256SUMS
python "$AUDIT/summarize.py" "$AUDIT/results" > /tmp/ghost-summary-f2f08b5.json
cmp /tmp/ghost-summary-f2f08b5.json "$AUDIT/results/summary.json"
OPENBLAS_NUM_THREADS=1 python verification/check_fields.py "$AUDIT/results" --epyc /path/to/previous-checks/timing/cylinder
OPENBLAS_NUM_THREADS=1 python verification/check_dense_plans.py "$AUDIT"
python replay/disk/compare_storage.py replay/disk --archive "$AUDIT"
python replay/check_compressed.py replay "$AUDIT"
```

The first two commands after the checksum rebuild the summary with Claude's revised script. check_fields.py independently recomputes timings, checks every archived complex timing field in both polarizations against a separately implemented annular cylinder reference and checks every matched pair. Use the optional EPYC argument to include the prior 5,984-unknown AMD runs. check_dense_plans.py stops the public solver before matrix allocation after capturing the actual TE pairing decision under the recorded historical RAM budget. Only the planner executes in those probes.

## Repeat the full 11,968-unknown solves

Run each command to completion in its own process. Supply four CPU IDs usable on your machine in place of 1-4. Start in a directory with sufficient free scratch space for one 2.134 GiB temporary file and with the GHOST dependencies and native shared libraries installed. The outputs below use a fresh directory so the archived evidence remains available for comparison. GHOST_MAX_SOLVE_GB applies only to the third process and uses the solver’s GiB budget. This cap suppresses the optional partner matrix while preserving in-memory residuals for this particular fixture.

```sh
mkdir -p rerun/disk/unpaired rerun/compressed
taskset -c 1-4 python replay/disk/run_storage.py memory --output rerun/disk
taskset -c 1-4 python replay/disk/run_storage.py disk --output rerun/disk
GHOST_MAX_SOLVE_GB=6 taskset -c 1-4 python replay/disk/run_storage.py memory --output rerun/disk/unpaired
taskset -c 1-4 python "$AUDIT/timed_job.py" 4224 compressed 360 4 rerun/compressed/fields.npz > rerun/compressed/run.json
python replay/disk/compare_storage.py rerun/disk --archive "$AUDIT"
python replay/check_compressed.py rerun "$AUDIT"
```

The scratch file holds the original coefficients used to compute residuals. All three Dense configurations use double-precision LU in RAM. The portable numerical evidence is in the NPZs. Linux elapsed time, RSS, effective backend, solve plans, per-factor events, stage timings and process I/O counters are in the JSON outputs. Linux process RSS measures resident pages, while cgroup file-cache accounting includes kernel cache and other processes in the cgroup. Stage timers can overlap. The two archived CSV files sample the disk and separate-assembly memory runs. Sampling on the disk run began after launch. For another such trace, run replay/disk/sample_cgroup.py with the active worker PID and its cgroup v2 directory from a separate process.
