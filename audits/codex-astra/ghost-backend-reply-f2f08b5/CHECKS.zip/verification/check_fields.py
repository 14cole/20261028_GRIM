"""Recalculate both hosts' timing and field checks from Claude's f2f08b5 results directory."""
import argparse
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
from statistics import median

import numpy as np
from scipy.special import hankel2, h2vp, jv, jvp, yv, yvp

POLARIZATIONS = ("TM", "TE")
A_BATCHES = ("c", "c_part2", "c_part3")
B_BATCHES = ("c_threads2", "c_drift")


@lru_cache(maxsize=None)
def reference(angular_count, pol):
    """Annular scatterer, using a Bessel combination satisfying the PEC surface at r=0.10 m."""
    k = 2 * np.pi * 10e9 / 299792458
    eps, mu = 2.8 - .06j, 1.
    m = np.sqrt(eps * mu)
    n = np.arange(91)
    inner, outer = k * m * .100, k * m * .120
    if pol == "TM":
        p, q, gradient = jv(n, inner), yv(n, inner), m / mu
    else:
        p, q, gradient = jvp(n, inner), yvp(n, inner), m / eps
    shell = q * jv(n, outer) - p * yv(n, outer)
    flux = gradient * (q * jvp(n, outer) - p * yvp(n, outer))
    x = k * .120
    scattering = (jv(n, x) * flux - jvp(n, x) * shell) / (h2vp(n, x) * shell - hankel2(n, x) * flux)
    amplitude = -4j * np.sum(scattering * (-1)**n * np.where(n == 0, 1, 2))
    directions = np.arange(angular_count) * (2 * np.pi / angular_count)
    return amplitude * np.exp(2j * k * (.031 * np.cos(directions) - .017 * np.sin(directions)))


def details(left, right):
    difference = abs(left - right)
    return float(difference.max() / np.max(abs(right))), int(np.argmax(difference))


def read_runs(root):
    for batch in (*A_BATCHES, *B_BATCHES):
        for line in (root / batch / "runs.jsonl").read_text().splitlines():
            row = json.loads(line)
            assert row["returncode"] == 0
            yield ("A" if batch in A_BATCHES else "B"), batch, row, root / batch / (row["tag"] + ".npz")
    for batch, host, names in (("c_large", "A", ("dense", "compressed")), ("c_residual", "B", ("memory", "disk"))):
        for name in names:
            row = json.loads((root / batch / (name + ".out")).read_text())
            matches = list((root / batch).glob(f"*_{name}.npz"))
            assert len(matches) == 1
            yield host, batch, row, matches[0]


def calculate(root, epyc=None):
    records = []
    groups = defaultdict(list)
    seen = set()
    archived_ref_delta = 0.
    max_logged_error_difference = 0.
    for host, batch, row, path in read_runs(root):
        assert path not in seen and row["quality_passed"] and np.isfinite(row["residual_max"])
        seen.add(path)
        sample = dict(host=host, batch=batch, name=str(path.relative_to(root)), n=row["unknowns_per_system"],
                      threads=row["threads"], angles=row["angles"], backend=row["requested"],
                      seconds=row["solve_wall_s"], rss=row["peak_rss_gib"],
                      mode=row.get("residual_storage_requested", "auto") if batch == "c_residual" else "auto")
        with np.load(path, allow_pickle=False) as arrays:
            theta = arrays["angles_deg"]
            assert np.array_equal(theta, np.arange(sample["angles"]) * (360. / sample["angles"]))
            sample["field"] = {}
            sample["errors"] = {}
            for pol in POLARIZATIONS:
                numerical = arrays["ghost_" + pol]
                assert numerical.shape == theta.shape and np.isfinite(numerical).all()
                sample["field"][pol] = numerical
                exact = reference(len(theta), pol)
                error = details(numerical, exact)[0]
                sample["errors"][pol] = error
                archived_ref_delta = max(archived_ref_delta, details(arrays["analytic_" + pol], exact)[0])
                max_logged_error_difference = max(max_logged_error_difference, abs(row["error_" + pol] - error))
        records.append(sample)
        groups[host,sample["n"],sample["threads"],sample["angles"],sample["backend"],sample["mode"]].append(sample)
    assert seen == set(root.glob("c*/*.npz"))
    grouped = {}
    for key, values in sorted(groups.items()):
        times = [v["seconds"] for v in values]
        rss = [v["rss"] for v in values]
        grouped[key] = dict(host=key[0], n=key[1], threads=key[2], angles=key[3], backend=key[4], mode=key[5],
                            seconds=times, median_s=median(times), rss_gib=rss, median_rss_gib=median(rss))
    cross_host = []
    for (host,n,t,a,b,m), data in grouped.items():
        key = ("A",n,t,a,b,m)
        if host == "B" and key in grouped:
            prior = grouped[key]
            cross_host.append(dict(n=n,threads=t,angles=a,backend=b,
                A_s=prior["median_s"], B_s=data["median_s"], A_gib=prior["median_rss_gib"], B_gib=data["median_rss_gib"],
                B_s_relative_to_A=data["median_s"]/prior["median_s"]-1,
                B_peak_relative_to_A=data["median_rss_gib"]/prior["median_rss_gib"]-1))
    worst = {}
    compared = defaultdict(int)
    for left, right in combinations(records, 2):
        if any(left[k] != right[k] for k in ("n", "angles")):
            continue
        backend_diff = left["backend"] != right["backend"]
        tag = ("same_backend_all_pairs" if not backend_diff else "both_backends_all_pairs")
        tags = [tag]
        if not backend_diff:
            if left["host"] != right["host"]:
                tags.append("cross_host")
                if left["threads"] == right["threads"]:
                    tags.append("cross_host_same_threads")
            if left["host"] == right["host"] and left["threads"] != right["threads"]:
                tags.append("within_host_threads")
            if left["host"] == right["host"] and left["threads"] == right["threads"]:
                if left["mode"] == right["mode"]:
                    tags.append("repeat")
                elif left["batch"] == right["batch"] == "c_residual":
                    tags.append("forced_storage")
        elif left["threads"] == right["threads"] and left["host"] == right["host"] == "B":
            tags.append("host_B_backend_same_threads")
        for pol in POLARIZATIONS:
            # Symmetric bound, normalizing to the smaller of the two arrays' peak amplitudes.
            left_field, right_field = left["field"][pol], right["field"][pol]
            diff = abs(left_field - right_field)
            worst_index = int(np.argmax(diff))
            peak = float(diff[worst_index] / min(max(abs(left_field)),max(abs(right_field))))
            for label in tags:
                compared[label] += 1
                if label not in worst or worst[label]["peak_normalized"] < peak:
                    worst[label] = dict(peak_normalized=peak, polarization=pol, angle_deg=worst_index*(360./left["angles"]),
                                        left=left["name"], right=right["name"])
    new_errors = {n:max(max(r["errors"].values()) for r in records if r["host"] == "B" and r["n"] == n)
                  for n in sorted({r["n"] for r in records if r["host"] == "B"})}
    epyc_comparison = []
    if epyc is not None:
        for line in (epyc / "runs.jsonl").read_text().splitlines():
            row = json.loads(line)
            assert row["returncode"] == 0 and row["quality_passed"]
            key = ("B", row["unknowns_per_system"], row["threads"], row["angles"], row["requested"], "auto")
            host_b = groups[key][0]
            with np.load(epyc / (row["tag"] + ".npz"), allow_pickle=False) as arrays:
                assert np.array_equal(arrays["angles_deg"], np.arange(360.))
                errors = {pol:details(arrays["ghost_" + pol], host_b["field"][pol])[0] for pol in POLARIZATIONS}
            epyc_comparison.append(dict(epyc=row["tag"], host_B=host_b["name"], peak_relative_by_polarization=errors))
    return dict(archives=len(seen),host_B_count=sum(r["host"] == "B" for r in records),
                max_stored_vs_independent_analytic=archived_ref_delta,max_logged_error_difference=max_logged_error_difference,
                max_analytic_discretization_error_host_B=new_errors,filtered_pair_counts=dict(compared),maxima=worst,
                drift=cross_host, epyc_same_configuration=epyc_comparison, host_B_groups=[g for g in grouped.values() if g["host"] == "B"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--epyc", type=Path, help="Optional timing/cylinder directory from Codex 98cbd3a CHECKS.zip")
    args = parser.parse_args()
    print(json.dumps(calculate(args.results, args.epyc), indent=2))
