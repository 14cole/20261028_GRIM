"""Replay three audit configurations up to the first TE/TM pairing decision.

GRIM_ROOT points to the ed90b65 checkout. Pass the pinned f2f08b5 audit folder.
Only the recorded RAM capacity and sufficient disk availability are supplied
externally. The public solver builds the full geometry and chooses its plan.
No dense matrix, scratch file or factor is allocated in this probe.
"""
import argparse
import json
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np


class PlanReached(Exception):
    pass


def collect(audit):
    sys.path.insert(0, str(audit))
    from harness import cylinder_geo, solve_fixed
    from ghost_backend.execution import dense_memory
    from ghost_backend.twod import solver
    from ghost_backend.twod.assembly import session

    original_pairing = session.plan_paired_assembly
    results = []
    for log in ("c_residual/memory.out", "c_residual/disk.out", "c_large/dense.out"):
        row = json.loads((audit / "results" / log).read_text())
        capacity = row["memory_accounting"]["cohort_capacity_gib"]
        geometry = cylinder_geo(a=.10, b=.12, eps=2.8-.06j, mu=1.,
                                center=(.031, -.017), sides=row["outer_sides"])

        def capture(pol, formulation, dofs, estimated_gib, limit_gib):
            paired = original_pairing(pol, formulation, dofs, estimated_gib, limit_gib)
            plan = dense_memory.current(dofs)
            assert (pol, formulation, dofs) == ("TE", "multi_region", row["unknowns_per_system"])
            assert plan is not None and paired == plan["paired_assembly"]
            keys = ("assembly_tile", "memory_recovery", "residual_storage", "residual_storage_requested",
                    "matrix_bytes", "temporary_disk_bytes", "partner_matrix_bytes", "paired_assembly",
                    "angle_batch_size", "peak_bytes")
            results.append(dict(source_log=log, cohort_gib=capacity, polarization=pol, formulation=formulation,
                                dofs=dofs, **{k:plan[k] for k in keys}))
            raise PlanReached

        try:
            with patch.object(solver, "_solve_memory_limit_gb", return_value=capacity), \
                 patch.object(dense_memory, "scratch_available", return_value=(True, None)), \
                 patch.object(session, "plan_paired_assembly", side_effect=capture):
                solve_fixed(geometry, row["ghz"], np.arange(row["angles"]), "dense",
                            threads=row["threads"], **row.get("extra_options", {}))
        except PlanReached:
            pass

    assert len(results) == 3
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audit", type=Path)
    print(json.dumps(collect(parser.parse_args().audit.resolve()), indent=2))
