"""Check the fresh Compressed run against all three Dense runs and Claude's Intel archives."""
import argparse
import json
from pathlib import Path

import numpy as np


def fields(path):
    with np.load(path, allow_pickle=False) as z:
        np.testing.assert_array_equal(z["angles_deg"], np.arange(360.))
        found = {p: z["ghost_" + p] for p in ("TE", "TM")}
        assert all(f.shape == (360,) and np.isfinite(f).all() for f in found.values())
        return found


def difference(got, reference):
    delta = got - reference
    return {
        "max_over_reference_peak": float(np.max(abs(delta)) / np.max(abs(reference))),
        "relative_l2": float(np.linalg.norm(delta) / np.linalg.norm(reference)),
        "worst_angle_deg": int(np.argmax(abs(delta))),
    }


def compare(local, intel):
    path = local / "compressed"
    row = json.loads((path / "run.json").read_text())
    assert row["quality_passed"] and row["panels"] == 7744 and row["unknowns_per_system"] == 11968
    assert row["angles"] == 360 and row["ghz"] == 10 and row["linear_backend"] == "cpu_hmatrix"
    got = fields(path / "fields.npz")
    refs = {
        "paired_dense": local / "disk" / "memory.npz",
        "unpaired_dense": local / "disk" / "unpaired" / "memory.npz",
        "disk_dense": local / "disk" / "disk.npz",
        "xeon_b_compressed": intel / "results/c_drift/s4224_a360_t4_f10_compressed_r0.npz",
    }
    result = {}
    for name, p in refs.items():
        ref = fields(p)
        result[name] = {pol: difference(got[pol], field) for pol, field in ref.items()}
    with np.load(path / "fields.npz", allow_pickle=False) as z:
        result["analytical"] = {pol: difference(got[pol], z["analytic_" + pol]) for pol in got}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("local", type=Path, help="replay directory in CHECKS.zip")
    parser.add_argument("intel", type=Path, help="Claude's pinned ghost-backend-audit folder")
    opts = parser.parse_args()
    print(json.dumps(compare(opts.local, opts.intel), indent=2))
