"""Time one Dense solve with a specified residual store in a fresh process.

Set GRIM_ROOT to shipped ed90b65 and PYTHONPATH to Claude's ghost-backend-audit.
Run python run_storage.py memory, followed by python run_storage.py disk.
The original fixture is built outside the timer. Field export is after it.
"""
import argparse
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("storage", choices=["memory", "disk"])
parser.add_argument("--output", type=Path, default=Path("."))
args = parser.parse_args()
for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS"):
    os.environ[variable] = "4"

import numpy as np
import scipy
from harness import cylinder_geo, fields_of, solve_fixed
from reference import stored_amplitude


def read_optional(path):
    p = Path(path)
    return p.read_text().strip() if p.is_file() else None


def counters():
    io_path = Path("/proc/self/io")
    usage = resource.getrusage(resource.RUSAGE_SELF)
    return dict(process_io={k: int(v) for k, v in
                             (line.split(":") for line in io_path.read_text().splitlines())},
                cpu_user=usage.ru_utime, cpu_system=usage.ru_stime,
                major_faults=usage.ru_majflt, minor_faults=usage.ru_minflt,
                peak_rss_bytes=usage.ru_maxrss * 1024,
                cgroup_memory_events=read_optional("/sys/fs/cgroup/memory.events"),
                cgroup_memory_stat=read_optional("/sys/fs/cgroup/memory.stat"),
                cgroup_cpu_stat=read_optional("/sys/fs/cgroup/cpu.stat"))


def metrics(field, exact):
    return dict(normalized_peak=float(np.max(abs(field-exact))/np.max(abs(exact))),
                relative_l2=float(np.linalg.norm(field-exact)/np.linalg.norm(exact)))


fixture = dict(a=0.100, b=0.120, eps=2.8-0.06j, mu=1.0, center=(0.031, -0.017))
angles = np.arange(360, dtype=float)
text = cylinder_geo(sides=4224, **fixture)
environment = dict(cpu=next(l.split(":")[1].strip() for l in Path("/proc/cpuinfo").read_text().splitlines()
                            if l.startswith("model name")),
                   affinity=sorted(os.sched_getaffinity(0)),
                   cpu_max=read_optional("/sys/fs/cgroup/cpu.max"),
                   memory_max=read_optional("/sys/fs/cgroup/memory.max"),
                   memory_current_start=read_optional("/sys/fs/cgroup/memory.current"),
                   explicit_environment={k: v for k, v in os.environ.items() if k.startswith("GHOST_")},
                   kernel=platform.release(), python=platform.python_version(),
                   numpy=np.__version__, scipy=scipy.__version__,
                   numpy_blas=np.__config__.CONFIG["Build Dependencies"]["blas"],
                   scipy_blas=scipy.__config__.CONFIG["Build Dependencies"]["blas"],
                   scratch_free_bytes=shutil.disk_usage(tempfile.gettempdir()).free)
before = counters()
result, wall = solve_fixed(text, 10., angles, "dense", threads=4,
                           dense_residual_storage=args.storage)
after = counters()
fields = fields_of(result)
exact = {pol: stored_amplitude(pol, 10., angles, **fixture) for pol in fields}
meta = result["metadata"]
row = dict(storage=args.storage, elapsed_s=wall, before=before, after=after,
           environment=environment, field_errors={p: metrics(f, exact[p]) for p, f in fields.items()},
           backend=meta["linear_backend"], panels=meta["panel_count"],
           dofs=meta["dense_largest_system"], residual_max=meta["residual_norm_max"],
           quality_passed=meta["quality_gate"]["passed"], method=meta["solver_method"],
           runtime_profile=meta["runtime_profile"], factor_details=meta["experimental_cpu"],
           memory_accounting=meta["memory_accounting"], warnings=meta.get("warnings"))
assert row["quality_passed"] and row["dofs"] == 11968 and row["panels"] == 7744
assert len(fields) == 2 and all(len(f) == len(angles) for f in fields.values())
args.output.mkdir(parents=True, exist_ok=True)
out = args.output / args.storage
np.savez_compressed(out.with_suffix(".npz"), angles_deg=angles, ghost_TM=fields["TM"], ghost_TE=fields["TE"],
                    analytic_TM=exact["TM"], analytic_TE=exact["TE"])
out.with_suffix(".json").write_text(json.dumps(row, indent=2, default=str) + "\n")
print(args.storage, round(wall, 4), after["peak_rss_bytes"] / 2**30, row["residual_max"], flush=True)
