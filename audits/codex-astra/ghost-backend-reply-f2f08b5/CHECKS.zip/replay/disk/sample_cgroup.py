"""Sample a Linux child worker's RSS and cgroup v2 accounting once a second.

Pass the worker PID. Use the cgroup-v2 root as mounted in this run. Cgroup
values include other processes in that cgroup, and file memory includes cache.
"""
import argparse
import csv
from pathlib import Path
import sys
import time


def counters(source):
    return {k.rstrip(":"): int(v.split()[0]) for k, v in
            (line.split(None, 1) for line in source.read_text().splitlines())}


def sample(pid, root):
    proc = Path("/proc") / str(pid)
    while proc.is_dir():
        try:
            status = proc.joinpath("status").read_text().splitlines()
            rss = int(next(v.split()[1] for v in status if v.startswith("VmRSS:"))) * 1024
            try:
                io = counters(proc / "io")
            except PermissionError:
                io = {}
            stats = counters(root / "memory.stat")
            yield {"monotonic": time.monotonic(), "process_rss_bytes": rss,
                   **{k: io.get(k) for k in ("rchar","wchar","read_bytes","write_bytes","cancelled_write_bytes")},
                   "cgroup_current": int((root / "memory.current").read_text()),
                   **{f"cgroup_{k}": stats[k] for k in ("anon", "file", "file_dirty", "file_writeback",
                                                        "pgscan", "pgsteal", "workingset_refault_file")}}
        except (FileNotFoundError, ProcessLookupError, StopIteration):
            break
        time.sleep(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("--cgroup", type=Path, default=Path("/sys/fs/cgroup"))
    args = parser.parse_args()
    writer = None
    for row in sample(args.pid, args.cgroup):
        if writer is None:
            writer = csv.DictWriter(sys.stdout, fieldnames=list(row))
            writer.writeheader()
        writer.writerow(row)
        sys.stdout.flush()
