"""Summarize the three local storage controls. Optionally compare Claude's fields."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np


def read_case(root, stem):
    with np.load(root / (stem + ".npz"), allow_pickle=False) as z:
        np.testing.assert_array_equal(z["angles_deg"], np.arange(360.))
        fields = {p: z["ghost_" + p] for p in ("TE", "TM")}
        assert all(f.shape == (360,) and np.isfinite(f).all() for f in fields.values())
    return fields


def compare(current, ref):
    return {p: dict(absolute_peak=float(max(abs(v - ref[p]))),
                    normalized_peak=float(max(abs(v - ref[p])) / max(abs(ref[p]))),
                    relative_l2=float(np.linalg.norm(v - ref[p]) / np.linalg.norm(ref[p])),
                    identical=np.array_equal(v, ref[p]))
            for p, v in current.items()}


def local_case(root, name):
    data = json.loads((root / (name + ".json")).read_text())
    plans = [r for r in data["factor_details"]["memory_estimates"] if r.get("model") == "dense_phase_v1"]
    plan_keys = ("paired_assembly", "partner_matrix_bytes", "angle_batch_size", "assembly_tile", "memory_recovery",
                 "residual_storage", "temporary_disk_bytes", "peak_bytes", "capacity_bytes")
    stages = data["runtime_profile"]
    before, after = data["before"], data["after"]
    assert data["quality_passed"] and data["dofs"] == 11968
    stages_wanted = ["operators","factorization","linear_solve","rhs_solve","far_field","condition_scaling"]
    return dict(elapsed_s=data["elapsed_s"], peak_rss_gib=after["peak_rss_bytes"] / 2**30,
                residual_max=data["residual_max"], quality=data["quality_passed"],
                cpu_user_s=after["cpu_user"]-before["cpu_user"],cpu_sys_s=after["cpu_system"]-before["cpu_system"],
                plans=[{k:p[k] for k in plan_keys} for p in plans],
                stages_s={k:stages["stage_seconds"].get(k) for k in stages_wanted},
                stage_calls=stages["stage_calls"], stages_semantics=stages["stage_semantics"],
                proc_io_delta={k:after["process_io"][k]-v for k,v in before["process_io"].items()},
                major_faults=after["major_faults"]-before["major_faults"])


def summarize(root, archive):
    names = {"paired_memory": "memory", "disk": "disk", "unpaired_memory": "unpaired/memory"}
    jobs = {k: local_case(root, v) for k,v in names.items()}
    fields = {k: read_case(root, v) for k, v in names.items()}
    result = dict(cases=jobs, versus_paired_memory={k: compare(v, fields["paired_memory"]) for k, v in fields.items()})
    result["disk_versus_unpaired_memory"] = compare(fields["disk"], fields["unpaired_memory"])
    if archive:
        result["versus_claude_memory"] = {
            k: compare(v, read_case(archive / "results" / "c_residual", "s4224_a360_t4_dense_memory"))
            for k,v in fields.items()}
    result["relative_costs"] = {}
    for case, base in (("disk","paired_memory"), ("disk", "unpaired_memory"), ("unpaired_memory","paired_memory")):
        result["relative_costs"][f"{case}_relative_to_{base}"] = {
            k+"_delta_pct":100*(jobs[case][k]/jobs[base][k]-1) for k in ("elapsed_s","peak_rss_gib")}
    result["sampled_cgroup"] = {}
    for key, path in (("disk", root / "disk-cgroup.csv"), ("unpaired_memory", root / "unpaired-cgroup.csv")):
        if path.is_file():
            rows=list(csv.DictReader(path.open()))
            if rows:
                result["sampled_cgroup"][key]={"count":len(rows),
                    **{k+"_max_gib":max(int(r[k]) for r in rows) / 2**30 for k in
                       ("cgroup_current","cgroup_file","cgroup_anon","cgroup_file_dirty","cgroup_file_writeback")},
                    **{k+"_delta":int(rows[-1][k])-int(rows[0][k]) for k in
                       ("cgroup_pgscan","cgroup_pgsteal","cgroup_workingset_refault_file")}}
    return result


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory", type=Path, nargs="?", default=Path("."))
    p.add_argument("--archive", type=Path)
    args=p.parse_args()
    print(json.dumps(summarize(args.directory, args.archive),indent=2))
