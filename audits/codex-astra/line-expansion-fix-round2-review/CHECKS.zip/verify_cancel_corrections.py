"""Exercise the proposed two local corrections in memory. No checkout is edited."""
import inspect
import json
from ghost_backend.assembly import expand_wing_sections as wing
from check_cancel_edges import run

source = inspect.getsource(wing.expand_wing_sections)
changes = [
    ('getattr(cancel_check, "__self__", None) is event for event in events',
     'cancel_check == event.is_set for event in events'),
    ('if not publication_gate.close_unless(canceled):\n                check_cancel()',
     'if not publication_gate.close_unless(canceled):\n'
     '                raise InterruptedError("Line expansion canceled; existing output kept.")'),
]
for original,revised in changes:
    assert source.count(original)==1
    source=source.replace(original,revised)
exec(compile(source,wing.__file__,'exec'),wing.__dict__)
data={case:run(case) for case in ('bound_sibling_callback','wrapped_sibling_callback',
        'consume_once_with_gate','consume_once_without_gate','latched_with_gate','rename_failure','normal')}
assert all(v['prior_preserved'] and not v['stage_files_after'] for c,v in data.items() if c!='normal')
assert data['normal']['outcome']=='saved'
print(json.dumps(data,indent=2))
