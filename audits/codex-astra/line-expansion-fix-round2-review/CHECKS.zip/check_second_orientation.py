"""Change the point-check geometry orientation and grid, then test the plan's role."""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import check_placed_feature as case
from ghost_backend.assembly import workflow

def run():
    case.ATT.update(axis_az_deg=-35.0, axis_el_deg=23.0, roll_deg=42.0)
    case.GRID.update(azimuths_deg=[30.0, 105.0, 285.0, 345.0], elevations_deg=[-20.0, 12.0])
    with tempfile.TemporaryDirectory() as work:
        baseline = case.run(Path(work))
    # Diagnostic only. Set external planning defaults to the known orientation.
    # Publishing such constants would break unrelated inputs.
    with patch.multiple(workflow, AXIS_AZ_DEG=-35.0, AXIS_EL_DEG=23.0, ROLL_DEG=42.0):
        with tempfile.TemporaryDirectory() as work:
            changed = case.run(Path(work))
    return {"before": baseline, "forced_external_attitude_rotated_control": changed["sections_rotated"]}

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
