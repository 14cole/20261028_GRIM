# Reproducing the review

Extract into a scratch directory and use the repository’s GHOST/GRIM numerical environment with Qt and pytest. Point CANDIDATE and ROUND_ONE at complete checkouts of the named revisions. The helper directory must stay at its normal depth in the candidate checkout for common.py to import successfully. Run the following from the extracted directory.

```bash
sha256sum -c SHA256SUMS
export CANDIDATE=/path/to/9635f7c
export ROUND_ONE=/path/to/d0a9b01
export RELEASED=/path/to/ed90b65
export CLAUDE_TESTS="$CANDIDATE/audits/claude-2026-11-26/astra-audit-response/line-expansion"
export GRIM_ROOT="$CANDIDATE"
export PYTHONPATH="$GRIM_ROOT:$GRIM_ROOT/tools/GHOST:$CLAUDE_TESTS"
export QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
mkdir -p replay
python -m pytest -q "$CLAUDE_TESTS/test_line_expansion_regressions.py"
python "$CLAUDE_TESTS/independent_checks.py" replay/independent.json
python "$CLAUDE_TESTS/gui_checks.py" replay/gui.json
python "$CLAUDE_TESTS/bor_base_check.py" replay/bor.json
python check_assembly_panel.py > replay/panel.json
python check_placed_feature.py > replay/placed.json
python check_placed_feature.py --one-sided > replay/placed-default.json
python check_second_orientation.py > replay/second-orientation.json
python check_attitude_roundtrip.py > replay/edge.json
python grid_admission.py > replay/grid-admission.json
python check_cancel_edges.py > replay/edge-candidate.json
python verify_cancel_corrections.py > replay/trial-corrections.json
```

The panel script instantiates the actual GRIM panel with the GHOST workflow service. It sets the input, selected mesh and units when applicable, and output. Check the classifier decision and both button states. The placed-feature script runs public preview, preparation and execution, reopens the output, subtracts the original base, and checks the addend against an analytic point field. Its default test uses a two-sided point. The one-sided switch exercises the application’s default response setting. The second-orientation script changes the angle and grid and then overrides three process-local planning constants for the rotated diagnostic control only. The cancellation trial also runs in memory. Neither trial edits repository files.

For the A/B tests, keep CLAUDE_TESTS at the candidate. Set GRIM_ROOT to ROUND_ONE, update PYTHONPATH as above, and run pytest, check_placed_feature.py and check_cancel_edges.py again. Set GRIM_ROOT to RELEASED to repeat check_assembly_panel.py and check_placed_feature.py on main.

The archived axes.json, imports.json, grid-large.json and the three r2cancel/r2publication JSON results use the unchanged first-round Codex scripts. Those scripts are in audits/codex-astra/line-expansion-fix-review/CHECKS.zip within the candidate checkout. Its REPLAY.md gives their command-line options. The updated grid_admission.py in this archive checks the expected passing behavior for round two.

Run your own orientation and geometry first, then compare the reopened arrays, warnings, metadata, GUI readiness and prior destination bytes. Several scripts record exceptions in JSON to preserve the successful controls alongside a failing case. A successful process exit alone does not establish that every tested behavior passed. Timestamps, temporary paths and timings can vary.
