"""Run in a GHOST environment against GRIM_ROOT, then inspect the emitted comparisons."""
import json
import os
from pathlib import Path
import sys
import tempfile
import numpy as np
root=Path(os.environ['GRIM_ROOT']).resolve()
sys.path[0:0]=[str(root),str(root/'tools/GHOST')]
from GRIM_Backend.datasets.grid import RcsGrid
from ghost_backend.assembly.expand_wing_sections import expand_wing_sections
from ghost_backend.assembly.fields import radar_grid_aspects
from ghost_backend.bor import dispatch
from ghost_backend.geometry.io import parse_geometry,build_geometry_snapshot
from ghost_backend.io.solver_export import export_solver_result
from ghost_backend.data_tools.cem_tools.native_samples import decode_native_samples,raw_amplitude

att=dict(axis_az_deg=20.,axis_el_deg=-10.,roll_deg=15.)
grid=dict(azimuths_deg=[0.,45.,120.,210.],elevations_deg=[15.,35.],frequencies_ghz=[1.])
settings=dict(coordinate_units='meters',geometry_units='meters',section_angle_step_deg=2.0,shadow=False)
def geometry(points,name):
    return f'Title: {name}\nSegment: {name}\nproperties: 2 -24 0 0 0\n'+'\n'.join(' '.join(map(str,(*a,*b))) for a,b in zip(points,points[1:]))+'\nIBCS_Resistances:\nDielectrics:\n'
def data(path):
    with np.load(path,allow_pickle=False) as archive:
        stored=decode_native_samples({k:archive[k] for k in archive.files})
        return stored,np.asarray(raw_amplitude(stored))
def compare(x,y):
    return float(np.max(abs(x-y))/np.max(abs(y)))
def run(work):
    t=np.linspace(0,np.pi,49)
    pts=np.column_stack((.15*np.sin(t),.15*np.cos(t)))
    pts[0,0]=pts[-1,0]=0
    snap=build_geometry_snapshot(*parse_geometry(geometry(pts,'sphere')))
    aspects=radar_grid_aspects(grid['azimuths_deg'],grid['elevations_deg'],att['axis_az_deg'],att['axis_el_deg'])
    result=dispatch.solve_monostatic_rcs_bor(snap,[1.],list(aspects),geometry_units='meters',workers=1)
    base=export_solver_result(result,str(work/'sphere.grim'),context=dict(solver_kind='bor',snapshot=snap,units='meters',radar_grid=dict(**grid,**att)))[0]
    wedge=work/'wedge.geo'
    wedge.write_text(geometry([[-.060,0],[.040,.025],[.060,0],[.020,-.012],[-.060,0]],'wedge'))
    start,tip=np.array([.02,-.05,.01]),np.array([.31,.09,.12]); normal=np.array([-.2,.1,1.]);span=tip-start
    normal-=span*(normal @ span)/(span @ span)
    sections=[dict(geometry=str(wedge),root=start,tip=tip,normal=normal/np.linalg.norm(normal))]
    standalone=work/'wedge.grim'
    expand_wing_sections(sections,output_grim=str(standalone),**settings,**att,**grid)
    expected=data(base)[1]+data(standalone)[1]
    loaded=RcsGrid.load(base)
    subsets={
        'intact':(base,[0,1,2,3]),
    }
    for label,dataset,indices in (
            ('axis_edit_seam',loaded.edit_axis_value('azimuth',0,360.),[1,2,3,0]),
            ('axis_crop_one_look',loaded.axis_crop(azimuths=[0.,45.,120.]),[0,1,2])):
        path=str(work/(label+'.grim'))
        dataset.save(path)
        subsets[label]=(path,indices)
    findings={}
    for label,(source,indices) in subsets.items():
        p,f=data(source)
        record=dict(field_unchanged_error=compare(f,data(base)[1][indices]),
                    axes=p['azimuths'].tolist(),request='requested_radar_grid_json' in p,
                    bor_model=all(k in p for k in ['body_model_aspects_deg','body_profile_rho_m','body_profile_z_m']))
        for mode,spec in [('implicit',{}),('explicit',att)]:
            target=work/f'{label}-{mode}.grim'
            try:
                answer=expand_wing_sections(sections,output_grim=str(target),body_grim=str(source),**settings,**spec)
                q,field=data(target)
                record[mode]=dict(relative_error=compare(field,expected[indices]),warnings=answer['warnings'])
            except ValueError as e:
                record[mode]=dict(refused=str(e))
        findings[label]=record
    return findings
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as directory:
        print(json.dumps(run(Path(directory)),indent=2))
