# Replaying the Line Expansion review

Use a Linux GHOST numerical environment with PySide6 and pytest. The fresh runs used x86-64, Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and PySide6 6.12.0. Unpack this archive in a scratch directory. Use separate checkouts of the candidate and main. The audit helper directory always comes from the pinned candidate, including when testing main.

Set these variables to absolute paths on your machine. Run the commands from the unpacked directory.

```bash
export GRIM_ROOT=/path/to/d0a9b01
export CLAUDE_TESTS="$GRIM_ROOT/audits/claude-2026-11-26/astra-audit-response/line-expansion"
export PYTHONPATH="$GRIM_ROOT:$GRIM_ROOT/tools/GHOST:$CLAUDE_TESTS"
export QT_QPA_PLATFORM=offscreen OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
sha256sum -c SHA256SUMS
mkdir -p replay/tmp
export TMPDIR="$PWD/replay/tmp"
python -m pytest -q "$CLAUDE_TESTS/test_line_expansion_regressions.py"
python "$CLAUDE_TESTS/independent_checks.py" replay/independent.json
python "$CLAUDE_TESTS/gui_checks.py" replay/gui.json
python "$CLAUDE_TESTS/bor_base_check.py" replay/bor.json
python check_bor_assembly.py "$TMPDIR"/le-bor-*/shadow_on.grim "$PWD/replay/bor-assembly.grim" > replay/bor-assembly.json
python check_assembly_consumer.py > replay/assembly-fixed.json
python check_grim_axis_edit.py > replay/axis-candidate.json
python check_imports.py > replay/imports-fixed.json
python grid_import_review.py > replay/grid_import_result.json
python probe_grid_preflight.py --require-refusal > replay/grid-control.json
python cancel_publication.py --output replay/cancel_existing.json
python cancel_sources.py > replay/cancel-sources-fixed.json
python publication_overlap.py > replay/publication-fixed.json
```

Use an empty temporary directory for the BoR test so the glob selects its single exported file. To check differences from main, keep CLAUDE_TESTS pinned to the candidate. Replace GRIM_ROOT and PYTHONPATH as follows.

```bash
export GRIM_ROOT=/path/to/ed90b65
export PYTHONPATH="$GRIM_ROOT:$GRIM_ROOT/tools/GHOST:$CLAUDE_TESTS"
python check_assembly_consumer.py > replay/assembly-main.json
python check_grim_axis_edit.py > replay/axis-main.json
python check_imports.py > replay/imports-main.json
python cancel_sources.py > replay/cancel-sources-main.json
python publication_overlap.py > replay/publication-main.json
```

The comparison scripts record exceptions and field errors in JSON so a failing example can be reviewed alongside its working control. A zero process exit code alone does not establish that a behavior passes. Build a separate fixture and compute the expected fields before comparing the saved reference data. Temporary filenames and timing will vary.

- `check_assembly_consumer.py` makes a sections-only file, then performs real Assembly preview, preparation and execution with and without a supplied STL. `check_bor_assembly.py` performs the same workflow on Claude’s actual shadowed BoR export.
- `check_grim_axis_edit.py` uses the production exporter and GRIM’s axis edit, crop, load and save operations. It compares the reopened body samples after permutation and the expanded fields against the section solved at the known orientation. `check_imports.py` separately tests the convention round trip, equivalent angles, and removal of precisely one optional member.
- `grid_import_review.py` scales only test ceilings and observes the members read by NumPy. The positive import and equivalent user-entered grid are controls. `probe_grid_preflight.py` uses the production ceilings and stops at the first attempted meshgrid with a process address-space cap as a backstop.
- `cancel_sources.py` combines supported cancellation inputs. `cancel_publication.py` checks worker signals in three states. `publication_overlap.py` uses barriers to force the two-job interleaving and the GUI click at the rename boundary. The solve, write, rename and reopen are real. The schedules establish reachability, not ordinary incidence.
