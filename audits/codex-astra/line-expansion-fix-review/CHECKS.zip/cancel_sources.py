"""Check the existing section_solver_kwargs abort event and new top-level event together with a callback."""
import inspect
import json
import tempfile
import threading
from pathlib import Path
from unittest.mock import patch
from ghost_backend.assembly.expand_wing_sections import expand_wing_sections
from ghost_backend.io import grim

def run(directory, mode):
    shape = directory/'square.geo'
    shape.write_text('Title: square\nSegment: shape 2\nproperties: 2 -24 0 0 0\n-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')
    out = directory/'result.grim'
    prior = b'old'
    out.write_bytes(prior)
    event = threading.Event()
    req=dict(sections=[dict(geometry=str(shape),root=(0,0,0),tip=(.25,0,0),normal=(0,0,1))],
             output_grim=str(out),coordinate_units='meters',geometry_units='meters',
             frequencies_ghz=[1.0],elevations_deg=[0.],azimuths_deg=[30.],section_angle_step_deg=5.)
    if mode.startswith('legacy'):
        event.set()
        req['section_solver_kwargs']={'abort_event':event}
    else:
        req['abort_event']=event
    if mode.endswith('callback'):
        req['cancel_check']=lambda:False
    save=grim._save_grim_npz
    def saving(payload,*args,**kwargs):
        path=save(payload,*args,**kwargs)
        if 'line_expansion_provenance_json' in payload and not mode.startswith('legacy'):
            event.set()
        return path
    with patch.object(grim,'_save_grim_npz',saving):
        try:
            expand_wing_sections(**req)
        except Exception as exc:
            result=type(exc).__name__+': '+str(exc)
        else:
            result='success'
    return dict(result=result,event_set=event.is_set(),existing_output_kept=out.read_bytes()==prior)

if __name__=='__main__':
    modes=['legacy_event_only','legacy_event_with_separate_callback']
    if 'abort_event' in inspect.signature(expand_wing_sections).parameters:
        modes+=['top_event_only','top_event_with_separate_callback']
    with tempfile.TemporaryDirectory() as tmp:
        print(json.dumps({mode:run(Path(tmp),mode) for mode in modes},indent=2))
