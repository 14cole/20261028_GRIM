"""Reach two publication boundaries using real requests in a temporary directory.

Set PYTHONPATH to the tested tools/GHOST directory. The barriers only schedule
worker interleaving. Section solves, staging, file replacement and reading all run.
"""
import argparse
import json
import inspect
import os
from pathlib import Path
import tempfile
import threading
import time
from unittest.mock import patch

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from ghost_backend.assembly.expand_wing_sections import expand_wing_sections
from ghost_backend.io import grim
from ghost_backend.ui.line_expansion import LineExpansionTab

SQUARE = ('Title: square\nSegment: shape 2\nproperties: 2 -24 0 0 0\n'
          '-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')

def settings(root):
    path=root/'square.geo'; path.write_text(SQUARE)
    return dict(sections=[dict(geometry=str(path),root=(0,0,0),tip=(.25,0,0),normal=(0,0,1))],
                coordinate_units='meters',geometry_units='meters',frequencies_ghz=[1.0],
                elevations_deg=[0.],section_angle_step_deg=10.,shadow=False)

def same_destination(root):
    """A succeeds; B is canceled before commit; only A's field should survive."""
    inputs=settings(root);out=root/'shared.grim'
    out.write_bytes(b'previous result')
    staged={name:threading.Event() for name in ('A','B')}
    release={name:threading.Event() for name in staged}
    cancel={name:threading.Event() for name in staged}
    paths={}; results={}
    writer=grim._save_grim_npz
    def synchronized_save(payload,path,*args,**kwargs):
        value=writer(payload,path,*args,**kwargs)
        if 'line_expansion_provenance_json' in payload:
            name=threading.current_thread().name
            paths[name]=Path(path).name
            staged[name].set();assert release[name].wait(60)
        return value
    def work(name, az):
        try:
            request_cancel = {'cancel_check': cancel[name].is_set}
            if 'abort_event' in inspect.signature(expand_wing_sections).parameters:
                request_cancel['abort_event'] = cancel[name]
            expand_wing_sections(**inputs,output_grim=str(out),azimuths_deg=[az],**request_cancel)
        except Exception as exc:
            results[name]=type(exc).__name__+': '+str(exc)
        else:
            results[name]='success'
    a=threading.Thread(target=work,args=('A',30),name='A')
    b=threading.Thread(target=work,args=('B',60),name='B')
    with patch.object(grim,'_save_grim_npz',synchronized_save):
        try:
            a.start();assert staged['A'].wait(30)
            b.start();assert staged['B'].wait(30)
            cancel['B'].set()
            release['A'].set();a.join(30);assert not a.is_alive()
            release['B'].set();b.join(30);assert not b.is_alive()
        finally:
            release['A'].set();release['B'].set()
    with np.load(out,allow_pickle=False) as z: az=z['azimuths'].tolist()
    return dict(result=results,requests={'A':30,'B':60},actual_output_azimuths=az,
                expected_output_azimuths=[30.],staged_filename_collision=paths['A']==paths['B'])

def cancel_at_rename(root):
    """Click the actual tab's Cancel button after the final poll, before rename."""
    app=QApplication.instance() or QApplication([])
    section=settings(root)['sections'][0]
    target=root/'gui.grim';prior=b'previous result';target.write_bytes(prior)
    tab=LineExpansionTab()
    tab.coordinate_units.setCurrentIndex(tab.coordinate_units.findData('meters'))
    tab.geometry_units.setCurrentIndex(tab.geometry_units.findData('meters'))
    tab._append_row([section['geometry'],*map(str,section['root']),*map(str,section['tip']),
                     *map(str,section['normal']),'','',''])
    tab.angle_step.setValue(10)
    for k,v in dict(frequencies_ghz='1',azimuths_deg='30',elevations_deg='0').items():
        tab.grid_fields[k].setText(v)
    tab.output_edit.setText(str(target));tab.show();app.processEvents()
    real_replace=os.replace
    gate=threading.Event();resume=threading.Event()
    def scheduled_replace(src,dst,*args,**kwargs):
        if Path(dst)==target:
            gate.set();assert resume.wait(30)
        return real_replace(src,dst,*args,**kwargs)
    with patch.object(os,'replace',scheduled_replace):
        tab.run_button.click();deadline=time.monotonic()+30
        try:
            while not gate.is_set() and time.monotonic()<deadline:
                app.processEvents();time.sleep(.002)
            assert gate.is_set() and target.read_bytes()==prior
            enabled=tab.cancel_button.isEnabled()
            QTest.mouseClick(tab.cancel_button,Qt.MouseButton.LeftButton)
            requested=tab._abort_event.is_set()
            status_before=tab.status_label.text()
        finally:
            resume.set()
        while tab.job_is_running() and time.monotonic()<deadline:
            app.processEvents();time.sleep(.002)
        app.processEvents();assert not tab.job_is_running()
    status_after=tab.status_label.text()
    tab.close();app.processEvents()
    return dict(click_enabled=enabled,request_event_set=requested,pre_rename_status=status_before,
                final_status=status_after,existing_file_preserved=target.read_bytes()==prior)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--require-isolation',action='store_true')
    args=parser.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp)
        data=dict(same_process_concurrent=same_destination(root),gui_rename_boundary=cancel_at_rename(root))
    print(json.dumps(data,indent=2))
    if args.require_isolation:
        assert data['same_process_concurrent']['actual_output_azimuths']==[30.]
