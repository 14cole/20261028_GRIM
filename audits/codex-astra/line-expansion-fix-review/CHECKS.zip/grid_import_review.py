"""Audit Line Expansion admission ordering with tiny genuine GRIM files.
Use the tested repository's tools/GHOST on PYTHONPATH. All inputs and outputs
are in a new temporary directory. Thresholds are scaled down only for the
instrumented cases so the test never builds a large multidimensional array.
"""
import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
from ghost_backend.assembly import expand_wing_sections as wing
from ghost_backend.ui.line_expansion import parse_samples


def request(section, output, **values):
    return wing.expand_wing_sections([section], output_grim=str(output), coordinate_units="meters",
                                      geometry_units="meters", section_angle_step_deg=10., shadow=False, **values)


def trace(section, path, out, *, from_file, cap):
    reads = []
    observed = []
    with np.load(path) as handle:
        cls = type(handle)
    original = cls.__getitem__
    def record(self, member):
        value = original(self, member)
        reads.append((member, value.nbytes))
        return value
    gate = wing._check_grid_size
    def check(*args):
        observed.append({"count": len(reads), "reads": list(reads)})
        return gate(*args)
    out.write_bytes(b'previous')
    arguments = {"body_grim": str(path)} if from_file else dict(
        azimuths_deg=[10.,20.,30.], elevations_deg=[0.,45.], frequencies_ghz=[1.])
    with patch.object(cls, "__getitem__", record), patch.object(wing, "MAX_LOOKS",cap), patch.object(wing, "_check_grid_size",check):
        try:
            request(section, out, **arguments)
            result = "completed"
        except ValueError as exc:
            result = str(exc)
    before = observed[0]["reads"]
    return dict(result=result, members_before_gate=len(before),
                sample_members_before_gate=[m for m in before if m[0] in ('rcs_complex','rcs_amp_real','rcs_amp_imag','rcs_power','rcs_phase')],
                old_output_preserved=out.read_bytes()==b'previous')


def run(root):
    source=root/'square.geo'
    source.write_text('Title: square\nSegment: section 2\nproperties: 2 -24 0 0 0\n'
                      '-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')
    section=dict(root=(0,0,0),tip=(.25,0,0),normal=(0,0,1),geometry=str(source))
    base=root/'base.grim'
    request(section, base, azimuths_deg=[10.,20.,30.], elevations_deg=[0.,45.], frequencies_ghz=[1.])
    native=trace(section,base,root/'out.grim',from_file=True,cap=5)
    standalone=trace(section,base,root/'out2.grim',from_file=False,cap=5)
    ok=trace(section,base,root/'out3.grim',from_file=True,cap=6)
    assert 'too large' in native['result'] and native['old_output_preserved']
    assert any(native['sample_members_before_gate'])
    assert 'too large' in standalone['result'] and not standalone['sample_members_before_gate']
    assert ok['result']=='completed'
    # Check that the fixed four-channel estimate covers every base this function admits.
    with np.load(base) as src:
        payload = {key: src[key] for key in src.files}
    native_field=payload['rcs_complex']
    payload['rcs_complex']=np.concatenate((native_field,native_field[...,2:3],native_field[...,0:1]),axis=3)
    payload['polarizations']=np.asarray(['VV','HH','VH','HV','TOTAL'])
    five=root/'five.grim'
    with five.open('wb') as handle:
        np.savez_compressed(handle, **payload)
    target=root/'five-out.grim'
    with patch.object(wing,'MAX_OUTPUT_SAMPLES',24):
        try:
            request(section,target,body_grim=str(five))
        except ValueError as exc:
            extra_pol=dict(result='refused',message=str(exc))
        else:
            with np.load(target) as saved:
                field=saved['rcs_complex']
                extra_delta=float(np.max(np.abs(field[...,4]-payload['rcs_complex'][...,4])))
                first_delta=float(np.max(np.abs(field[...,0]-payload['rcs_complex'][...,0])))
            extra_pol=dict(result='completed', actual_complex_samples=int(field.size), cap=24,
                          unrecognized_total_max_change=extra_delta, first_vv_max_change=first_delta)
    from ghost_backend.assembly import fields
    class PreflightReachedBasis(Exception):
        pass
    with patch.object(fields,'radar_frame_basis',side_effect=PreflightReachedBasis):
        try:
            request(section,root/'manyfreq.grim', frequencies_ghz=range(1,100_002),
                    azimuths_deg=[0.],elevations_deg=[0.])
        except PreflightReachedBasis:
            direct_api_axis_limit = 'accepted by preflight (stopped before any look or solve)'
        except ValueError as exc:
            direct_api_axis_limit = 'refused: '+str(exc)
    sweep = parse_samples('0:99999.9999999995:1','test')
    count = len(parse_samples('0:99999:1','test'))
    try: parse_samples('0:100000:1','test')
    except ValueError: over_rejected=True
    else: over_rejected=False
    return dict(direct_api_100001_frequencies=direct_api_axis_limit, five_channel_base=extra_pol, base_file=native, specified_axes=standalone, accepted_base_control=ok,
                exact_axis_max=count, one_over_max_rejected=over_rejected,
                fractional_stop_rounds_above_max=len(sweep), last_rounded_value=sweep[-1])


if __name__ == '__main__':
    with tempfile.TemporaryDirectory() as temp:
        print(json.dumps(run(Path(temp)),indent=2))
