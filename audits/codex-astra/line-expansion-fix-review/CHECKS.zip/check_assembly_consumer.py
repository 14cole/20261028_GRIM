"""Exercise actual preview and prepare/execute on a freshly produced Line Expansion base.
GRIM_ROOT must point to the version tested. Put Claude's line-expansion audit on PYTHONPATH.
"""
import json, sys, tempfile
from pathlib import Path
import numpy as np
from common import write_section, expand, reopen, rel
from ghost_backend.assembly.workflow import FeatureAssemblyRequest, prepare_feature_assembly, execute_feature_assembly, prepare_feature_input_preview


def record(fn):
    try:
        return dict(success=True,result=fn())
    except Exception as exc:
        return dict(success=False,error=f'{type(exc).__name__}: {exc}')


def check(path):
    path = Path(path)
    section = write_section(path)
    base = path / 'section.grim'
    expand([section], output_grim=str(base), azimuths_deg=[10.,55.], elevations_deg=[15.], frequencies_ghz=[1.])
    before, initial = reopen(base)
    mesh = path / 'mesh.stl'
    mesh.write_text('solid panel\nfacet normal 0 0 1\nouter loop\nvertex 0 0 0\nvertex 1 0 0\nvertex 0 1 0\nendloop\nendfacet\nendsolid panel\n')
    results = dict(requested_radar_grid_present='requested_radar_grid_json' in before,
                   body_profile_present='body_profile_rho_m' in before)
    for with_stl in (False, True):
        name = 'with_stl' if with_stl else 'without_stl'
        kwargs = dict(surface_mesh=mesh, surface_units='meters') if with_stl else {}
        def preview():
            view = prepare_feature_input_preview(base_grim=base, **kwargs)
            return dict(body_source=view.body_source)
        def assemble():
            request = FeatureAssemblyRequest(base_grim=base, output_grim=path/(name+'.grim'), **kwargs)
            plan = prepare_feature_assembly(request)
            finished = execute_feature_assembly(plan, acknowledged_plan_sha256=plan.prepared_plan_sha256)
            output, field = reopen(finished)
            return dict(max_relative_field_difference=rel(field,initial),samples=field.size)
        results[name] = dict(preview=record(preview), assembly=record(assemble))
    return results
with tempfile.TemporaryDirectory() as directory:
    print(json.dumps(check(directory),indent=2))
