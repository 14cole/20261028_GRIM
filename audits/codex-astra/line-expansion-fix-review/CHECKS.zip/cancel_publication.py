"""Use a real Line Expansion worker, section solver and writer, with a deterministic cancel at final save."""
import argparse
import json
import tempfile
import threading
from pathlib import Path
from unittest.mock import patch

from PySide6.QtCore import QCoreApplication
from ghost_backend.io import grim
from ghost_backend.twod import solver
from ghost_backend.ui.line_expansion import _ExpansionWorker


def check(directory, cancel_at):
    shape = directory / 'section.geo'
    shape.write_text('Title: square\nSegment: shape 2\nproperties: 2 -24 0 0 0\n'
                     '-.05 -.05 -.05 .05\n-.05 .05 .05 .05\n.05 .05 .05 -.05\n.05 -.05 -.05 -.05\n')
    out = directory / 'previous.grim'
    sentinel = b'previous output bytes'
    out.write_bytes(sentinel)
    abort = threading.Event()
    sections = [dict(geometry=str(shape), root=(0,0,0), tip=(.25,0,0), normal=(0,0,1))]
    settings = dict(output_grim=str(out), coordinate_units='meters', geometry_units='meters',
                    frequencies_ghz=[1.0], azimuths_deg=[30.,60.], elevations_deg=[0.],
                    section_angle_step_deg=10., shadow=False)
    signals, at_save, received = [], [], []
    old_save = grim._save_grim_npz
    old_solve = solver.solve_monostatic_rcs_2d_certified
    def save(payload, *args, **kwargs):
        result = old_save(payload, *args, **kwargs)
        if 'line_expansion_provenance_json' in payload:
            at_save.append(True)
            if cancel_at == 'after_stage_write':
                abort.set()
        return result
    def solve(*args, **kwargs):
        received.append(kwargs.get('abort_event') is abort)
        return old_solve(*args, **kwargs)
    worker = _ExpansionWorker(sections, settings, abort)
    worker.finished.connect(lambda _: signals.append('finished'))
    worker.canceled.connect(lambda _: signals.append('canceled'))
    worker.error.connect(lambda error: signals.append('error: '+error))
    if cancel_at == 'before_work':
        abort.set()
    with patch.object(grim, '_save_grim_npz', save), patch.object(solver, 'solve_monostatic_rcs_2d_certified', solve):
        worker.run()
    return dict(cancel_at=cancel_at, event_set=abort.is_set(), signals=signals,
                at_final_save=bool(at_save), passed_event_to_section_solver=received,
                existing_file_preserved=out.read_bytes()==sentinel,
                residual_staged_files=[p.name for p in directory.glob('*.tmp.*')])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    app = QCoreApplication([])
    with tempfile.TemporaryDirectory() as tmp:
        results = [check(Path(tmp), case) for case in ('before_work','none','after_stage_write')]
    print(json.dumps(results,indent=2))
    args.output.write_text(json.dumps(results,indent=2)+'\n')
    assert results[0]['signals']==['canceled'] and results[0]['existing_file_preserved']
    assert results[1]['signals']==['finished'] and results[1]['at_final_save']
    assert results[2]['event_set'] and results[2]['at_final_save']
