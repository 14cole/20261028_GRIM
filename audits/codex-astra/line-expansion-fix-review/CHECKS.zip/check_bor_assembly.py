"""Run a real Assembly plan on Claude's shadow_on.grim from the real BoR check.
GRIM_ROOT points to the source, PYTHONPATH includes the directory with common.py.
"""
import json,sys
from pathlib import Path
import numpy as np
from common import reopen, rel
from ghost_backend.assembly.workflow import FeatureAssemblyRequest,prepare_feature_assembly,execute_feature_assembly,prepare_feature_input_preview
base=Path(sys.argv[1])
result=Path(sys.argv[2])
preview=prepare_feature_input_preview(base_grim=base)
plan=prepare_feature_assembly(FeatureAssemblyRequest(base_grim=base,output_grim=result))
written=execute_feature_assembly(plan, acknowledged_plan_sha256=plan.prepared_plan_sha256)
bp,b=reopen(str(base))
p,actual=reopen(written)
print(json.dumps(dict(preview=preview.body_source, n=actual.size, error=rel(actual,b), shadowed_section_field_nonzero=bool(np.max(np.abs(b))>0), line_provenance_preserved='line_expansion_provenance_json' in p),indent=2))
