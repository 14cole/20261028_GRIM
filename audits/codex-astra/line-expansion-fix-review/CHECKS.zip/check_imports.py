"""Run with GRIM_ROOT at the candidate and PYTHONPATH including Claude's audit/line-expansion directory."""
import json
import tempfile
from pathlib import Path
import numpy as np
from common import expand, write_section, reopen, rel, scalar
from ghost_backend.assembly.fields import load_body_requested_radar_grid
from ghost_backend.io.grim import _save_grim_npz
from ghost_backend.bor import dispatch
from ghost_backend.geometry.io import parse_geometry, build_geometry_snapshot
from ghost_backend.io.solver_export import export_solver_result
from ghost_backend.assembly.fields import radar_grid_aspects

ATT = dict(axis_az_deg=20.,axis_el_deg=-10.,roll_deg=15.)
GRID = dict(frequencies_ghz=[1.],azimuths_deg=[5.,45.,120.,210.],elevations_deg=[15.,35.])

def sphere(tmp):
    t = np.linspace(0,np.pi,49)
    pts = np.column_stack((.15*np.sin(t),.15*np.cos(t)))
    pts[0,0]=pts[-1,0]=0
    geo = 'Title: sphere\nSegment: sphere 2\nproperties: 2 1 0 0 0\n'+'\n'.join(
        ' '.join(map(str,(*a,*b))) for a,b in zip(pts,pts[1:]))+'\nIBCS_Resistances:\nDielectrics:\n'
    g=parse_geometry(geo)
    snap=build_geometry_snapshot(*g) if isinstance(g,tuple) else build_geometry_snapshot(g)
    aspects=sorted(set(np.asarray(radar_grid_aspects(GRID['azimuths_deg'],GRID['elevations_deg'],ATT['axis_az_deg'],ATT['axis_el_deg'])).ravel()))
    res=dispatch.solve_monostatic_rcs_bor(snap,[1.],aspects,geometry_units='meters',workers=1)
    return Path(export_solver_result(res,str(tmp/'sphere.grim'),context=dict(solver_kind='bor',snapshot=snap,units='meters',radar_grid=dict(**GRID,**ATT)))[0])

def run(folder):
    section=write_section(folder)
    out={}
    def compute(tag, base=None, **att):
        path=folder/(tag+'.grim')
        resp=expand([section],output_grim=str(path),**(dict(body_grim=str(base)) if base else GRID),**att)
        return path,*reopen(path),resp['warnings']
    ref,base,ref_field,_=compute('section',**ATT)
    def report(tag,path,expected,**att):
        try:
            dest,payload,field,warnings=compute(tag,path,**att)
            result=dict(error=rel(field,expected),warnings=warnings,domain=scalar(payload,'complex_field_domain'),
                        assumptions=scalar(payload,'metadata_advisories_json'),
                        attitude={k:(load_body_requested_radar_grid(dest) or {}).get(k) for k in ATT})
        except (TypeError,ValueError,KeyError) as exc:
            dest=None;result=dict(refused=str(exc))
        out[tag]=result
        return dest
    # A phase-and-power GRIM made using the repository's own writer, on the canonical grid.
    power_phase={k:v for k,v in base.items() if k not in ('rcs_amp_real','rcs_amp_imag','complex_field_domain','raw_complex_amplitude_preserved')}
    power_phase.update(rcs_power=4*np.pi*abs(ref_field)**2, rcs_phase=np.angle(ref_field))
    old=Path(_save_grim_npz(power_phase,str(folder/'power-phase.grim'),format_version=1))
    with np.load(old,allow_pickle=False) as data:
        out['power_phase_input']=dict(keys=data.files,domain=scalar(data,'complex_field_domain'))
    out1=report('power_phase_first',old,2*ref_field,**ATT)
    if out1:report('power_phase_second',out1,3*ref_field,**ATT)
    report('full_attitude_control',ref,2*ref_field,**ATT)
    report('equivalent_plus_360',ref,2*ref_field,**{**ATT,'axis_az_deg':ATT['axis_az_deg']+360})
    bor=sphere(folder)
    _,bf=reopen(bor)
    report('bor_intact',bor,bf+ref_field,**ATT)
    # Same actual BoR field and profile, with the optional request removed to match a legacy file.
    with np.load(bor,allow_pickle=False) as z: stripped={k:z[k] for k in z.files if k!='requested_radar_grid_json'}
    missing=folder/'bor-no-request.grim'
    with missing.open('wb') as h: np.savez_compressed(h,**stripped)
    out['synthesized_angle']= {k:load_body_requested_radar_grid(missing)[k] for k in ATT}
    report('bor_no_request_implicit',missing,bf+ref_field)
    report('bor_no_request_explicit',missing,bf+ref_field,**ATT)
    return out
if __name__=='__main__':
    with tempfile.TemporaryDirectory() as work:
        print(json.dumps(run(Path(work)),indent=2))
